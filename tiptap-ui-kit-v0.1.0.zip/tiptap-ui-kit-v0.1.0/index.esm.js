import { ref, computed, defineComponent, createBlock, openBlock, unref, withCtx, createElementVNode, normalizeClass, renderSlot, createCommentVNode, resolveDynamicComponent, reactive, readonly, createElementBlock, normalizeStyle, onBeforeUnmount, resolveComponent, createVNode, toDisplayString, Fragment, renderList, withModifiers, watch, withDirectives, vModelText, createTextVNode, withKeys, nextTick, createApp, h, Transition, onMounted, onUnmounted, render as render$1, Teleport, shallowRef, createSlots } from "vue";
import { nodeViewProps, NodeViewWrapper, VueNodeViewRenderer, Editor, EditorContent } from "@tiptap/vue-3";
import { Tooltip, Popover, message, Input, Button, notification, Modal, Select, Switch } from "ant-design-vue";
import { DownOutlined, RightOutlined, StopOutlined, BoldOutlined, ItalicOutlined, UnderlineOutlined, StrikethroughOutlined, CodeOutlined, UnorderedListOutlined, OrderedListOutlined, CheckSquareOutlined, FontSizeOutlined, AlignLeftOutlined, AlignCenterOutlined, AlignRightOutlined, MenuOutlined, UploadOutlined, LinkOutlined, PictureOutlined, InboxOutlined, ClearOutlined, InsertRowAboveOutlined, InsertRowBelowOutlined, DeleteRowOutlined, InsertRowLeftOutlined, InsertRowRightOutlined, DeleteColumnOutlined, MergeCellsOutlined, SplitCellsOutlined, TableOutlined, DeleteOutlined, SortDescendingOutlined, SortAscendingOutlined, UndoOutlined, RedoOutlined, FormatPainterOutlined, LoadingOutlined, ArrowDownOutlined, ThunderboltOutlined, EditOutlined, FileTextOutlined, BulbOutlined, TranslationOutlined, CheckCircleOutlined, CloseCircleOutlined, ApiOutlined, FontColorsOutlined, HighlightOutlined, EyeOutlined, HolderOutlined, ScissorOutlined, CopyOutlined, MenuUnfoldOutlined, MenuFoldOutlined } from "@ant-design/icons-vue";
import Image from "@tiptap/extension-image";
import { Extension, Mark, mergeAttributes, Node, InputRule } from "@tiptap/core";
import { BubbleMenu } from "@tiptap/vue-3/menus";
import { CellSelection } from "@tiptap/pm/tables";
import { TableCell, Table } from "@tiptap/extension-table";
import { Plugin, NodeSelection, PluginKey } from "@tiptap/pm/state";
import { Decoration, DecorationSet } from "@tiptap/pm/view";
import StarterKit from "@tiptap/starter-kit";
import { Placeholder } from "@tiptap/extension-placeholder";
import { TextAlign } from "@tiptap/extension-text-align";
import { Underline } from "@tiptap/extension-underline";
import { Color } from "@tiptap/extension-color";
import { TextStyle } from "@tiptap/extension-text-style";
import { Highlight } from "@tiptap/extension-highlight";
import { Link } from "@tiptap/extension-link";
import { TableRow } from "@tiptap/extension-table-row";
import { TableCell as TableCell$1 } from "@tiptap/extension-table-cell";
import { TableHeader } from "@tiptap/extension-table-header";
import { TaskList } from "@tiptap/extension-task-list";
import { TaskItem } from "@tiptap/extension-task-item";
import { FontFamily } from "@tiptap/extension-font-family";
import { Subscript } from "@tiptap/extension-subscript";
import { Superscript } from "@tiptap/extension-superscript";
import { CharacterCount } from "@tiptap/extension-character-count";
const A4_WIDTH_PX = 794;
const A4_HEIGHT_PX = 1123;
const PAGE_PADDING_TOP_PX = 96;
const PAGE_PADDING_BOTTOM_PX = 96;
const PAGE_CONTENT_HEIGHT_PX = A4_HEIGHT_PX - PAGE_PADDING_TOP_PX - PAGE_PADDING_BOTTOM_PX;
const zhCN = {
  toolbar: {
    // 文本格式
    bold: "粗体",
    italic: "斜体",
    underline: "下划线",
    strikethrough: "删除线",
    code: "代码",
    subscript: "下标",
    superscript: "上标",
    // 清除格式
    clear: "清除",
    clearFormat: "清除格式",
    formatPainter: "格式刷",
    // 标题
    heading: "标题",
    heading1: "标题 1",
    heading2: "标题 2",
    heading3: "标题 3",
    heading4: "标题 4",
    heading5: "标题 5",
    heading6: "标题 6",
    paragraph: "正文",
    // 字体
    fontFamily: "字体",
    fontSize: "字号",
    lineHeight: "行距",
    // 颜色
    textColor: "文字颜色",
    backgroundColor: "背景颜色",
    highlightColor: "高亮颜色",
    // 列表
    bulletList: "无序列表",
    orderedList: "有序列表",
    taskList: "任务列表",
    indent: "增加缩进",
    outdent: "减少缩进",
    // 对齐
    alignLeft: "左对齐",
    alignCenter: "居中对齐",
    alignRight: "右对齐",
    alignJustify: "两端对齐",
    // 插入
    insertLink: "插入链接",
    insertImage: "插入图片",
    insertTable: "插入表格",
    insertCodeBlock: "插入代码块",
    insertHorizontalRule: "插入分隔线",
    // 链接
    link: "链接",
    linkUrl: "链接地址",
    linkText: "链接文本",
    openLink: "打开链接",
    editLink: "编辑链接",
    removeLink: "移除链接",
    // 撤销重做
    undo: "撤销",
    redo: "重做",
    undoDisabledInCollab: "协作模式下不可用",
    redoDisabledInCollab: "协作模式下不可用",
    // 更多
    more: "更多"
  },
  table: {
    insertTable: "插入表格",
    deleteTable: "删除表格",
    addColumnBefore: "在左侧插入列",
    addColumnAfter: "在右侧插入列",
    deleteColumn: "删除列",
    addRowBefore: "在上方插入行",
    addRowAfter: "在下方插入行",
    deleteRow: "删除行",
    mergeCells: "合并单元格",
    splitCell: "拆分单元格",
    toggleHeaderCell: "切换表头单元格",
    toggleHeaderColumn: "切换表头列",
    toggleHeaderRow: "切换表头行",
    setCellAttribute: "设置单元格属性",
    fixTables: "修复表格"
  },
  bubbleMenu: {
    turnInto: "转换为",
    textStyle: "文本样式",
    color: "颜色"
  },
  dragMenu: {
    delete: "删除",
    duplicate: "复制",
    copy: "拷贝",
    cut: "剪切",
    moveUp: "上移",
    moveDown: "下移"
  },
  codeBlock: {
    language: "语言",
    selectLanguage: "选择语言"
  },
  stats: {
    characters: "字符",
    words: "词",
    pages: "页",
    zoom: "缩放",
    reset: "重置",
    total: "共"
  },
  placeholder: {
    default: "请输入内容...",
    heading: "标题",
    paragraph: "正文"
  },
  messages: {
    imageUploadFailed: "图片上传失败",
    imageUploadSuccess: "图片上传成功",
    invalidImageFormat: "不支持的图片格式",
    imageTooLarge: "图片大小超过限制",
    networkError: "网络错误，请稍后重试",
    pasteCleanedUp: "已清理粘贴内容的格式",
    linkRequired: "请输入链接地址",
    linkInvalid: "链接地址无效",
    // AI 功能错误消息
    translationFailed: "翻译失败",
    polishFailed: "润色失败",
    summarizeFailed: "总结失败",
    continueWritingFailed: "续写失败",
    customAiFailed: "自定义 AI 失败"
  },
  editor: {
    // 标题快捷方式
    h1: "标题 1",
    h2: "标题 2",
    h3: "标题 3",
    h4: "标题 4",
    h5: "标题 5",
    h6: "标题 6",
    paragraph: "正文",
    heading: "标题",
    heading1: "标题 1",
    heading2: "标题 2",
    heading3: "标题 3",
    heading4: "标题 4",
    heading5: "标题 5",
    heading6: "标题 6",
    // 文本格式
    bold: "粗体",
    italic: "斜体",
    underline: "下划线",
    strike: "删除线",
    inlineCode: "代码",
    superscript: "上标",
    subscript: "下标",
    // 列表
    bulletList: "无序列表",
    orderedList: "有序列表",
    taskList: "任务列表",
    // 对齐
    align: "对齐",
    alignLeft: "左对齐",
    alignCenter: "居中对齐",
    alignRight: "右对齐",
    alignJustify: "两端对齐",
    // 缩进
    indent: "增加缩进",
    outdent: "减少缩进",
    indentAndAlign: "缩进和对齐",
    // 颜色
    colors: "颜色",
    text: "文字",
    highlight: "高亮",
    textColor: "文字颜色",
    backgroundColor: "背景颜色",
    defaultColors: "默认颜色",
    standardColors: "标准色",
    showAdvanced: "高级选择器",
    hideAdvanced: "收起",
    clearColor: "清空颜色",
    // 操作
    actions: "操作",
    cut: "剪切",
    copy: "拷贝",
    delete: "删除",
    // 基础操作
    undo: "撤销",
    redo: "重做",
    undoDisabledInCollab: "协作模式下不可用",
    redoDisabledInCollab: "协作模式下不可用",
    clearFormat: "清除格式",
    formatPainter: "格式刷",
    // 字体
    font: "字体",
    fontSize: "字号",
    lineHeight: "行距",
    // 插入
    insertLink: "插入链接",
    insertImage: "插入图片",
    insertTable: "插入表格",
    image: "图片",
    link: "链接",
    editLink: "编辑链接",
    openLink: "打开链接",
    removeLink: "移除链接",
    linkPlaceholder: "请输入链接地址",
    imagePlaceholder: "请输入图片地址",
    // 表格
    deleteTable: "删除表格",
    includeHeader: "包含表头",
    // 上传
    localUpload: "本地上传",
    localUploadImage: "本地上传图片",
    webUpload: "网络上传",
    clickOrDragUpload: "点击或拖拽文件到此区域上传",
    onlySupportImage: "仅支持图片格式",
    // 更多
    more: "更多",
    aiTool: "AI 工具",
    ai: "AI",
    // 格式刷相关
    pleaseSelectTextToSample: "请先选择要采样的文本",
    pleaseSelectTextToSampleShort: "请先选择文本",
    pleaseSelectTextToSampleDouble: "请先双击选择要采样的文本",
    sampleSuccessSingle: "格式采样成功，点击目标文本应用格式",
    sampleSuccessContinuous: "格式采样成功，可连续点击多个目标文本应用格式",
    formatPainterExited: "已退出格式刷模式",
    collaborationNoFormatPainter: "协作模式下不支持格式刷功能",
    // 链接相关
    enterValidLink: "请输入有效的链接地址",
    // 数学公式
    math: "数学公式",
    mathInline: "行内公式",
    mathBlock: "块级公式",
    mathPlaceholder: "输入 LaTeX 公式...",
    mathEmpty: "点击编辑公式",
    // AI 相关
    continueWriting: "继续写作",
    polish: "润色文本",
    summarize: "总结内容",
    translate: "翻译",
    translateTo: "翻译为 {lang}",
    customAi: "自定义 AI",
    selectLanguage: "选择语言",
    // AI 建议相关
    aiSuggestion: "AI 建议",
    aiContinueWriting: "AI 续写：",
    originalText: "原文：",
    suggestedText: "建议：",
    generatedContent: "生成内容：",
    generating: "正在生成...",
    selectedContent: "选中内容：",
    currentStatus: "当前状态",
    noTextSelected: "未选中文本，AI 内容将插入到光标位置",
    // AI 功能提示信息
    pleaseSelectText: "请先选中文字",
    continueWritingRequiresSelection: "续写功能需要先选中要续写的文字",
    polishRequiresSelection: "润色功能需要先选中要润色的文字",
    summarizeRequiresSelection: "总结功能需要先选中要总结的文字",
    translateRequiresSelection: "翻译功能需要先选中要翻译的文字",
    customAiRequiresSelection: "自定义AI功能需要先选中要处理的文字",
    aiPrompt: "AI 指令",
    aiPromptPlaceholder: "请输入 AI 指令，例如：优化这段文字、翻译成英文...",
    customAiCommand: "自定义 AI 指令",
    customAiPromptPlaceholder: "请输入你的 AI 指令，例如：请帮我优化这段文字、请翻译成英文、请总结要点等",
    execute: "执行",
    cancel: "取消",
    reject: "拒绝",
    accept: "接受",
    // 语言代码
    lang: {
      "zh-CN": "简体中文",
      "zh-TW": "繁体中文",
      zh: "中文",
      en: "英语",
      ja: "日语",
      th: "泰语",
      fr: "法语",
      es: "西班牙语",
      pt: "葡萄牙语",
      ko: "韩语",
      vi: "越南语",
      ru: "俄语",
      de: "德语",
      hi: "印地语",
      id: "印尼语",
      ar: "阿拉伯语"
    }
  },
  versionHistory: {
    title: "版本历史",
    saveVersion: "保存版本",
    noVersions: "暂无历史版本",
    autoSave: "自动保存",
    words: "字",
    justNow: "刚刚",
    minutesAgo: "分钟前",
    hoursAgo: "小时前",
    daysAgo: "天前",
    restore: "恢复此版本",
    compare: "对比",
    rename: "重命名",
    delete: "删除",
    comparing: "正在对比",
    clearCompare: "取消对比",
    versionName: "版本名称",
    saved: "版本已保存",
    restored: "版本已恢复",
    deleted: "版本已删除",
    noDiff: "内容相同"
  },
  aiSettings: {
    title: "AI 设置",
    provider: "AI 提供商",
    apiKeyPlaceholder: "请输入 API Key",
    apiKeyHint: "API Key 仅保存在本地浏览器中，不会上传到服务器",
    endpoint: "API 端点",
    model: "模型",
    enableAi: "启用 AI 功能",
    testConnection: "测试连接",
    testing: "测试中...",
    testSuccess: "连接成功",
    testFailed: "连接失败",
    viewDocs: "查看文档",
    save: "保存",
    cancel: "取消",
    clear: "清除配置"
  }
};
const zhTW = {
  toolbar: {
    // 文本格式
    bold: "粗體",
    italic: "斜體",
    underline: "底線",
    strikethrough: "刪除線",
    code: "程式碼",
    subscript: "下標",
    superscript: "上標",
    // 清除格式
    clear: "清除",
    clearFormat: "清除格式",
    formatPainter: "格式刷",
    // 標題
    heading: "標題",
    heading1: "標題 1",
    heading2: "標題 2",
    heading3: "標題 3",
    heading4: "標題 4",
    heading5: "標題 5",
    heading6: "標題 6",
    paragraph: "正文",
    // 字體
    fontFamily: "字體",
    fontSize: "字號",
    lineHeight: "行距",
    // 顏色
    textColor: "文字顏色",
    backgroundColor: "背景顏色",
    highlightColor: "高亮顏色",
    // 列表
    bulletList: "項目符號清單",
    orderedList: "編號清單",
    taskList: "工作清單",
    indent: "增加縮排",
    outdent: "減少縮排",
    // 對齊
    alignLeft: "靠左對齊",
    alignCenter: "置中對齊",
    alignRight: "靠右對齊",
    alignJustify: "左右對齊",
    // 插入
    insertLink: "插入連結",
    insertImage: "插入圖片",
    insertTable: "插入表格",
    insertCodeBlock: "插入程式碼區塊",
    insertHorizontalRule: "插入分隔線",
    // 連結
    link: "連結",
    linkUrl: "連結位址",
    linkText: "連結文字",
    openLink: "開啟連結",
    editLink: "編輯連結",
    removeLink: "移除連結",
    // 撤銷重做
    undo: "復原",
    redo: "重做",
    undoDisabledInCollab: "協作模式下不可用",
    redoDisabledInCollab: "協作模式下不可用",
    // 更多
    more: "更多"
  },
  table: {
    insertTable: "插入表格",
    deleteTable: "刪除表格",
    addColumnBefore: "在左側插入欄",
    addColumnAfter: "在右側插入欄",
    deleteColumn: "刪除欄",
    addRowBefore: "在上方插入列",
    addRowAfter: "在下方插入列",
    deleteRow: "刪除列",
    mergeCells: "合併儲存格",
    splitCell: "分割儲存格",
    toggleHeaderCell: "切換標題儲存格",
    toggleHeaderColumn: "切換標題欄",
    toggleHeaderRow: "切換標題列",
    setCellAttribute: "設定儲存格屬性",
    fixTables: "修復表格"
  },
  bubbleMenu: {
    turnInto: "轉換為",
    textStyle: "文字樣式",
    color: "顏色"
  },
  dragMenu: {
    delete: "刪除",
    duplicate: "複製",
    copy: "拷貝",
    cut: "剪下",
    moveUp: "上移",
    moveDown: "下移"
  },
  codeBlock: {
    language: "語言",
    selectLanguage: "選擇語言"
  },
  stats: {
    characters: "字元",
    words: "詞",
    pages: "頁",
    zoom: "縮放",
    reset: "重置",
    total: "共"
  },
  placeholder: {
    default: "請輸入內容...",
    heading: "標題",
    paragraph: "正文"
  },
  messages: {
    imageUploadFailed: "圖片上傳失敗",
    imageUploadSuccess: "圖片上傳成功",
    invalidImageFormat: "不支援的圖片格式",
    imageTooLarge: "圖片大小超過限制",
    networkError: "網路錯誤，請稍後重試",
    pasteCleanedUp: "已清理貼上內容的格式",
    linkRequired: "請輸入連結位址",
    linkInvalid: "連結位址無效",
    // AI 功能錯誤訊息
    translationFailed: "翻譯失敗",
    polishFailed: "潤色失敗",
    summarizeFailed: "總結失敗",
    continueWritingFailed: "續寫失敗",
    customAiFailed: "自定義 AI 失敗"
  },
  editor: {
    // 標題快捷方式
    h1: "標題 1",
    h2: "標題 2",
    h3: "標題 3",
    h4: "標題 4",
    h5: "標題 5",
    h6: "標題 6",
    paragraph: "正文",
    heading: "標題",
    heading1: "標題 1",
    heading2: "標題 2",
    heading3: "標題 3",
    heading4: "標題 4",
    heading5: "標題 5",
    heading6: "標題 6",
    // 文本格式
    bold: "粗體",
    italic: "斜體",
    underline: "底線",
    strike: "刪除線",
    inlineCode: "程式碼",
    superscript: "上標",
    subscript: "下標",
    // 列表
    bulletList: "項目符號清單",
    orderedList: "編號清單",
    taskList: "工作清單",
    // 對齊
    align: "對齊",
    alignLeft: "靠左對齊",
    alignCenter: "置中對齊",
    alignRight: "靠右對齊",
    alignJustify: "左右對齊",
    // 縮排
    indent: "增加縮排",
    outdent: "減少縮排",
    indentAndAlign: "縮排和對齊",
    // 顏色
    colors: "顏色",
    text: "文字",
    highlight: "高亮",
    textColor: "文字顏色",
    backgroundColor: "背景顏色",
    defaultColors: "預設顏色",
    standardColors: "標準色",
    showAdvanced: "高級選擇器",
    hideAdvanced: "收起",
    clearColor: "清空顏色",
    // 操作
    actions: "操作",
    cut: "剪下",
    copy: "拷貝",
    delete: "刪除",
    // 基礎操作
    undo: "復原",
    redo: "重做",
    undoDisabledInCollab: "協作模式下不可用",
    redoDisabledInCollab: "協作模式下不可用",
    clearFormat: "清除格式",
    formatPainter: "格式刷",
    // 字體
    font: "字體",
    fontSize: "字號",
    lineHeight: "行距",
    // 插入
    insertLink: "插入連結",
    insertImage: "插入圖片",
    insertTable: "插入表格",
    image: "圖片",
    link: "連結",
    editLink: "編輯連結",
    openLink: "開啟連結",
    removeLink: "移除連結",
    linkPlaceholder: "請輸入連結位址",
    imagePlaceholder: "請輸入圖片位址",
    // 表格
    deleteTable: "刪除表格",
    includeHeader: "包含標題",
    // 上傳
    localUpload: "本地上傳",
    localUploadImage: "本地上傳圖片",
    webUpload: "網路上傳",
    clickOrDragUpload: "點擊或拖拽檔案到此區域上傳",
    onlySupportImage: "僅支援圖片格式",
    // 更多
    more: "更多",
    aiTool: "AI 工具",
    ai: "AI",
    // 格式刷相關
    pleaseSelectTextToSample: "請先選擇要採樣的文字",
    pleaseSelectTextToSampleShort: "請先選擇文字",
    pleaseSelectTextToSampleDouble: "請先雙擊選擇要採樣的文字",
    sampleSuccessSingle: "格式採樣成功，點擊目標文字套用格式",
    sampleSuccessContinuous: "格式採樣成功，可連續點擊多個目標文字套用格式",
    formatPainterExited: "已退出格式刷模式",
    collaborationNoFormatPainter: "協作模式下不支援格式刷功能",
    // 連結相關
    enterValidLink: "請輸入有效的連結位址",
    // 數學公式
    math: "數學公式",
    mathInline: "行內公式",
    mathBlock: "塊級公式",
    mathPlaceholder: "輸入 LaTeX 公式...",
    mathEmpty: "點擊編輯公式",
    // AI 相關
    continueWriting: "繼續寫作",
    polish: "潤色文字",
    summarize: "總結內容",
    translate: "翻譯",
    translateTo: "翻譯為 {lang}",
    customAi: "自定義 AI",
    selectLanguage: "選擇語言",
    // AI 建議相關
    aiSuggestion: "AI 建議",
    aiContinueWriting: "AI 續寫：",
    originalText: "原文：",
    suggestedText: "建議：",
    generatedContent: "生成內容：",
    generating: "正在生成...",
    selectedContent: "選中內容：",
    currentStatus: "當前狀態",
    noTextSelected: "未選中文本，AI 內容將插入到光標位置",
    // AI 功能提示訊息
    pleaseSelectText: "請先選中文字",
    continueWritingRequiresSelection: "續寫功能需要先選中要續寫的文字",
    polishRequiresSelection: "潤色功能需要先選中要潤色的文字",
    summarizeRequiresSelection: "總結功能需要先選中要總結的文字",
    translateRequiresSelection: "翻譯功能需要先選中要翻譯的文字",
    customAiRequiresSelection: "自定義AI功能需要先選中要處理的文字",
    aiPrompt: "AI 指令",
    aiPromptPlaceholder: "請輸入 AI 指令，例如：優化這段文字、翻譯成英文...",
    customAiCommand: "自定義 AI 指令",
    customAiPromptPlaceholder: "請輸入你的 AI 指令，例如：請幫我優化這段文字、請翻譯成英文、請總結要點等",
    execute: "執行",
    cancel: "取消",
    reject: "拒絕",
    accept: "接受",
    // 語言代碼
    lang: {
      "zh-CN": "簡體中文",
      "zh-TW": "繁體中文",
      zh: "中文",
      en: "英語",
      ja: "日語",
      th: "泰語",
      fr: "法語",
      es: "西班牙語",
      pt: "葡萄牙語",
      ko: "韓語",
      vi: "越南語",
      ru: "俄語",
      de: "德語",
      hi: "印地語",
      id: "印尼語",
      ar: "阿拉伯語"
    }
  },
  versionHistory: {
    title: "版本歷史",
    saveVersion: "儲存版本",
    noVersions: "暫無歷史版本",
    autoSave: "自動儲存",
    words: "字",
    justNow: "剛剛",
    minutesAgo: "分鐘前",
    hoursAgo: "小時前",
    daysAgo: "天前",
    restore: "恢復此版本",
    compare: "對比",
    rename: "重新命名",
    delete: "刪除",
    comparing: "正在對比",
    clearCompare: "取消對比",
    versionName: "版本名稱",
    saved: "版本已儲存",
    restored: "版本已恢復",
    deleted: "版本已刪除",
    noDiff: "內容相同"
  },
  aiSettings: {
    title: "AI 設定",
    provider: "AI 提供商",
    apiKeyPlaceholder: "請輸入 API Key",
    apiKeyHint: "API Key 僅保存在本地瀏覽器中，不會上傳到伺服器",
    endpoint: "API 端點",
    model: "模型",
    enableAi: "啟用 AI 功能",
    testConnection: "測試連線",
    testing: "測試中...",
    testSuccess: "連線成功",
    testFailed: "連線失敗",
    viewDocs: "查看文檔",
    save: "儲存",
    cancel: "取消",
    clear: "清除設定"
  }
};
const enUS = {
  toolbar: {
    // Text format
    bold: "Bold",
    italic: "Italic",
    underline: "Underline",
    strikethrough: "Strikethrough",
    code: "Code",
    subscript: "Subscript",
    superscript: "Superscript",
    // Clear format
    clear: "Clear",
    clearFormat: "Clear Format",
    formatPainter: "Format Painter",
    // Headings
    heading: "Heading",
    heading1: "Heading 1",
    heading2: "Heading 2",
    heading3: "Heading 3",
    heading4: "Heading 4",
    heading5: "Heading 5",
    heading6: "Heading 6",
    paragraph: "Paragraph",
    // Font
    fontFamily: "Font",
    fontSize: "Font Size",
    lineHeight: "Line Height",
    // Colors
    textColor: "Text Color",
    backgroundColor: "Background Color",
    highlightColor: "Highlight Color",
    // Lists
    bulletList: "Bullet List",
    orderedList: "Numbered List",
    taskList: "Task List",
    indent: "Indent",
    outdent: "Outdent",
    // Alignment
    alignLeft: "Align Left",
    alignCenter: "Align Center",
    alignRight: "Align Right",
    alignJustify: "Justify",
    // Insert
    insertLink: "Insert Link",
    insertImage: "Insert Image",
    insertTable: "Insert Table",
    insertCodeBlock: "Insert Code Block",
    insertHorizontalRule: "Insert Horizontal Rule",
    // Link
    link: "Link",
    linkUrl: "Link URL",
    linkText: "Link Text",
    openLink: "Open Link",
    editLink: "Edit Link",
    removeLink: "Remove Link",
    // Undo/Redo
    undo: "Undo",
    redo: "Redo",
    undoDisabledInCollab: "Disabled in collaboration mode",
    redoDisabledInCollab: "Disabled in collaboration mode",
    // More
    more: "More"
  },
  table: {
    insertTable: "Insert Table",
    deleteTable: "Delete Table",
    addColumnBefore: "Add Column Before",
    addColumnAfter: "Add Column After",
    deleteColumn: "Delete Column",
    addRowBefore: "Add Row Before",
    addRowAfter: "Add Row After",
    deleteRow: "Delete Row",
    mergeCells: "Merge Cells",
    splitCell: "Split Cell",
    toggleHeaderCell: "Toggle Header Cell",
    toggleHeaderColumn: "Toggle Header Column",
    toggleHeaderRow: "Toggle Header Row",
    setCellAttribute: "Set Cell Attribute",
    fixTables: "Fix Tables"
  },
  bubbleMenu: {
    turnInto: "Turn Into",
    textStyle: "Text Style",
    color: "Color"
  },
  dragMenu: {
    delete: "Delete",
    duplicate: "Duplicate",
    copy: "Copy",
    cut: "Cut",
    moveUp: "Move Up",
    moveDown: "Move Down"
  },
  codeBlock: {
    language: "Language",
    selectLanguage: "Select Language"
  },
  stats: {
    characters: "Characters",
    words: "Words",
    pages: "Pages",
    zoom: "Zoom",
    reset: "Reset",
    total: "Total"
  },
  placeholder: {
    default: "Type something...",
    heading: "Heading",
    paragraph: "Paragraph"
  },
  messages: {
    imageUploadFailed: "Image upload failed",
    imageUploadSuccess: "Image uploaded successfully",
    invalidImageFormat: "Invalid image format",
    imageTooLarge: "Image is too large",
    networkError: "Network error, please try again",
    pasteCleanedUp: "Pasted content has been cleaned up",
    linkRequired: "Link URL is required",
    linkInvalid: "Invalid link URL",
    // AI feature error messages
    translationFailed: "Translation failed",
    polishFailed: "Polish failed",
    summarizeFailed: "Summarize failed",
    continueWritingFailed: "Continue writing failed",
    customAiFailed: "Custom AI failed"
  },
  editor: {
    // Heading shortcuts
    h1: "Heading 1",
    h2: "Heading 2",
    h3: "Heading 3",
    h4: "Heading 4",
    h5: "Heading 5",
    h6: "Heading 6",
    paragraph: "Paragraph",
    heading: "Heading",
    heading1: "Heading 1",
    heading2: "Heading 2",
    heading3: "Heading 3",
    heading4: "Heading 4",
    heading5: "Heading 5",
    heading6: "Heading 6",
    // Text format
    bold: "Bold",
    italic: "Italic",
    underline: "Underline",
    strike: "Strikethrough",
    inlineCode: "Code",
    superscript: "Superscript",
    subscript: "Subscript",
    // Lists
    bulletList: "Bullet List",
    orderedList: "Numbered List",
    taskList: "Task List",
    // Alignment
    align: "Align",
    alignLeft: "Align Left",
    alignCenter: "Align Center",
    alignRight: "Align Right",
    alignJustify: "Justify",
    // Indent
    indent: "Indent",
    outdent: "Outdent",
    indentAndAlign: "Indent and Align",
    // Colors
    colors: "Colors",
    text: "Text",
    highlight: "Highlight",
    textColor: "Text Color",
    backgroundColor: "Background Color",
    defaultColors: "Default Colors",
    standardColors: "Standard Colors",
    showAdvanced: "Advanced Picker",
    hideAdvanced: "Hide",
    clearColor: "Clear Color",
    // Actions
    actions: "Actions",
    cut: "Cut",
    copy: "Copy",
    delete: "Delete",
    // Basic operations
    undo: "Undo",
    redo: "Redo",
    undoDisabledInCollab: "Disabled in collaboration mode",
    redoDisabledInCollab: "Disabled in collaboration mode",
    clearFormat: "Clear Format",
    formatPainter: "Format Painter",
    // Font
    font: "Font",
    fontSize: "Font Size",
    lineHeight: "Line Height",
    // Insert
    insertLink: "Insert Link",
    insertImage: "Insert Image",
    insertTable: "Insert Table",
    image: "Image",
    link: "Link",
    editLink: "Edit Link",
    openLink: "Open Link",
    removeLink: "Remove Link",
    linkPlaceholder: "Enter link URL",
    imagePlaceholder: "Enter image URL",
    // Table
    deleteTable: "Delete Table",
    includeHeader: "Include Header",
    // Upload
    localUpload: "Local Upload",
    localUploadImage: "Upload Image from Local",
    webUpload: "Web Upload",
    clickOrDragUpload: "Click or drag file to this area to upload",
    onlySupportImage: "Only image formats are supported",
    // More
    more: "More",
    aiTool: "AI Tool",
    ai: "AI",
    // Format painter related
    pleaseSelectTextToSample: "Please select text to sample first",
    pleaseSelectTextToSampleShort: "Please select text first",
    pleaseSelectTextToSampleDouble: "Please double-click to select text to sample",
    sampleSuccessSingle: "Format sampled successfully, click target text to apply format",
    sampleSuccessContinuous: "Format sampled successfully, you can click multiple target texts to apply format",
    formatPainterExited: "Format painter mode exited",
    collaborationNoFormatPainter: "Format painter is not supported in collaboration mode",
    // Link related
    enterValidLink: "Please enter a valid link URL",
    // Math
    math: "Math Formula",
    mathInline: "Inline Formula",
    mathBlock: "Block Formula",
    mathPlaceholder: "Enter LaTeX formula...",
    mathEmpty: "Click to edit formula",
    // AI related
    continueWriting: "Continue Writing",
    polish: "Polish Text",
    summarize: "Summarize Content",
    translate: "Translate",
    translateTo: "Translate to {lang}",
    customAi: "Custom AI",
    selectLanguage: "Select Language",
    // AI suggestion related
    aiSuggestion: "AI Suggestion",
    aiContinueWriting: "AI Continue Writing:",
    originalText: "Original:",
    suggestedText: "Suggestion:",
    generatedContent: "Generated Content:",
    generating: "Generating...",
    selectedContent: "Selected Content:",
    currentStatus: "Current Status",
    noTextSelected: "No text selected, AI content will be inserted at cursor position",
    // AI feature prompt messages
    pleaseSelectText: "Please select text first",
    continueWritingRequiresSelection: "Continue writing requires selecting text to continue",
    polishRequiresSelection: "Polish function requires selecting text to polish first",
    summarizeRequiresSelection: "Summarize function requires selecting text to summarize first",
    translateRequiresSelection: "Translation function requires selecting text to translate first",
    customAiRequiresSelection: "Custom AI function requires selecting text to process first",
    aiPrompt: "AI Prompt",
    aiPromptPlaceholder: "Enter AI instruction, e.g.: Optimize this text, Translate to English...",
    customAiCommand: "Custom AI Command",
    customAiPromptPlaceholder: "Enter your AI instruction, e.g.: Please optimize this text, Please translate to English, Please summarize key points, etc.",
    execute: "Execute",
    cancel: "Cancel",
    reject: "Reject",
    accept: "Accept",
    // Language codes
    lang: {
      "zh-CN": "Simplified Chinese",
      "zh-TW": "Traditional Chinese",
      zh: "Chinese",
      en: "English",
      ja: "Japanese",
      th: "Thai",
      fr: "French",
      es: "Spanish",
      pt: "Portuguese",
      ko: "Korean",
      vi: "Vietnamese",
      ru: "Russian",
      de: "German",
      hi: "Hindi",
      id: "Indonesian",
      ar: "Arabic"
    }
  },
  versionHistory: {
    title: "Version History",
    saveVersion: "Save Version",
    noVersions: "No versions yet",
    autoSave: "Auto-saved",
    words: "words",
    justNow: "Just now",
    minutesAgo: "minutes ago",
    hoursAgo: "hours ago",
    daysAgo: "days ago",
    restore: "Restore",
    compare: "Compare",
    rename: "Rename",
    delete: "Delete",
    comparing: "Comparing",
    clearCompare: "Clear",
    versionName: "Version name",
    saved: "Version saved",
    restored: "Version restored",
    deleted: "Version deleted",
    noDiff: "No differences"
  },
  aiSettings: {
    title: "AI Settings",
    provider: "AI Provider",
    apiKeyPlaceholder: "Enter API Key",
    apiKeyHint: "API Key is stored locally in your browser and will not be uploaded to any server",
    endpoint: "API Endpoint",
    model: "Model",
    enableAi: "Enable AI Features",
    testConnection: "Test Connection",
    testing: "Testing...",
    testSuccess: "Connection Successful",
    testFailed: "Connection Failed",
    viewDocs: "View Docs",
    save: "Save",
    cancel: "Cancel",
    clear: "Clear Config"
  }
};
const builtInLocales = {
  "zh-CN": zhCN,
  "zh-TW": zhTW,
  "en-US": enUS
};
const currentLocale = ref("zh-CN");
const customMessages = ref({});
function getNestedValue(obj, key) {
  if (!obj) return key;
  const keys = key.split(".");
  let result = obj;
  for (const k of keys) {
    if (result === void 0 || result === null || typeof result !== "object") {
      return key;
    }
    result = result[k];
  }
  return typeof result === "string" ? result : key;
}
function t(key, params) {
  const locale = currentLocale.value;
  let result = key;
  if (customMessages.value[locale]) {
    const custom = getNestedValue(customMessages.value[locale], key);
    if (custom !== key) result = custom;
  }
  if (result === key) {
    const builtIn = builtInLocales[locale];
    if (builtIn) {
      const builtInResult = getNestedValue(builtIn, key);
      if (builtInResult !== key) result = builtInResult;
    }
  }
  if (result === key && locale !== "en-US") {
    const fallbackResult = getNestedValue(builtInLocales["en-US"], key);
    if (fallbackResult !== key) result = fallbackResult;
  }
  if (params && result !== key) {
    Object.entries(params).forEach(([paramKey, value]) => {
      result = result.replace(new RegExp(`\\{${paramKey}\\}`, "g"), String(value));
    });
  }
  return result;
}
function createI18n(options) {
  if (options?.locale) {
    currentLocale.value = options.locale;
  }
  if (options?.messages) {
    customMessages.value = options.messages;
  }
}
function useI18n() {
  return {
    t,
    locale: computed(() => currentLocale.value),
    setLocale: (locale) => {
      currentLocale.value = locale;
    },
    availableLocales: Object.keys(builtInLocales)
  };
}
const _hoisted_1$k = ["disabled"];
const _hoisted_2$j = { class: "tt-toolbar-button__content" };
const _sfc_main$z = /* @__PURE__ */ defineComponent({
  __name: "ToolbarButton",
  props: {
    icon: {},
    title: {},
    active: { type: Boolean, default: false },
    disabled: { type: Boolean, default: false },
    danger: { type: Boolean, default: false },
    size: { default: "medium" }
  },
  emits: ["click", "dblclick"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    function onClick() {
      if (props.disabled) return;
      emit("click");
    }
    function onDblClick() {
      if (props.disabled) return;
      emit("dblclick");
    }
    return (_ctx, _cache) => {
      return openBlock(), createBlock(unref(Tooltip), {
        title: __props.title,
        placement: "top"
      }, {
        default: withCtx(() => [
          createElementVNode("button", {
            class: normalizeClass([
              "tt-toolbar-button",
              `tt-toolbar-button--${__props.size}`,
              { "is-active": __props.active, "is-danger": __props.danger }
            ]),
            disabled: __props.disabled,
            type: "button",
            onClick,
            onDblclick: onDblClick
          }, [
            createElementVNode("span", _hoisted_2$j, [
              renderSlot(_ctx.$slots, "icon", {}, () => [
                __props.icon ? (openBlock(), createBlock(resolveDynamicComponent(__props.icon), { key: 0 })) : createCommentVNode("", true)
              ]),
              renderSlot(_ctx.$slots, "default")
            ])
          ], 42, _hoisted_1$k)
        ]),
        _: 3
      }, 8, ["title"]);
    };
  }
});
const state$1 = reactive({
  userInfo: null
});
function setUserInfo(info) {
  state$1.userInfo = info;
}
function useUserStore() {
  return {
    userInfo: readonly(state$1).userInfo,
    setUserInfo,
    getUserInfo: () => state$1.userInfo
  };
}
const currentTheme = ref("light");
function usePreferences() {
  const theme = computed(() => currentTheme.value);
  const isDark = computed(() => currentTheme.value === "dark");
  const setTheme2 = (t2) => {
    currentTheme.value = t2;
    if (typeof document !== "undefined") {
      document.documentElement.setAttribute("data-theme", t2);
    }
  };
  const toggleTheme = () => {
    setTheme2(currentTheme.value === "light" ? "dark" : "light");
  };
  return {
    theme: readonly(theme),
    isDark: readonly(isDark),
    setTheme: setTheme2,
    toggleTheme
  };
}
function initTheme() {
  if (typeof window !== "undefined" && window.matchMedia) {
    const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    currentTheme.value = prefersDark ? "dark" : "light";
  }
}
const _sfc_main$y = /* @__PURE__ */ defineComponent({
  __name: "ToolbarGroup",
  props: {
    direction: { default: "horizontal" },
    gap: { default: 4 },
    divider: { type: Boolean, default: false },
    dividerColor: { default: void 0 }
  },
  setup(__props) {
    const props = __props;
    const { isDark } = usePreferences();
    const groupStyle = computed(() => ({
      gap: `${props.gap}px`
    }));
    const dividerDirection = computed(() => {
      return props.direction === "horizontal" ? "vertical" : "horizontal";
    });
    const computedDividerColor = computed(() => {
      if (props.dividerColor) {
        return props.dividerColor;
      }
      return isDark.value ? "#434343" : "#e8e8e8";
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass([
          "toolbar-group",
          `toolbar-group--${__props.direction}`,
          { "toolbar-group--with-divider": __props.divider }
        ]),
        style: normalizeStyle(groupStyle.value)
      }, [
        renderSlot(_ctx.$slots, "default", {}, void 0, true),
        __props.divider ? (openBlock(), createBlock(unref(ToolbarDivider), {
          key: 0,
          direction: dividerDirection.value,
          color: computedDividerColor.value
        }, null, 8, ["direction", "color"])) : createCommentVNode("", true)
      ], 6);
    };
  }
});
const _export_sfc = (sfc, props) => {
  const target = sfc.__vccOpts || sfc;
  for (const [key, val] of props) {
    target[key] = val;
  }
  return target;
};
const ToolbarGroup = /* @__PURE__ */ _export_sfc(_sfc_main$y, [["__scopeId", "data-v-72ccadf1"]]);
const _sfc_main$x = /* @__PURE__ */ defineComponent({
  __name: "ToolbarDivider",
  props: {
    direction: { default: "vertical" },
    color: { default: "#e8e8e8" }
  },
  setup(__props) {
    const props = __props;
    const dividerStyle = computed(() => {
      return props.direction === "vertical" ? { width: "1px", height: "100%", backgroundColor: props.color, marginLeft: "8px", marginRight: "8px" } : { height: "1px", width: "100%", backgroundColor: props.color, marginTop: "8px", marginBottom: "8px" };
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(["tt-toolbar-divider", `tt-toolbar-divider--${__props.direction}`]),
        style: normalizeStyle(dividerStyle.value)
      }, null, 6);
    };
  }
});
const ToolbarDivider = /* @__PURE__ */ _export_sfc(_sfc_main$x, [["__scopeId", "data-v-de553069"]]);
const _hoisted_1$j = { class: "tt-dropdown-btn__content" };
const _hoisted_2$i = {
  key: 1,
  class: "tt-dropdown-btn__label"
};
const _hoisted_3$h = { class: "tt-dropdown-menu-item" };
const _hoisted_4$f = { class: "tt-dropdown-menu-item__label" };
const _hoisted_5$f = { class: "tt-dropdown-menu-item" };
const _hoisted_6$f = { class: "tt-dropdown-menu-item__label" };
const _hoisted_7$e = { class: "tt-translate-split__main" };
const _hoisted_8$b = ["onClick"];
const _hoisted_9$b = ["title"];
const _hoisted_10$9 = { class: "tt-dropdown-menu-item" };
const _hoisted_11$9 = { class: "tt-dropdown-menu-item__label" };
const _hoisted_12$8 = { class: "tt-dropdown-menu-item" };
const _hoisted_13$7 = { class: "tt-dropdown-menu-item__label" };
const _sfc_main$w = /* @__PURE__ */ defineComponent({
  __name: "ToolbarDropdownButton",
  props: {
    icon: {},
    label: {},
    title: {},
    active: { type: Boolean, default: false },
    items: {},
    placement: { default: "bottom" }
  },
  emits: ["select"],
  setup(__props, { emit: __emit }) {
    const currentTranslateLang2 = {};
    const setTranslateLang2 = (_label) => {
    };
    const dropdownOpen = ref(false);
    const props = __props;
    const emit = __emit;
    const overlayOpen = ref(false);
    const hasSelectedLang = computed(() => false);
    const selectedLangKey = computed(() => "");
    let closeTimeout = null;
    function cancelClose() {
      if (closeTimeout) {
        clearTimeout(closeTimeout);
        closeTimeout = null;
      }
    }
    onBeforeUnmount(() => {
      cancelClose();
    });
    function scheduleClose() {
      cancelClose();
      closeTimeout = window.setTimeout(() => {
        overlayOpen.value = false;
      }, 150);
    }
    function onRowEnter() {
      if (!hasSelectedLang.value) {
        cancelClose();
        overlayOpen.value = true;
      }
    }
    function onRowLeave() {
      if (!hasSelectedLang.value) {
        scheduleClose();
      }
    }
    function onOverlayEnter() {
      cancelClose();
    }
    function onOverlayLeave() {
      scheduleClose();
    }
    function onDropOpenChange(nextOpen) {
      if (hasSelectedLang.value) {
        overlayOpen.value = nextOpen;
      }
    }
    function findItemByKey(items, key) {
      for (const item of items) {
        if (item.key === key) return item;
        if (item.children?.length) {
          const found = findItemByKey(item.children, key);
          if (found) return found;
        }
      }
      return void 0;
    }
    function onMenuClick(info) {
      const item = findItemByKey(props.items, info.key);
      if (!item) return;
      item.action?.();
      emit("select", info.key);
    }
    function onTranslateDefault(item) {
      if (!hasSelectedLang.value) {
        overlayOpen.value = true;
        return;
      }
      item.action?.();
    }
    function onTranslateLangClick(info) {
      const child = findItemByKey(props.items, info.key);
      if (!child) return;
      setTranslateLang2(child.label);
      child.action?.();
      emit("select", info.key);
    }
    return (_ctx, _cache) => {
      const _component_a_button = resolveComponent("a-button");
      const _component_a_menu_item = resolveComponent("a-menu-item");
      const _component_a_sub_menu = resolveComponent("a-sub-menu");
      const _component_a_menu = resolveComponent("a-menu");
      const _component_a_dropdown = resolveComponent("a-dropdown");
      return openBlock(), createBlock(_component_a_dropdown, {
        placement: __props.placement,
        trigger: ["click"],
        open: dropdownOpen.value,
        "onUpdate:open": _cache[0] || (_cache[0] = ($event) => dropdownOpen.value = $event)
      }, {
        overlay: withCtx(() => [
          createVNode(_component_a_menu, {
            onClick: onMenuClick,
            style: { "max-height": "360px", "overflow-y": "auto" }
          }, {
            default: withCtx(() => [
              (openBlock(true), createElementBlock(Fragment, null, renderList(__props.items, (item) => {
                return openBlock(), createElementBlock(Fragment, {
                  key: item.key
                }, [
                  item.children && item.children.length && item.key !== "translate" ? (openBlock(), createBlock(_component_a_sub_menu, {
                    key: item.key + ":submenu"
                  }, {
                    title: withCtx(() => [
                      createElementVNode("span", _hoisted_3$h, [
                        item.icon ? (openBlock(), createBlock(resolveDynamicComponent(item.icon), {
                          key: 0,
                          class: "tt-dropdown-menu-item__icon"
                        })) : createCommentVNode("", true),
                        createElementVNode("span", _hoisted_4$f, toDisplayString(item.label), 1)
                      ])
                    ]),
                    default: withCtx(() => [
                      (openBlock(true), createElementBlock(Fragment, null, renderList(item.children, (child) => {
                        return openBlock(), createBlock(_component_a_menu_item, {
                          key: child.key,
                          disabled: child.disabled,
                          danger: child.danger
                        }, {
                          default: withCtx(() => [
                            createElementVNode("span", _hoisted_5$f, [
                              child.icon ? (openBlock(), createBlock(resolveDynamicComponent(child.icon), {
                                key: 0,
                                class: "tt-dropdown-menu-item__icon"
                              })) : createCommentVNode("", true),
                              createElementVNode("span", _hoisted_6$f, toDisplayString(child.label), 1)
                            ])
                          ]),
                          _: 2
                        }, 1032, ["disabled", "danger"]);
                      }), 128))
                    ]),
                    _: 2
                  }, 1024)) : item.children && item.key === "translate" ? (openBlock(), createBlock(_component_a_menu_item, {
                    key: item.key + ":translate"
                  }, {
                    default: withCtx(() => [
                      createElementVNode("div", {
                        class: "tt-translate-split",
                        onMouseenter: onRowEnter,
                        onMouseleave: onRowLeave
                      }, [
                        createElementVNode("span", _hoisted_7$e, [
                          item.icon ? (openBlock(), createBlock(resolveDynamicComponent(item.icon), {
                            key: 0,
                            class: "tt-dropdown-menu-item__icon"
                          })) : createCommentVNode("", true),
                          createElementVNode("span", {
                            class: "tt-dropdown-menu-item__label",
                            onClick: withModifiers(($event) => onTranslateDefault(item), ["stop"])
                          }, toDisplayString(hasSelectedLang.value ? unref(t)("editor.translateTo") + currentTranslateLang2 : unref(t)("editor.selectLanguage")), 9, _hoisted_8$b)
                        ]),
                        createVNode(_component_a_dropdown, {
                          trigger: hasSelectedLang.value ? ["hover"] : [],
                          placement: "rightTop",
                          open: overlayOpen.value,
                          onOpenChange: onDropOpenChange
                        }, {
                          overlay: withCtx(() => [
                            createElementVNode("div", {
                              class: "tt-translate-overlay",
                              onMouseenter: onOverlayEnter,
                              onMouseleave: onOverlayLeave
                            }, [
                              createVNode(_component_a_menu, {
                                onClick: onTranslateLangClick,
                                class: "tt-dropdown-overlay",
                                selectedKeys: selectedLangKey.value ? [selectedLangKey.value] : []
                              }, {
                                default: withCtx(() => [
                                  (openBlock(true), createElementBlock(Fragment, null, renderList(item.children, (child) => {
                                    return openBlock(), createBlock(_component_a_menu_item, {
                                      key: child.key,
                                      disabled: child.disabled,
                                      danger: child.danger
                                    }, {
                                      default: withCtx(() => [
                                        createElementVNode("span", _hoisted_10$9, [
                                          createElementVNode("span", _hoisted_11$9, toDisplayString(child.label), 1)
                                        ])
                                      ]),
                                      _: 2
                                    }, 1032, ["disabled", "danger"]);
                                  }), 128))
                                ]),
                                _: 2
                              }, 1032, ["selectedKeys"])
                            ], 32)
                          ]),
                          default: withCtx(() => [
                            createElementVNode("span", {
                              class: "tt-translate-split__arrow",
                              title: unref(t)("editor.selectLanguage")
                            }, [
                              createVNode(unref(RightOutlined))
                            ], 8, _hoisted_9$b)
                          ]),
                          _: 2
                        }, 1032, ["trigger", "open"])
                      ], 32)
                    ]),
                    _: 2
                  }, 1024)) : (openBlock(), createBlock(_component_a_menu_item, {
                    key: item.key,
                    disabled: item.disabled,
                    danger: item.danger,
                    class: normalizeClass({ "ant-menu-item-selected": item.active })
                  }, {
                    default: withCtx(() => [
                      createElementVNode("span", _hoisted_12$8, [
                        item.icon ? (openBlock(), createBlock(resolveDynamicComponent(item.icon), {
                          key: 0,
                          class: "tt-dropdown-menu-item__icon"
                        })) : createCommentVNode("", true),
                        createElementVNode("span", _hoisted_13$7, toDisplayString(item.label), 1)
                      ])
                    ]),
                    _: 2
                  }, 1032, ["disabled", "danger", "class"]))
                ], 64);
              }), 128))
            ]),
            _: 1
          })
        ]),
        default: withCtx(() => [
          createVNode(unref(Tooltip), {
            title: __props.title,
            placement: "top",
            open: dropdownOpen.value ? false : void 0
          }, {
            default: withCtx(() => [
              createVNode(_component_a_button, {
                type: "text",
                class: normalizeClass(["tt-dropdown-btn", { "is-active": __props.active }])
              }, {
                default: withCtx(() => [
                  createElementVNode("span", _hoisted_1$j, [
                    __props.icon ? (openBlock(), createBlock(resolveDynamicComponent(__props.icon), {
                      key: 0,
                      class: "tt-dropdown-btn__icon"
                    })) : createCommentVNode("", true),
                    __props.label ? (openBlock(), createElementBlock("span", _hoisted_2$i, toDisplayString(__props.label), 1)) : createCommentVNode("", true),
                    createVNode(unref(DownOutlined), { class: "tt-dropdown-btn__arrow" })
                  ])
                ]),
                _: 1
              }, 8, ["class"])
            ]),
            _: 1
          }, 8, ["title", "open"])
        ]),
        _: 1
      }, 8, ["placement", "open"]);
    };
  }
});
const _hoisted_1$i = { class: "tt-color-picker-content" };
const _hoisted_2$h = { class: "tt-color-picker-header" };
const _hoisted_3$g = ["title"];
const _hoisted_4$e = { class: "tt-color-picker-preview" };
const _hoisted_5$e = { class: "tt-color-picker-title" };
const _hoisted_6$e = ["title"];
const _hoisted_7$d = { class: "tt-color-picker-section" };
const _hoisted_8$a = { class: "tt-color-picker-section-title" };
const _hoisted_9$a = ["onClick", "title"];
const _hoisted_10$8 = { class: "tt-color-picker-section" };
const _hoisted_11$8 = { class: "tt-color-picker-section-title" };
const _hoisted_12$7 = ["onClick", "title"];
const _hoisted_13$6 = {
  key: 0,
  class: "tt-color-picker-advanced"
};
const _hoisted_14$5 = { class: "tt-color-picker-advanced-header" };
const _hoisted_15$4 = { class: "tt-color-picker-advanced-title" };
const _hoisted_16$3 = ["title"];
const _hoisted_17$3 = { class: "tt-color-picker-advanced-content" };
const _hoisted_18$3 = {
  key: 1,
  class: "tt-color-current-preview"
};
const _sfc_main$v = /* @__PURE__ */ defineComponent({
  __name: "ColorPicker",
  props: {
    columns: { default: 10 },
    itemSize: { default: 20 },
    modelValue: { default: void 0 },
    gap: { default: 8 },
    icon: { default: void 0 },
    type: { default: "text" },
    title: { default: void 0 }
  },
  emits: ["update:modelValue", "select"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const DEFAULT_COLORS = [
      // 第1行：各列的最浅色（主色）
      "#ffffff",
      "#f2f2f2",
      "#e0e0e0",
      "#ffcccc",
      "#ffcc99",
      "#ffffcc",
      "#ccffcc",
      "#cce5ff",
      "#e4d9ff",
      "#ffd9e6",
      // 第2行：各列的浅色（80% 主色）
      "#f5f5f5",
      "#e6e6e6",
      "#c0c0c0",
      "#ff9999",
      "#ff9966",
      "#ffff99",
      "#99ff99",
      "#99ccff",
      "#ccb3ff",
      "#ffb3cc",
      // 第3行：各列的中等色（60% 主色）
      "#d9d9d9",
      "#cccccc",
      "#808080",
      "#ff6666",
      "#ff9900",
      "#ffff00",
      "#66ff66",
      "#6699ff",
      "#9966ff",
      "#ff6699",
      // 第4行：各列的深色（40% 主色）
      "#a6a6a6",
      "#999999",
      "#595959",
      "#ff0000",
      "#ff7700",
      "#ffd700",
      "#00ff00",
      "#0066ff",
      "#6600cc",
      "#ff0066",
      // 第5行：各列的最深色（20% 主色）
      "#000000",
      "#666666",
      "#404040",
      "#990000",
      "#cc6600",
      "#cccc00",
      "#006600",
      "#003366",
      "#330066",
      "#cc0033"
    ];
    const STANDARD_COLORS = [
      "#c00000",
      // 深红
      "#ff6600",
      // 亮橙
      "#ffc000",
      // 亮黄
      "#92d050",
      // 浅绿
      "#00b050",
      // 标准绿
      "#00b0f0",
      // 浅蓝
      "#0070c0",
      // 青色
      "#0050d0",
      // 中蓝
      "#002060",
      // 深蓝
      "#7030a0"
      // 紫色
    ];
    const normalizeColor = (color) => color?.trim().toLowerCase() || "#000000";
    const normalizedColor = computed(() => normalizeColor(props.modelValue));
    const buttonTitle = computed(() => {
      if (props.title) return props.title;
      return props.type === "text" ? t("editor.textColor") : t("editor.backgroundColor");
    });
    const getTextColorForBackground = (bgColor) => {
      if (!bgColor || bgColor === "transparent") return "#000";
      let hex = bgColor.replace("#", "");
      if (hex.length === 3) {
        hex = hex.split("").map((c) => c + c).join("");
      }
      if (hex.length !== 6) return "#000";
      const r = parseInt(hex.substr(0, 2), 16);
      const g = parseInt(hex.substr(2, 2), 16);
      const b = parseInt(hex.substr(4, 2), 16);
      const brightness = (r * 299 + g * 587 + b * 114) / 1e3;
      return brightness > 120 ? "#000" : "#fff";
    };
    const previewTextStyle = computed(() => {
      if (props.type === "text") {
        return { color: normalizedColor.value };
      } else {
        return {
          backgroundColor: normalizedColor.value,
          color: getTextColorForBackground(normalizedColor.value)
        };
      }
    });
    const gridStyle = computed(() => ({
      gridTemplateColumns: `repeat(${props.columns}, ${props.itemSize}px)`
    }));
    const standardGridStyle = computed(() => ({
      gridTemplateColumns: `repeat(10, ${props.itemSize}px)`
    }));
    const showPicker = ref(false);
    const showAdvancedPicker = ref(false);
    const advancedColor = ref(normalizedColor.value || "#000000");
    watch(showAdvancedPicker, (isOpen) => {
      if (isOpen) {
        advancedColor.value = normalizedColor.value || "#000000";
      }
    });
    const updateColor = (color) => {
      emit("update:modelValue", color);
      emit("select", color);
    };
    const handleSelectColor = (color) => {
      updateColor(normalizeColor(color));
    };
    const clearColor = () => {
      updateColor(props.type === "text" ? "#000000" : "transparent");
    };
    const handleAdvancedColorChange = (e) => {
      const target = e.target;
      const color = normalizeColor(target.value);
      advancedColor.value = color;
      updateColor(color);
    };
    const handleAdvancedColorInput = (e) => {
      const target = e.target;
      let color = target.value.trim();
      if (color && !color.startsWith("#")) {
        color = "#" + color;
      }
      if (/^#[0-9A-Fa-f]{6}$/.test(color) || /^#[0-9A-Fa-f]{3}$/.test(color)) {
        const normalized = normalizeColor(color);
        advancedColor.value = normalized;
        updateColor(normalized);
      }
    };
    watch(normalizedColor, (newColor) => {
      if (showAdvancedPicker.value) {
        advancedColor.value = newColor;
      }
    });
    return (_ctx, _cache) => {
      return openBlock(), createBlock(unref(Popover), {
        trigger: "click",
        placement: "bottomLeft",
        open: showPicker.value,
        "onUpdate:open": _cache[4] || (_cache[4] = ($event) => showPicker.value = $event),
        "overlay-class-name": "tt-color-picker-popover"
      }, {
        content: withCtx(() => [
          createElementVNode("div", _hoisted_1$i, [
            createElementVNode("div", _hoisted_2$h, [
              createElementVNode("button", {
                class: "tt-color-picker-preview-btn",
                type: "button",
                onClick: _cache[0] || (_cache[0] = withModifiers(($event) => showAdvancedPicker.value = true, ["stop"])),
                title: unref(t)("editor.showAdvanced")
              }, [
                createElementVNode("div", _hoisted_4$e, [
                  createElementVNode("div", {
                    class: "tt-color-picker-preview-color",
                    style: normalizeStyle({ backgroundColor: normalizedColor.value })
                  }, null, 4)
                ])
              ], 8, _hoisted_3$g),
              _cache[5] || (_cache[5] = createElementVNode("div", { class: "tt-color-picker-separator" }, null, -1)),
              createElementVNode("div", _hoisted_5$e, toDisplayString(unref(t)("editor.colors")), 1),
              createElementVNode("div", {
                class: normalizeClass(["tt-color-picker-preview-text", { "is-background": __props.type === "background" }]),
                style: normalizeStyle(previewTextStyle.value)
              }, " A ", 6),
              createElementVNode("button", {
                class: "tt-color-clear-btn",
                type: "button",
                onClick: withModifiers(clearColor, ["stop"]),
                title: unref(t)("editor.clearColor")
              }, [
                createVNode(unref(StopOutlined), { class: "tt-color-clear-icon" })
              ], 8, _hoisted_6$e)
            ]),
            createElementVNode("div", _hoisted_7$d, [
              createElementVNode("div", _hoisted_8$a, toDisplayString(unref(t)("editor.defaultColors")), 1),
              createElementVNode("div", {
                class: "tt-color-picker-grid",
                style: normalizeStyle(gridStyle.value)
              }, [
                (openBlock(), createElementBlock(Fragment, null, renderList(DEFAULT_COLORS, (color) => {
                  return createElementVNode("button", {
                    key: color,
                    class: normalizeClass(["tt-color-picker__item", { "is-selected": normalizedColor.value === normalizeColor(color) }]),
                    style: normalizeStyle({
                      width: `${props.itemSize}px`,
                      height: `${props.itemSize}px`,
                      backgroundColor: color
                    }),
                    type: "button",
                    onClick: ($event) => handleSelectColor(color),
                    title: color
                  }, null, 14, _hoisted_9$a);
                }), 64))
              ], 4)
            ]),
            createElementVNode("div", _hoisted_10$8, [
              createElementVNode("div", _hoisted_11$8, toDisplayString(unref(t)("editor.standardColors")), 1),
              createElementVNode("div", {
                class: "tt-color-picker-grid",
                style: normalizeStyle(standardGridStyle.value)
              }, [
                (openBlock(), createElementBlock(Fragment, null, renderList(STANDARD_COLORS, (color) => {
                  return createElementVNode("button", {
                    key: color,
                    class: normalizeClass(["tt-color-picker__item", { "is-selected": normalizedColor.value === normalizeColor(color) }]),
                    style: normalizeStyle({
                      width: `${props.itemSize}px`,
                      height: `${props.itemSize}px`,
                      backgroundColor: color
                    }),
                    type: "button",
                    onClick: ($event) => handleSelectColor(color),
                    title: color
                  }, null, 14, _hoisted_12$7);
                }), 64))
              ], 4)
            ]),
            showAdvancedPicker.value ? (openBlock(), createElementBlock("div", _hoisted_13$6, [
              createElementVNode("div", _hoisted_14$5, [
                createElementVNode("span", _hoisted_15$4, toDisplayString(unref(t)("editor.showAdvanced")), 1),
                createElementVNode("button", {
                  class: "tt-color-picker-advanced-close",
                  type: "button",
                  onClick: _cache[1] || (_cache[1] = withModifiers(($event) => showAdvancedPicker.value = false, ["stop"])),
                  title: unref(t)("editor.hideAdvanced")
                }, " × ", 8, _hoisted_16$3)
              ]),
              createElementVNode("div", _hoisted_17$3, [
                withDirectives(createElementVNode("input", {
                  "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => advancedColor.value = $event),
                  type: "color",
                  class: "tt-color-picker-color-input",
                  onChange: handleAdvancedColorChange
                }, null, 544), [
                  [vModelText, advancedColor.value]
                ]),
                withDirectives(createElementVNode("input", {
                  "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => advancedColor.value = $event),
                  type: "text",
                  class: "tt-color-picker-color-text",
                  placeholder: "#000000",
                  onInput: handleAdvancedColorInput
                }, null, 544), [
                  [vModelText, advancedColor.value]
                ])
              ])
            ])) : createCommentVNode("", true)
          ])
        ]),
        default: withCtx(() => [
          createVNode(unref(Tooltip), {
            title: buttonTitle.value,
            placement: "top",
            open: showPicker.value ? false : void 0
          }, {
            default: withCtx(() => [
              createElementVNode("div", {
                class: normalizeClass(["tt-color-current-btn", { "has-icon": __props.icon }])
              }, [
                __props.icon ? (openBlock(), createBlock(resolveDynamicComponent(__props.icon), {
                  key: 0,
                  class: "tt-color-icon"
                })) : (openBlock(), createElementBlock("div", _hoisted_18$3))
              ], 2)
            ]),
            _: 1
          }, 8, ["title", "open"])
        ]),
        _: 1
      }, 8, ["open"]);
    };
  }
});
const ColorPicker = /* @__PURE__ */ _export_sfc(_sfc_main$v, [["__scopeId", "data-v-993434b1"]]);
function createCommandRunner(editor) {
  return (fn) => () => {
    const e = editor.value;
    if (!e) {
      console.warn("[editorCommands] Editor instance is null or undefined");
      return;
    }
    fn(e.chain().focus()).run();
  };
}
function executeBatchCommands(editor, commands, withFocus = true) {
  const e = editor.value;
  if (!e) {
    console.warn("[editorCommands] Editor instance is null or undefined");
    return false;
  }
  let chain = withFocus ? e.chain().focus() : e.chain();
  for (const command of commands) {
    chain = command(chain);
  }
  return chain.run();
}
function createStateCheckers(editor) {
  return {
    /**
     * 检查节点/标记是否激活
     * @param name - 节点或标记名称
     * @param attributes - 可选的属性对象
     * @returns 是否激活
     */
    isActive: (name, attributes) => {
      const e = editor.value;
      if (!e) return false;
      return attributes ? e.isActive(name, attributes) : e.isActive(name);
    },
    /**
     * 检查标题级别是否激活
     * @param level - 标题级别 (1-6)
     * @returns 是否激活
     */
    isHeadingActive: (level) => {
      const e = editor.value;
      if (!e) return false;
      return e.isActive("heading", { level });
    },
    /**
     * 检查对齐方式是否激活
     * @param value - 对齐方式
     * @returns 是否激活
     */
    isActiveAlign: (value) => {
      const e = editor.value;
      if (!e) return false;
      return e.isActive({ textAlign: value });
    },
    /**
     * 检查命令是否可执行
     * @param command - 命令名称
     * @returns 是否可执行
     */
    canExecute: (command) => {
      const e = editor.value;
      if (!e) return false;
      const canObj = e.can();
      const fn = canObj[command];
      return typeof fn === "function" ? fn() : false;
    }
  };
}
const _sfc_main$u = /* @__PURE__ */ defineComponent({
  __name: "TextFormatButtons",
  props: {
    editor: {},
    showCode: { type: Boolean, default: false }
  },
  setup(__props) {
    const props = __props;
    const editor = computed(() => props.editor ?? null);
    const runCommand = createCommandRunner(editor);
    const { isActive } = createStateCheckers(editor);
    const textFormats = computed(() => {
      const formats = [
        {
          name: "bold",
          icon: BoldOutlined,
          title: t("editor.bold"),
          action: () => runCommand((chain) => chain.toggleBold())()
        },
        {
          name: "italic",
          icon: ItalicOutlined,
          title: t("editor.italic"),
          action: () => runCommand((chain) => chain.toggleItalic())()
        },
        {
          name: "underline",
          icon: UnderlineOutlined,
          title: t("editor.underline"),
          action: () => runCommand((chain) => chain.toggleUnderline?.() ?? chain)()
        },
        {
          name: "strike",
          icon: StrikethroughOutlined,
          title: t("editor.strike"),
          action: () => runCommand((chain) => chain.toggleStrike())()
        }
      ];
      if (props.showCode) {
        formats.push({
          name: "code",
          icon: CodeOutlined,
          title: t("editor.inlineCode"),
          action: () => runCommand((chain) => chain.toggleCode())()
        });
      }
      return formats;
    });
    return (_ctx, _cache) => {
      return openBlock(), createBlock(unref(ToolbarGroup), null, {
        default: withCtx(() => [
          (openBlock(true), createElementBlock(Fragment, null, renderList(textFormats.value, (format) => {
            return openBlock(), createBlock(unref(_sfc_main$z), {
              key: format.name,
              icon: format.icon,
              title: format.title,
              active: unref(isActive)(format.name),
              onClick: format.action
            }, null, 8, ["icon", "title", "active", "onClick"]);
          }), 128))
        ]),
        _: 1
      });
    };
  }
});
const _sfc_main$t = /* @__PURE__ */ defineComponent({
  __name: "ListTools",
  props: {
    editor: {},
    showTaskList: { type: Boolean, default: false }
  },
  setup(__props) {
    const props = __props;
    const editor = computed(() => props.editor ?? null);
    const runCommand = createCommandRunner(editor);
    const { isActive } = createStateCheckers(editor);
    const listItems = computed(() => {
      const items = [
        {
          name: "bulletList",
          icon: UnorderedListOutlined,
          title: t("editor.bulletList"),
          action: () => runCommand((chain) => chain.toggleBulletList())()
        },
        {
          name: "orderedList",
          icon: OrderedListOutlined,
          title: t("editor.orderedList"),
          action: () => runCommand((chain) => chain.toggleOrderedList())()
        }
      ];
      if (props.showTaskList) {
        items.push({
          name: "taskList",
          icon: CheckSquareOutlined,
          title: t("editor.taskList"),
          action: () => runCommand((chain) => chain.toggleTaskList?.() ?? chain)()
        });
      }
      return items;
    });
    return (_ctx, _cache) => {
      return openBlock(), createBlock(unref(ToolbarGroup), null, {
        default: withCtx(() => [
          (openBlock(true), createElementBlock(Fragment, null, renderList(listItems.value, (item) => {
            return openBlock(), createBlock(unref(_sfc_main$z), {
              key: item.name,
              icon: item.icon,
              title: item.title,
              active: unref(isActive)(item.name),
              onClick: item.action
            }, null, 8, ["icon", "title", "active", "onClick"]);
          }), 128))
        ]),
        _: 1
      });
    };
  }
});
const FONT_FAMILIES = [
  { label: "PMingLiU", value: "PMingLiU" },
  { label: "Microsoft YaHei", value: "Microsoft YaHei" },
  { label: "SimSun", value: "SimSun" },
  { label: "SimHei", value: "SimHei" },
  { label: "Arial", value: "Arial" },
  { label: "Times New Roman", value: "Times New Roman" },
  { label: "Courier New", value: "Courier New" },
  { label: "Monospace", value: "monospace" }
];
const FONT_SIZES = [
  { label: "12", value: "12px" },
  { label: "14", value: "14px" },
  { label: "16", value: "16px" },
  { label: "18", value: "18px" },
  { label: "20", value: "20px" },
  { label: "24", value: "24px" },
  { label: "28", value: "28px" },
  { label: "32", value: "32px" }
];
const HEADING_OPTIONS = [
  { label: "正文", value: "paragraph" },
  { label: "H1", value: "h1" },
  { label: "H2", value: "h2" },
  { label: "H3", value: "h3" },
  { label: "H4", value: "h4" },
  { label: "H5", value: "h5" },
  { label: "H6", value: "h6" }
];
const DEFAULT_VALUES = {
  /** 默认字体 */
  fontFamily: "PMingLiU",
  /** 默认字号 */
  fontSize: "16px"
};
const _sfc_main$s = /* @__PURE__ */ defineComponent({
  __name: "HeadingDropdown",
  props: {
    editor: {}
  },
  setup(__props) {
    const props = __props;
    const editor = computed(() => props.editor ?? null);
    const headingItems = computed(() => {
      if (!editor.value) return [];
      return HEADING_OPTIONS.map((opt) => ({
        key: opt.value,
        label: t(`editor.${opt.value}`),
        action: () => onHeadingChange(opt.value)
      }));
    });
    function onHeadingChange(val) {
      const e = editor.value;
      if (!e) return;
      const { from, to } = e.state.selection;
      if (val === "paragraph") {
        e.chain().setParagraph().setTextSelection({ from, to }).run();
        return;
      }
      const level = Number(val.replace(/^h/, ""));
      if (![1, 2, 3, 4, 5, 6].includes(level)) return;
      const $from = e.state.selection.$from;
      const start = $from.start($from.depth);
      const end = $from.end($from.depth);
      e.chain().setHeading({ level }).setTextSelection({ from: start, to: end }).unsetMark("textStyle").setTextSelection({ from, to }).run();
    }
    return (_ctx, _cache) => {
      return openBlock(), createBlock(unref(ToolbarGroup), null, {
        default: withCtx(() => [
          createVNode(unref(_sfc_main$w), {
            icon: unref(FontSizeOutlined),
            title: unref(t)("editor.heading"),
            items: headingItems.value,
            placement: "bottomLeft"
          }, null, 8, ["icon", "title", "items"])
        ]),
        _: 1
      });
    };
  }
});
const _sfc_main$r = /* @__PURE__ */ defineComponent({
  __name: "HeadingButtons",
  props: {
    editor: {},
    levels: { default: () => [1, 2, 3] }
  },
  setup(__props) {
    const props = __props;
    const editor = computed(() => props.editor ?? null);
    const runCommand = createCommandRunner(editor);
    const { isHeadingActive } = createStateCheckers(editor);
    const headings = computed(
      () => props.levels.map((level) => ({
        level,
        action: runCommand((chain) => chain.toggleHeading({ level })),
        title: t(`editor.h${level}`)
      }))
    );
    return (_ctx, _cache) => {
      return openBlock(), createBlock(unref(ToolbarGroup), null, {
        default: withCtx(() => [
          (openBlock(true), createElementBlock(Fragment, null, renderList(headings.value, (heading) => {
            return openBlock(), createBlock(unref(_sfc_main$z), {
              key: heading.level,
              title: heading.title,
              active: unref(isHeadingActive)(heading.level),
              onClick: heading.action,
              class: "heading-btn",
              "data-level": heading.level
            }, {
              default: withCtx(() => [
                createTextVNode(" H" + toDisplayString(heading.level), 1)
              ]),
              _: 2
            }, 1032, ["title", "active", "onClick", "data-level"]);
          }), 128))
        ]),
        _: 1
      });
    };
  }
});
const HeadingButtons = /* @__PURE__ */ _export_sfc(_sfc_main$r, [["__scopeId", "data-v-6e857370"]]);
const _sfc_main$q = /* @__PURE__ */ defineComponent({
  __name: "AlignDropdown",
  props: {
    editor: {}
  },
  setup(__props) {
    const props = __props;
    const editor = computed(() => props.editor ?? null);
    const runCommand = createCommandRunner(editor);
    const { isActiveAlign } = createStateCheckers(editor);
    const alignMenuItems = computed(() => [
      { key: "align-left", label: t("editor.alignLeft"), icon: AlignLeftOutlined, action: () => setAlign("left") },
      { key: "align-center", label: t("editor.alignCenter"), icon: AlignCenterOutlined, action: () => setAlign("center") },
      { key: "align-right", label: t("editor.alignRight"), icon: AlignRightOutlined, action: () => setAlign("right") },
      { key: "align-justify", label: t("editor.alignJustify"), icon: MenuOutlined, action: () => setAlign("justify") }
    ]);
    const currentAlignIcon = computed(() => {
      if (isActiveAlign("center")) return AlignCenterOutlined;
      if (isActiveAlign("right")) return AlignRightOutlined;
      if (isActiveAlign("justify")) return MenuOutlined;
      return AlignLeftOutlined;
    });
    function setAlign(value) {
      runCommand((chain) => chain.setTextAlign(value))();
    }
    return (_ctx, _cache) => {
      return openBlock(), createBlock(unref(ToolbarGroup), null, {
        default: withCtx(() => [
          createVNode(unref(_sfc_main$w), {
            icon: currentAlignIcon.value,
            title: unref(t)("editor.align"),
            items: alignMenuItems.value,
            placement: "bottomLeft"
          }, null, 8, ["icon", "title", "items"])
        ]),
        _: 1
      });
    };
  }
});
const _hoisted_1$h = { class: "ant-upload-drag-icon" };
const _hoisted_2$g = { class: "ant-upload-text" };
const _hoisted_3$f = { class: "ant-upload-hint" };
const _sfc_main$p = /* @__PURE__ */ defineComponent({
  __name: "ImageUpload",
  props: {
    editor: {},
    uploadImage: { type: Function, default: void 0 }
  },
  setup(__props) {
    const props = __props;
    const editor = computed(() => props.editor ?? null);
    const runCommand = createCommandRunner(editor);
    const imageModalOpen = ref(false);
    const imageUrl = ref("");
    const localUploadOpen = ref(false);
    const imageMenuItems = computed(() => [
      {
        key: "upload-local",
        label: t("editor.localUpload"),
        icon: UploadOutlined,
        action: () => localUploadOpen.value = true
      },
      {
        key: "upload-url",
        label: t("editor.webUpload"),
        icon: LinkOutlined,
        action: () => imageModalOpen.value = true
      }
    ]);
    function applyImage() {
      if (imageUrl.value) {
        runCommand((chain) => chain.insertContent({ type: "image", attrs: { src: imageUrl.value } }))();
      }
      imageModalOpen.value = false;
      imageUrl.value = "";
    }
    async function handleLocalUpload(options) {
      const { file, onSuccess, onError } = options || {};
      try {
        let url;
        if (props.uploadImage) {
          url = await props.uploadImage(file);
        } else {
          url = await new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(String(reader.result));
            reader.onerror = reject;
            reader.readAsDataURL(file);
          });
        }
        runCommand((chain) => chain.insertContent({ type: "image", attrs: { src: url } }))();
        localUploadOpen.value = false;
        onSuccess && onSuccess({ url });
      } catch (e) {
        onError && onError(e);
      }
    }
    return (_ctx, _cache) => {
      const _component_a_input = resolveComponent("a-input");
      const _component_a_modal = resolveComponent("a-modal");
      const _component_a_upload_dragger = resolveComponent("a-upload-dragger");
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(unref(ToolbarGroup), null, {
          default: withCtx(() => [
            createVNode(unref(_sfc_main$w), {
              icon: unref(PictureOutlined),
              title: unref(t)("editor.image"),
              items: imageMenuItems.value,
              placement: "bottomLeft"
            }, null, 8, ["icon", "title", "items"])
          ]),
          _: 1
        }),
        createVNode(_component_a_modal, {
          open: imageModalOpen.value,
          "onUpdate:open": _cache[1] || (_cache[1] = ($event) => imageModalOpen.value = $event),
          title: unref(t)("editor.insertImage"),
          onOk: applyImage
        }, {
          default: withCtx(() => [
            createVNode(_component_a_input, {
              value: imageUrl.value,
              "onUpdate:value": _cache[0] || (_cache[0] = ($event) => imageUrl.value = $event),
              placeholder: unref(t)("editor.imagePlaceholder")
            }, null, 8, ["value", "placeholder"])
          ]),
          _: 1
        }, 8, ["open", "title"]),
        createVNode(_component_a_modal, {
          open: localUploadOpen.value,
          "onUpdate:open": _cache[2] || (_cache[2] = ($event) => localUploadOpen.value = $event),
          title: unref(t)("editor.localUploadImage"),
          footer: null
        }, {
          default: withCtx(() => [
            createVNode(_component_a_upload_dragger, {
              "show-upload-list": false,
              "custom-request": handleLocalUpload,
              accept: "image/*"
            }, {
              default: withCtx(() => [
                createElementVNode("p", _hoisted_1$h, [
                  createVNode(unref(InboxOutlined))
                ]),
                createElementVNode("p", _hoisted_2$g, toDisplayString(unref(t)("editor.clickOrDragUpload")), 1),
                createElementVNode("p", _hoisted_3$f, toDisplayString(unref(t)("editor.onlySupportImage")), 1)
              ]),
              _: 1
            })
          ]),
          _: 1
        }, 8, ["open", "title"])
      ], 64);
    };
  }
});
const ResizableImage = Image.extend({
  name: "image",
  addOptions() {
    return {
      ...this.parent?.(),
      HTMLAttributes: {},
      inline: true,
      allowBase64: true,
      enableResize: true
      // 默认开启图片增强功能
    };
  },
  addAttributes() {
    const createSizeAttribute = (name) => ({
      default: null,
      parseHTML: (element) => {
        const value = element.getAttribute(name);
        return value ? parseInt(value, 10) : null;
      },
      renderHTML: (attributes) => {
        return attributes[name] ? { [name]: attributes[name] } : {};
      }
    });
    return {
      ...this.parent?.(),
      width: createSizeAttribute("width"),
      height: createSizeAttribute("height"),
      align: {
        default: null,
        parseHTML: (element) => {
          const align = element.getAttribute("data-align") || element.style.textAlign || element.parentElement?.style.textAlign;
          return align === "left" || align === "center" || align === "right" ? align : null;
        },
        renderHTML: (attributes) => {
          return attributes.align ? { "data-align": attributes.align } : {};
        }
      }
    };
  },
  addNodeView() {
    return ({ node, HTMLAttributes, getPos, editor }) => {
      const options = this.options;
      const enableResize = options.enableResize !== false;
      const dom = document.createElement("div");
      dom.className = "resizable-image-wrapper";
      dom.setAttribute("data-type", "resizable-image-wrapper");
      if (node.attrs.align) {
        dom.style.textAlign = node.attrs.align;
        dom.setAttribute("data-align", node.attrs.align);
      }
      const img = document.createElement("img");
      img.src = node.attrs.src;
      img.alt = node.attrs.alt || "";
      img.title = node.attrs.title || "";
      if (enableResize) {
        img.draggable = true;
        img.style.cursor = "move";
      }
      const updateImageSize = () => {
        if (node.attrs.width) {
          img.style.width = `${node.attrs.width}px`;
          img.style.height = "auto";
        } else if (node.attrs.height) {
          img.style.height = `${node.attrs.height}px`;
          img.style.width = "auto";
        } else {
          img.style.maxWidth = "100%";
          img.style.height = "auto";
        }
      };
      updateImageSize();
      img.onload = () => {
        if (!node.attrs.width && !node.attrs.height && img.naturalWidth > 0) {
          img.style.width = `${img.naturalWidth}px`;
          img.style.height = "auto";
        }
      };
      Object.entries(HTMLAttributes).forEach(([key, value]) => {
        if (key !== "width" && key !== "height" && key !== "src" && key !== "alt" && key !== "title") {
          img.setAttribute(key, value);
        }
      });
      let resizeHandle = null;
      if (enableResize) {
        resizeHandle = document.createElement("div");
        resizeHandle.className = "resize-handle";
        resizeHandle.setAttribute("contenteditable", "false");
        resizeHandle.draggable = false;
        dom.appendChild(resizeHandle);
      }
      dom.appendChild(img);
      dom.addEventListener("click", (e) => {
        if (enableResize && resizeHandle && (e.target === resizeHandle || resizeHandle.contains(e.target))) {
          return;
        }
        e.stopPropagation();
        const pos = typeof getPos === "function" ? getPos() : null;
        if (pos !== null && pos !== void 0) {
          editor.commands.setNodeSelection(pos);
        }
      });
      if (enableResize) {
        img.addEventListener("dragstart", (e) => {
          const pos = typeof getPos === "function" ? getPos() : null;
          if (pos !== null && pos !== void 0) {
            const { state: state2 } = editor;
            const nodeAtPos = state2.doc.nodeAt(pos);
            if (nodeAtPos && nodeAtPos.type.name === "image") {
              if (e.dataTransfer) {
                e.dataTransfer.effectAllowed = "move";
                const dragImage = img.cloneNode(true);
                dragImage.style.width = `${img.offsetWidth}px`;
                dragImage.style.height = `${img.offsetHeight}px`;
                dragImage.style.opacity = "0.5";
                document.body.appendChild(dragImage);
                e.dataTransfer.setDragImage(dragImage, img.offsetWidth / 2, img.offsetHeight / 2);
                setTimeout(() => {
                  if (document.body.contains(dragImage)) {
                    document.body.removeChild(dragImage);
                  }
                }, 0);
              }
            }
          }
        });
        if (resizeHandle) {
          resizeHandle.addEventListener("mousedown", (e) => {
            e.stopPropagation();
          });
        }
      }
      if (enableResize && resizeHandle) {
        let isResizing = false;
        let startX = 0;
        let startY = 0;
        let startWidth = 0;
        let startHeight = 0;
        let aspectRatio = 1;
        const handleMouseDown = (e) => {
          e.preventDefault();
          e.stopPropagation();
          img.draggable = false;
          isResizing = true;
          startX = e.clientX;
          startY = e.clientY;
          startWidth = node.attrs.width || img.offsetWidth || img.naturalWidth;
          startHeight = node.attrs.height || img.offsetHeight || img.naturalHeight;
          if (img.naturalWidth && img.naturalHeight) {
            aspectRatio = img.naturalHeight / img.naturalWidth;
          } else if (startWidth && startHeight) {
            aspectRatio = startHeight / startWidth;
          } else {
            aspectRatio = 1;
          }
          document.addEventListener("mousemove", handleMouseMove);
          document.addEventListener("mouseup", handleMouseUp);
          dom.classList.add("resizing");
        };
        const handleMouseMove = (e) => {
          if (!isResizing) return;
          const deltaX = e.clientX - startX;
          const deltaY = e.clientY - startY;
          const delta = Math.abs(deltaX) > Math.abs(deltaY) ? deltaX : deltaY;
          const newWidth = Math.max(50, Math.min(2e3, startWidth + delta));
          const newHeight = newWidth * aspectRatio;
          img.style.width = `${newWidth}px`;
          img.style.height = `${newHeight}px`;
        };
        const handleMouseUp = () => {
          if (!isResizing) return;
          isResizing = false;
          const finalWidth = parseInt(img.style.width, 10);
          const finalHeight = parseInt(img.style.height, 10);
          const pos = typeof getPos === "function" ? getPos() : null;
          if (pos !== null && pos !== void 0) {
            const { state: state2, view } = editor;
            const { tr } = state2;
            const nodeAtPos = tr.doc.nodeAt(pos);
            if (nodeAtPos && nodeAtPos.type.name === "image") {
              tr.setNodeMarkup(pos, void 0, {
                ...nodeAtPos.attrs,
                width: finalWidth,
                height: finalHeight
              });
              view.dispatch(tr);
            }
          }
          document.removeEventListener("mousemove", handleMouseMove);
          document.removeEventListener("mouseup", handleMouseUp);
          dom.classList.remove("resizing");
          img.draggable = true;
        };
        resizeHandle.addEventListener("mousedown", handleMouseDown);
      }
      return {
        dom,
        contentDOM: null,
        update: (updatedNode) => {
          if (updatedNode.attrs.src !== node.attrs.src) {
            img.src = updatedNode.attrs.src;
          }
          if (updatedNode.attrs.width !== node.attrs.width || updatedNode.attrs.height !== node.attrs.height) {
            if (updatedNode.attrs.width) {
              img.style.width = `${updatedNode.attrs.width}px`;
              img.style.height = "auto";
            } else if (updatedNode.attrs.height) {
              img.style.height = `${updatedNode.attrs.height}px`;
              img.style.width = "auto";
            } else {
              img.style.width = "";
              img.style.height = "";
              img.style.maxWidth = "100%";
            }
          }
          if (updatedNode.attrs.align !== node.attrs.align) {
            if (updatedNode.attrs.align) {
              dom.style.textAlign = updatedNode.attrs.align;
              dom.setAttribute("data-align", updatedNode.attrs.align);
            } else {
              dom.style.textAlign = "";
              dom.removeAttribute("data-align");
            }
          }
          node = updatedNode;
          return true;
        },
        destroy: () => {
        }
      };
    };
  },
  renderHTML({ HTMLAttributes }) {
    const { width, height, ...rest } = HTMLAttributes;
    const style = [];
    if (width) {
      style.push(`width: ${width}px`);
    }
    if (height) {
      style.push(`height: ${height}px`);
    }
    return [
      "img",
      {
        ...rest,
        ...style.length > 0 ? { style: style.join("; ") } : {}
      }
    ];
  }
});
const _sfc_main$o = /* @__PURE__ */ defineComponent({
  __name: "FontFamilySelect",
  props: {
    editor: {}
  },
  setup(__props) {
    const props = __props;
    const editor = computed(() => props.editor ?? null);
    const runCommand = createCommandRunner(editor);
    const currentFont = ref(DEFAULT_VALUES.fontFamily);
    watch(
      () => editor.value?.getAttributes("textStyle")?.fontFamily,
      (fontFamily) => {
        if (fontFamily) {
          currentFont.value = fontFamily;
        } else {
          currentFont.value = DEFAULT_VALUES.fontFamily;
        }
      },
      { deep: true, immediate: true }
    );
    function onFontChange(val) {
      const e = editor.value;
      if (!e) return;
      currentFont.value = val;
      const { from, to, empty } = e.state.selection;
      if (empty) {
        const $from = e.state.selection.$from;
        const start = $from.start($from.depth);
        const end = $from.end($from.depth);
        executeBatchCommands(editor, [
          (chain) => chain.setTextSelection({ from: start, to: end }),
          (chain) => chain.setFontFamily(val),
          (chain) => chain.setTextSelection({ from, to })
        ]);
      } else {
        runCommand((chain) => chain.setFontFamily(val))();
      }
    }
    return (_ctx, _cache) => {
      const _component_a_select_option = resolveComponent("a-select-option");
      const _component_a_select = resolveComponent("a-select");
      return openBlock(), createBlock(_component_a_select, {
        value: currentFont.value,
        "onUpdate:value": _cache[0] || (_cache[0] = ($event) => currentFont.value = $event),
        placeholder: unref(t)("toolbar.fontFamily"),
        class: "font-family-select",
        style: { "width": "140px" },
        onChange: onFontChange
      }, {
        default: withCtx(() => [
          (openBlock(true), createElementBlock(Fragment, null, renderList(unref(FONT_FAMILIES), (font) => {
            return openBlock(), createBlock(_component_a_select_option, {
              key: font.value,
              value: font.value
            }, {
              default: withCtx(() => [
                createTextVNode(toDisplayString(font.label), 1)
              ]),
              _: 2
            }, 1032, ["value"]);
          }), 128))
        ]),
        _: 1
      }, 8, ["value", "placeholder"]);
    };
  }
});
const FontFamilySelect = /* @__PURE__ */ _export_sfc(_sfc_main$o, [["__scopeId", "data-v-aaad180f"]]);
const _sfc_main$n = /* @__PURE__ */ defineComponent({
  __name: "FontSizeSelect",
  props: {
    editor: {}
  },
  setup(__props) {
    const props = __props;
    const editor = computed(() => props.editor ?? null);
    const runCommand = createCommandRunner(editor);
    const currentFontSize = ref(DEFAULT_VALUES.fontSize);
    watch(
      () => editor.value?.getAttributes("textStyle")?.fontSize,
      (fontSize) => {
        if (fontSize) {
          currentFontSize.value = fontSize;
        } else {
          currentFontSize.value = DEFAULT_VALUES.fontSize;
        }
      },
      { deep: true, immediate: true }
    );
    function onFontSizeChange(val) {
      const e = editor.value;
      if (!e) return;
      currentFontSize.value = val;
      const { from, to, empty } = e.state.selection;
      if (empty) {
        const $from = e.state.selection.$from;
        const start = $from.start($from.depth);
        const end = $from.end($from.depth);
        executeBatchCommands(editor, [
          (chain) => chain.setTextSelection({ from: start, to: end }),
          (chain) => chain.setMark("textStyle", { fontSize: val }),
          (chain) => chain.setTextSelection({ from, to })
        ]);
      } else {
        runCommand((chain) => chain.setMark("textStyle", { fontSize: val }))();
      }
    }
    return (_ctx, _cache) => {
      const _component_a_select_option = resolveComponent("a-select-option");
      const _component_a_select = resolveComponent("a-select");
      return openBlock(), createBlock(_component_a_select, {
        value: currentFontSize.value,
        "onUpdate:value": _cache[0] || (_cache[0] = ($event) => currentFontSize.value = $event),
        placeholder: unref(t)("toolbar.fontSize"),
        class: "font-size-select",
        style: { "width": "100px" },
        onChange: onFontSizeChange
      }, {
        default: withCtx(() => [
          (openBlock(true), createElementBlock(Fragment, null, renderList(unref(FONT_SIZES), (size) => {
            return openBlock(), createBlock(_component_a_select_option, {
              key: size.value,
              value: size.value
            }, {
              default: withCtx(() => [
                createTextVNode(toDisplayString(size.label), 1)
              ]),
              _: 2
            }, 1032, ["value"]);
          }), 128))
        ]),
        _: 1
      }, 8, ["value", "placeholder"]);
    };
  }
});
const FontSizeSelect = /* @__PURE__ */ _export_sfc(_sfc_main$n, [["__scopeId", "data-v-00e6ab62"]]);
const FontSize = Extension.create({
  name: "fontSize",
  addOptions() {
    return {
      types: ["textStyle"]
    };
  },
  addGlobalAttributes() {
    return [
      {
        types: this.options.types,
        attributes: {
          fontSize: {
            default: null,
            parseHTML: (element) => element.style.fontSize || null,
            renderHTML: (attributes) => {
              if (!attributes.fontSize) {
                return {};
              }
              return {
                style: `font-size: ${attributes.fontSize}`
              };
            }
          }
        }
      }
    ];
  },
  addCommands() {
    return {
      setFontSize: (fontSize) => ({ chain }) => {
        return chain().setMark("textStyle", { fontSize }).run();
      },
      unsetFontSize: () => ({ chain }) => {
        return chain().setMark("textStyle", { fontSize: null }).removeEmptyTextStyle().run();
      }
    };
  }
});
const LineHeight = Extension.create({
  name: "lineHeight",
  addOptions() {
    return {
      types: ["paragraph", "heading"],
      defaultLineHeight: "1.5"
    };
  },
  addGlobalAttributes() {
    return [
      {
        types: this.options.types,
        attributes: {
          lineHeight: {
            default: this.options.defaultLineHeight,
            parseHTML: (element) => element.style.lineHeight || this.options.defaultLineHeight,
            renderHTML: (attributes) => {
              if (!attributes.lineHeight) {
                return {};
              }
              return {
                style: `line-height: ${attributes.lineHeight}`
              };
            }
          }
        }
      }
    ];
  },
  addCommands() {
    return {
      setLineHeight: (lineHeight) => ({ commands }) => {
        return this.options.types.every((type) => commands.updateAttributes(type, { lineHeight }));
      },
      unsetLineHeight: () => ({ commands }) => {
        return this.options.types.every((type) => commands.updateAttributes(type, { lineHeight: null }));
      }
    };
  }
});
const _sfc_main$m = /* @__PURE__ */ defineComponent({
  __name: "ClearFormatButton",
  props: {
    editor: {}
  },
  setup(__props) {
    const props = __props;
    const editor = computed(() => props.editor ?? null);
    const runCommand = createCommandRunner(editor);
    function clearFormat() {
      runCommand((chain) => chain.clearNodes().unsetAllMarks())();
    }
    return (_ctx, _cache) => {
      return openBlock(), createBlock(unref(ToolbarGroup), null, {
        default: withCtx(() => [
          createVNode(unref(_sfc_main$z), {
            icon: unref(ClearOutlined),
            title: unref(t)("editor.clearFormat"),
            onClick: clearFormat
          }, null, 8, ["icon", "title"])
        ]),
        _: 1
      });
    };
  }
});
const _sfc_main$l = /* @__PURE__ */ defineComponent({
  __name: "LinkButton",
  props: {
    editor: {}
  },
  setup(__props) {
    const props = __props;
    const editor = computed(() => props.editor ?? null);
    const linkModalOpen = ref(false);
    const linkUrl = ref("");
    const runCommand = createCommandRunner(editor);
    const { isActive } = createStateCheckers(editor);
    function handleClick() {
      const e = editor.value;
      if (!e) return;
      if (e.isActive("link")) {
        linkUrl.value = e.getAttributes("link")?.href ?? "";
      } else {
        linkUrl.value = "";
      }
      linkModalOpen.value = true;
    }
    function isValidUrl(url) {
      try {
        const parsed = new URL(url);
        return parsed.protocol === "http:" || parsed.protocol === "https:";
      } catch {
        return false;
      }
    }
    function buildLinkAttrs(href) {
      return {
        href,
        target: "_blank",
        rel: "noopener noreferrer"
      };
    }
    function applyLink() {
      const rawUrl = linkUrl.value.trim();
      const e = editor.value;
      if (!e) return;
      if (!rawUrl) {
        runCommand((chain2) => chain2.unsetLink())();
        linkModalOpen.value = false;
        linkUrl.value = "";
        return;
      }
      if (!isValidUrl(rawUrl)) {
        message.warning(t("editor.enterValidLink"));
        return;
      }
      const hasSelection = !e.state.selection.empty;
      const chain = e.chain().focus();
      if (hasSelection) {
        chain.extendMarkRange("link").setLink(buildLinkAttrs(rawUrl)).run();
      } else {
        chain.insertContent([
          {
            type: "text",
            text: rawUrl,
            marks: [{ type: "link", attrs: buildLinkAttrs(rawUrl) }]
          }
        ]).run();
      }
      linkModalOpen.value = false;
      linkUrl.value = "";
    }
    return (_ctx, _cache) => {
      const _component_a_input = resolveComponent("a-input");
      const _component_a_modal = resolveComponent("a-modal");
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(unref(ToolbarGroup), null, {
          default: withCtx(() => [
            createVNode(unref(_sfc_main$z), {
              icon: unref(LinkOutlined),
              title: unref(t)("editor.link"),
              active: unref(isActive)("link"),
              onClick: handleClick
            }, null, 8, ["icon", "title", "active"])
          ]),
          _: 1
        }),
        createVNode(_component_a_modal, {
          open: linkModalOpen.value,
          "onUpdate:open": _cache[1] || (_cache[1] = ($event) => linkModalOpen.value = $event),
          title: unref(t)("editor.insertLink"),
          onOk: applyLink,
          width: "400px"
        }, {
          default: withCtx(() => [
            createVNode(_component_a_input, {
              value: linkUrl.value,
              "onUpdate:value": _cache[0] || (_cache[0] = ($event) => linkUrl.value = $event),
              placeholder: unref(t)("editor.linkPlaceholder"),
              onKeyup: withKeys(applyLink, ["enter"])
            }, null, 8, ["value", "placeholder"])
          ]),
          _: 1
        }, 8, ["open", "title"])
      ], 64);
    };
  }
});
const _hoisted_1$g = { class: "table-insert-panel" };
const _hoisted_2$f = ["onMouseenter", "onClick"];
const _hoisted_3$e = { class: "attrs" };
const _hoisted_4$d = { class: "attr-row" };
const _hoisted_5$d = { class: "table-toolbar-section" };
const _hoisted_6$d = { class: "table-menu-row" };
const _hoisted_7$c = { class: "table-menu-group" };
const _hoisted_8$9 = ["disabled", "onClick", "title"];
const _hoisted_9$9 = { class: "table-menu-group" };
const _hoisted_10$7 = ["disabled", "onClick", "title"];
const _hoisted_11$7 = { class: "table-menu-row" };
const _hoisted_12$6 = { class: "table-menu-group" };
const _hoisted_13$5 = ["disabled", "onClick", "title"];
const gridRows = 10;
const gridCols = 10;
const _sfc_main$k = /* @__PURE__ */ defineComponent({
  __name: "TableButton",
  props: {
    editor: {}
  },
  setup(__props) {
    const props = __props;
    const editor = computed(() => props.editor ?? null);
    const runCommand = createCommandRunner(editor);
    const { canExecute } = createStateCheckers(editor);
    const rowTools = [
      {
        name: "addRowBefore",
        icon: InsertRowAboveOutlined,
        title: t("table.addRowBefore"),
        command: "addRowBefore",
        action: runCommand((chain) => chain.addRowBefore())
      },
      {
        name: "addRowAfter",
        icon: InsertRowBelowOutlined,
        title: t("table.addRowAfter"),
        command: "addRowAfter",
        action: runCommand((chain) => chain.addRowAfter())
      },
      {
        name: "deleteRow",
        icon: DeleteRowOutlined,
        title: t("table.deleteRow"),
        command: "deleteRow",
        action: runCommand((chain) => chain.deleteRow())
      }
    ];
    const columnTools = [
      {
        name: "addColumnBefore",
        icon: InsertRowLeftOutlined,
        title: t("table.addColumnBefore"),
        command: "addColumnBefore",
        action: runCommand((chain) => chain.addColumnBefore())
      },
      {
        name: "addColumnAfter",
        icon: InsertRowRightOutlined,
        title: t("table.addColumnAfter"),
        command: "addColumnAfter",
        action: runCommand((chain) => chain.addColumnAfter())
      },
      {
        name: "deleteColumn",
        icon: DeleteColumnOutlined,
        title: t("table.deleteColumn"),
        command: "deleteColumn",
        action: runCommand((chain) => chain.deleteColumn())
      }
    ];
    const cellTools = [
      {
        name: "mergeCells",
        icon: MergeCellsOutlined,
        title: t("table.mergeCells"),
        command: "mergeCells",
        action: runCommand((chain) => chain.mergeCells())
      },
      {
        name: "splitCell",
        icon: SplitCellsOutlined,
        title: t("table.splitCell"),
        command: "splitCell",
        action: runCommand((chain) => chain.splitCell())
      },
      {
        name: "toggleHeaderRow",
        icon: TableOutlined,
        title: t("table.toggleHeaderRow"),
        command: "toggleHeaderRow",
        action: runCommand((chain) => chain.toggleHeaderRow())
      },
      {
        name: "toggleHeaderColumn",
        icon: TableOutlined,
        title: t("table.toggleHeaderColumn"),
        command: "toggleHeaderColumn",
        action: runCommand((chain) => chain.toggleHeaderColumn())
      }
    ];
    const tableDropdownOpen = ref(false);
    const tableWithHeader = ref(true);
    const hoverRows = ref(0);
    const hoverCols = ref(0);
    function setHover(r, c) {
      hoverRows.value = r;
      hoverCols.value = c;
    }
    function resetGridHover() {
      hoverRows.value = 0;
      hoverCols.value = 0;
    }
    function applyCreateTable(rows, cols) {
      const r = Math.max(1, Number(rows));
      const c = Math.max(1, Number(cols));
      runCommand((chain) => chain.insertTable({ rows: r, cols: c, withHeaderRow: tableWithHeader.value }))();
      tableDropdownOpen.value = false;
    }
    function deleteTable() {
      runCommand((chain) => chain.deleteTable())();
    }
    return (_ctx, _cache) => {
      const _component_a_checkbox = resolveComponent("a-checkbox");
      const _component_a_button = resolveComponent("a-button");
      return openBlock(), createBlock(unref(ToolbarGroup), null, {
        default: withCtx(() => [
          createVNode(unref(Popover), {
            trigger: "click",
            placement: "bottomLeft",
            open: tableDropdownOpen.value,
            "onUpdate:open": _cache[2] || (_cache[2] = ($event) => tableDropdownOpen.value = $event)
          }, {
            content: withCtx(() => [
              createElementVNode("div", _hoisted_1$g, [
                createElementVNode("div", {
                  class: "grid",
                  onMouseleave: resetGridHover
                }, [
                  (openBlock(), createElementBlock(Fragment, null, renderList(gridRows, (r) => {
                    return createElementVNode("div", {
                      key: "r-" + r,
                      class: "grid-row"
                    }, [
                      (openBlock(), createElementBlock(Fragment, null, renderList(gridCols, (c) => {
                        return createElementVNode("div", {
                          key: "c-" + r + "-" + c,
                          class: normalizeClass(["grid-cell", r <= hoverRows.value && c <= hoverCols.value ? "active" : ""]),
                          onMouseenter: ($event) => setHover(r, c),
                          onClick: ($event) => applyCreateTable(r, c)
                        }, null, 42, _hoisted_2$f);
                      }), 64))
                    ]);
                  }), 64))
                ], 32),
                createElementVNode("div", _hoisted_3$e, [
                  createElementVNode("div", _hoisted_4$d, [
                    createVNode(_component_a_checkbox, {
                      checked: tableWithHeader.value,
                      "onUpdate:checked": _cache[0] || (_cache[0] = ($event) => tableWithHeader.value = $event)
                    }, {
                      default: withCtx(() => [
                        createTextVNode(toDisplayString(unref(t)("editor.includeHeader")), 1)
                      ]),
                      _: 1
                    }, 8, ["checked"])
                  ]),
                  createElementVNode("div", _hoisted_5$d, [
                    createElementVNode("div", _hoisted_6$d, [
                      createElementVNode("div", _hoisted_7$c, [
                        (openBlock(), createElementBlock(Fragment, null, renderList(rowTools, (item) => {
                          return createElementVNode("button", {
                            key: item.name,
                            class: "table-menu-btn",
                            disabled: !unref(canExecute)(item.command),
                            onClick: item.action,
                            title: item.title
                          }, [
                            (openBlock(), createBlock(resolveDynamicComponent(item.icon)))
                          ], 8, _hoisted_8$9);
                        }), 64))
                      ]),
                      createElementVNode("div", _hoisted_9$9, [
                        (openBlock(), createElementBlock(Fragment, null, renderList(columnTools, (item) => {
                          return createElementVNode("button", {
                            key: item.name,
                            class: "table-menu-btn",
                            disabled: !unref(canExecute)(item.command),
                            onClick: item.action,
                            title: item.title
                          }, [
                            (openBlock(), createBlock(resolveDynamicComponent(item.icon)))
                          ], 8, _hoisted_10$7);
                        }), 64))
                      ])
                    ]),
                    createElementVNode("div", _hoisted_11$7, [
                      createElementVNode("div", _hoisted_12$6, [
                        (openBlock(), createElementBlock(Fragment, null, renderList(cellTools, (item) => {
                          return createElementVNode("button", {
                            key: item.name,
                            class: "table-menu-btn",
                            disabled: !unref(canExecute)(item.command),
                            onClick: item.action,
                            title: item.title
                          }, [
                            (openBlock(), createBlock(resolveDynamicComponent(item.icon)))
                          ], 8, _hoisted_13$5);
                        }), 64))
                      ])
                    ])
                  ]),
                  createVNode(_component_a_button, {
                    type: "primary",
                    danger: "",
                    block: "",
                    disabled: !editor.value?.isActive("table"),
                    onClick: _cache[1] || (_cache[1] = ($event) => {
                      deleteTable();
                      tableDropdownOpen.value = false;
                    })
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(unref(t)("editor.deleteTable")), 1)
                    ]),
                    _: 1
                  }, 8, ["disabled"])
                ])
              ])
            ]),
            default: withCtx(() => [
              createVNode(unref(_sfc_main$z), {
                icon: unref(TableOutlined),
                title: unref(t)("editor.insertTable")
              }, null, 8, ["icon", "title"])
            ]),
            _: 1
          }, 8, ["open"])
        ]),
        _: 1
      });
    };
  }
});
const TableButton = /* @__PURE__ */ _export_sfc(_sfc_main$k, [["__scopeId", "data-v-94c8671a"]]);
const _hoisted_1$f = { class: "table-menu-content" };
const _hoisted_2$e = { class: "table-menu-row" };
const _hoisted_3$d = { class: "table-menu-group" };
const _hoisted_4$c = ["disabled", "onClick", "title"];
const _hoisted_5$c = { class: "table-menu-group" };
const _hoisted_6$c = ["disabled", "onClick", "title"];
const _hoisted_7$b = { class: "table-menu-row" };
const _hoisted_8$8 = { class: "table-menu-group" };
const _hoisted_9$8 = ["disabled", "onClick", "title"];
const _hoisted_10$6 = { class: "table-menu-group" };
const _hoisted_11$6 = ["title"];
const _sfc_main$j = /* @__PURE__ */ defineComponent({
  __name: "TableToolbar",
  props: {
    editor: {},
    readonly: { type: Boolean, default: false },
    showMode: { default: 2 },
    enabled: { type: Boolean, default: false }
  },
  setup(__props) {
    const props = __props;
    const editor = computed(() => props.editor ?? null);
    const runCommand = createCommandRunner(editor);
    const { canExecute } = createStateCheckers(editor);
    const rowTools = [
      {
        name: "addRowBefore",
        icon: InsertRowAboveOutlined,
        title: t("table.addRowBefore"),
        command: "addRowBefore",
        action: runCommand((chain) => chain.addRowBefore())
      },
      {
        name: "addRowAfter",
        icon: InsertRowBelowOutlined,
        title: t("table.addRowAfter"),
        command: "addRowAfter",
        action: runCommand((chain) => chain.addRowAfter())
      },
      {
        name: "deleteRow",
        icon: DeleteRowOutlined,
        title: t("table.deleteRow"),
        command: "deleteRow",
        action: runCommand((chain) => chain.deleteRow())
      }
    ];
    const columnTools = [
      {
        name: "addColumnBefore",
        icon: InsertRowLeftOutlined,
        title: t("table.addColumnBefore"),
        command: "addColumnBefore",
        action: runCommand((chain) => chain.addColumnBefore())
      },
      {
        name: "addColumnAfter",
        icon: InsertRowRightOutlined,
        title: t("table.addColumnAfter"),
        command: "addColumnAfter",
        action: runCommand((chain) => chain.addColumnAfter())
      },
      {
        name: "deleteColumn",
        icon: DeleteColumnOutlined,
        title: t("table.deleteColumn"),
        command: "deleteColumn",
        action: runCommand((chain) => chain.deleteColumn())
      }
    ];
    const cellTools = [
      {
        name: "mergeCells",
        icon: MergeCellsOutlined,
        title: t("table.mergeCells"),
        command: "mergeCells",
        action: runCommand((chain) => chain.mergeCells())
      },
      {
        name: "splitCell",
        icon: SplitCellsOutlined,
        title: t("table.splitCell"),
        command: "splitCell",
        action: runCommand((chain) => chain.splitCell())
      },
      {
        name: "toggleHeaderRow",
        icon: TableOutlined,
        title: t("table.toggleHeaderRow"),
        command: "toggleHeaderRow",
        action: runCommand((chain) => chain.toggleHeaderRow())
      },
      {
        name: "toggleHeaderColumn",
        icon: TableOutlined,
        title: t("table.toggleHeaderColumn"),
        command: "toggleHeaderColumn",
        action: runCommand((chain) => chain.toggleHeaderColumn())
      }
    ];
    const shouldShow = (bubbleProps) => {
      if (!props.enabled) return false;
      if (props.readonly) return false;
      if (props.showMode === 1) {
        if (!bubbleProps.editor.isActive("table")) return false;
      }
      if (props.showMode === 2) {
        const sel = bubbleProps.state?.selection;
        return sel instanceof CellSelection;
      }
      return true;
    };
    function deleteTable() {
      runCommand((chain) => chain.deleteTable())();
    }
    return (_ctx, _cache) => {
      return editor.value && __props.enabled ? (openBlock(), createBlock(unref(BubbleMenu), {
        key: 0,
        editor: editor.value,
        "tippy-options": { duration: 100, placement: "top", offset: [0, 16] },
        "should-show": shouldShow,
        class: "table-bubble-menu"
      }, {
        default: withCtx(() => [
          createElementVNode("div", _hoisted_1$f, [
            createElementVNode("div", _hoisted_2$e, [
              createElementVNode("div", _hoisted_3$d, [
                (openBlock(), createElementBlock(Fragment, null, renderList(rowTools, (item) => {
                  return createElementVNode("button", {
                    key: item.name,
                    class: "table-menu-btn",
                    disabled: !unref(canExecute)(item.command),
                    onClick: item.action,
                    title: item.title
                  }, [
                    (openBlock(), createBlock(resolveDynamicComponent(item.icon)))
                  ], 8, _hoisted_4$c);
                }), 64))
              ]),
              createElementVNode("div", _hoisted_5$c, [
                (openBlock(), createElementBlock(Fragment, null, renderList(columnTools, (item) => {
                  return createElementVNode("button", {
                    key: item.name,
                    class: "table-menu-btn",
                    disabled: !unref(canExecute)(item.command),
                    onClick: item.action,
                    title: item.title
                  }, [
                    (openBlock(), createBlock(resolveDynamicComponent(item.icon)))
                  ], 8, _hoisted_6$c);
                }), 64))
              ])
            ]),
            createElementVNode("div", _hoisted_7$b, [
              createElementVNode("div", _hoisted_8$8, [
                (openBlock(), createElementBlock(Fragment, null, renderList(cellTools, (item) => {
                  return createElementVNode("button", {
                    key: item.name,
                    class: "table-menu-btn",
                    disabled: !unref(canExecute)(item.command),
                    onClick: item.action,
                    title: item.title
                  }, [
                    (openBlock(), createBlock(resolveDynamicComponent(item.icon)))
                  ], 8, _hoisted_9$8);
                }), 64))
              ]),
              createElementVNode("div", _hoisted_10$6, [
                createElementVNode("button", {
                  class: "table-menu-btn table-menu-btn--danger",
                  onClick: deleteTable,
                  title: unref(t)("editor.deleteTable")
                }, [
                  createVNode(unref(DeleteOutlined))
                ], 8, _hoisted_11$6)
              ])
            ])
          ])
        ]),
        _: 1
      }, 8, ["editor"])) : createCommentVNode("", true);
    };
  }
});
const TableToolbar = /* @__PURE__ */ _export_sfc(_sfc_main$j, [["__scopeId", "data-v-a3a454d4"]]);
TableCell.extend({
  addAttributes() {
    return {
      // 继承父类的所有属性
      ...this.parent?.(),
      // 添加 backgroundColor 属性
      backgroundColor: {
        default: null,
        parseHTML: (element) => element.getAttribute("data-background-color") || element.style.backgroundColor || null,
        renderHTML: (attributes) => {
          if (!attributes.backgroundColor) {
            return {};
          }
          return {
            "data-background-color": attributes.backgroundColor,
            style: `background-color: ${attributes.backgroundColor}`
          };
        }
      },
      // 添加 textAlign 属性（如果 TableToolbar 需要）
      textAlign: {
        default: null,
        parseHTML: (element) => element.getAttribute("data-text-align") || element.style.textAlign || null,
        renderHTML: (attributes) => {
          if (!attributes.textAlign) {
            return {};
          }
          return {
            "data-text-align": attributes.textAlign,
            style: `text-align: ${attributes.textAlign}`
          };
        }
      }
    };
  }
});
const _sfc_main$i = /* @__PURE__ */ defineComponent({
  __name: "SubscriptSuperscriptButton",
  props: {
    editor: {}
  },
  setup(__props) {
    const props = __props;
    const editor = computed(() => props.editor ?? null);
    const { isActive } = createStateCheckers(editor);
    const formats = computed(() => [
      {
        name: "superscript",
        icon: SortDescendingOutlined,
        title: t("editor.superscript"),
        action: () => {
          const e = editor.value;
          if (!e) return;
          e.chain().focus().toggleSuperscript().run();
        }
      },
      {
        name: "subscript",
        icon: SortAscendingOutlined,
        title: t("editor.subscript"),
        action: () => {
          const e = editor.value;
          if (!e) return;
          e.chain().focus().toggleSubscript().run();
        }
      }
    ]);
    return (_ctx, _cache) => {
      return openBlock(), createBlock(unref(ToolbarGroup), null, {
        default: withCtx(() => [
          (openBlock(true), createElementBlock(Fragment, null, renderList(formats.value, (format) => {
            return openBlock(), createBlock(unref(_sfc_main$z), {
              key: format.name,
              icon: format.icon,
              title: format.title,
              active: unref(isActive)(format.name),
              onClick: format.action
            }, null, 8, ["icon", "title", "active", "onClick"]);
          }), 128))
        ]),
        _: 1
      });
    };
  }
});
const _sfc_main$h = /* @__PURE__ */ defineComponent({
  __name: "UndoRedoButton",
  props: {
    editor: {},
    disabled: { type: Boolean, default: false }
  },
  setup(__props) {
    const props = __props;
    const editor = computed(() => props.editor ?? null);
    const runCommand = createCommandRunner(editor);
    const canUndo = ref(false);
    const canRedo = ref(false);
    const hasRealEdit = ref(false);
    function updateUndoRedoState() {
      const e = editor.value;
      if (!e) {
        canUndo.value = false;
        canRedo.value = false;
        return;
      }
      try {
        const undoCheck = e.can().undo?.();
        const redoCheck = e.can().redo?.();
        canUndo.value = undoCheck && hasRealEdit.value;
        canRedo.value = Boolean(redoCheck);
      } catch (error) {
        canUndo.value = false;
        canRedo.value = false;
      }
    }
    function handleUpdate() {
      const e = editor.value;
      if (!e) return;
      hasRealEdit.value = true;
      updateUndoRedoState();
    }
    function setupEditorSubscriptions() {
      cleanupEditorSubscriptions();
      const e = editor.value;
      if (!e) return;
      hasRealEdit.value = false;
      nextTick(() => {
        updateUndoRedoState();
        e.on("update", handleUpdate);
        e.on("selectionUpdate", updateUndoRedoState);
        e.on("transaction", updateUndoRedoState);
        e.on("create", () => {
          hasRealEdit.value = false;
          updateUndoRedoState();
        });
      });
    }
    function cleanupEditorSubscriptions() {
      const e = editor.value;
      if (!e) return;
      try {
        e.off("update", handleUpdate);
        e.off("selectionUpdate", updateUndoRedoState);
        e.off("transaction", updateUndoRedoState);
        e.off("create", updateUndoRedoState);
      } catch (error) {
      }
    }
    if (editor.value) setupEditorSubscriptions();
    watch(editor, setupEditorSubscriptions, { immediate: true });
    onBeforeUnmount(() => {
      cleanupEditorSubscriptions();
    });
    const undo = runCommand((chain) => chain.undo());
    const redo = runCommand((chain) => chain.redo());
    return (_ctx, _cache) => {
      return openBlock(), createBlock(unref(ToolbarGroup), null, {
        default: withCtx(() => [
          createVNode(unref(_sfc_main$z), {
            icon: unref(UndoOutlined),
            title: __props.disabled ? unref(t)("editor.undoDisabledInCollab") : unref(t)("editor.undo"),
            disabled: __props.disabled || !canUndo.value,
            onClick: unref(undo)
          }, null, 8, ["icon", "title", "disabled", "onClick"]),
          createVNode(unref(_sfc_main$z), {
            icon: unref(RedoOutlined),
            title: __props.disabled ? unref(t)("editor.redoDisabledInCollab") : unref(t)("editor.redo"),
            disabled: __props.disabled || !canRedo.value,
            onClick: unref(redo)
          }, null, 8, ["icon", "title", "disabled", "onClick"])
        ]),
        _: 1
      });
    };
  }
});
const STORAGE_KEY$2 = "tiptap-format-painter-formats";
function sampleFormats(editor) {
  try {
    const formats = {};
    formats.bold = editor.isActive("bold");
    formats.italic = editor.isActive("italic");
    formats.underline = editor.isActive("underline");
    formats.strike = editor.isActive("strike");
    formats.subscript = editor.isActive("subscript");
    formats.superscript = editor.isActive("superscript");
    const textStyleAttrs = editor.getAttributes("textStyle");
    formats.color = textStyleAttrs?.color ?? null;
    formats.fontFamily = textStyleAttrs?.fontFamily ?? null;
    formats.fontSize = textStyleAttrs?.fontSize ?? null;
    formats.lineHeight = textStyleAttrs?.lineHeight ?? null;
    const highlightAttrs = editor.getAttributes("highlight");
    formats.highlight = highlightAttrs?.color ?? null;
    const paragraphAttrs = editor.getAttributes("paragraph");
    const headingAttrs = editor.getAttributes("heading");
    formats.textAlign = paragraphAttrs?.textAlign ?? headingAttrs?.textAlign ?? null;
    return formats;
  } catch (error) {
    return null;
  }
}
function saveFormatsToStorage(formats) {
  try {
    localStorage.setItem(STORAGE_KEY$2, JSON.stringify(formats));
  } catch (error) {
  }
}
function loadFormatsFromStorage() {
  try {
    const data = localStorage.getItem(STORAGE_KEY$2);
    if (data) {
      return JSON.parse(data);
    }
  } catch (error) {
  }
  return null;
}
function clearFormatsFromStorage() {
  try {
    localStorage.removeItem(STORAGE_KEY$2);
  } catch (error) {
  }
}
function updateCursorStyle(editor, add) {
  try {
    const dom = editor.view.dom;
    if (add) {
      dom.classList.add("cursor-format-painter");
    } else {
      dom.classList.remove("cursor-format-painter");
    }
  } catch (error) {
  }
}
function isCollaborationMultiUser(editor) {
  try {
    const hasCollaboration = editor.extensionManager.extensions.some((ext) => ext.name === "collaboration");
    if (!hasCollaboration) return false;
    const anyEditor = editor;
    const count = Number(anyEditor?.storage?.__collaborationUsersCount ?? 0);
    return count > 1;
  } catch (error) {
    return false;
  }
}
const FormatPainter = Extension.create({
  name: "formatPainter",
  addStorage() {
    const savedFormats = loadFormatsFromStorage();
    return {
      isActive: false,
      isContinuous: false,
      formats: savedFormats || {}
    };
  },
  addCommands() {
    return {
      /**
       * 采样当前选区的格式
       * @param mode - 模式：1 为单次模式（默认），2 为连续模式
       * @description 获取选中文本的所有格式信息并保存，根据 mode 决定是单次还是连续应用
       */
      startFormatPainting: (mode) => ({ editor }) => {
        if (isCollaborationMultiUser(editor)) {
          return false;
        }
        try {
          const sel = editor.state.selection;
          if (!sel || sel.empty) {
            return false;
          }
        } catch (error) {
          return false;
        }
        const formats = sampleFormats(editor);
        if (!formats) {
          return false;
        }
        this.storage.formats = formats;
        this.storage.isActive = true;
        this.storage.isContinuous = mode === 2;
        saveFormatsToStorage(formats);
        updateCursorStyle(editor, true);
        return true;
      },
      /**
       * 采样当前选区的格式（连续应用模式）
       * @description 获取选中文本的所有格式信息并保存，可以连续应用多次
       */
      startContinuousFormatPainting: () => ({ editor }) => {
        if (isCollaborationMultiUser(editor)) {
          return false;
        }
        try {
          const sel = editor.state.selection;
          if (!sel || sel.empty) {
            return false;
          }
        } catch (error) {
          return false;
        }
        const formats = sampleFormats(editor);
        if (!formats) {
          return false;
        }
        this.storage.formats = formats;
        this.storage.isActive = true;
        this.storage.isContinuous = true;
        saveFormatsToStorage(formats);
        updateCursorStyle(editor, true);
        return true;
      },
      /**
       * 将保存的格式应用到当前选区
       * @description 将之前采样的格式应用到当前选中的文本
       */
      applyFormat: () => ({ editor }) => {
        if (isCollaborationMultiUser(editor)) {
          if (this.storage.isActive) {
            this.storage.isActive = false;
            this.storage.isContinuous = false;
            updateCursorStyle(editor, false);
          }
          return false;
        }
        if (!this.storage.isActive) {
          return false;
        }
        try {
          const sel = editor.state.selection;
          if (!sel || sel.empty) {
            return false;
          }
        } catch (error) {
          return false;
        }
        let formats = this.storage.formats;
        if (!formats || Object.keys(formats).length === 0) {
          const savedFormats = loadFormatsFromStorage();
          if (savedFormats) {
            this.storage.formats = savedFormats;
            formats = savedFormats;
          }
        }
        if (!formats || Object.keys(formats).length === 0) {
          return false;
        }
        const { from, to } = editor.state.selection;
        try {
          const chain = editor.chain().focus();
          if (formats.bold) chain.setMark("bold");
          else chain.unsetMark("bold");
          if (formats.italic) chain.setMark("italic");
          else chain.unsetMark("italic");
          if (formats.underline) chain.setMark("underline");
          else chain.unsetMark("underline");
          if (formats.strike) chain.setMark("strike");
          else chain.unsetMark("strike");
          chain.unsetMark("subscript").unsetMark("superscript");
          if (formats.subscript) chain.setMark("subscript");
          else if (formats.superscript) chain.setMark("superscript");
          const textStyleAttrs = {};
          if (formats.color) textStyleAttrs.color = formats.color;
          if (formats.fontFamily) textStyleAttrs.fontFamily = formats.fontFamily;
          if (formats.fontSize) textStyleAttrs.fontSize = formats.fontSize;
          if (Object.keys(textStyleAttrs).length > 0) {
            chain.setMark("textStyle", textStyleAttrs);
          } else {
            chain.unsetMark("textStyle");
          }
          if (formats.highlight) {
            ;
            chain.setHighlight({ color: formats.highlight });
          } else {
            ;
            chain.unsetHighlight?.();
          }
          chain.run();
          if (formats.textAlign) {
            editor.chain().focus().setTextSelection({ from, to }).setTextAlign(formats.textAlign).run();
          }
          if (formats.lineHeight) {
            editor.chain().focus().setTextSelection({ from, to }).setLineHeight(formats.lineHeight).run();
          }
        } catch (error) {
          return false;
        }
        if (!this.storage.isContinuous) {
          this.storage.isActive = false;
          updateCursorStyle(editor, false);
        }
        return true;
      },
      /**
       * 取消格式刷状态并清除缓存
       * @description 清除格式刷的激活状态、保存的格式信息以及浏览器缓存
       */
      cancelFormatPainting: () => ({ editor }) => {
        this.storage.isActive = false;
        this.storage.isContinuous = false;
        this.storage.formats = {};
        clearFormatsFromStorage();
        updateCursorStyle(editor, false);
        return true;
      },
      /**
       * 切换连续应用模式
       * @description 切换格式刷的连续应用模式开关
       */
      toggleContinuousMode: () => () => {
        this.storage.isContinuous = !this.storage.isContinuous;
        return true;
      }
    };
  },
  addProseMirrorPlugins() {
    const ext = this;
    return [
      new Plugin({
        props: {
          // 监听键盘事件，ESC 键退出格式刷
          handleKeyDown(_view, event) {
            const storage = ext.storage;
            if (storage.isActive && event.key === "Escape") {
              ext.editor?.commands.cancelFormatPainting();
              return true;
            }
            return false;
          },
          // 监听鼠标抬起事件，在格式刷激活时自动应用格式
          handleDOMEvents: {
            mouseup: () => {
              const storage = ext.storage;
              if (storage.isActive && ext.editor) {
                requestAnimationFrame(() => {
                  if (!storage.isActive || !ext.editor) {
                    return;
                  }
                  try {
                    const { state: state2 } = ext.editor;
                    const { empty } = state2.selection;
                    if (!empty) {
                      ext.editor.commands.applyFormat();
                    }
                  } catch (error) {
                  }
                });
              }
              return false;
            }
          }
        }
      })
    ];
  }
});
const _sfc_main$g = /* @__PURE__ */ defineComponent({
  __name: "FormatPainterButton",
  props: {
    editor: {},
    disabled: { type: Boolean, default: void 0 }
  },
  setup(__props) {
    const props = __props;
    const editor = computed(() => props.editor ?? null);
    const isDisabled = computed(() => {
      if (props.disabled !== void 0) {
        return props.disabled;
      }
      const e = editor.value;
      if (!e) return false;
      try {
        const collaborationExt = e.extensionManager.extensions.find(
          (ext) => ext.name === "collaboration"
        );
        return !!collaborationExt;
      } catch (error) {
        return false;
      }
    });
    function getFormatPainterStorage() {
      const e = editor.value;
      return e?.storage?.formatPainter;
    }
    const isFormatPainterActive = ref(false);
    function updateFormatPainterActive() {
      const storage = getFormatPainterStorage();
      isFormatPainterActive.value = Boolean(storage?.isActive);
    }
    function setupFormatPainterSubscriptions() {
      cleanupFormatPainterSubscriptions();
      const e = editor.value;
      if (!e) return;
      updateFormatPainterActive();
      e.on("update", updateFormatPainterActive);
      e.on("selectionUpdate", updateFormatPainterActive);
      e.on("transaction", updateFormatPainterActive);
    }
    function cleanupFormatPainterSubscriptions() {
      const e = editor.value;
      if (!e) return;
      try {
        e.off("update", updateFormatPainterActive);
        e.off("selectionUpdate", updateFormatPainterActive);
        e.off("transaction", updateFormatPainterActive);
      } catch (error) {
      }
    }
    if (editor.value) setupFormatPainterSubscriptions();
    watch(editor, setupFormatPainterSubscriptions, { immediate: true });
    onBeforeUnmount(() => {
      cleanupFormatPainterSubscriptions();
    });
    function toggleFormatPainter() {
      const e = editor.value;
      if (!e) return;
      if (isDisabled.value) {
        message.warning(t("editor.collaborationNoFormatPainter"));
        return;
      }
      const active = e.storage?.formatPainter?.isActive ?? false;
      if (!active) {
        try {
          const selection = e.state.selection;
          if (!selection || selection.empty) {
            message.warning(t("editor.pleaseSelectTextToSample"));
            return;
          }
        } catch (error) {
          message.warning(t("editor.pleaseSelectTextToSampleShort"));
          return;
        }
        const success = e.commands.startFormatPainting();
        if (success) {
          message.success(t("editor.sampleSuccessSingle"));
          updateFormatPainterActive();
        }
      } else {
        e.commands.cancelFormatPainting();
        updateFormatPainterActive();
        message.info(t("editor.formatPainterExited"));
      }
    }
    function toggleFormatPainterContinuous() {
      const e = editor.value;
      if (!e) return;
      if (isDisabled.value) {
        message.warning(t("editor.collaborationNoFormatPainter"));
        return;
      }
      const active = e.storage?.formatPainter?.isActive ?? false;
      if (!active) {
        try {
          const selection = e.state.selection;
          if (!selection || selection.empty) {
            message.warning(t("editor.pleaseSelectTextToSampleDouble"));
            return;
          }
        } catch (error) {
          message.warning(t("editor.pleaseSelectTextToSampleShort"));
          return;
        }
        const success = e.commands.startContinuousFormatPainting();
        if (success) {
          message.success(t("editor.sampleSuccessContinuous"));
          updateFormatPainterActive();
        }
      } else {
        e.commands.cancelFormatPainting();
        updateFormatPainterActive();
        message.info(t("editor.formatPainterExited"));
      }
    }
    return (_ctx, _cache) => {
      return openBlock(), createBlock(unref(_sfc_main$z), {
        icon: unref(FormatPainterOutlined),
        title: unref(t)("editor.formatPainter"),
        active: isFormatPainterActive.value,
        disabled: isDisabled.value,
        onClick: toggleFormatPainter,
        onDblclick: toggleFormatPainterContinuous
      }, null, 8, ["icon", "title", "active", "disabled"]);
    };
  }
});
const DEFAULT_CONFIG = {
  provider: "openai",
  endpoint: "",
  model: "gpt-4o-mini",
  timeout: 6e4,
  enabled: true
};
const AI_PROVIDERS = [
  {
    id: "openai",
    name: "OpenAI",
    description: "GPT-4o, GPT-4o-mini 等模型",
    defaultEndpoint: "https://api.openai.com/v1",
    defaultModel: "gpt-4o-mini",
    requiresApiKey: true,
    docsUrl: "https://platform.openai.com/docs"
  },
  {
    id: "deepseek",
    name: "DeepSeek",
    description: "DeepSeek-V3, DeepSeek-R1 等模型",
    defaultEndpoint: "https://api.deepseek.com",
    defaultModel: "deepseek-chat",
    requiresApiKey: true,
    docsUrl: "https://platform.deepseek.com/docs"
  },
  {
    id: "anthropic",
    name: "Anthropic",
    description: "Claude 3.5 Sonnet, Claude 3 Opus 等模型",
    defaultEndpoint: "https://api.anthropic.com/v1",
    defaultModel: "claude-3-5-sonnet-20241022",
    requiresApiKey: true,
    docsUrl: "https://docs.anthropic.com"
  },
  {
    id: "aliyun",
    name: "阿里云通义千问",
    description: "Qwen-Max, Qwen-Plus 等模型",
    defaultEndpoint: "https://dashscope.aliyuncs.com/compatible-mode/v1",
    defaultModel: "qwen-plus",
    requiresApiKey: true,
    docsUrl: "https://help.aliyun.com/zh/dashscope/"
  },
  {
    id: "ollama",
    name: "Ollama (本地)",
    description: "本地运行的开源模型",
    defaultEndpoint: "http://localhost:11434/api",
    defaultModel: "llama3.2",
    requiresApiKey: false,
    docsUrl: "https://ollama.com/docs"
  },
  {
    id: "custom",
    name: "自定义",
    description: "自定义 OpenAI 兼容接口",
    defaultEndpoint: "",
    defaultModel: "",
    requiresApiKey: true
  }
];
function getProviderInfo(provider) {
  return AI_PROVIDERS.find((p) => p.id === provider);
}
const STORAGE_KEY$1 = "tiptap-ai-config";
const API_KEY_STORAGE_KEY = "tiptap-ai-apikey";
function obfuscate(str) {
  if (!str) return "";
  try {
    return btoa(encodeURIComponent(str).split("").reverse().join(""));
  } catch {
    return "";
  }
}
function deobfuscate(str) {
  if (!str) return "";
  try {
    return decodeURIComponent(atob(str).split("").reverse().join(""));
  } catch {
    return "";
  }
}
function safeGetItem(key) {
  try {
    return localStorage.getItem(key);
  } catch {
    return null;
  }
}
function safeSetItem(key, value) {
  try {
    localStorage.setItem(key, value);
    return true;
  } catch {
    return false;
  }
}
function safeRemoveItem(key) {
  try {
    localStorage.removeItem(key);
  } catch {
  }
}
function getStoredConfig() {
  const data = safeGetItem(STORAGE_KEY$1);
  if (!data) return null;
  try {
    const parsed = JSON.parse(data);
    if (parsed && typeof parsed.provider === "string") {
      return {
        provider: parsed.provider,
        endpoint: parsed.endpoint || "",
        model: parsed.model || "",
        timeout: parsed.timeout || DEFAULT_CONFIG.timeout,
        enabled: parsed.enabled !== false,
        updatedAt: parsed.updatedAt || Date.now()
      };
    }
  } catch {
  }
  return null;
}
function getStoredApiKey() {
  const obfuscated = safeGetItem(API_KEY_STORAGE_KEY);
  return obfuscated ? deobfuscate(obfuscated) : "";
}
function createAiConfigStore() {
  return {
    getConfig() {
      const stored = getStoredConfig();
      if (!stored) return null;
      return {
        ...stored,
        apiKey: getStoredApiKey()
      };
    },
    saveConfig(config) {
      const { apiKey, ...rest } = config;
      const configToStore = {
        ...rest,
        updatedAt: Date.now()
      };
      safeSetItem(STORAGE_KEY$1, JSON.stringify(configToStore));
      if (apiKey) {
        safeSetItem(API_KEY_STORAGE_KEY, obfuscate(apiKey));
      } else {
        safeRemoveItem(API_KEY_STORAGE_KEY);
      }
    },
    clearConfig() {
      safeRemoveItem(STORAGE_KEY$1);
      safeRemoveItem(API_KEY_STORAGE_KEY);
    },
    getApiKey() {
      const key = getStoredApiKey();
      return key || null;
    },
    isConfigured() {
      const config = this.getConfig();
      if (!config || !config.enabled) return false;
      const providerInfo = getProviderInfo(config.provider);
      if (!providerInfo) return false;
      if (providerInfo.requiresApiKey && !config.apiKey) {
        return false;
      }
      if (config.provider === "custom" && !config.endpoint) {
        return false;
      }
      return true;
    }
  };
}
let storeInstance = null;
function getAiConfigStore() {
  if (!storeInstance) {
    storeInstance = createAiConfigStore();
  }
  return storeInstance;
}
const state = ref({
  config: null,
  initialized: false,
  testStatus: "idle",
  testError: null
});
let isInitialized = false;
function initConfig() {
  if (isInitialized) return;
  const store = getAiConfigStore();
  const savedConfig = store.getConfig();
  if (savedConfig) {
    state.value.config = savedConfig;
  }
  state.value.initialized = true;
  isInitialized = true;
}
async function testConnection(config) {
  const providerInfo = getProviderInfo(config.provider);
  if (!providerInfo) {
    return { success: false, message: "未知的提供商" };
  }
  if (providerInfo.requiresApiKey && !config.apiKey) {
    return { success: false, message: "请输入 API Key" };
  }
  const endpoint = config.endpoint || providerInfo.defaultEndpoint;
  if (!endpoint) {
    return { success: false, message: "请输入 API 端点" };
  }
  const startTime = Date.now();
  try {
    let testUrl = endpoint;
    let testBody;
    const headers = {
      "Content-Type": "application/json"
    };
    if (config.provider === "ollama") {
      testUrl = endpoint.replace(/\/api\/?$/, "") + "/api/tags";
      const response2 = await fetch(testUrl, {
        method: "GET",
        signal: AbortSignal.timeout(1e4)
      });
      if (!response2.ok) {
        throw new Error(`HTTP ${response2.status}`);
      }
      const latency2 = Date.now() - startTime;
      return { success: true, message: "连接成功", latency: latency2 };
    }
    if (config.provider === "anthropic") {
      headers["x-api-key"] = config.apiKey;
      headers["anthropic-version"] = "2023-06-01";
      testUrl = endpoint.replace(/\/$/, "") + "/messages";
      testBody = JSON.stringify({
        model: config.model || providerInfo.defaultModel,
        max_tokens: 1,
        messages: [{ role: "user", content: "Hi" }]
      });
    } else {
      headers["Authorization"] = `Bearer ${config.apiKey}`;
      testUrl = endpoint.replace(/\/$/, "") + "/chat/completions";
      testBody = JSON.stringify({
        model: config.model || providerInfo.defaultModel,
        max_tokens: 1,
        messages: [{ role: "user", content: "Hi" }]
      });
    }
    const response = await fetch(testUrl, {
      method: "POST",
      headers,
      body: testBody,
      signal: AbortSignal.timeout(15e3)
    });
    const latency = Date.now() - startTime;
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      const errorMessage = errorData.error?.message || errorData.message || `HTTP ${response.status}`;
      return { success: false, message: errorMessage, latency };
    }
    return { success: true, message: "连接成功", latency };
  } catch (error) {
    const latency = Date.now() - startTime;
    if (error instanceof Error) {
      if (error.name === "AbortError" || error.name === "TimeoutError") {
        return { success: false, message: "连接超时", latency };
      }
      return { success: false, message: error.message, latency };
    }
    return { success: false, message: "连接失败", latency };
  }
}
function useAiConfig() {
  initConfig();
  const store = getAiConfigStore();
  const config = computed(() => state.value.config);
  const isConfigured = computed(() => store.isConfigured());
  const isEnabled = computed(() => state.value.config?.enabled ?? false);
  const currentProvider = computed(() => state.value.config?.provider ?? "openai");
  const currentProviderInfo = computed(() => getProviderInfo(currentProvider.value));
  const testStatus = computed(() => state.value.testStatus);
  const testError = computed(() => state.value.testError);
  function saveConfig(newConfig) {
    store.saveConfig(newConfig);
    state.value.config = newConfig;
    state.value.testStatus = "idle";
    state.value.testError = null;
  }
  function updateConfig(partial) {
    const current = state.value.config || {
      ...DEFAULT_CONFIG,
      apiKey: "",
      updatedAt: Date.now()
    };
    saveConfig({ ...current, ...partial });
  }
  function setProvider(provider) {
    const providerInfo = getProviderInfo(provider);
    if (!providerInfo) return;
    updateConfig({
      provider,
      endpoint: providerInfo.defaultEndpoint,
      model: providerInfo.defaultModel
    });
  }
  async function testConnectionAsync() {
    const currentConfig = state.value.config;
    if (!currentConfig) {
      return { success: false, message: "请先配置 AI 设置" };
    }
    state.value.testStatus = "testing";
    state.value.testError = null;
    const result = await testConnection(currentConfig);
    state.value.testStatus = result.success ? "success" : "error";
    state.value.testError = result.success ? null : result.message;
    return result;
  }
  function clearConfig() {
    store.clearConfig();
    state.value.config = null;
    state.value.testStatus = "idle";
    state.value.testError = null;
  }
  function getRequestConfig() {
    const cfg = state.value.config;
    if (!cfg || !cfg.enabled) return null;
    const providerInfo = getProviderInfo(cfg.provider);
    if (!providerInfo) return null;
    return {
      endpoint: cfg.endpoint || providerInfo.defaultEndpoint,
      apiKey: cfg.apiKey,
      model: cfg.model || providerInfo.defaultModel,
      timeout: cfg.timeout || DEFAULT_CONFIG.timeout
    };
  }
  return {
    // 状态
    config: readonly(config),
    isConfigured: readonly(isConfigured),
    isEnabled: readonly(isEnabled),
    currentProvider: readonly(currentProvider),
    currentProviderInfo: readonly(currentProviderInfo),
    testStatus: readonly(testStatus),
    testError: readonly(testError),
    providers: AI_PROVIDERS,
    // 方法
    saveConfig,
    updateConfig,
    setProvider,
    testConnection: testConnectionAsync,
    clearConfig,
    getRequestConfig
  };
}
function getAiRequestConfig() {
  const store = getAiConfigStore();
  const config = store.getConfig();
  if (!config || !config.enabled) return null;
  const providerInfo = getProviderInfo(config.provider);
  if (!providerInfo) return null;
  if (providerInfo.requiresApiKey && !config.apiKey) {
    return null;
  }
  return {
    endpoint: config.endpoint || providerInfo.defaultEndpoint,
    apiKey: config.apiKey,
    model: config.model || providerInfo.defaultModel,
    timeout: config.timeout || DEFAULT_CONFIG.timeout,
    provider: config.provider
  };
}
const __vite_import_meta_env__$1 = {};
function getAiConfig() {
  const userConfig = getAiRequestConfig();
  if (userConfig) {
    return {
      provider: userConfig.provider,
      apiKey: userConfig.apiKey,
      baseUrl: userConfig.endpoint,
      model: userConfig.model,
      timeout: userConfig.timeout
    };
  }
  const env = __vite_import_meta_env__$1 || {};
  return {
    provider: env.VITE_AI_PROVIDER || "openai",
    apiKey: env.VITE_AI_API_KEY || "",
    baseUrl: env.VITE_AI_BASE_URL || "",
    model: env.VITE_AI_MODEL || "gpt-4o-mini",
    timeout: DEFAULT_TIMEOUT
  };
}
function getBaseUrl(provider, customUrl) {
  if (customUrl) return customUrl;
  const urls = {
    openai: "https://api.openai.com/v1",
    aliyun: "https://dashscope.aliyuncs.com/compatible-mode/v1",
    deepseek: "https://api.deepseek.com/v1",
    ollama: "http://localhost:11434/api"
  };
  return urls[provider] || urls.openai;
}
const DEFAULT_TIMEOUT = 6e4;
async function sendStreamingRequest(prompt, content, callback) {
  const config = getAiConfig();
  if (!config.apiKey) {
    callback.onError?.(new Error("AI API key not configured. Please configure in AI Settings or set VITE_AI_API_KEY in .env"));
    return;
  }
  const baseUrl = getBaseUrl(config.provider, config.baseUrl);
  const timeout = config.timeout || DEFAULT_TIMEOUT;
  const controller = new AbortController();
  const timeoutId = setTimeout(() => {
    controller.abort();
  }, timeout);
  let reader = null;
  try {
    callback.onStart?.();
    const response = await fetch(`${baseUrl}/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${config.apiKey}`
      },
      body: JSON.stringify({
        model: config.model,
        messages: [
          { role: "system", content: prompt },
          { role: "user", content }
        ],
        stream: true
      }),
      signal: controller.signal
    });
    if (!response.ok) {
      throw new Error(`AI API error: ${response.status} ${response.statusText}`);
    }
    reader = response.body?.getReader() ?? null;
    if (!reader) {
      throw new Error("No response body");
    }
    const decoder = new TextDecoder();
    let buffer = "";
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() || "";
      for (const line of lines) {
        if (!line.trim() || !line.startsWith("data: ")) continue;
        const data = line.slice(6);
        if (data === "[DONE]") continue;
        try {
          const parsed = JSON.parse(data);
          const messageContent = parsed.choices?.[0]?.delta?.content;
          if (messageContent) {
            callback.onMessage?.({ content: messageContent });
          }
        } catch {
        }
      }
    }
    callback.onStop?.();
  } catch (error) {
    if (error instanceof Error && error.name === "AbortError") {
      callback.onError?.(new Error("AI request timeout. Please try again."));
    } else {
      callback.onError?.(error instanceof Error ? error : new Error(String(error)));
    }
  } finally {
    clearTimeout(timeoutId);
    if (reader) {
      try {
        await reader.cancel();
      } catch {
      }
    }
  }
}
const aiApiService = {
  /**
   * Continue writing - streaming
   */
  continueWriting(content, sysPrompt, callback) {
    const prompt = `${sysPrompt}

你是一个专业的写作助手。请根据用户选中的文字，续写接下来的内容。保持原文的风格和语气。只输出续写的内容，不要重复用户选中的文字。`;
    sendStreamingRequest(prompt, content, callback);
  },
  /**
   * Polish text - streaming
   */
  polish(content, sysPrompt, callback) {
    const prompt = `${sysPrompt}

你是一个专业的文字润色助手。请润色以下文字，使其更加流畅、专业。保持原意，只输出润色后的文字。`;
    sendStreamingRequest(prompt, content, callback);
  },
  /**
   * Summarize content - streaming
   */
  summarize(content, sysPrompt, callback) {
    const prompt = `${sysPrompt}

你是一个专业的总结助手。请总结以下内容的要点。简洁明了，输出总结内容。`;
    sendStreamingRequest(prompt, content, callback);
  },
  /**
   * Translate text - streaming
   */
  translate(content, targetLang, sysPrompt, callback) {
    const prompt = `${sysPrompt}

你是一个专业的翻译助手。请将以下内容翻译为${targetLang}。只输出翻译结果。`;
    sendStreamingRequest(prompt, content, callback);
  },
  /**
   * Custom AI command - streaming
   */
  customCommand(content, customPrompt, sysPrompt, callback) {
    const prompt = `${sysPrompt}

${customPrompt}`;
    sendStreamingRequest(prompt, content, callback);
  }
};
function buildParagraphNodesFromText(text2, schema) {
  if (!schema.nodes.paragraph) {
    console.warn("[prosemirrorUtils] Schema does not have paragraph node");
    return [];
  }
  const lines = text2.split(/\r?\n/);
  const nodes = [];
  for (const line of lines) {
    if (line.length > 0) {
      const textNode = schema.text(line);
      const paragraphNode = schema.nodes.paragraph.create(null, textNode);
      nodes.push(paragraphNode);
    } else {
      const paragraphNode = schema.nodes.paragraph.create();
      nodes.push(paragraphNode);
    }
  }
  return nodes;
}
function hasNewlines(text2) {
  return /\r?\n/.test(text2);
}
function isValidSelection(selection, docSize) {
  return selection.from >= 0 && selection.to >= 0 && selection.from <= docSize && selection.to <= docSize && selection.from <= selection.to;
}
const AiHighlightMark = Mark.create({
  name: "aiHighlight",
  addOptions() {
    return {
      HTMLAttributes: {
        class: "ai-highlight"
      }
    };
  },
  addAttributes() {
    return {
      originalText: {
        default: null,
        parseHTML: (element) => element.getAttribute("data-original-text"),
        renderHTML: (attributes) => {
          if (!attributes.originalText) {
            return {};
          }
          return {
            "data-original-text": attributes.originalText
          };
        }
      },
      suggestedText: {
        default: null,
        parseHTML: (element) => element.getAttribute("data-suggested-text"),
        renderHTML: (attributes) => {
          if (!attributes.suggestedText) {
            return {};
          }
          return {
            "data-suggested-text": attributes.suggestedText
          };
        }
      },
      isStreaming: {
        default: false,
        parseHTML: (element) => element.getAttribute("data-is-streaming") === "true",
        renderHTML: (attributes) => {
          return {
            "data-is-streaming": attributes.isStreaming ? "true" : "false"
          };
        }
      }
    };
  },
  parseHTML() {
    return [
      {
        tag: "span.ai-highlight",
        getAttrs: (element) => {
          if (typeof element === "string") return false;
          return {
            originalText: element.getAttribute("data-original-text"),
            suggestedText: element.getAttribute("data-suggested-text"),
            isStreaming: element.getAttribute("data-is-streaming") === "true"
          };
        }
      }
    ];
  },
  renderHTML({ HTMLAttributes }) {
    return [
      "span",
      mergeAttributes(this.options.HTMLAttributes, HTMLAttributes),
      0
    ];
  },
  addCommands() {
    return {
      setAiHighlight: (data) => ({ commands }) => {
        return commands.setMark(this.name, data || {});
      },
      unsetAiHighlight: () => ({ commands }) => {
        return commands.unsetMark(this.name);
      }
    };
  }
});
function addAiHighlight(editor, from, to, data) {
  const { state: state2 } = editor;
  const { tr, doc } = state2;
  const aiHighlightMark = state2.schema.marks.aiHighlight;
  if (!aiHighlightMark) {
    console.warn("[AI Highlight] aiHighlight mark not found in schema");
    return;
  }
  const docSize = doc.content.size;
  if (from < 0 || to < 0 || from > docSize || to > docSize || from > to) {
    console.warn("[AI Highlight] Invalid range for add:", { from, to, docSize });
    return;
  }
  tr.addMark(from, to, aiHighlightMark.create(data || {}));
  editor.view.dispatch(tr);
}
function updateAiHighlight(editor, from, to, data) {
  const { state: state2 } = editor;
  const { tr, doc } = state2;
  const aiHighlightMark = state2.schema.marks.aiHighlight;
  if (!aiHighlightMark) {
    console.warn("[AI Highlight] aiHighlight mark not found in schema");
    return;
  }
  const docSize = doc.content.size;
  if (from < 0 || to < 0 || from > docSize || to > docSize || from > to) {
    console.warn("[AI Highlight] Invalid range for update:", { from, to, docSize });
    return;
  }
  let existingMark = null;
  doc.nodesBetween(from, to, (node) => {
    const mark = node.marks.find((m) => m.type.name === "aiHighlight");
    if (mark) {
      existingMark = mark;
      return false;
    }
  });
  if (existingMark && existingMark.attrs) {
    const attrs = existingMark.attrs;
    const newAttrs = { ...attrs, ...data };
    tr.removeMark(from, to, aiHighlightMark);
    tr.addMark(from, to, aiHighlightMark.create(newAttrs));
    editor.view.dispatch(tr);
  }
}
function removeAiHighlight(editor) {
  const { state: state2 } = editor;
  const { tr, doc } = state2;
  doc.descendants((node, pos) => {
    if (node.marks.some((mark) => mark.type.name === "aiHighlight")) {
      const from = pos;
      const to = pos + node.nodeSize;
      tr.removeMark(from, to, state2.schema.marks.aiHighlight);
    }
  });
  editor.view.dispatch(tr);
}
function getAiSuggestionData(editor, pos) {
  const { state: state2 } = editor;
  const { doc } = state2;
  const $pos = doc.resolve(pos);
  const marks = $pos.marks();
  const aiMark = marks.find((mark) => mark.type.name === "aiHighlight");
  if (aiMark) {
    const attrs = aiMark.attrs;
    if (attrs) {
      return {
        originalText: attrs.originalText || "",
        suggestedText: attrs.suggestedText || "",
        isStreaming: attrs.isStreaming || false
      };
    }
  }
  return null;
}
const _hoisted_1$e = { class: "custom-ai-content" };
const _hoisted_2$d = {
  key: 0,
  class: "custom-ai-input-stage"
};
const _hoisted_3$c = { class: "custom-ai-header" };
const _hoisted_4$b = { class: "custom-ai-title" };
const _hoisted_5$b = {
  key: 0,
  class: "custom-ai-selected-text"
};
const _hoisted_6$b = { class: "text-label" };
const _hoisted_7$a = { class: "text-content" };
const _hoisted_8$7 = { class: "custom-ai-prompt-input" };
const _hoisted_9$7 = { class: "custom-ai-footer" };
const _hoisted_10$5 = {
  key: 1,
  class: "custom-ai-result-stage"
};
const _hoisted_11$5 = { class: "custom-ai-header" };
const _hoisted_12$5 = { class: "custom-ai-title" };
const _hoisted_13$4 = {
  key: 0,
  class: "original-text"
};
const _hoisted_14$4 = { class: "text-label" };
const _hoisted_15$3 = { class: "text-content" };
const _hoisted_16$2 = { class: "suggested-text" };
const _hoisted_17$2 = { class: "text-label" };
const _hoisted_18$2 = { class: "text-content" };
const _hoisted_19$2 = { class: "custom-ai-footer" };
const _hoisted_20$1 = { class: "footer-right" };
const _sfc_main$f = /* @__PURE__ */ defineComponent({
  __name: "CustomAiPopover",
  props: {
    visible: { type: Boolean, default: false },
    originalText: { default: "" },
    suggestedText: { default: "" },
    isStreaming: { type: Boolean, default: false },
    isExecuting: { type: Boolean, default: false },
    position: {},
    editorElement: {}
  },
  emits: ["update:visible", "execute", "accept", "reject", "cancel", "cancelGeneration"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const promptInputRef = ref();
    const promptInput = ref("");
    const anchorStyle = computed(() => {
      if (!props.position) {
        return {
          position: "absolute",
          top: "0px",
          left: "0px",
          width: "0px",
          height: "0px",
          pointerEvents: "none"
        };
      }
      return {
        position: "absolute",
        top: `${props.position.top}px`,
        left: `${props.position.left}px`,
        width: "0px",
        height: "0px",
        pointerEvents: "none"
      };
    });
    const getPopupContainer = () => {
      return props.editorElement || document.body;
    };
    const handleExecute = () => {
      if (promptInput.value.trim()) {
        emit("execute", promptInput.value.trim());
      }
    };
    const handleAccept2 = () => {
      emit("accept");
      promptInput.value = "";
    };
    const handleReject2 = () => {
      emit("reject");
      promptInput.value = "";
    };
    const handleCancel2 = () => {
      emit("cancel");
      promptInput.value = "";
    };
    const handleCancelGeneration = () => {
      emit("cancelGeneration");
      promptInput.value = "";
    };
    const handleVisibleChange = (val) => {
      emit("update:visible", val);
      if (!val) {
        emit("cancel");
        promptInput.value = "";
      }
    };
    watch(
      () => props.visible,
      (newVal) => {
        if (newVal && !props.isExecuting) {
          nextTick(() => {
            promptInputRef.value?.focus();
          });
        }
      }
    );
    return (_ctx, _cache) => {
      return openBlock(), createBlock(unref(Popover), {
        open: __props.visible,
        getPopupContainer,
        placement: "bottomLeft",
        trigger: [],
        overlayClassName: "custom-ai-popover",
        "onUpdate:open": handleVisibleChange
      }, {
        content: withCtx(() => [
          createElementVNode("div", _hoisted_1$e, [
            !__props.isExecuting && !__props.isStreaming ? (openBlock(), createElementBlock("div", _hoisted_2$d, [
              createElementVNode("div", _hoisted_3$c, [
                createElementVNode("span", _hoisted_4$b, toDisplayString(unref(t)("editor.customAiCommand")), 1)
              ]),
              __props.originalText ? (openBlock(), createElementBlock("div", _hoisted_5$b, [
                createElementVNode("div", _hoisted_6$b, toDisplayString(unref(t)("editor.selectedContent")), 1),
                createElementVNode("div", _hoisted_7$a, toDisplayString(__props.originalText), 1)
              ])) : createCommentVNode("", true),
              createElementVNode("div", _hoisted_8$7, [
                createVNode(unref(Input), {
                  ref_key: "promptInputRef",
                  ref: promptInputRef,
                  value: promptInput.value,
                  "onUpdate:value": _cache[0] || (_cache[0] = ($event) => promptInput.value = $event),
                  placeholder: unref(t)("editor.aiPromptPlaceholder"),
                  "auto-size": { minRows: 3, maxRows: 6 },
                  onKeydown: withKeys(withModifiers(handleExecute, ["ctrl"]), ["enter"])
                }, null, 8, ["value", "placeholder", "onKeydown"])
              ]),
              createElementVNode("div", _hoisted_9$7, [
                createVNode(unref(Button), {
                  size: "small",
                  onClick: handleCancel2
                }, {
                  default: withCtx(() => [
                    createTextVNode(toDisplayString(unref(t)("editor.cancel")), 1)
                  ]),
                  _: 1
                }),
                createVNode(unref(Button), {
                  type: "primary",
                  size: "small",
                  onClick: handleExecute,
                  disabled: !promptInput.value.trim()
                }, {
                  default: withCtx(() => [
                    createTextVNode(toDisplayString(unref(t)("editor.execute")), 1)
                  ]),
                  _: 1
                }, 8, ["disabled"])
              ])
            ])) : (openBlock(), createElementBlock("div", _hoisted_10$5, [
              createElementVNode("div", _hoisted_11$5, [
                createElementVNode("span", _hoisted_12$5, toDisplayString(unref(t)("editor.aiSuggestion")), 1),
                __props.isStreaming ? (openBlock(), createBlock(unref(LoadingOutlined), {
                  key: 0,
                  class: "ai-loading-icon"
                })) : createCommentVNode("", true)
              ]),
              __props.originalText ? (openBlock(), createElementBlock("div", _hoisted_13$4, [
                createElementVNode("div", _hoisted_14$4, toDisplayString(unref(t)("editor.originalText")), 1),
                createElementVNode("div", _hoisted_15$3, toDisplayString(__props.originalText), 1)
              ])) : createCommentVNode("", true),
              __props.originalText ? (openBlock(), createBlock(unref(ArrowDownOutlined), {
                key: 1,
                class: "arrow-icon"
              })) : createCommentVNode("", true),
              createElementVNode("div", _hoisted_16$2, [
                createElementVNode("div", _hoisted_17$2, toDisplayString(__props.originalText ? unref(t)("editor.suggestedText") : unref(t)("editor.generatedContent")), 1),
                createElementVNode("div", _hoisted_18$2, toDisplayString(__props.suggestedText || unref(t)("editor.generating")), 1)
              ]),
              createElementVNode("div", _hoisted_19$2, [
                createVNode(unref(Button), {
                  size: "small",
                  onClick: handleCancelGeneration,
                  disabled: __props.isStreaming
                }, {
                  default: withCtx(() => [
                    createTextVNode(toDisplayString(unref(t)("editor.cancel")), 1)
                  ]),
                  _: 1
                }, 8, ["disabled"]),
                createElementVNode("div", _hoisted_20$1, [
                  createVNode(unref(Button), {
                    size: "small",
                    onClick: handleReject2,
                    disabled: __props.isStreaming
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(unref(t)("editor.reject")), 1)
                    ]),
                    _: 1
                  }, 8, ["disabled"]),
                  createVNode(unref(Button), {
                    type: "primary",
                    size: "small",
                    onClick: handleAccept2,
                    disabled: __props.isStreaming
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(unref(t)("editor.accept")), 1)
                    ]),
                    _: 1
                  }, 8, ["disabled"])
                ])
              ])
            ]))
          ])
        ]),
        default: withCtx(() => [
          createElementVNode("span", {
            style: normalizeStyle(anchorStyle.value)
          }, null, 4)
        ]),
        _: 1
      }, 8, ["open"]);
    };
  }
});
const CustomAiPopover = /* @__PURE__ */ _export_sfc(_sfc_main$f, [["__scopeId", "data-v-09350e42"]]);
const CustomAiExtension = Extension.create({
  name: "customAi",
  addCommands() {
    return {
      customAi: () => ({ state: state2, editor }) => {
        const { selection } = state2;
        const { from, to } = selection;
        const selectedText = state2.doc.textBetween(from, to, " ");
        if (!selectedText.trim()) {
          notification.warning({
            message: t("editor.pleaseSelectText"),
            description: t("editor.customAiRequiresSelection"),
            duration: 2
          });
          return false;
        }
        const originalSelection = { from, to };
        showCustomAiModal(
          editor,
          selectedText,
          originalSelection
        );
        return true;
      }
    };
  }
});
let customAiPopoverApp = null;
let customAiContainer = null;
let currentEditor$2 = null;
let currentSelection$2 = null;
const visibleRef$2 = ref(false);
const originalTextRef$2 = ref("");
const suggestedTextRef$2 = ref("");
const isStreamingRef$2 = ref(false);
const isExecutingRef = ref(false);
function showCustomAiModal(editor, selectedText, originalSelection, _hasSelectedText) {
  currentEditor$2 = editor;
  currentSelection$2 = originalSelection;
  visibleRef$2.value = true;
  originalTextRef$2.value = selectedText;
  suggestedTextRef$2.value = "";
  isStreamingRef$2.value = false;
  isExecutingRef.value = false;
  const highlightData = {
    originalText: selectedText,
    suggestedText: "",
    isStreaming: false
  };
  addAiHighlight(
    editor,
    originalSelection.from,
    originalSelection.to,
    highlightData
  );
  if (!customAiPopoverApp) {
    mountCustomAiPopover(editor);
  }
}
function mountCustomAiPopover(editor) {
  if (customAiPopoverApp) {
    unmountCustomAiPopover();
  }
  customAiContainer = document.createElement("div");
  customAiContainer.style.position = "absolute";
  customAiContainer.style.top = "0";
  customAiContainer.style.left = "0";
  customAiContainer.style.zIndex = "1000";
  const editorElement = editor.view.dom.parentElement;
  if (editorElement) {
    editorElement.append(customAiContainer);
  } else {
    document.body.append(customAiContainer);
  }
  const position = calculatePopoverPosition$2(editor);
  customAiPopoverApp = createApp({
    render: () => h(CustomAiPopover, {
      visible: visibleRef$2.value,
      originalText: originalTextRef$2.value,
      suggestedText: suggestedTextRef$2.value,
      isStreaming: isStreamingRef$2.value,
      isExecuting: isExecutingRef.value,
      position,
      editorElement: editorElement || void 0,
      "onUpdate:visible": (val) => {
        visibleRef$2.value = val;
      },
      onExecute: (prompt) => {
        handleExecutePrompt(prompt);
      },
      onAccept: () => {
        handleAccept$2();
      },
      onReject: () => {
        handleReject$2();
      },
      onCancel: () => {
        handleCancel$2();
      },
      onCancelGeneration: () => {
        handleCancel$2();
      }
    })
  });
  customAiPopoverApp.mount(customAiContainer);
}
function unmountCustomAiPopover() {
  if (customAiPopoverApp) {
    customAiPopoverApp.unmount();
    customAiPopoverApp = null;
  }
  if (customAiContainer && customAiContainer.parentNode) {
    customAiContainer.remove();
    customAiContainer = null;
  }
}
function calculatePopoverPosition$2(editor) {
  if (!currentSelection$2) {
    return { left: 0, top: 0 };
  }
  const { from, to } = currentSelection$2;
  const { view } = editor;
  const start = view.coordsAtPos(from);
  const end = view.coordsAtPos(to);
  const editorRect = view.dom.getBoundingClientRect();
  const top = end.bottom - editorRect.top + 8;
  const left = start.left - editorRect.left;
  return { left, top };
}
function handleExecutePrompt(prompt) {
  if (!currentEditor$2 || !currentSelection$2) return;
  isExecutingRef.value = true;
  isStreamingRef$2.value = true;
  performCustomAi(
    currentEditor$2,
    originalTextRef$2.value,
    prompt,
    currentSelection$2,
    originalTextRef$2.value.trim().length > 0
  );
}
function handleAccept$2() {
  if (!currentEditor$2 || !currentSelection$2) return;
  const suggestedText = suggestedTextRef$2.value;
  const { state: state2 } = currentEditor$2;
  const { doc } = state2;
  const docSize = doc.content.size;
  if (!isValidSelection(currentSelection$2, docSize)) {
    console.warn("[Custom AI] Invalid selection range, cannot accept");
    handleCleanup$2();
    return;
  }
  if (hasNewlines(suggestedText)) {
    const nodes = buildParagraphNodesFromText(suggestedText, state2.schema);
    if (nodes.length > 0) {
      const tr = state2.tr;
      tr.replaceWith(currentSelection$2.from, currentSelection$2.to, nodes);
      currentEditor$2.view.dispatch(tr);
    }
  } else {
    currentEditor$2.chain().focus().deleteRange(currentSelection$2).insertContentAt(currentSelection$2.from, suggestedText).run();
  }
  handleCleanup$2();
}
function handleReject$2() {
  handleCleanup$2();
}
function handleCancel$2() {
  handleCleanup$2();
}
function handleCleanup$2() {
  if (currentEditor$2) {
    removeAiHighlight(currentEditor$2);
  }
  unmountCustomAiPopover();
  visibleRef$2.value = false;
  originalTextRef$2.value = "";
  suggestedTextRef$2.value = "";
  isStreamingRef$2.value = false;
  isExecutingRef.value = false;
  currentEditor$2 = null;
  currentSelection$2 = null;
}
function performCustomAi(editor, selectedText, prompt, _originalSelection, _hasSelectedText) {
  let accumulatedContent = "";
  const callback = {
    onStart: () => {
      accumulatedContent = "";
    },
    onMessage: (message2) => {
      if (message2 && message2.content) {
        accumulatedContent += message2.content;
        suggestedTextRef$2.value = accumulatedContent;
        if (currentSelection$2 && currentEditor$2) {
          const { state: state2 } = currentEditor$2;
          const { doc } = state2;
          const docSize = doc.content.size;
          if (currentSelection$2.from >= 0 && currentSelection$2.to >= 0 && currentSelection$2.from <= docSize && currentSelection$2.to <= docSize && currentSelection$2.from <= currentSelection$2.to) {
            updateAiHighlight(
              editor,
              currentSelection$2.from,
              currentSelection$2.to,
              {
                suggestedText: accumulatedContent
              }
            );
          }
        }
      }
    },
    onStop: () => {
      try {
        isStreamingRef$2.value = false;
        if (currentSelection$2 && currentEditor$2) {
          const { state: state2 } = currentEditor$2;
          const { doc } = state2;
          const docSize = doc.content.size;
          if (currentSelection$2.from >= 0 && currentSelection$2.to >= 0 && currentSelection$2.from <= docSize && currentSelection$2.to <= docSize && currentSelection$2.from <= currentSelection$2.to) {
            updateAiHighlight(
              editor,
              currentSelection$2.from,
              currentSelection$2.to,
              {
                isStreaming: false
              }
            );
          }
        }
      } catch (error) {
        console.warn("[Custom AI] Failed to finalize formatting:", error);
      }
    },
    onError: (error) => {
      console.error("[Custom AI] Error:", error);
      handleCleanup$2();
      notification.error({
        message: "自定义 AI 失败",
        description: error.message || "请稍后重试",
        duration: 3
      });
    }
  };
  aiApiService.customCommand(
    selectedText,
    prompt,
    "你係一個專業嘅文本處理助手。直接返回處理結果,唔好加任何解釋。",
    callback
  );
}
const _hoisted_1$d = { class: "ai-suggestion-content" };
const _hoisted_2$c = { class: "ai-suggestion-header" };
const _hoisted_3$b = { class: "ai-suggestion-title" };
const _hoisted_4$a = { class: "ai-suggestion-body" };
const _hoisted_5$a = { class: "original-text" };
const _hoisted_6$a = { class: "text-label" };
const _hoisted_7$9 = { class: "text-content" };
const _hoisted_8$6 = { class: "suggested-text" };
const _hoisted_9$6 = { class: "text-label" };
const _hoisted_10$4 = { class: "text-content" };
const _hoisted_11$4 = { class: "ai-suggestion-footer" };
const _hoisted_12$4 = { class: "footer-right" };
const _sfc_main$e = /* @__PURE__ */ defineComponent({
  __name: "AiSuggestionPopover",
  props: {
    visible: { type: Boolean, default: false },
    originalText: { default: "" },
    suggestedText: { default: "" },
    isStreaming: { type: Boolean, default: false },
    position: {},
    editorElement: {}
  },
  emits: ["update:visible", "accept", "reject", "cancel"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const anchorRef = ref();
    const anchorStyle = computed(() => {
      if (!props.position) {
        return {
          position: "absolute",
          top: "0px",
          left: "0px",
          width: "0px",
          height: "0px",
          pointerEvents: "none"
        };
      }
      return {
        position: "absolute",
        top: `${props.position.top}px`,
        left: `${props.position.left}px`,
        width: "0px",
        height: "0px",
        pointerEvents: "none"
      };
    });
    const getPopupContainer = () => {
      return props.editorElement || document.body;
    };
    const handleAccept2 = () => {
      emit("accept");
    };
    const handleReject2 = () => {
      emit("reject");
    };
    const handleCancel2 = () => {
      emit("cancel");
    };
    const handleVisibleChange = (val) => {
      emit("update:visible", val);
      if (!val) {
        emit("cancel");
      }
    };
    return (_ctx, _cache) => {
      return openBlock(), createBlock(unref(Popover), {
        open: __props.visible,
        getPopupContainer,
        placement: "bottomLeft",
        trigger: [],
        overlayClassName: "ai-suggestion-popover",
        "onUpdate:open": handleVisibleChange
      }, {
        content: withCtx(() => [
          createElementVNode("div", _hoisted_1$d, [
            createElementVNode("div", _hoisted_2$c, [
              createElementVNode("span", _hoisted_3$b, toDisplayString(unref(t)("editor.aiSuggestion")), 1),
              __props.isStreaming ? (openBlock(), createBlock(unref(LoadingOutlined), {
                key: 0,
                class: "ai-loading-icon"
              })) : createCommentVNode("", true)
            ]),
            createElementVNode("div", _hoisted_4$a, [
              __props.originalText ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
                createElementVNode("div", _hoisted_5$a, [
                  createElementVNode("div", _hoisted_6$a, toDisplayString(unref(t)("editor.originalText")), 1),
                  createElementVNode("div", _hoisted_7$9, toDisplayString(__props.originalText), 1)
                ]),
                createVNode(unref(ArrowDownOutlined), { class: "arrow-icon" })
              ], 64)) : createCommentVNode("", true),
              createElementVNode("div", _hoisted_8$6, [
                createElementVNode("div", _hoisted_9$6, toDisplayString(__props.originalText ? unref(t)("editor.suggestedText") : unref(t)("editor.aiContinueWriting")), 1),
                createElementVNode("div", _hoisted_10$4, toDisplayString(__props.suggestedText || unref(t)("editor.generating")), 1)
              ])
            ]),
            createElementVNode("div", _hoisted_11$4, [
              createVNode(unref(Button), {
                size: "small",
                onClick: handleCancel2,
                disabled: __props.isStreaming
              }, {
                default: withCtx(() => [
                  createTextVNode(toDisplayString(unref(t)("editor.cancel")), 1)
                ]),
                _: 1
              }, 8, ["disabled"]),
              createElementVNode("div", _hoisted_12$4, [
                createVNode(unref(Button), {
                  size: "small",
                  onClick: handleReject2,
                  disabled: __props.isStreaming
                }, {
                  default: withCtx(() => [
                    createTextVNode(toDisplayString(unref(t)("editor.reject")), 1)
                  ]),
                  _: 1
                }, 8, ["disabled"]),
                createVNode(unref(Button), {
                  type: "primary",
                  size: "small",
                  onClick: handleAccept2,
                  disabled: __props.isStreaming
                }, {
                  default: withCtx(() => [
                    createTextVNode(toDisplayString(unref(t)("editor.accept")), 1)
                  ]),
                  _: 1
                }, 8, ["disabled"])
              ])
            ])
          ])
        ]),
        default: withCtx(() => [
          createElementVNode("span", {
            ref_key: "anchorRef",
            ref: anchorRef,
            style: normalizeStyle(anchorStyle.value)
          }, null, 4)
        ]),
        _: 1
      }, 8, ["open"]);
    };
  }
});
const AiSuggestionPopover = /* @__PURE__ */ _export_sfc(_sfc_main$e, [["__scopeId", "data-v-d17aa9af"]]);
const ContinueWritingExtension = Extension.create({
  name: "continueWriting",
  addCommands() {
    return {
      continueWriting: () => ({ state: state2, editor }) => {
        const { selection } = state2;
        const { from, to } = selection;
        const selectedText = state2.doc.textBetween(from, to, " ");
        if (!selectedText.trim()) {
          console.warn("[Continue Writing] No text selected");
          notification.warning({
            message: t("editor.pleaseSelectText"),
            description: t("editor.continueWritingRequiresSelection"),
            duration: 2,
            placement: "topRight"
          });
          return false;
        }
        const originalSelectedRange2 = { from, to };
        const originalSelection = { from: to, to };
        const fullText = state2.doc.textBetween(
          0,
          state2.doc.content.size,
          " "
        );
        const sysPrompt = `以下係完整嘅文件內容:

${fullText}`;
        performContinueWriting(
          editor,
          selectedText,
          sysPrompt,
          originalSelection,
          to,
          originalSelectedRange2
        );
        return true;
      }
    };
  }
});
let continueWritingPopoverApp = null;
let continueWritingContainer = null;
let currentEditor$1 = null;
let currentSelection$1 = null;
let originalSelectedRange = null;
const visibleRef$1 = ref(false);
const originalTextRef$1 = ref("");
const suggestedTextRef$1 = ref("");
const isStreamingRef$1 = ref(false);
function performContinueWriting(editor, selectedText, sysPrompt, originalSelection, insertPosition, userSelectedRange) {
  removeAiHighlight(editor);
  currentEditor$1 = editor;
  currentSelection$1 = originalSelection;
  originalSelectedRange = userSelectedRange;
  visibleRef$1.value = true;
  originalTextRef$1.value = selectedText;
  suggestedTextRef$1.value = "";
  isStreamingRef$1.value = true;
  const selectedTextHighlight = {
    originalText: selectedText,
    suggestedText: "",
    isStreaming: false
  };
  addAiHighlight(
    editor,
    userSelectedRange.from,
    userSelectedRange.to,
    selectedTextHighlight
  );
  editor.chain().focus().insertContentAt(insertPosition, " ").run();
  const suggestionSelection = {
    from: insertPosition,
    to: insertPosition + 1
  };
  const highlightData = {
    originalText: "",
    suggestedText: "",
    isStreaming: true
  };
  addAiHighlight(
    editor,
    suggestionSelection.from,
    suggestionSelection.to,
    highlightData
  );
  if (!continueWritingPopoverApp) {
    mountContinueWritingPopover(editor);
  }
  setupClickHandler$1();
  let accumulatedContent = "";
  const callback = {
    onStart: () => {
      accumulatedContent = "";
    },
    onMessage: (message2) => {
      if (message2 && message2.content) {
        accumulatedContent += message2.content;
        suggestedTextRef$1.value = accumulatedContent;
        if (currentSelection$1 && currentEditor$1) {
          const { state: state2 } = currentEditor$1;
          const { doc } = state2;
          const docSize = doc.content.size;
          if (currentSelection$1.from >= 0 && currentSelection$1.to >= 0 && currentSelection$1.from <= docSize && currentSelection$1.to <= docSize && currentSelection$1.from <= currentSelection$1.to) {
            updateAiHighlight(
              editor,
              currentSelection$1.from,
              currentSelection$1.to,
              {
                suggestedText: accumulatedContent
              }
            );
          }
        }
      }
    },
    onStop: () => {
      try {
        isStreamingRef$1.value = false;
        if (currentSelection$1 && currentEditor$1) {
          const { state: state2 } = currentEditor$1;
          const { doc } = state2;
          const docSize = doc.content.size;
          if (currentSelection$1.from >= 0 && currentSelection$1.to >= 0 && currentSelection$1.from <= docSize && currentSelection$1.to <= docSize && currentSelection$1.from <= currentSelection$1.to) {
            updateAiHighlight(
              editor,
              currentSelection$1.from,
              currentSelection$1.to,
              {
                isStreaming: false
              }
            );
          }
        }
      } catch (error) {
        console.warn(
          "[Continue Writing] Failed to finalize formatting:",
          error
        );
      }
    },
    onError: (error) => {
      console.error("[Continue Writing] Error:", error);
      handleCleanup$1();
      notification.error({
        message: "续写失败",
        description: error.message || t("messages.networkError"),
        duration: 3
      });
    }
  };
  aiApiService.continueWriting(selectedText, sysPrompt, callback);
}
function mountContinueWritingPopover(editor) {
  if (continueWritingPopoverApp) {
    continueWritingPopoverApp.unmount();
    continueWritingPopoverApp = null;
  }
  const editorElement = editor.view.dom.parentElement;
  if (!continueWritingContainer || !continueWritingContainer.parentNode) {
    continueWritingContainer = document.createElement("div");
    continueWritingContainer.style.position = "absolute";
    continueWritingContainer.style.top = "0";
    continueWritingContainer.style.left = "0";
    continueWritingContainer.style.zIndex = "1000";
    if (editorElement) {
      editorElement.append(continueWritingContainer);
    } else {
      document.body.append(continueWritingContainer);
    }
  }
  const position = calculatePopoverPosition$1(editor);
  continueWritingPopoverApp = createApp({
    render: () => h(AiSuggestionPopover, {
      visible: visibleRef$1.value,
      originalText: originalTextRef$1.value,
      suggestedText: suggestedTextRef$1.value,
      isStreaming: isStreamingRef$1.value,
      position,
      editorElement: editorElement || void 0,
      "onUpdate:visible": (val) => {
        visibleRef$1.value = val;
      },
      onAccept: () => {
        handleAccept$1();
      },
      onReject: () => {
        handleReject$1();
      },
      onCancel: () => {
        handleCancel$1();
      }
    })
  });
  continueWritingPopoverApp.mount(continueWritingContainer);
}
function unmountContinueWritingPopover() {
  if (continueWritingPopoverApp) {
    continueWritingPopoverApp.unmount();
    continueWritingPopoverApp = null;
  }
}
function calculatePopoverPosition$1(editor) {
  const rangeToUse = originalSelectedRange || currentSelection$1;
  if (!rangeToUse) {
    return { left: 0, top: 0 };
  }
  const { from, to } = rangeToUse;
  const { view } = editor;
  const start = view.coordsAtPos(from);
  const end = view.coordsAtPos(to);
  const editorRect = view.dom.getBoundingClientRect();
  const top = end.bottom - editorRect.top + 8;
  const left = start.left - editorRect.left;
  return { left, top };
}
function handleAccept$1() {
  if (!currentEditor$1 || !currentSelection$1) return;
  const suggestedText = suggestedTextRef$1.value;
  const { state: state2 } = currentEditor$1;
  const { doc } = state2;
  const docSize = doc.content.size;
  if (!isValidSelection(currentSelection$1, docSize)) {
    console.warn("[Continue Writing] Invalid selection range, cannot accept");
    handleCleanup$1();
    return;
  }
  if (hasNewlines(suggestedText)) {
    const nodes = buildParagraphNodesFromText(suggestedText, state2.schema);
    if (nodes.length > 0) {
      const tr = state2.tr;
      tr.replaceWith(currentSelection$1.from, currentSelection$1.to, nodes);
      currentEditor$1.view.dispatch(tr);
    }
  } else {
    currentEditor$1.chain().focus().deleteRange(currentSelection$1).insertContentAt(currentSelection$1.from, suggestedText).run();
  }
  handleCleanup$1();
}
function handleReject$1() {
  handleCleanup$1();
}
function handleCancel$1() {
  unmountContinueWritingPopover();
  visibleRef$1.value = false;
  setupClickHandler$1();
}
function setupClickHandler$1() {
  if (!currentEditor$1) return;
  const editorDom = currentEditor$1.view.dom;
  const existingHandler = editorDom._continueWritingClickHandler;
  if (existingHandler) {
    editorDom.removeEventListener("click", existingHandler);
  }
  const clickHandler = (event) => {
    const target = event.target;
    if (!target) return;
    const highlightElement = target.classList.contains("ai-highlight") ? target : target.closest(".ai-highlight");
    if (!highlightElement) return;
    if (!currentEditor$1 || !currentSelection$1) return;
    if (visibleRef$1.value) return;
    event.stopPropagation();
    let pos;
    try {
      pos = currentEditor$1.view.posAtDOM(highlightElement, 0);
    } catch (error) {
      console.warn("[Continue Writing] Failed to get position from DOM:", error);
      pos = originalSelectedRange?.from || currentSelection$1.from;
    }
    let data = getAiSuggestionData(currentEditor$1, pos);
    if (!data && originalSelectedRange) {
      data = getAiSuggestionData(currentEditor$1, originalSelectedRange.from);
    }
    if (!data) {
      data = {
        originalText: originalTextRef$1.value,
        suggestedText: suggestedTextRef$1.value,
        isStreaming: isStreamingRef$1.value
      };
    }
    originalTextRef$1.value = data.originalText || originalTextRef$1.value;
    suggestedTextRef$1.value = data.suggestedText || suggestedTextRef$1.value;
    isStreamingRef$1.value = data.isStreaming || false;
    unmountContinueWritingPopover();
    mountContinueWritingPopover(currentEditor$1);
    visibleRef$1.value = true;
  };
  editorDom._continueWritingClickHandler = clickHandler;
  editorDom.addEventListener("click", clickHandler);
}
function handleCleanup$1() {
  if (currentEditor$1) {
    const editorDom = currentEditor$1.view.dom;
    const existingHandler = editorDom._continueWritingClickHandler;
    if (existingHandler) {
      editorDom.removeEventListener("click", existingHandler);
      delete editorDom._continueWritingClickHandler;
    }
    removeAiHighlight(currentEditor$1);
  }
  unmountContinueWritingPopover();
  visibleRef$1.value = false;
  originalTextRef$1.value = "";
  suggestedTextRef$1.value = "";
  isStreamingRef$1.value = false;
  currentEditor$1 = null;
  currentSelection$1 = null;
  originalSelectedRange = null;
}
const PolishExtension = Extension.create({
  name: "polish",
  addCommands() {
    return {
      polish: () => ({ state: state2, editor }) => {
        const { selection } = state2;
        const { from, to } = selection;
        const selectedText = state2.doc.textBetween(from, to, " ");
        if (!selectedText.trim()) {
          console.warn("[Polish] No text selected");
          notification.warning({
            message: t("editor.pleaseSelectText"),
            description: t("editor.polishRequiresSelection"),
            duration: 2,
            placement: "topRight"
          });
          return false;
        }
        const originalSelection = { from, to };
        const fullText = state2.doc.textBetween(
          0,
          state2.doc.content.size,
          " "
        );
        const sysPrompt = `以下係完整嘅文件內容:

${fullText}`;
        performPolish(
          editor,
          selectedText,
          sysPrompt,
          originalSelection
        );
        return true;
      }
    };
  }
});
let polishPopoverApp = null;
let polishContainer = null;
let currentEditor = null;
let currentSelection = null;
const visibleRef = ref(false);
const originalTextRef = ref("");
const suggestedTextRef = ref("");
const isStreamingRef = ref(false);
function performPolish(editor, selectedText, sysPrompt, originalSelection) {
  removeAiHighlight(editor);
  currentEditor = editor;
  currentSelection = originalSelection;
  visibleRef.value = true;
  originalTextRef.value = selectedText;
  suggestedTextRef.value = "";
  isStreamingRef.value = true;
  const highlightData = {
    originalText: selectedText,
    suggestedText: "",
    isStreaming: true
  };
  addAiHighlight(
    editor,
    originalSelection.from,
    originalSelection.to,
    highlightData
  );
  if (!polishPopoverApp) {
    mountPolishPopover(editor);
  }
  setupClickHandler();
  let accumulatedContent = "";
  const callback = {
    onStart: () => {
      accumulatedContent = "";
    },
    onMessage: (message2) => {
      if (message2 && message2.content) {
        accumulatedContent += message2.content;
        suggestedTextRef.value = accumulatedContent;
        if (currentSelection && currentEditor) {
          const { state: state2 } = currentEditor;
          const { doc } = state2;
          const docSize = doc.content.size;
          if (currentSelection.from >= 0 && currentSelection.to >= 0 && currentSelection.from <= docSize && currentSelection.to <= docSize && currentSelection.from <= currentSelection.to) {
            updateAiHighlight(
              editor,
              currentSelection.from,
              currentSelection.to,
              {
                suggestedText: accumulatedContent
              }
            );
          }
        }
      }
    },
    onStop: () => {
      try {
        isStreamingRef.value = false;
        if (currentSelection && currentEditor) {
          const { state: state2 } = currentEditor;
          const { doc } = state2;
          const docSize = doc.content.size;
          if (currentSelection.from >= 0 && currentSelection.to >= 0 && currentSelection.from <= docSize && currentSelection.to <= docSize && currentSelection.from <= currentSelection.to) {
            updateAiHighlight(
              editor,
              currentSelection.from,
              currentSelection.to,
              {
                isStreaming: false
              }
            );
          }
        }
      } catch (error) {
        console.warn("[Polish] Failed to finalize formatting:", error);
      }
    },
    onError: (error) => {
      console.error("[Polish] Error:", error);
      handleCleanup();
      notification.error({
        message: "润色失败",
        description: error.message || t("messages.networkError"),
        duration: 3
      });
    }
  };
  aiApiService.polish(selectedText, sysPrompt, callback);
}
function mountPolishPopover(editor) {
  if (polishPopoverApp) {
    polishPopoverApp.unmount();
    polishPopoverApp = null;
  }
  const editorElement = editor.view.dom.parentElement;
  if (!polishContainer || !polishContainer.parentNode) {
    polishContainer = document.createElement("div");
    polishContainer.style.position = "absolute";
    polishContainer.style.top = "0";
    polishContainer.style.left = "0";
    polishContainer.style.zIndex = "1000";
    if (editorElement) {
      editorElement.append(polishContainer);
    } else {
      document.body.append(polishContainer);
    }
  } else {
    polishContainer.innerHTML = "";
  }
  const position = calculatePopoverPosition(editor);
  polishPopoverApp = createApp({
    render: () => h(AiSuggestionPopover, {
      visible: visibleRef.value,
      originalText: originalTextRef.value,
      suggestedText: suggestedTextRef.value,
      isStreaming: isStreamingRef.value,
      position,
      editorElement: editorElement || void 0,
      "onUpdate:visible": (val) => {
        visibleRef.value = val;
      },
      onAccept: () => {
        handleAccept();
      },
      onReject: () => {
        handleReject();
      },
      onCancel: () => {
        handleCancel();
      }
    })
  });
  polishPopoverApp.mount(polishContainer);
}
function unmountPolishPopover() {
  if (polishPopoverApp) {
    polishPopoverApp.unmount();
    polishPopoverApp = null;
  }
}
function calculatePopoverPosition(editor) {
  if (!currentSelection) {
    return { left: 0, top: 0 };
  }
  const { from, to } = currentSelection;
  const { view } = editor;
  const start = view.coordsAtPos(from);
  const end = view.coordsAtPos(to);
  const editorRect = view.dom.getBoundingClientRect();
  const top = end.bottom - editorRect.top + 8;
  const left = start.left - editorRect.left;
  return { left, top };
}
function handleAccept() {
  if (!currentEditor || !currentSelection) return;
  const suggestedText = suggestedTextRef.value;
  const { state: state2 } = currentEditor;
  const { doc } = state2;
  const docSize = doc.content.size;
  if (!isValidSelection(currentSelection, docSize)) {
    console.warn("[Polish] Invalid selection range, cannot accept");
    handleCleanup();
    return;
  }
  if (hasNewlines(suggestedText)) {
    const nodes = buildParagraphNodesFromText(suggestedText, state2.schema);
    if (nodes.length > 0) {
      const tr = state2.tr;
      tr.replaceWith(currentSelection.from, currentSelection.to, nodes);
      currentEditor.view.dispatch(tr);
    }
  } else {
    currentEditor.chain().focus().deleteRange(currentSelection).insertContentAt(currentSelection.from, suggestedText).run();
  }
  handleCleanup();
}
function handleReject() {
  handleCleanup();
}
function handleCancel() {
  unmountPolishPopover();
  visibleRef.value = false;
  setupClickHandler();
}
function setupClickHandler() {
  if (!currentEditor) return;
  const editorDom = currentEditor.view.dom;
  const existingHandler = editorDom._polishClickHandler;
  if (existingHandler) {
    editorDom.removeEventListener("click", existingHandler);
  }
  const clickHandler = (event) => {
    const target = event.target;
    if (!target) return;
    const highlightElement = target.classList.contains("ai-highlight") ? target : target.closest(".ai-highlight");
    if (!highlightElement) return;
    if (!currentEditor || !currentSelection) return;
    if (visibleRef.value) return;
    event.stopPropagation();
    let pos;
    try {
      pos = currentEditor.view.posAtDOM(highlightElement, 0);
    } catch (error) {
      console.warn("[Polish] Failed to get position from DOM:", error);
      pos = currentSelection.from;
    }
    let data = getAiSuggestionData(currentEditor, pos);
    if (!data && currentSelection) {
      data = getAiSuggestionData(currentEditor, currentSelection.from);
    }
    if (!data) {
      data = {
        originalText: originalTextRef.value,
        suggestedText: suggestedTextRef.value,
        isStreaming: isStreamingRef.value
      };
    }
    originalTextRef.value = data.originalText || originalTextRef.value;
    suggestedTextRef.value = data.suggestedText || suggestedTextRef.value;
    isStreamingRef.value = data.isStreaming || false;
    unmountPolishPopover();
    mountPolishPopover(currentEditor);
    visibleRef.value = true;
  };
  editorDom._polishClickHandler = clickHandler;
  editorDom.addEventListener("click", clickHandler);
}
function handleCleanup() {
  if (currentEditor) {
    const editorDom = currentEditor.view.dom;
    const existingHandler = editorDom._polishClickHandler;
    if (existingHandler) {
      editorDom.removeEventListener("click", existingHandler);
      delete editorDom._polishClickHandler;
    }
    removeAiHighlight(currentEditor);
  }
  unmountPolishPopover();
  if (polishContainer && polishContainer.parentNode) {
    polishContainer.parentNode.removeChild(polishContainer);
  }
  polishContainer = null;
  visibleRef.value = false;
  originalTextRef.value = "";
  suggestedTextRef.value = "";
  isStreamingRef.value = false;
  currentEditor = null;
  currentSelection = null;
}
class AiSuggestionManager {
  editor = null;
  popoverApp = null;
  container = null;
  state = {
    visible: false,
    originalText: "",
    suggestedText: "",
    isStreaming: false,
    originalSelection: { from: 0, to: 0 }
  };
  // Reactive refs for the popover component
  visibleRef = ref(false);
  originalTextRef = ref("");
  suggestedTextRef = ref("");
  isStreamingRef = ref(false);
  // Track if the suggestion is temporarily hidden
  isTemporarilyHidden = false;
  // Event handler reference for cleanup
  clickHandler = null;
  /**
   * Initialize the suggestion manager
   */
  init(editor) {
    this.editor = editor;
    this.setupClickHandler();
    this.restoreExistingHighlights();
  }
  /**
   * Setup click handler for highlighted text
   */
  setupClickHandler() {
    if (!this.editor) return;
    this.removeClickHandler();
    this.clickHandler = (event) => {
      const target = event.target;
      const highlightElement = target.classList.contains("ai-highlight") ? target : target.closest(".ai-highlight");
      if (highlightElement) {
        const pos = this.editor.view.posAtDOM(highlightElement, 0);
        const data = getAiSuggestionData(this.editor, pos);
        if (data) {
          if (this.isTemporarilyHidden && this.state.visible) {
            this.showPopover();
          } else if (!this.state.visible) {
            this.restoreSuggestion(highlightElement, data);
          }
        }
      }
    };
    this.editor.view.dom.addEventListener("click", this.clickHandler);
  }
  /**
   * Remove click handler to prevent memory leaks
   */
  removeClickHandler() {
    if (this.editor && this.clickHandler) {
      this.editor.view.dom.removeEventListener("click", this.clickHandler);
      this.clickHandler = null;
    }
  }
  /**
   * Restore existing highlights from the document
   */
  restoreExistingHighlights() {
    if (!this.editor) return;
  }
  /**
   * Restore a suggestion from saved data
   */
  restoreSuggestion(element, data) {
    if (!this.editor) return;
    const pos = this.editor.view.posAtDOM(element, 0);
    const node = this.editor.state.doc.nodeAt(pos);
    if (!node) return;
    const from = pos;
    const to = pos + node.nodeSize;
    this.state = {
      visible: true,
      originalText: data.originalText,
      suggestedText: data.suggestedText,
      isStreaming: false,
      originalSelection: { from, to }
    };
    this.visibleRef.value = true;
    this.originalTextRef.value = data.originalText;
    this.suggestedTextRef.value = data.suggestedText;
    this.isStreamingRef.value = false;
    this.isTemporarilyHidden = false;
    if (!this.popoverApp) {
      this.mountPopover();
    }
  }
  /**
   * Show AI suggestion popover
   */
  show(originalText, originalSelection, editor) {
    if (editor && !this.editor) {
      this.init(editor);
    }
    if (!this.editor) return;
    this.state = {
      visible: true,
      originalText,
      suggestedText: "",
      isStreaming: true,
      originalSelection
    };
    this.visibleRef.value = true;
    this.originalTextRef.value = originalText;
    this.suggestedTextRef.value = "";
    this.isStreamingRef.value = true;
    this.isTemporarilyHidden = false;
    const highlightData = {
      originalText,
      suggestedText: "",
      isStreaming: true
    };
    addAiHighlight(
      this.editor,
      originalSelection.from,
      originalSelection.to,
      highlightData
    );
    if (!this.popoverApp) {
      this.mountPopover();
    }
  }
  /**
   * Show the popover (for clicking on highlighted text)
   */
  showPopover() {
    this.isTemporarilyHidden = false;
    this.visibleRef.value = true;
  }
  /**
   * Update suggested text (for streaming)
   */
  updateSuggestion(text2) {
    this.state.suggestedText = text2;
    this.suggestedTextRef.value = text2;
    if (this.editor && this.state.originalSelection) {
      updateAiHighlight(
        this.editor,
        this.state.originalSelection.from,
        this.state.originalSelection.to,
        {
          suggestedText: text2
        }
      );
    }
  }
  /**
   * Stop streaming
   */
  stopStreaming() {
    this.state.isStreaming = false;
    this.isStreamingRef.value = false;
    if (this.editor && this.state.originalSelection) {
      updateAiHighlight(
        this.editor,
        this.state.originalSelection.from,
        this.state.originalSelection.to,
        {
          isStreaming: false
        }
      );
    }
  }
  /**
   * Accept the suggestion
   */
  accept() {
    if (!this.editor || !this.state.visible) return;
    const { originalSelection, suggestedText } = this.state;
    const { state: state2 } = this.editor;
    const hasNewlines2 = /\r?\n/.test(suggestedText);
    if (hasNewlines2) {
      const paragraphNodes = this.buildParagraphNodes(suggestedText);
      if (paragraphNodes.length > 0) {
        const tr = state2.tr;
        tr.replaceWith(
          originalSelection.from,
          originalSelection.to,
          paragraphNodes
        );
        this.editor.view.dispatch(tr);
      }
    } else {
      this.editor.chain().focus().deleteRange(originalSelection).insertContentAt(originalSelection.from, suggestedText).run();
    }
    this.hide();
  }
  /**
   * Build paragraph nodes from text with newlines
   */
  buildParagraphNodes(text2) {
    if (!this.editor) return [];
    const { schema } = this.editor.state;
    if (!schema.nodes.paragraph) return [];
    const lines = text2.split(/\r?\n/);
    const nodes = [];
    for (const line of lines) {
      if (line.length > 0) {
        const textNode = schema.text(line);
        const paragraphNode = schema.nodes.paragraph.create(null, textNode);
        nodes.push(paragraphNode);
      } else {
        const paragraphNode = schema.nodes.paragraph.create();
        nodes.push(paragraphNode);
      }
    }
    return nodes;
  }
  /**
   * Reject the suggestion
   */
  reject() {
    this.hide();
  }
  /**
   * Cancel (temporarily hide) the suggestion
   */
  cancel() {
    this.isTemporarilyHidden = true;
    this.visibleRef.value = false;
  }
  /**
   * Hide the popover and cleanup
   */
  hide() {
    if (!this.editor) return;
    this.visibleRef.value = false;
    this.isTemporarilyHidden = false;
    removeAiHighlight(this.editor);
    this.unmountPopover();
    this.state = {
      visible: false,
      originalText: "",
      suggestedText: "",
      isStreaming: false,
      originalSelection: { from: 0, to: 0 }
    };
  }
  /**
   * Check if suggestion is visible
   */
  isVisible() {
    return this.state.visible;
  }
  /**
   * Get current state
   */
  getState() {
    return { ...this.state };
  }
  /**
   * Mount the popover component
   */
  mountPopover() {
    if (!this.editor) return;
    if (this.popoverApp && this.container) return;
    this.container = document.createElement("div");
    this.container.style.position = "absolute";
    this.container.style.top = "0";
    this.container.style.left = "0";
    this.container.style.zIndex = "1000";
    const editorElement = this.editor.view.dom.parentElement;
    if (editorElement) {
      editorElement.append(this.container);
    } else {
      document.body.append(this.container);
    }
    const position = this.calculatePopoverPosition();
    this.popoverApp = createApp({
      render: () => h(AiSuggestionPopover, {
        visible: this.visibleRef.value,
        originalText: this.originalTextRef.value,
        suggestedText: this.suggestedTextRef.value,
        isStreaming: this.isStreamingRef.value,
        position,
        editorElement: editorElement || void 0,
        "onUpdate:visible": (val) => {
          this.visibleRef.value = val;
        },
        onAccept: () => {
          this.accept();
        },
        onReject: () => {
          this.reject();
        },
        onCancel: () => {
          this.cancel();
        }
      })
    });
    this.popoverApp.mount(this.container);
  }
  /**
   * Unmount the popover component
   */
  unmountPopover() {
    if (this.popoverApp) {
      this.popoverApp.unmount();
      this.popoverApp = null;
    }
    if (this.container && this.container.parentNode) {
      this.container.remove();
      this.container = null;
    }
  }
  /**
   * Calculate popover position based on selection
   */
  calculatePopoverPosition() {
    if (!this.editor) {
      return { top: 0, left: 0 };
    }
    const { from, to } = this.state.originalSelection;
    const { view } = this.editor;
    const start = view.coordsAtPos(from);
    const end = view.coordsAtPos(to);
    const editorRect = view.dom.getBoundingClientRect();
    const top = end.bottom - editorRect.top + 8;
    const left = start.left - editorRect.left;
    return { top, left };
  }
  /**
   * Cleanup
   */
  destroy() {
    this.removeClickHandler();
    this.hide();
    this.editor = null;
  }
}
const aiSuggestionManager = new AiSuggestionManager();
const SummarizeExtension = Extension.create({
  name: "summarize",
  addCommands() {
    return {
      summarize: () => ({ state: state2, editor }) => {
        const { selection } = state2;
        const { from, to } = selection;
        const selectedText = state2.doc.textBetween(from, to, " ");
        if (!selectedText.trim()) {
          console.warn("[Summarize] No text selected");
          notification.warning({
            message: t("editor.pleaseSelectText"),
            description: t("editor.summarizeRequiresSelection"),
            duration: 3,
            placement: "topRight"
          });
          return false;
        }
        performSummarize(editor, selectedText, { from, to });
        return true;
      }
    };
  }
});
function performSummarize(editor, selectedText, originalSelection) {
  let accumulatedContent = "";
  aiSuggestionManager.show(selectedText, originalSelection, editor);
  const state2 = editor.state;
  const fullText = state2.doc.textBetween(0, state2.doc.content.size, " ");
  const sysPrompt = `以下係完整嘅文件內容:

${fullText}`;
  const callback = {
    onStart: () => {
      accumulatedContent = "";
    },
    onMessage: (message2) => {
      if (message2 && message2.content) {
        accumulatedContent += message2.content;
        aiSuggestionManager.updateSuggestion(accumulatedContent);
      }
    },
    onStop: () => {
      try {
        aiSuggestionManager.stopStreaming();
        aiSuggestionManager.updateSuggestion(accumulatedContent);
      } catch (error) {
        console.warn("[Summarize] Failed to finalize formatting:", error);
      }
    },
    onError: (error) => {
      console.error("[Summarize] Error:", error);
      aiSuggestionManager.hide();
      notification.error({
        message: "总结失败",
        description: error.message || t("messages.networkError"),
        duration: 3
      });
    }
  };
  aiApiService.summarize(selectedText, sysPrompt, callback);
}
const STORAGE_KEY = "tiptap_translate_target_lang";
const saved = typeof window !== "undefined" ? window.localStorage?.getItem(STORAGE_KEY) : null;
const currentTranslateLang = ref(saved || "");
function setTranslateLang(label) {
  try {
    currentTranslateLang.value = label;
    if (typeof window !== "undefined") {
      window.localStorage?.setItem(STORAGE_KEY, label);
    }
  } catch (error) {
    console.warn("[Translate Store] Failed to save language preference:", error);
  }
}
const TranslationExtension = Extension.create({
  name: "translation",
  addOptions() {
    return {
      defaultTargetLang: "英文"
    };
  },
  addCommands() {
    return {
      translate: (targetLang) => ({ state: state2, editor }) => {
        const { selection } = state2;
        const { from, to } = selection;
        const selectedText = state2.doc.textBetween(from, to, " ");
        if (!selectedText.trim()) {
          console.warn("[Translation] No text selected");
          notification.warning({
            message: t("editor.pleaseSelectText"),
            description: t("editor.translateRequiresSelection"),
            duration: 3,
            placement: "topRight"
          });
          return false;
        }
        const lang = targetLang || currentTranslateLang.value || this.options.defaultTargetLang || "英文";
        performTranslation(editor, selectedText, lang, { from, to });
        return true;
      }
    };
  }
});
function performTranslation(editor, selectedText, targetLang, originalSelection) {
  let accumulatedContent = "";
  aiSuggestionManager.show(selectedText, originalSelection, editor);
  const state2 = editor.state;
  const fullText = state2.doc.textBetween(0, state2.doc.content.size, " ");
  const sysPrompt = `以下係完整嘅文件內容:

${fullText}`;
  const callback = {
    onStart: () => {
      accumulatedContent = "";
    },
    onMessage: (message2) => {
      if (message2 && message2.content) {
        accumulatedContent += message2.content;
        aiSuggestionManager.updateSuggestion(accumulatedContent);
      }
    },
    onStop: () => {
      try {
        aiSuggestionManager.stopStreaming();
        aiSuggestionManager.updateSuggestion(accumulatedContent);
      } catch (error) {
        console.warn("[Translation] Failed to finalize formatting:", error);
      }
    },
    onError: (error) => {
      console.error("[Translation] Error:", error);
      aiSuggestionManager.hide();
      notification.error({
        message: t("messages.translationFailed"),
        description: error.message || t("messages.networkError"),
        duration: 3
      });
    }
  };
  aiApiService.translate(selectedText, targetLang, sysPrompt, callback);
}
const LANGUAGE_CODES = [
  { code: "zh-CN", key: "zh-CN" },
  { code: "zh-TW", key: "zh-TW" },
  { code: "en", key: "en" },
  { code: "ja", key: "ja" },
  { code: "th", key: "th" },
  { code: "fr", key: "fr" },
  { code: "es", key: "es" },
  { code: "pt", key: "pt" },
  { code: "ko", key: "ko" },
  { code: "vi", key: "vi" },
  { code: "ru", key: "ru" },
  { code: "de", key: "de" },
  { code: "hi", key: "hi" },
  { code: "id", key: "id" }
];
const _hoisted_1$c = { class: "ai-menu-button__content" };
const _hoisted_2$b = {
  key: 1,
  class: "ai-menu-button__label"
};
const _hoisted_3$a = ["onClick"];
const _hoisted_4$9 = { class: "ai-menu-item__label" };
const _hoisted_5$9 = ["title"];
const _hoisted_6$9 = { class: "ai-menu-item" };
const _hoisted_7$8 = { class: "ai-menu-item__label" };
const _hoisted_8$5 = { class: "ai-menu-item" };
const _hoisted_9$5 = { class: "ai-menu-item__label" };
const _sfc_main$d = /* @__PURE__ */ defineComponent({
  __name: "AiMenuButton",
  props: {
    editor: {},
    icon: {},
    label: {},
    title: {},
    active: { type: Boolean, default: false },
    placement: { default: "bottom" }
  },
  setup(__props) {
    const dropdownOpen = ref(false);
    const props = __props;
    const overlayOpen = ref(false);
    const hasSelectedLang = computed(() => !!currentTranslateLang.value);
    const selectedLangKey = computed(() => {
      if (!currentTranslateLang.value) return "";
      const lang = LANGUAGE_CODES.find((l) => t(`editor.lang.${l.key}`) === currentTranslateLang.value);
      return lang ? `translate-${lang.code}` : "";
    });
    let closeTimeout = null;
    function cancelClose() {
      if (closeTimeout) {
        clearTimeout(closeTimeout);
        closeTimeout = null;
      }
    }
    function scheduleClose() {
      cancelClose();
      closeTimeout = window.setTimeout(() => {
        overlayOpen.value = false;
      }, 150);
    }
    function onRowEnter() {
      if (!hasSelectedLang.value) {
        cancelClose();
        overlayOpen.value = true;
      }
    }
    function onRowLeave() {
      if (!hasSelectedLang.value) {
        scheduleClose();
      }
    }
    function onOverlayEnter() {
      cancelClose();
    }
    function onOverlayLeave() {
      scheduleClose();
    }
    function onDropOpenChange(nextOpen) {
      if (hasSelectedLang.value) {
        overlayOpen.value = nextOpen;
      }
    }
    function findItemByKey(items, key) {
      for (const item of items) {
        if (item.key === key) return item;
        if (item.children?.length) {
          const found = findItemByKey(item.children, key);
          if (found) return found;
        }
      }
      return void 0;
    }
    function onMenuClick(info) {
      const item = findItemByKey(menuItems.value, info.key);
      if (!item) return;
      nextTick(() => {
        requestAnimationFrame(() => {
          setTimeout(() => {
            try {
              item.action?.();
            } catch (error) {
              console.error("[AI Menu] Error executing command:", error);
            }
          }, 50);
        });
      });
    }
    function onTranslateDefault(item) {
      if (!hasSelectedLang.value) {
        overlayOpen.value = true;
        return;
      }
      nextTick(() => {
        requestAnimationFrame(() => {
          setTimeout(() => {
            try {
              item.action?.();
            } catch (error) {
              console.error("[AI Menu] Error executing translate:", error);
            }
          }, 50);
        });
      });
    }
    function onTranslateLangClick(info) {
      const child = findItemByKey(menuItems.value, info.key);
      if (!child) return;
      nextTick(() => {
        requestAnimationFrame(() => {
          setTimeout(() => {
            try {
              child.action?.();
            } catch (error) {
              console.error("[AI Menu] Error executing translate:", error);
            }
          }, 50);
        });
      });
    }
    function handleOpenChange(open2) {
      if (!open2) {
        overlayOpen.value = false;
      }
    }
    const menuItems = computed(() => {
      const { editor } = props;
      return [
        {
          key: "continueWriting",
          label: t("editor.continueWriting"),
          icon: ThunderboltOutlined,
          action: () => {
            if (!editor) return;
            try {
              const { state: state2 } = editor;
              const { selection, doc } = state2;
              const docSize = doc.content.size;
              if (selection.from < 0 || selection.to < 0 || selection.from > docSize || selection.to > docSize || selection.from > selection.to) {
                console.warn("[AI Menu] Invalid selection, cannot execute continueWriting");
                return;
              }
              if (typeof editor.commands.continueWriting === "function") {
                const result = editor.chain().focus().continueWriting().run();
                if (!result) {
                  console.warn("[AI Menu] continueWriting command returned false");
                }
              } else {
                console.warn("[AI Menu] continueWriting command not available");
                editor.commands.focus();
              }
            } catch (error) {
              console.error("[AI Menu] Error executing continueWriting:", error);
            }
          },
          disabled: false,
          danger: false
        },
        {
          key: "polish",
          label: t("editor.polish"),
          icon: EditOutlined,
          action: () => {
            if (!editor) return;
            try {
              const { state: state2 } = editor;
              const { selection, doc } = state2;
              const docSize = doc.content.size;
              if (selection.from < 0 || selection.to < 0 || selection.from > docSize || selection.to > docSize || selection.from > selection.to) {
                console.warn("[AI Menu] Invalid selection, cannot execute polish");
                return;
              }
              if (typeof editor.commands.polish === "function") {
                const result = editor.chain().focus().polish().run();
                if (!result) {
                  console.warn("[AI Menu] polish command returned false");
                }
              } else {
                console.warn("[AI Menu] polish command not available");
                editor.commands.focus();
              }
            } catch (error) {
              console.error("[AI Menu] Error executing polish:", error);
            }
          },
          disabled: false,
          danger: false
        },
        {
          key: "summarize",
          label: t("editor.summarize"),
          icon: FileTextOutlined,
          action: () => {
            if (!editor) return;
            try {
              const { state: state2 } = editor;
              const { selection, doc } = state2;
              const docSize = doc.content.size;
              if (selection.from < 0 || selection.to < 0 || selection.from > docSize || selection.to > docSize || selection.from > selection.to) {
                console.warn("[AI Menu] Invalid selection, cannot execute summarize");
                return;
              }
              if (typeof editor.commands.summarize === "function") {
                const result = editor.chain().focus().summarize().run();
                if (!result) {
                  console.warn("[AI Menu] summarize command returned false");
                }
              } else {
                console.warn("[AI Menu] summarize command not available");
                editor.commands.focus();
              }
            } catch (error) {
              console.error("[AI Menu] Error executing summarize:", error);
            }
          },
          disabled: false,
          danger: false
        },
        {
          key: "customAi",
          label: t("editor.customAi"),
          icon: BulbOutlined,
          action: () => {
            if (!editor) return;
            try {
              const { state: state2 } = editor;
              const { selection, doc } = state2;
              const docSize = doc.content.size;
              if (selection.from < 0 || selection.to < 0 || selection.from > docSize || selection.to > docSize || selection.from > selection.to) {
                console.warn("[AI Menu] Invalid selection, cannot execute customAi");
                return;
              }
              if (typeof editor.commands.customAi === "function") {
                const result = editor.chain().focus().customAi().run();
                if (!result) {
                  console.warn("[AI Menu] customAi command returned false");
                }
              } else {
                console.warn("[AI Menu] customAi command not available");
                editor.commands.focus();
              }
            } catch (error) {
              console.error("[AI Menu] Error executing customAi:", error);
            }
          },
          disabled: false,
          danger: false
        },
        {
          key: "translate",
          label: currentTranslateLang.value ? t("editor.translateTo", { lang: currentTranslateLang.value }) : t("editor.translate"),
          icon: TranslationOutlined,
          action: () => {
            if (!editor) return;
            try {
              const { state: state2 } = editor;
              const { selection, doc } = state2;
              const docSize = doc.content.size;
              if (selection.from < 0 || selection.to < 0 || selection.from > docSize || selection.to > docSize || selection.from > selection.to) {
                console.warn("[AI Menu] Invalid selection, cannot execute translate");
                return;
              }
              const targetLang = currentTranslateLang.value || "英文";
              if (typeof editor.commands.translate === "function") {
                const result = editor.chain().focus().translate(targetLang).run();
                if (!result) {
                  console.warn("[AI Menu] translate command returned false");
                }
              } else {
                console.warn("[AI Menu] translate command not available");
                editor.commands.focus();
              }
            } catch (error) {
              console.error("[AI Menu] Error executing translate:", error);
            }
          },
          disabled: false,
          danger: false,
          children: LANGUAGE_CODES.map(({ code, key }) => {
            const langLabel = t(`editor.lang.${key}`);
            return {
              key: `translate-${code}`,
              label: langLabel,
              action: () => {
                if (!editor) return;
                setTranslateLang(langLabel);
                try {
                  const { state: state2 } = editor;
                  const { selection, doc } = state2;
                  const docSize = doc.content.size;
                  if (selection.from < 0 || selection.to < 0 || selection.from > docSize || selection.to > docSize || selection.from > selection.to) {
                    console.warn("[AI Menu] Invalid selection, cannot execute translate");
                    return;
                  }
                  if (typeof editor.commands.translate === "function") {
                    const result = editor.chain().focus().translate(langLabel).run();
                    if (!result) {
                      console.warn("[AI Menu] translate command returned false");
                    }
                  } else {
                    console.warn("[AI Menu] translate command not available");
                    editor.commands.focus();
                  }
                } catch (error) {
                  console.error("[AI Menu] Error executing translate:", error);
                }
              },
              disabled: false,
              danger: false
            };
          })
        }
      ];
    });
    return (_ctx, _cache) => {
      const _component_a_button = resolveComponent("a-button");
      const _component_a_menu_item = resolveComponent("a-menu-item");
      const _component_a_menu = resolveComponent("a-menu");
      const _component_a_dropdown = resolveComponent("a-dropdown");
      return openBlock(), createBlock(_component_a_dropdown, {
        placement: __props.placement,
        trigger: ["click"],
        open: dropdownOpen.value,
        "onUpdate:open": _cache[0] || (_cache[0] = ($event) => dropdownOpen.value = $event),
        onOpenChange: handleOpenChange
      }, {
        overlay: withCtx(() => [
          createVNode(_component_a_menu, {
            onClick: onMenuClick,
            style: { "max-height": "360px", "overflow-y": "auto" }
          }, {
            default: withCtx(() => [
              (openBlock(true), createElementBlock(Fragment, null, renderList(menuItems.value, (item) => {
                return openBlock(), createElementBlock(Fragment, {
                  key: item.key
                }, [
                  item.children && item.children.length > 0 ? (openBlock(), createBlock(_component_a_menu_item, {
                    key: item.key + ":with-children"
                  }, {
                    default: withCtx(() => [
                      createElementVNode("div", {
                        class: "ai-menu-translate-split",
                        onMouseenter: onRowEnter,
                        onMouseleave: onRowLeave
                      }, [
                        createElementVNode("span", {
                          class: "ai-menu-translate-split__main",
                          onClick: withModifiers(($event) => onTranslateDefault(item), ["stop"])
                        }, [
                          item.icon ? (openBlock(), createBlock(resolveDynamicComponent(item.icon), {
                            key: 0,
                            class: "ai-menu-item__icon"
                          })) : createCommentVNode("", true),
                          createElementVNode("span", _hoisted_4$9, toDisplayString(item.label), 1)
                        ], 8, _hoisted_3$a),
                        createVNode(_component_a_dropdown, {
                          trigger: hasSelectedLang.value ? ["hover"] : [],
                          placement: "rightTop",
                          open: overlayOpen.value,
                          onOpenChange: onDropOpenChange
                        }, {
                          overlay: withCtx(() => [
                            createElementVNode("div", {
                              class: "ai-menu-translate-overlay",
                              onMouseenter: onOverlayEnter,
                              onMouseleave: onOverlayLeave
                            }, [
                              createVNode(_component_a_menu, {
                                onClick: onTranslateLangClick,
                                class: "ai-menu-dropdown-overlay",
                                selectedKeys: selectedLangKey.value ? [selectedLangKey.value] : []
                              }, {
                                default: withCtx(() => [
                                  (openBlock(true), createElementBlock(Fragment, null, renderList(item.children, (child) => {
                                    return openBlock(), createBlock(_component_a_menu_item, {
                                      key: child.key,
                                      disabled: child.disabled,
                                      danger: child.danger
                                    }, {
                                      default: withCtx(() => [
                                        createElementVNode("span", _hoisted_6$9, [
                                          createElementVNode("span", _hoisted_7$8, toDisplayString(child.label), 1)
                                        ])
                                      ]),
                                      _: 2
                                    }, 1032, ["disabled", "danger"]);
                                  }), 128))
                                ]),
                                _: 2
                              }, 1032, ["selectedKeys"])
                            ], 32)
                          ]),
                          default: withCtx(() => [
                            createElementVNode("span", {
                              class: "ai-menu-translate-split__arrow",
                              title: unref(t)("editor.selectLanguage")
                            }, [
                              createVNode(unref(RightOutlined))
                            ], 8, _hoisted_5$9)
                          ]),
                          _: 2
                        }, 1032, ["trigger", "open"])
                      ], 32)
                    ]),
                    _: 2
                  }, 1024)) : (openBlock(), createBlock(_component_a_menu_item, {
                    key: item.key,
                    disabled: item.disabled,
                    danger: item.danger
                  }, {
                    default: withCtx(() => [
                      createElementVNode("span", _hoisted_8$5, [
                        item.icon ? (openBlock(), createBlock(resolveDynamicComponent(item.icon), {
                          key: 0,
                          class: "ai-menu-item__icon"
                        })) : createCommentVNode("", true),
                        createElementVNode("span", _hoisted_9$5, toDisplayString(item.label), 1)
                      ])
                    ]),
                    _: 2
                  }, 1032, ["disabled", "danger"]))
                ], 64);
              }), 128))
            ]),
            _: 1
          })
        ]),
        default: withCtx(() => [
          createVNode(unref(Tooltip), {
            title: __props.title,
            placement: "top",
            open: dropdownOpen.value ? false : void 0
          }, {
            default: withCtx(() => [
              createVNode(_component_a_button, {
                type: "text",
                class: normalizeClass(["ai-menu-button", { "is-active": __props.active }])
              }, {
                default: withCtx(() => [
                  createElementVNode("span", _hoisted_1$c, [
                    __props.icon ? (openBlock(), createBlock(resolveDynamicComponent(__props.icon), {
                      key: 0,
                      class: "ai-menu-button__icon"
                    })) : createCommentVNode("", true),
                    __props.label ? (openBlock(), createElementBlock("span", _hoisted_2$b, toDisplayString(__props.label), 1)) : createCommentVNode("", true),
                    createVNode(unref(DownOutlined), { class: "ai-menu-button__arrow" })
                  ])
                ]),
                _: 1
              }, 8, ["class"])
            ]),
            _: 1
          }, 8, ["title", "open"])
        ]),
        _: 1
      }, 8, ["placement", "open"]);
    };
  }
});
const AiMenuButton = /* @__PURE__ */ _export_sfc(_sfc_main$d, [["__scopeId", "data-v-f1df6707"]]);
const _sfc_main$c = /* @__PURE__ */ defineComponent({
  __name: "BaseTooltip",
  props: {
    title: {},
    placement: { default: "top" }
  },
  setup(__props) {
    const showTooltip = ref(false);
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: "tt-tooltip-wrapper",
        onMouseenter: _cache[0] || (_cache[0] = ($event) => showTooltip.value = true),
        onMouseleave: _cache[1] || (_cache[1] = ($event) => showTooltip.value = false),
        onFocus: _cache[2] || (_cache[2] = ($event) => showTooltip.value = true),
        onBlur: _cache[3] || (_cache[3] = ($event) => showTooltip.value = false)
      }, [
        renderSlot(_ctx.$slots, "default", {}, void 0, true),
        createVNode(Transition, { name: "tt-tooltip-fade" }, {
          default: withCtx(() => [
            showTooltip.value && __props.title ? (openBlock(), createElementBlock("div", {
              key: 0,
              class: normalizeClass(["tt-tooltip", `tt-tooltip--${__props.placement}`])
            }, [
              createTextVNode(toDisplayString(__props.title) + " ", 1),
              _cache[4] || (_cache[4] = createElementVNode("div", { class: "tt-tooltip__arrow" }, null, -1))
            ], 2)) : createCommentVNode("", true)
          ]),
          _: 1
        })
      ], 32);
    };
  }
});
const BaseTooltip = /* @__PURE__ */ _export_sfc(_sfc_main$c, [["__scopeId", "data-v-b37cc79e"]]);
const _hoisted_1$b = { class: "ai-settings" };
const _hoisted_2$a = { class: "ai-settings__section" };
const _hoisted_3$9 = { class: "ai-settings__label" };
const _hoisted_4$8 = {
  key: 0,
  class: "ai-settings__hint"
};
const _hoisted_5$8 = ["href"];
const _hoisted_6$8 = {
  key: 0,
  class: "ai-settings__section"
};
const _hoisted_7$7 = { class: "ai-settings__hint" };
const _hoisted_8$4 = {
  key: 1,
  class: "ai-settings__section"
};
const _hoisted_9$4 = { class: "ai-settings__label" };
const _hoisted_10$3 = { class: "ai-settings__section" };
const _hoisted_11$3 = { class: "ai-settings__label" };
const _hoisted_12$3 = { class: "ai-settings__hint" };
const _hoisted_13$3 = { class: "ai-settings__section" };
const _hoisted_14$3 = {
  key: 0,
  class: "ai-settings__latency"
};
const _hoisted_15$2 = {
  key: 1,
  class: "ai-settings__error"
};
const _hoisted_16$1 = { class: "ai-settings__section ai-settings__section--inline" };
const _hoisted_17$1 = { class: "ai-settings__label" };
const _hoisted_18$1 = { class: "ai-settings__actions" };
const _hoisted_19$1 = { class: "ai-settings__actions-right" };
const _sfc_main$b = /* @__PURE__ */ defineComponent({
  __name: "AiSettingsModal",
  props: {
    open: { type: Boolean, default: false }
  },
  emits: ["update:open", "saved"],
  setup(__props, { emit: __emit }) {
    const AInputPassword = Input.Password;
    const props = __props;
    const emit = __emit;
    const visible = computed({
      get: () => props.open,
      set: (val) => emit("update:open", val)
    });
    const {
      config,
      testConnection: testConnection2,
      saveConfig,
      clearConfig
    } = useAiConfig();
    const formData = reactive({
      provider: "openai",
      apiKey: "",
      endpoint: "",
      model: "",
      timeout: DEFAULT_CONFIG.timeout,
      enabled: true
    });
    const testStatus = ref("idle");
    const testError = ref(null);
    const testLatency = ref(null);
    const providerOptions = computed(
      () => AI_PROVIDERS.map((p) => ({
        value: p.id,
        label: p.name
      }))
    );
    const currentProviderInfo = computed(() => getProviderInfo(formData.provider));
    const canSave = computed(() => {
      const info = currentProviderInfo.value;
      if (!info) return false;
      if (info.requiresApiKey && !formData.apiKey) return false;
      if (formData.provider === "custom" && !formData.endpoint) return false;
      return true;
    });
    const testButtonText = computed(() => {
      switch (testStatus.value) {
        case "testing":
          return t("aiSettings.testing");
        case "success":
          return t("aiSettings.testSuccess");
        case "error":
          return t("aiSettings.testFailed");
        default:
          return t("aiSettings.testConnection");
      }
    });
    watch(() => props.open, (isOpen) => {
      if (isOpen && config.value) {
        Object.assign(formData, {
          provider: config.value.provider,
          apiKey: config.value.apiKey,
          endpoint: config.value.endpoint || "",
          model: config.value.model,
          timeout: config.value.timeout,
          enabled: config.value.enabled
        });
        testStatus.value = "idle";
        testError.value = null;
        testLatency.value = null;
      }
    });
    function onProviderChange(value) {
      const provider = value;
      const info = getProviderInfo(provider);
      if (info) {
        formData.endpoint = info.defaultEndpoint;
        formData.model = info.defaultModel;
      }
      testStatus.value = "idle";
      testError.value = null;
    }
    async function handleTest() {
      testStatus.value = "testing";
      testError.value = null;
      testLatency.value = null;
      const tempConfig = {
        ...formData,
        updatedAt: Date.now()
      };
      saveConfig(tempConfig);
      const result = await testConnection2();
      testStatus.value = result.success ? "success" : "error";
      testError.value = result.success ? null : result.message;
      testLatency.value = result.latency ?? null;
    }
    function handleSave() {
      const configToSave = {
        ...formData,
        updatedAt: Date.now()
      };
      saveConfig(configToSave);
      emit("saved");
      handleClose();
    }
    function handleClear() {
      clearConfig();
      Object.assign(formData, {
        provider: "openai",
        apiKey: "",
        endpoint: "",
        model: "",
        timeout: DEFAULT_CONFIG.timeout,
        enabled: true
      });
      testStatus.value = "idle";
      testError.value = null;
      testLatency.value = null;
    }
    function handleClose() {
      visible.value = false;
    }
    return (_ctx, _cache) => {
      return openBlock(), createBlock(unref(Modal), {
        open: visible.value,
        "onUpdate:open": _cache[5] || (_cache[5] = ($event) => visible.value = $event),
        title: unref(t)("aiSettings.title"),
        width: 520,
        footer: null,
        onCancel: handleClose,
        class: "ai-settings-modal"
      }, {
        default: withCtx(() => [
          createElementVNode("div", _hoisted_1$b, [
            createElementVNode("div", _hoisted_2$a, [
              createElementVNode("label", _hoisted_3$9, toDisplayString(unref(t)("aiSettings.provider")), 1),
              createVNode(unref(Select), {
                value: formData.provider,
                "onUpdate:value": _cache[0] || (_cache[0] = ($event) => formData.provider = $event),
                options: providerOptions.value,
                class: "ai-settings__select",
                onChange: onProviderChange
              }, null, 8, ["value", "options"]),
              currentProviderInfo.value?.docsUrl ? (openBlock(), createElementBlock("p", _hoisted_4$8, [
                createElementVNode("a", {
                  href: currentProviderInfo.value.docsUrl,
                  target: "_blank",
                  rel: "noopener"
                }, toDisplayString(unref(t)("aiSettings.viewDocs")) + " → ", 9, _hoisted_5$8)
              ])) : createCommentVNode("", true)
            ]),
            currentProviderInfo.value?.requiresApiKey ? (openBlock(), createElementBlock("div", _hoisted_6$8, [
              _cache[6] || (_cache[6] = createElementVNode("label", { class: "ai-settings__label" }, "API Key", -1)),
              createVNode(unref(AInputPassword), {
                value: formData.apiKey,
                "onUpdate:value": _cache[1] || (_cache[1] = ($event) => formData.apiKey = $event),
                placeholder: unref(t)("aiSettings.apiKeyPlaceholder"),
                class: "ai-settings__input"
              }, null, 8, ["value", "placeholder"]),
              createElementVNode("p", _hoisted_7$7, toDisplayString(unref(t)("aiSettings.apiKeyHint")), 1)
            ])) : createCommentVNode("", true),
            formData.provider === "custom" || formData.provider === "ollama" ? (openBlock(), createElementBlock("div", _hoisted_8$4, [
              createElementVNode("label", _hoisted_9$4, toDisplayString(unref(t)("aiSettings.endpoint")), 1),
              createVNode(unref(Input), {
                value: formData.endpoint,
                "onUpdate:value": _cache[2] || (_cache[2] = ($event) => formData.endpoint = $event),
                placeholder: currentProviderInfo.value?.defaultEndpoint || "https://api.example.com/v1",
                class: "ai-settings__input"
              }, null, 8, ["value", "placeholder"])
            ])) : createCommentVNode("", true),
            createElementVNode("div", _hoisted_10$3, [
              createElementVNode("label", _hoisted_11$3, toDisplayString(unref(t)("aiSettings.model")), 1),
              createVNode(unref(Input), {
                value: formData.model,
                "onUpdate:value": _cache[3] || (_cache[3] = ($event) => formData.model = $event),
                placeholder: currentProviderInfo.value?.defaultModel || "gpt-4o-mini",
                class: "ai-settings__input"
              }, null, 8, ["value", "placeholder"]),
              createElementVNode("p", _hoisted_12$3, toDisplayString(currentProviderInfo.value?.description), 1)
            ]),
            createElementVNode("div", _hoisted_13$3, [
              createVNode(unref(Button), {
                loading: testStatus.value === "testing",
                type: testStatus.value === "success" ? "default" : "primary",
                onClick: handleTest
              }, {
                icon: withCtx(() => [
                  testStatus.value === "success" ? (openBlock(), createBlock(unref(CheckCircleOutlined), {
                    key: 0,
                    style: { "color": "#52c41a" }
                  })) : testStatus.value === "error" ? (openBlock(), createBlock(unref(CloseCircleOutlined), {
                    key: 1,
                    style: { "color": "#ff4d4f" }
                  })) : (openBlock(), createBlock(unref(ApiOutlined), { key: 2 }))
                ]),
                default: withCtx(() => [
                  createTextVNode(" " + toDisplayString(testButtonText.value), 1)
                ]),
                _: 1
              }, 8, ["loading", "type"]),
              testLatency.value ? (openBlock(), createElementBlock("span", _hoisted_14$3, toDisplayString(testLatency.value) + "ms ", 1)) : createCommentVNode("", true),
              testError.value ? (openBlock(), createElementBlock("p", _hoisted_15$2, toDisplayString(testError.value), 1)) : createCommentVNode("", true)
            ]),
            createElementVNode("div", _hoisted_16$1, [
              createElementVNode("label", _hoisted_17$1, toDisplayString(unref(t)("aiSettings.enableAi")), 1),
              createVNode(unref(Switch), {
                checked: formData.enabled,
                "onUpdate:checked": _cache[4] || (_cache[4] = ($event) => formData.enabled = $event)
              }, null, 8, ["checked"])
            ]),
            createElementVNode("div", _hoisted_18$1, [
              createVNode(unref(Button), {
                onClick: handleClear,
                danger: ""
              }, {
                default: withCtx(() => [
                  createTextVNode(toDisplayString(unref(t)("aiSettings.clear")), 1)
                ]),
                _: 1
              }),
              createElementVNode("div", _hoisted_19$1, [
                createVNode(unref(Button), { onClick: handleClose }, {
                  default: withCtx(() => [
                    createTextVNode(toDisplayString(unref(t)("aiSettings.cancel")), 1)
                  ]),
                  _: 1
                }),
                createVNode(unref(Button), {
                  type: "primary",
                  onClick: handleSave,
                  disabled: !canSave.value
                }, {
                  default: withCtx(() => [
                    createTextVNode(toDisplayString(unref(t)("aiSettings.save")), 1)
                  ]),
                  _: 1
                }, 8, ["disabled"])
              ])
            ])
          ])
        ]),
        _: 1
      }, 8, ["open", "title"]);
    };
  }
});
const _hoisted_1$a = ["disabled"];
const _hoisted_2$9 = {
  key: 0,
  class: "ai-spinner"
};
const _hoisted_3$8 = {
  key: 1,
  class: "ai-badge"
};
const _hoisted_4$7 = {
  key: 0,
  class: "ai-menu-dropdown"
};
const _hoisted_5$7 = {
  key: 0,
  class: "ai-menu-hint"
};
const _hoisted_6$7 = ["onClick", "disabled"];
const _hoisted_7$6 = { class: "ai-menu-item-icon" };
const _hoisted_8$3 = { class: "ai-menu-item-label" };
const _hoisted_9$3 = { class: "ai-menu-custom" };
const _hoisted_10$2 = ["placeholder", "disabled"];
const _hoisted_11$2 = ["disabled"];
const _hoisted_12$2 = { class: "ai-menu-item-label" };
const _hoisted_13$2 = {
  key: 0,
  class: "ai-status-dot ai-status-dot--success"
};
const _hoisted_14$2 = {
  key: 1,
  class: "ai-status-dot ai-status-dot--warning"
};
const _sfc_main$a = /* @__PURE__ */ defineComponent({
  __name: "AiToolbarMenu",
  props: {
    editor: {},
    adapter: {}
  },
  setup(__props) {
    const props = __props;
    const isOpen = ref(false);
    const customPrompt = ref("");
    const containerRef = ref(null);
    const showSettings = ref(false);
    const { isConfigured } = useAiConfig();
    const { isLoading, continueWritingStream, polishStream, summarizeStream, translateStream, customAiStream } = useAi({
      adapter: props.adapter
    });
    const menuItems = computed(() => [
      { key: "continue", label: t("editor.continueWriting"), icon: "✍️", action: handleContinue },
      { key: "polish", label: t("editor.polish"), icon: "✨", action: handlePolish },
      { key: "summarize", label: t("editor.summarize"), icon: "📝", action: handleSummarize },
      { key: "translate-en", label: t("editor.lang.en"), icon: "🌐", action: () => handleTranslate("en") },
      { key: "translate-zh", label: t("editor.lang.zh-CN"), icon: "🇨🇳", action: () => handleTranslate("zh-CN") }
    ]);
    const toggleMenu = () => {
      isOpen.value = !isOpen.value;
    };
    const getSelectedText = () => {
      if (!props.editor) return "";
      const { from, to } = props.editor.state.selection;
      return props.editor.state.doc.textBetween(from, to, " ");
    };
    const insertAtCursor = (text2) => {
      props.editor?.chain().focus().insertContent(text2).run();
    };
    const replaceSelection = (text2) => {
      props.editor?.chain().focus().deleteSelection().insertContent(text2).run();
    };
    const handleContinue = async () => {
      isOpen.value = false;
      const text2 = getSelectedText() || props.editor?.getText() || "";
      if (!text2.trim()) return;
      props.editor?.commands.focus("end");
      await continueWritingStream(text2, {
        onToken: (token) => insertAtCursor(token),
        onError: (error) => console.error("AI Error:", error)
      });
    };
    const handlePolish = async () => {
      isOpen.value = false;
      const text2 = getSelectedText();
      if (!text2.trim()) return;
      let result = "";
      await polishStream(text2, {
        onToken: (token) => {
          result += token;
        },
        onComplete: () => replaceSelection(result),
        onError: (error) => console.error("AI Error:", error)
      });
    };
    const handleSummarize = async () => {
      isOpen.value = false;
      const text2 = getSelectedText() || props.editor?.getText() || "";
      if (!text2.trim()) return;
      await summarizeStream(text2, {
        onToken: (token) => insertAtCursor(token),
        onError: (error) => console.error("AI Error:", error)
      });
    };
    const handleTranslate = async (lang) => {
      isOpen.value = false;
      const text2 = getSelectedText();
      if (!text2.trim()) return;
      let result = "";
      await translateStream(text2, lang, {
        onToken: (token) => {
          result += token;
        },
        onComplete: () => replaceSelection(result),
        onError: (error) => console.error("AI Error:", error)
      });
    };
    const handleCustomAi = async () => {
      if (!customPrompt.value.trim()) return;
      isOpen.value = false;
      const text2 = getSelectedText() || props.editor?.getText() || "";
      const instruction = customPrompt.value;
      customPrompt.value = "";
      await customAiStream(text2, instruction, {
        onToken: (token) => insertAtCursor(token),
        onError: (error) => console.error("AI Error:", error)
      });
    };
    const handleItemClick = (item) => {
      item.action();
    };
    const openSettings = () => {
      isOpen.value = false;
      showSettings.value = true;
    };
    const onSettingsSaved = () => {
    };
    const handleClickOutside = (e) => {
      if (containerRef.value && !containerRef.value.contains(e.target)) {
        isOpen.value = false;
      }
    };
    onMounted(() => {
      document.addEventListener("click", handleClickOutside);
    });
    onUnmounted(() => {
      document.removeEventListener("click", handleClickOutside);
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: "ai-toolbar-menu",
        ref_key: "containerRef",
        ref: containerRef
      }, [
        createVNode(BaseTooltip, {
          title: unref(isConfigured) ? "AI 助手" : unref(t)("aiSettings.title")
        }, {
          default: withCtx(() => [
            createElementVNode("button", {
              class: normalizeClass(["ai-toolbar-trigger", { "is-open": isOpen.value, "is-loading": unref(isLoading), "not-configured": !unref(isConfigured) }]),
              type: "button",
              onClick: toggleMenu,
              disabled: unref(isLoading)
            }, [
              _cache[2] || (_cache[2] = createElementVNode("span", { class: "ai-icon" }, "✨", -1)),
              _cache[3] || (_cache[3] = createElementVNode("span", { class: "ai-label" }, "AI", -1)),
              unref(isLoading) ? (openBlock(), createElementBlock("span", _hoisted_2$9)) : createCommentVNode("", true),
              !unref(isConfigured) ? (openBlock(), createElementBlock("span", _hoisted_3$8, "!")) : createCommentVNode("", true)
            ], 10, _hoisted_1$a)
          ]),
          _: 1
        }, 8, ["title"]),
        createVNode(Transition, { name: "ai-menu-fade" }, {
          default: withCtx(() => [
            isOpen.value ? (openBlock(), createElementBlock("div", _hoisted_4$7, [
              !unref(isConfigured) ? (openBlock(), createElementBlock("div", _hoisted_5$7, toDisplayString(unref(t)("aiSettings.apiKeyHint")), 1)) : createCommentVNode("", true),
              (openBlock(true), createElementBlock(Fragment, null, renderList(menuItems.value, (item) => {
                return openBlock(), createElementBlock("button", {
                  key: item.key,
                  class: normalizeClass(["ai-menu-item", { "is-disabled": !unref(isConfigured) && item.key !== "settings" }]),
                  type: "button",
                  onClick: ($event) => handleItemClick(item),
                  disabled: !unref(isConfigured) && item.key !== "settings"
                }, [
                  createElementVNode("span", _hoisted_7$6, toDisplayString(item.icon), 1),
                  createElementVNode("span", _hoisted_8$3, toDisplayString(item.label), 1)
                ], 10, _hoisted_6$7);
              }), 128)),
              _cache[5] || (_cache[5] = createElementVNode("div", { class: "ai-menu-divider" }, null, -1)),
              createElementVNode("div", _hoisted_9$3, [
                withDirectives(createElementVNode("input", {
                  "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => customPrompt.value = $event),
                  type: "text",
                  class: "ai-menu-input",
                  placeholder: unref(t)("editor.aiPromptPlaceholder"),
                  disabled: !unref(isConfigured),
                  onKeydown: withKeys(handleCustomAi, ["enter"])
                }, null, 40, _hoisted_10$2), [
                  [vModelText, customPrompt.value]
                ]),
                createElementVNode("button", {
                  class: "ai-menu-send",
                  type: "button",
                  onClick: handleCustomAi,
                  disabled: !customPrompt.value.trim() || !unref(isConfigured)
                }, " → ", 8, _hoisted_11$2)
              ]),
              _cache[6] || (_cache[6] = createElementVNode("div", { class: "ai-menu-divider" }, null, -1)),
              createElementVNode("button", {
                class: "ai-menu-item ai-menu-item--settings",
                type: "button",
                onClick: openSettings
              }, [
                _cache[4] || (_cache[4] = createElementVNode("span", { class: "ai-menu-item-icon" }, "⚙️", -1)),
                createElementVNode("span", _hoisted_12$2, toDisplayString(unref(t)("aiSettings.title")), 1),
                unref(isConfigured) ? (openBlock(), createElementBlock("span", _hoisted_13$2)) : (openBlock(), createElementBlock("span", _hoisted_14$2))
              ])
            ])) : createCommentVNode("", true)
          ]),
          _: 1
        }),
        createVNode(_sfc_main$b, {
          open: showSettings.value,
          "onUpdate:open": _cache[1] || (_cache[1] = ($event) => showSettings.value = $event),
          onSaved: onSettingsSaved
        }, null, 8, ["open"])
      ], 512);
    };
  }
});
const AiToolbarMenu = /* @__PURE__ */ _export_sfc(_sfc_main$a, [["__scopeId", "data-v-a58b4296"]]);
const AI_PROMPTS = {
  continueWriting: {
    system: `你是一位专业的写作助手。你的任务是根据用户提供的内容进行续写。
要求：
- 保持原文的风格和语气
- 自然流畅地衔接上文
- 提供有价值的内容扩展
- 使用与原文相同的语言（中文或英文）
不要重复用户的内容，直接输出续写的部分。`
  },
  polish: {
    system: `你是一位专业的文字润色专家。你的任务是优化用户提供的文本。
要求：
- 提高文本的流畅性和可读性
- 修正语法和标点错误
- 优化词汇选择
- 保持原文的核心意思不变
- 使用与原文相同的语言
直接输出润色后的文本，不要添加解释。`
  },
  summarize: {
    system: `你是一位专业的内容总结专家。你的任务是提取用户提供内容的关键要点。
要求：
- 准确把握核心内容
- 用简洁的语言概括要点
- 保持逻辑清晰
- 使用与原文相同的语言
- 以条目形式呈现（如果内容较多）
直接输出总结内容。`
  },
  translate: {
    system: `你是一位专业的翻译专家。你的任务是将文本翻译成指定语言。
要求：
- 准确传达原文含义
- 使译文自然流畅
- 保持原文风格
- 处理好文化差异
直接输出翻译结果，不要添加解释。`,
    targetLanguages: {
      "zh-CN": "简体中文",
      "zh-TW": "繁體中文",
      "en": "English",
      "ja": "日本語",
      "ko": "한국어",
      "fr": "Français",
      "de": "Deutsch",
      "es": "Español"
    }
  },
  customAi: {
    system: `你是一个智能助手。请根据用户的具体指令处理提供的文本内容。
直接输出处理结果，不要添加额外解释。`
  }
};
function useAi(options) {
  const { adapter, onError } = options;
  const isLoading = ref(false);
  const result = ref("");
  const error = ref(null);
  let abortController = null;
  const handleError = (e) => {
    error.value = e;
    onError?.(e);
  };
  const runChat = async (systemPrompt, userContent) => {
    abortController = new AbortController();
    isLoading.value = true;
    error.value = null;
    result.value = "";
    try {
      const messages = [
        { role: "system", content: systemPrompt },
        { role: "user", content: userContent }
      ];
      const response = await adapter.chat(messages);
      result.value = response.content;
      return response.content;
    } catch (e) {
      handleError(e);
      throw e;
    } finally {
      isLoading.value = false;
    }
  };
  const runChatStream = async (systemPrompt, userContent, callbacks) => {
    isLoading.value = true;
    error.value = null;
    result.value = "";
    const messages = [
      { role: "system", content: systemPrompt },
      { role: "user", content: userContent }
    ];
    const streamCallbacks = {
      onStart: () => {
        callbacks.onStart?.();
      },
      onToken: (token) => {
        result.value += token;
        callbacks.onToken?.(token);
      },
      onComplete: (fullText) => {
        isLoading.value = false;
        callbacks.onComplete?.(fullText);
      },
      onError: (e) => {
        isLoading.value = false;
        handleError(e);
        callbacks.onError?.(e);
      }
    };
    await adapter.chatStream(messages, streamCallbacks);
  };
  return {
    isLoading: readonly(isLoading),
    result: readonly(result),
    error: readonly(error),
    // Non-streaming
    continueWriting: (text2) => runChat(AI_PROMPTS.continueWriting.system, text2),
    polish: (text2) => runChat(AI_PROMPTS.polish.system, text2),
    summarize: (text2) => runChat(AI_PROMPTS.summarize.system, text2),
    translate: (text2, targetLang) => {
      const langName = AI_PROMPTS.translate.targetLanguages[targetLang] || targetLang;
      return runChat(`${AI_PROMPTS.translate.system}
目标语言: ${langName}`, text2);
    },
    customAi: (text2, instruction) => runChat(`${AI_PROMPTS.customAi.system}
用户指令: ${instruction}`, text2),
    // Streaming
    continueWritingStream: (text2, cb) => runChatStream(AI_PROMPTS.continueWriting.system, text2, cb),
    polishStream: (text2, cb) => runChatStream(AI_PROMPTS.polish.system, text2, cb),
    summarizeStream: (text2, cb) => runChatStream(AI_PROMPTS.summarize.system, text2, cb),
    translateStream: (text2, targetLang, cb) => {
      const langName = AI_PROMPTS.translate.targetLanguages[targetLang] || targetLang;
      return runChatStream(`${AI_PROMPTS.translate.system}
目标语言: ${langName}`, text2, cb);
    },
    customAiStream: (text2, instruction, cb) => runChatStream(`${AI_PROMPTS.customAi.system}
用户指令: ${instruction}`, text2, cb),
    abort: () => {
      abortController?.abort();
      abortController = null;
    }
  };
}
const DEFAULT_TOOLBAR_CONFIG = {
  textFormat: true,
  colorPicker: true,
  heading: true,
  list: true,
  align: true,
  image: true,
  codeBlock: false,
  link: false,
  table: false,
  undoRedo: false,
  clearFormat: false,
  font: false,
  lineHeight: false,
  subscriptSuperscript: false,
  formatPainter: false,
  ai: true
};
const BASIC_TOOLBAR_CONFIG = {
  textFormat: true,
  colorPicker: true,
  heading: true,
  list: true,
  align: true,
  image: true,
  codeBlock: false,
  link: false,
  table: false,
  undoRedo: false,
  clearFormat: false,
  font: false,
  lineHeight: false,
  subscriptSuperscript: false,
  formatPainter: false,
  ai: true
};
const ADVANCED_TOOLBAR_CONFIG = {
  textFormat: true,
  colorPicker: true,
  heading: true,
  list: true,
  align: true,
  image: true,
  codeBlock: true,
  link: true,
  table: true,
  undoRedo: true,
  clearFormat: true,
  font: true,
  lineHeight: true,
  subscriptSuperscript: true,
  formatPainter: true,
  ai: true
};
const _hoisted_1$9 = {
  key: 0,
  class: "editor-toolbar-container"
};
const _hoisted_2$8 = { class: "editor-toolbar" };
const _hoisted_3$7 = { class: "toolbar-left" };
const _hoisted_4$6 = {
  key: 0,
  class: "tool-group"
};
const _hoisted_5$6 = {
  key: 1,
  class: "tool-group"
};
const _hoisted_6$6 = {
  key: 2,
  class: "tool-group"
};
const _hoisted_7$5 = {
  key: 3,
  class: "tool-group"
};
const _hoisted_8$2 = {
  key: 4,
  class: "tool-group"
};
const _hoisted_9$2 = {
  key: 5,
  class: "tool-group"
};
const _hoisted_10$1 = {
  key: 6,
  class: "tool-group"
};
const _hoisted_11$1 = {
  key: 7,
  class: "tool-group"
};
const _hoisted_12$1 = {
  key: 8,
  class: "tool-group"
};
const _hoisted_13$1 = {
  key: 9,
  class: "tool-group"
};
const _hoisted_14$1 = {
  key: 10,
  class: "tool-group"
};
const _hoisted_15$1 = {
  key: 0,
  class: "toolbar-right"
};
const _sfc_main$9 = /* @__PURE__ */ defineComponent({
  __name: "ToolbarNav",
  props: {
    editor: {},
    config: { default: () => DEFAULT_TOOLBAR_CONFIG },
    enabled: { type: Boolean, default: true }
  },
  setup(__props) {
    const props = __props;
    const editor = computed(() => props.editor ?? null);
    const config = computed(() => {
      return {
        ...DEFAULT_TOOLBAR_CONFIG,
        ...props.config
      };
    });
    const currentTextColor = ref("#000000");
    const currentBgColor = ref("#ffffff");
    function normalizeColor(color) {
      if (!color) return "#000000";
      const trimmed = color.trim();
      if (trimmed.startsWith("#")) {
        return trimmed.toLowerCase();
      }
      return trimmed.toLowerCase();
    }
    const runCommand = createCommandRunner(editor);
    const setTextColor = (color) => {
      currentTextColor.value = color;
      runCommand((chain) => chain.setColor(color))();
    };
    const setHighlight = (color) => {
      currentBgColor.value = color;
      runCommand((chain) => chain.setHighlight({ color }))();
    };
    watch(
      () => editor.value?.getAttributes("textStyle"),
      (attrs) => {
        if (attrs?.color) {
          currentTextColor.value = normalizeColor(attrs.color);
        } else {
          currentTextColor.value = "#000000";
        }
      },
      { deep: true, immediate: true }
    );
    watch(
      () => editor.value?.getAttributes("highlight"),
      (attrs) => {
        if (attrs?.color) {
          currentBgColor.value = normalizeColor(attrs.color);
        } else {
          currentBgColor.value = "#ffffff";
        }
      },
      { deep: true, immediate: true }
    );
    return (_ctx, _cache) => {
      return __props.enabled ? (openBlock(), createElementBlock("div", _hoisted_1$9, [
        createElementVNode("div", _hoisted_2$8, [
          createElementVNode("div", _hoisted_3$7, [
            config.value.undoRedo ? (openBlock(), createElementBlock("div", _hoisted_4$6, [
              createVNode(unref(_sfc_main$h), {
                editor: editor.value,
                disabled: config.value.undoRedoDisabled
              }, null, 8, ["editor", "disabled"])
            ])) : createCommentVNode("", true),
            config.value.formatPainter ? (openBlock(), createElementBlock("div", _hoisted_5$6, [
              createVNode(unref(_sfc_main$g), {
                editor: editor.value,
                disabled: config.value.formatPainterDisabled
              }, null, 8, ["editor", "disabled"])
            ])) : createCommentVNode("", true),
            config.value.clearFormat ? (openBlock(), createElementBlock("div", _hoisted_6$6, [
              createVNode(unref(_sfc_main$m), { editor: editor.value }, null, 8, ["editor"])
            ])) : createCommentVNode("", true),
            config.value.font ? (openBlock(), createElementBlock("div", _hoisted_7$5, [
              createVNode(unref(FontFamilySelect), { editor: editor.value }, null, 8, ["editor"]),
              createVNode(unref(FontSizeSelect), { editor: editor.value }, null, 8, ["editor"])
            ])) : createCommentVNode("", true),
            config.value.textFormat || config.value.codeBlock ? (openBlock(), createElementBlock("div", _hoisted_8$2, [
              createVNode(unref(_sfc_main$u), {
                editor: editor.value,
                "show-code": config.value.codeBlock
              }, null, 8, ["editor", "show-code"])
            ])) : createCommentVNode("", true),
            config.value.colorPicker ? (openBlock(), createElementBlock("div", _hoisted_9$2, [
              createVNode(unref(ToolbarGroup), null, {
                default: withCtx(() => [
                  createVNode(unref(ColorPicker), {
                    icon: unref(FontColorsOutlined),
                    type: "text",
                    "model-value": currentTextColor.value,
                    title: unref(t)("editor.textColor"),
                    onSelect: setTextColor
                  }, null, 8, ["icon", "model-value", "title"]),
                  createVNode(unref(ColorPicker), {
                    icon: unref(HighlightOutlined),
                    type: "background",
                    "model-value": currentBgColor.value,
                    title: unref(t)("editor.backgroundColor"),
                    onSelect: setHighlight
                  }, null, 8, ["icon", "model-value", "title"])
                ]),
                _: 1
              })
            ])) : createCommentVNode("", true),
            config.value.heading || config.value.list ? (openBlock(), createElementBlock("div", _hoisted_10$1, [
              config.value.heading ? (openBlock(), createBlock(unref(_sfc_main$s), {
                key: 0,
                editor: editor.value
              }, null, 8, ["editor"])) : createCommentVNode("", true),
              config.value.list ? (openBlock(), createBlock(unref(_sfc_main$t), {
                key: 1,
                editor: editor.value,
                "show-task-list": true
              }, null, 8, ["editor"])) : createCommentVNode("", true)
            ])) : createCommentVNode("", true),
            config.value.align ? (openBlock(), createElementBlock("div", _hoisted_11$1, [
              createVNode(unref(_sfc_main$q), { editor: editor.value }, null, 8, ["editor"])
            ])) : createCommentVNode("", true),
            config.value.link || config.value.table || config.value.image ? (openBlock(), createElementBlock("div", _hoisted_12$1, [
              config.value.link ? (openBlock(), createBlock(unref(_sfc_main$l), {
                key: 0,
                editor: editor.value
              }, null, 8, ["editor"])) : createCommentVNode("", true),
              config.value.table ? (openBlock(), createBlock(unref(TableButton), {
                key: 1,
                editor: editor.value
              }, null, 8, ["editor"])) : createCommentVNode("", true),
              config.value.image ? (openBlock(), createBlock(unref(_sfc_main$p), {
                key: 2,
                editor: editor.value
              }, null, 8, ["editor"])) : createCommentVNode("", true)
            ])) : createCommentVNode("", true),
            config.value.subscriptSuperscript ? (openBlock(), createElementBlock("div", _hoisted_13$1, [
              createVNode(unref(_sfc_main$i), { editor: editor.value }, null, 8, ["editor"])
            ])) : createCommentVNode("", true),
            config.value.ai && editor.value ? (openBlock(), createElementBlock("div", _hoisted_14$1, [
              createVNode(unref(AiMenuButton), {
                editor: editor.value,
                icon: unref(ThunderboltOutlined),
                label: unref(t)("editor.ai"),
                title: unref(t)("editor.ai")
              }, null, 8, ["editor", "icon", "label", "title"])
            ])) : createCommentVNode("", true),
            renderSlot(_ctx.$slots, "extra", {}, void 0, true)
          ]),
          _ctx.$slots.right ? (openBlock(), createElementBlock("div", _hoisted_15$1, [
            renderSlot(_ctx.$slots, "right", {}, void 0, true)
          ])) : createCommentVNode("", true)
        ])
      ])) : createCommentVNode("", true);
    };
  }
});
const ToolbarNav = /* @__PURE__ */ _export_sfc(_sfc_main$9, [["__scopeId", "data-v-6e49b1ff"]]);
const _hoisted_1$8 = { class: "link-bubble-menu-content" };
const _hoisted_2$7 = { class: "link-url-display" };
const _hoisted_3$6 = ["title"];
const _hoisted_4$5 = { class: "link-actions" };
const _hoisted_5$5 = ["title"];
const _hoisted_6$5 = ["title"];
const _hoisted_7$4 = ["title"];
const _sfc_main$8 = /* @__PURE__ */ defineComponent({
  __name: "LinkBubbleMenu",
  props: {
    editor: {},
    readonly: { type: Boolean, default: false },
    enabled: { type: Boolean, default: false }
  },
  setup(__props) {
    const props = __props;
    const editor = computed(() => props.editor ?? null);
    const runCommand = createCommandRunner(editor);
    const currentLinkUrl = ref("");
    const linkModalOpen = ref(false);
    const linkUrl = ref("");
    function updateCurrentLinkUrl() {
      const e = editor.value;
      if (!e) {
        currentLinkUrl.value = "";
        return;
      }
      if (e.isActive("link")) {
        const attrs = e.getAttributes("link");
        currentLinkUrl.value = attrs.href || "";
      } else {
        currentLinkUrl.value = "";
      }
    }
    const shouldShow = (bubbleProps) => {
      if (!props.enabled) {
        return false;
      }
      if (props.readonly) {
        return false;
      }
      const e = bubbleProps.editor;
      if (!e) {
        return false;
      }
      const { from, to } = bubbleProps;
      const { state: state2 } = bubbleProps;
      if (from === to) {
        return false;
      }
      try {
        const start = Math.min(from, to);
        const end = Math.max(from, to);
        const $from = state2.doc.resolve(start);
        const $to = state2.doc.resolve(end);
        const marksAtStart = $from.marks();
        let linkMarkAtStart = null;
        for (const mark of marksAtStart) {
          if (mark.type && mark.type.name === "link" && mark.attrs?.href) {
            linkMarkAtStart = mark;
            break;
          }
        }
        const marksAtEnd = $to.marks();
        let linkMarkAtEnd = null;
        for (const mark of marksAtEnd) {
          if (mark.type && mark.type.name === "link" && mark.attrs?.href) {
            linkMarkAtEnd = mark;
            break;
          }
        }
        if (linkMarkAtStart && linkMarkAtEnd) {
          if (linkMarkAtStart.attrs?.href === linkMarkAtEnd.attrs?.href) {
            currentLinkUrl.value = linkMarkAtStart.attrs.href;
            return true;
          }
        }
        let allNodesHaveLink = false;
        let linkHref = "";
        let hasNonLinkText = false;
        state2.doc.nodesBetween(start, end, (node) => {
          if (node.isText) {
            if (node.marks && node.marks.length > 0) {
              const linkMark = node.marks.find(
                (mark) => mark.type && mark.type.name === "link" && mark.attrs?.href
              );
              if (linkMark) {
                if (!linkHref) {
                  linkHref = linkMark.attrs.href;
                } else if (linkHref !== linkMark.attrs.href) {
                  hasNonLinkText = true;
                  return false;
                }
                allNodesHaveLink = true;
              } else {
                hasNonLinkText = true;
                return false;
              }
            } else {
              hasNonLinkText = true;
              return false;
            }
          }
        });
        if (allNodesHaveLink && !hasNonLinkText && linkHref) {
          currentLinkUrl.value = linkHref;
          return true;
        }
      } catch (error) {
      }
      return false;
    };
    watch(
      () => editor.value?.state.selection,
      () => {
        if (editor.value?.isActive("link")) {
          updateCurrentLinkUrl();
        }
      },
      { deep: true }
    );
    watch(
      () => editor.value?.state,
      () => {
        updateCurrentLinkUrl();
      },
      { deep: true, immediate: true }
    );
    function editLink() {
      const e = editor.value;
      if (!e) return;
      if (e.isActive("link")) {
        linkUrl.value = e.getAttributes("link").href || "";
      } else {
        linkUrl.value = "";
      }
      linkModalOpen.value = true;
    }
    function applyLink() {
      const e = editor.value;
      if (!e) return;
      const finalUrl = linkUrl.value.trim();
      if (finalUrl) {
        let urlToSet = finalUrl;
        try {
          const url = new URL(finalUrl);
          if (url.protocol !== "http:" && url.protocol !== "https:") {
            throw new Error("Invalid protocol");
          }
          urlToSet = finalUrl;
        } catch {
          urlToSet = finalUrl.startsWith("http") ? finalUrl : `https://${finalUrl}`;
        }
        if (e) {
          const hasSelection = !e.state.selection.empty;
          const chain = e.chain().focus();
          if (hasSelection) {
            const success = chain.extendMarkRange("link").setLink({ href: urlToSet, target: "_blank" }).run();
            if (success) {
              currentLinkUrl.value = urlToSet;
              nextTick(() => {
                updateCurrentLinkUrl();
              });
            }
          } else {
            const success = chain.setLink({ href: urlToSet, target: "_blank" }).run();
            if (success) {
              currentLinkUrl.value = urlToSet;
              nextTick(() => {
                updateCurrentLinkUrl();
              });
            }
          }
        }
      } else {
        runCommand((chain) => chain.unsetLink())();
        currentLinkUrl.value = "";
      }
      linkModalOpen.value = false;
      linkUrl.value = "";
    }
    function openLink() {
      const e = editor.value;
      if (!e) return;
      if (e.isActive("link")) {
        const attrs = e.getAttributes("link");
        const href = attrs.href || "";
        if (href) {
          window.open(href, "_blank", "noopener,noreferrer");
        }
      }
    }
    function removeLink() {
      runCommand((chain) => chain.unsetLink())();
    }
    return (_ctx, _cache) => {
      const _component_a_input = resolveComponent("a-input");
      const _component_a_modal = resolveComponent("a-modal");
      return editor.value ? (openBlock(), createBlock(unref(BubbleMenu), {
        key: 0,
        editor: editor.value,
        "tippy-options": { duration: 100, placement: "top", offset: [0, 8], zIndex: 1002 },
        "should-show": shouldShow,
        class: "link-bubble-menu"
      }, {
        default: withCtx(() => [
          createElementVNode("div", _hoisted_1$8, [
            createElementVNode("div", _hoisted_2$7, [
              createElementVNode("span", {
                class: "link-url-text",
                title: currentLinkUrl.value
              }, toDisplayString(currentLinkUrl.value), 9, _hoisted_3$6)
            ]),
            createElementVNode("div", _hoisted_4$5, [
              _cache[2] || (_cache[2] = createElementVNode("div", { class: "link-divider" }, null, -1)),
              createElementVNode("button", {
                class: "link-action-btn",
                onClick: editLink,
                title: unref(t)("editor.editLink")
              }, [
                createVNode(unref(EditOutlined))
              ], 8, _hoisted_5$5),
              _cache[3] || (_cache[3] = createElementVNode("div", { class: "link-divider" }, null, -1)),
              createElementVNode("button", {
                class: "link-action-btn",
                onClick: openLink,
                title: unref(t)("editor.openLink")
              }, [
                createVNode(unref(LinkOutlined))
              ], 8, _hoisted_6$5),
              _cache[4] || (_cache[4] = createElementVNode("div", { class: "link-divider" }, null, -1)),
              createElementVNode("button", {
                class: "link-action-btn link-action-btn--danger",
                onClick: removeLink,
                title: unref(t)("editor.removeLink")
              }, [
                createVNode(unref(DeleteOutlined))
              ], 8, _hoisted_7$4)
            ])
          ]),
          createVNode(_component_a_modal, {
            open: linkModalOpen.value,
            "onUpdate:open": _cache[1] || (_cache[1] = ($event) => linkModalOpen.value = $event),
            title: unref(t)("editor.editLink"),
            onOk: applyLink,
            width: "400px"
          }, {
            default: withCtx(() => [
              createVNode(_component_a_input, {
                value: linkUrl.value,
                "onUpdate:value": _cache[0] || (_cache[0] = ($event) => linkUrl.value = $event),
                placeholder: unref(t)("editor.linkPlaceholder"),
                onKeyup: withKeys(applyLink, ["enter"])
              }, null, 8, ["value", "placeholder"])
            ]),
            _: 1
          }, 8, ["open", "title"])
        ]),
        _: 1
      }, 8, ["editor"])) : createCommentVNode("", true);
    };
  }
});
const LinkBubbleMenu = /* @__PURE__ */ _export_sfc(_sfc_main$8, [["__scopeId", "data-v-d7a68184"]]);
const _hoisted_1$7 = { class: "zoom-level" };
const _hoisted_2$6 = { class: "page-info" };
const _hoisted_3$5 = {
  key: 0,
  class: "char-count"
};
const _sfc_main$7 = /* @__PURE__ */ defineComponent({
  __name: "ZoomBar",
  props: {
    zoomLevel: {},
    totalPages: {},
    editor: {},
    showCharCount: { type: Boolean, default: true },
    min: { default: 50 },
    max: { default: 200 },
    step: { default: 10 },
    placement: { default: "belowToolbar" }
  },
  emits: ["update:zoomLevel", "change", "reset"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const onZoomIn = () => {
      if (props.zoomLevel < props.max) {
        const v = Math.min(props.zoomLevel + props.step, props.max);
        emit("update:zoomLevel", v);
        emit("change", v);
      }
    };
    const onZoomOut = () => {
      if (props.zoomLevel > props.min) {
        const v = Math.max(props.zoomLevel - props.step, props.min);
        emit("update:zoomLevel", v);
        emit("change", v);
      }
    };
    const onReset = () => {
      const v = 100;
      emit("update:zoomLevel", v);
      emit("change", v);
      emit("reset", v);
    };
    const classes = computed(
      () => ["zoom-controls", props.placement === "bottom" ? "zoom-controls--bottom" : null].filter(Boolean).join(" ")
    );
    const characterCount = ref(0);
    const wordCount = ref(0);
    const updateCounts = () => {
      if (!props.editor) {
        characterCount.value = 0;
        wordCount.value = 0;
        return;
      }
      try {
        const storage = props.editor.storage.characterCount;
        if (storage) {
          characterCount.value = storage.characters?.() ?? 0;
          wordCount.value = storage.words?.() ?? 0;
        } else {
          characterCount.value = 0;
          wordCount.value = 0;
        }
      } catch (error) {
        console.warn("Failed to get character count:", error);
        characterCount.value = 0;
        wordCount.value = 0;
      }
    };
    watch(
      () => props.editor,
      (editor) => {
        if (editor) {
          updateCounts();
          editor.on("update", updateCounts);
          editor.on("selectionUpdate", updateCounts);
        }
      },
      { immediate: true }
    );
    watch(
      () => props.editor,
      (editor, oldEditor) => {
        if (oldEditor && !editor) {
          oldEditor.off("update", updateCounts);
          oldEditor.off("selectionUpdate", updateCounts);
        }
      }
    );
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(classes.value)
      }, [
        createVNode(unref(Button), {
          size: "small",
          onClick: onZoomOut
        }, {
          default: withCtx(() => [..._cache[0] || (_cache[0] = [
            createTextVNode("-", -1)
          ])]),
          _: 1
        }),
        createElementVNode("span", _hoisted_1$7, toDisplayString(__props.zoomLevel) + "%", 1),
        createVNode(unref(Button), {
          size: "small",
          onClick: onZoomIn
        }, {
          default: withCtx(() => [..._cache[1] || (_cache[1] = [
            createTextVNode("+", -1)
          ])]),
          _: 1
        }),
        createVNode(unref(Button), {
          size: "small",
          onClick: onReset
        }, {
          default: withCtx(() => [
            createTextVNode(toDisplayString(unref(t)("stats.reset")), 1)
          ]),
          _: 1
        }),
        createElementVNode("span", _hoisted_2$6, toDisplayString(unref(t)("stats.total")) + " " + toDisplayString(__props.totalPages) + " " + toDisplayString(unref(t)("stats.pages")), 1),
        __props.showCharCount && __props.editor ? (openBlock(), createElementBlock("span", _hoisted_3$5, toDisplayString(characterCount.value) + " " + toDisplayString(unref(t)("stats.characters")) + " / " + toDisplayString(wordCount.value) + " " + toDisplayString(unref(t)("stats.words")), 1)) : createCommentVNode("", true)
      ], 2);
    };
  }
});
const _hoisted_1$6 = {
  key: 0,
  class: "footer-nav-container"
};
const _sfc_main$6 = /* @__PURE__ */ defineComponent({
  __name: "FooterNav",
  props: {
    zoomLevel: {},
    totalPages: {},
    editor: {},
    showCharCount: { type: Boolean, default: true },
    min: { default: 50 },
    max: { default: 200 },
    step: { default: 10 },
    enabled: { type: Boolean, default: true }
  },
  emits: ["update:zoomLevel", "change", "reset"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const localZoomLevel = ref(props.zoomLevel);
    watch(
      () => props.zoomLevel,
      (newValue) => {
        if (localZoomLevel.value !== newValue) {
          localZoomLevel.value = newValue;
        }
      },
      { immediate: true }
    );
    const handleZoomUpdate = (value) => {
      localZoomLevel.value = value;
      emit("update:zoomLevel", value);
    };
    const handleZoomChange = (value) => {
      emit("change", value);
    };
    const handleZoomReset = (value) => {
      emit("reset", value);
    };
    return (_ctx, _cache) => {
      return __props.enabled ? (openBlock(), createElementBlock("div", _hoisted_1$6, [
        createVNode(unref(_sfc_main$7), {
          zoomLevel: localZoomLevel.value,
          "onUpdate:zoomLevel": [
            _cache[0] || (_cache[0] = ($event) => localZoomLevel.value = $event),
            handleZoomUpdate
          ],
          totalPages: __props.totalPages,
          editor: __props.editor,
          showCharCount: __props.showCharCount,
          min: __props.min,
          max: __props.max,
          step: __props.step,
          placement: "bottom",
          onChange: handleZoomChange,
          onReset: handleZoomReset
        }, null, 8, ["zoomLevel", "totalPages", "editor", "showCharCount", "min", "max", "step"])
      ])) : createCommentVNode("", true);
    };
  }
});
const FooterNav = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["__scopeId", "data-v-f011b152"]]);
const _hoisted_1$5 = { class: "image-menu-content" };
const _hoisted_2$5 = { class: "image-menu-group" };
const _hoisted_3$4 = ["onClick", "title"];
const _hoisted_4$4 = { class: "image-menu-group" };
const _hoisted_5$4 = { class: "image-menu-group" };
const _hoisted_6$4 = ["src"];
const _sfc_main$5 = /* @__PURE__ */ defineComponent({
  __name: "ImageToolbar",
  props: {
    editor: {},
    readonly: { type: Boolean, default: false },
    enabled: { type: Boolean, default: true }
  },
  setup(__props) {
    const props = __props;
    const editor = computed(() => props.editor ?? null);
    const runCommand = createCommandRunner(editor);
    const previewVisible = ref(false);
    const currentImageSrc = ref("");
    const currentAlign = ref(null);
    const alignOptions = [
      { value: "left", icon: AlignLeftOutlined, title: "左对齐" },
      { value: "center", icon: AlignCenterOutlined, title: "居中" },
      { value: "right", icon: AlignRightOutlined, title: "右对齐" }
    ];
    function getCurrentImageInfo() {
      const e = editor.value;
      if (!e) return { node: null, pos: null };
      const { state: state2 } = e;
      const { selection } = state2;
      let node = null;
      let pos = null;
      if (selection instanceof NodeSelection && selection.node && selection.node.type.name === "image") {
        node = selection.node;
        pos = selection.from;
        return { node, pos };
      }
      const $anchor = selection.$anchor;
      const nodeAfter = $anchor.nodeAfter;
      const nodeBefore = $anchor.nodeBefore;
      if (nodeAfter?.type.name === "image") {
        node = nodeAfter;
      } else if (nodeBefore?.type.name === "image") {
        node = nodeBefore;
      }
      if (node && pos === null) {
        state2.doc.descendants((n, p) => {
          if (n === node) {
            pos = p;
            return false;
          }
        });
      }
      return { node, pos };
    }
    function getImageAlign() {
      const { node, pos } = getCurrentImageInfo();
      if (!node || pos === null) return null;
      const nodeAlign = node.attrs.align;
      if (nodeAlign === "left" || nodeAlign === "center" || nodeAlign === "right") {
        return nodeAlign;
      }
      const e = editor.value;
      if (!e) return null;
      const $pos = e.state.doc.resolve(pos);
      const parent = $pos.parent;
      const parentAlign = parent?.attrs.textAlign || parent?.attrs.align;
      if (parentAlign === "left" || parentAlign === "center" || parentAlign === "right") {
        return parentAlign;
      }
      return null;
    }
    const shouldShow = (bubbleProps) => {
      if (!props.enabled) {
        return false;
      }
      if (!bubbleProps.editor) {
        return false;
      }
      if (props.readonly || !bubbleProps.editor.isActive("image")) {
        return false;
      }
      const { node } = getCurrentImageInfo();
      if (node?.type.name === "image") {
        currentImageSrc.value = node.attrs.src || "";
        currentAlign.value = getImageAlign();
      }
      return true;
    };
    function setAlign(align) {
      const e = editor.value;
      if (!e) return;
      const { node, pos } = getCurrentImageInfo();
      if (!node || pos === null) return;
      const $pos = e.state.doc.resolve(pos);
      const parent = $pos.parent;
      if (parent && (parent.type.name === "paragraph" || parent.type.name === "heading")) {
        const parentStart = $pos.start($pos.depth);
        e.chain().setTextSelection({ from: parentStart, to: parentStart + parent.nodeSize }).setTextAlign(align).run();
      }
      e.chain().focus().setNodeSelection(pos).updateAttributes("image", { align }).run();
      currentAlign.value = align;
    }
    function previewImage() {
      const { node } = getCurrentImageInfo();
      if (node?.type.name === "image") {
        currentImageSrc.value = node.attrs.src || "";
        previewVisible.value = true;
      }
    }
    function deleteImage() {
      runCommand((chain) => chain.deleteSelection())();
    }
    return (_ctx, _cache) => {
      const _component_a_modal = resolveComponent("a-modal");
      return editor.value ? (openBlock(), createBlock(unref(BubbleMenu), {
        key: 0,
        editor: editor.value,
        "tippy-options": { duration: 100, placement: "top", offset: [0, 16] },
        "should-show": shouldShow,
        class: "image-bubble-menu"
      }, {
        default: withCtx(() => [
          createElementVNode("div", _hoisted_1$5, [
            createElementVNode("div", _hoisted_2$5, [
              (openBlock(), createElementBlock(Fragment, null, renderList(alignOptions, (alignOption) => {
                return createElementVNode("button", {
                  key: alignOption.value,
                  class: normalizeClass(["image-menu-btn", { active: currentAlign.value === alignOption.value }]),
                  onClick: ($event) => setAlign(alignOption.value),
                  title: alignOption.title
                }, [
                  (openBlock(), createBlock(resolveDynamicComponent(alignOption.icon)))
                ], 10, _hoisted_3$4);
              }), 64))
            ]),
            createElementVNode("div", _hoisted_4$4, [
              createElementVNode("button", {
                class: "image-menu-btn",
                onClick: previewImage,
                title: "预览"
              }, [
                createVNode(unref(EyeOutlined))
              ])
            ]),
            createElementVNode("div", _hoisted_5$4, [
              createElementVNode("button", {
                class: "image-menu-btn image-menu-btn--danger",
                onClick: deleteImage,
                title: "删除图片"
              }, [
                createVNode(unref(DeleteOutlined))
              ])
            ])
          ]),
          createVNode(_component_a_modal, {
            open: previewVisible.value,
            "onUpdate:open": _cache[0] || (_cache[0] = ($event) => previewVisible.value = $event),
            footer: null,
            width: 800,
            centered: "",
            onCancel: _cache[1] || (_cache[1] = ($event) => previewVisible.value = false)
          }, {
            default: withCtx(() => [
              currentImageSrc.value ? (openBlock(), createElementBlock("img", {
                key: 0,
                src: currentImageSrc.value,
                alt: "预览",
                style: { "width": "100%", "height": "auto" }
              }, null, 8, _hoisted_6$4)) : createCommentVNode("", true)
            ]),
            _: 1
          }, 8, ["open"])
        ]),
        _: 1
      }, 8, ["editor"])) : createCommentVNode("", true);
    };
  }
});
const ImageToolbar = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["__scopeId", "data-v-48a92be7"]]);
const _hoisted_1$4 = { class: "bubble-menu-content menu-content" };
const _hoisted_2$4 = { class: "bubble-group menu-group" };
const _hoisted_3$3 = { class: "bubble-group menu-group" };
const _hoisted_4$3 = { class: "bubble-group menu-group" };
const _hoisted_5$3 = { class: "bubble-group menu-group" };
const _hoisted_6$3 = { class: "bubble-group menu-group" };
const _hoisted_7$3 = { class: "bubble-group menu-group" };
const _sfc_main$4 = /* @__PURE__ */ defineComponent({
  __name: "FloatingMenu",
  props: {
    editor: {},
    readonly: { type: Boolean, default: false },
    enabled: { type: Boolean, default: true }
  },
  setup(__props) {
    const props = __props;
    const editor = computed(() => props.editor ?? null);
    const currentTextColor = ref("#000000");
    const currentBgColor = ref("#ffffff");
    const runCommand = createCommandRunner(editor);
    function normalizeColor(color) {
      if (!color) return "#000000";
      const trimmed = color.trim();
      if (trimmed.startsWith("#")) {
        return trimmed.toLowerCase();
      }
      return trimmed.toLowerCase();
    }
    watch(
      () => editor.value?.getAttributes("textStyle"),
      (attrs) => {
        if (attrs?.color) {
          currentTextColor.value = normalizeColor(attrs.color);
        } else {
          currentTextColor.value = "#000000";
        }
      },
      { deep: true, immediate: true }
    );
    watch(
      () => editor.value?.getAttributes("highlight"),
      (attrs) => {
        if (attrs?.color) {
          currentBgColor.value = normalizeColor(attrs.color);
        } else {
          currentBgColor.value = "#ffffff";
        }
      },
      { deep: true, immediate: true }
    );
    const shouldShow = (bubbleProps) => {
      if (!props.enabled) {
        return false;
      }
      if (props.readonly) return false;
      const { from, to } = bubbleProps;
      const isEmptySelection = from === to;
      if (isEmptySelection) return false;
      if (bubbleProps.editor.isActive("codeBlock")) return false;
      if (bubbleProps.editor.isActive("table")) return false;
      if (bubbleProps.editor.isActive("image")) return false;
      const { state: state2 } = bubbleProps;
      const { selection } = state2;
      if (selection.node && selection.node.type.name === "image") {
        return false;
      }
      const $anchor = selection.$anchor;
      const nodeAfter = $anchor.nodeAfter;
      const nodeBefore = $anchor.nodeBefore;
      if (nodeAfter && nodeAfter.type.name === "image" || nodeBefore && nodeBefore.type.name === "image") {
        return false;
      }
      if (bubbleProps.editor.isActive("link")) {
        return false;
      }
      return true;
    };
    const setTextColor = (color) => {
      currentTextColor.value = color;
      runCommand((chain) => chain.setColor(color))();
    };
    const setHighlight = (color) => {
      currentBgColor.value = color;
      runCommand((chain) => chain.setHighlight({ color }))();
    };
    return (_ctx, _cache) => {
      return editor.value ? (openBlock(), createBlock(unref(BubbleMenu), {
        key: 0,
        editor: editor.value,
        "tippy-options": { duration: 100, placement: "top" },
        "should-show": shouldShow,
        class: "bubble-menu floating-menu"
      }, {
        default: withCtx(() => [
          createElementVNode("div", _hoisted_1$4, [
            createElementVNode("div", _hoisted_2$4, [
              createVNode(unref(HeadingButtons), { editor: editor.value }, null, 8, ["editor"])
            ]),
            createElementVNode("div", _hoisted_3$3, [
              createVNode(unref(_sfc_main$u), { editor: editor.value }, null, 8, ["editor"])
            ]),
            createElementVNode("div", _hoisted_4$3, [
              createVNode(unref(ColorPicker), {
                icon: unref(FontColorsOutlined),
                type: "text",
                "model-value": currentTextColor.value,
                title: unref(t)("editor.textColor"),
                onSelect: setTextColor
              }, null, 8, ["icon", "model-value", "title"]),
              createVNode(unref(ColorPicker), {
                icon: unref(HighlightOutlined),
                type: "background",
                "model-value": currentBgColor.value,
                title: unref(t)("editor.backgroundColor"),
                onSelect: setHighlight
              }, null, 8, ["icon", "model-value", "title"])
            ]),
            createElementVNode("div", _hoisted_5$3, [
              createVNode(unref(_sfc_main$l), { editor: editor.value }, null, 8, ["editor"])
            ]),
            createElementVNode("div", _hoisted_6$3, [
              createVNode(unref(_sfc_main$t), {
                editor: editor.value,
                "show-task-list": true
              }, null, 8, ["editor"])
            ]),
            createElementVNode("div", _hoisted_7$3, [
              editor.value ? (openBlock(), createBlock(unref(AiMenuButton), {
                key: 0,
                editor: editor.value,
                icon: unref(ThunderboltOutlined),
                label: unref(t)("editor.ai"),
                title: unref(t)("editor.ai"),
                placement: "top"
              }, null, 8, ["editor", "icon", "label", "title"])) : createCommentVNode("", true)
            ])
          ])
        ]),
        _: 1
      }, 8, ["editor"])) : createCommentVNode("", true);
    };
  }
});
const FloatingMenu = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["__scopeId", "data-v-14cde2b4"]]);
const dragHandleWithMenuKey = new PluginKey("dragHandleWithMenu");
const EXCLUDED_NODE_TYPES = ["doc", "table", "image", "figure", "tableCell", "tableHeader"];
const EXCLUDED_LIST_TYPES = ["taskList", "listItem", "taskItem"];
const ALLOWED_LIST_TYPES = ["orderedList", "bulletList"];
function shouldShowHandle(node, parent) {
  if (!node.isBlock || node.type.name === "doc") return false;
  if (EXCLUDED_NODE_TYPES.includes(node.type.name)) return false;
  if (parent.type.name === "table") return false;
  if (ALLOWED_LIST_TYPES.includes(node.type.name)) {
    return true;
  }
  if (EXCLUDED_LIST_TYPES.includes(node.type.name)) {
    return false;
  }
  if ((parent.type.name === "listItem" || parent.type.name === "taskItem") && node.type.name === "paragraph") {
    return false;
  }
  if (ALLOWED_LIST_TYPES.includes(parent.type.name) && node.type.name === "paragraph") {
    return false;
  }
  if (parent.type.name === "tableCell" || parent.type.name === "tableHeader") {
    return false;
  }
  if (node.content.size === 0) return false;
  return true;
}
function createDragHandle(node, pos, view, onHandleClick) {
  const handle = document.createElement("div");
  handle.className = "drag-handle";
  handle.contentEditable = "false";
  handle.draggable = false;
  render$1(h(HolderOutlined), handle);
  handle.addEventListener("mousedown", (e) => {
    e.stopPropagation();
    e.preventDefault();
  });
  handle.addEventListener("click", (e) => {
    e.stopPropagation();
    e.preventDefault();
    const nodeTo = pos + node.nodeSize;
    const handleRect = handle.getBoundingClientRect();
    view.dom.querySelectorAll(".drag-handle.active").forEach((el) => {
      el.classList.remove("active");
    });
    handle.classList.add("active");
    if (onHandleClick) {
      onHandleClick({
        position: { x: handleRect.right + 10, y: handleRect.top },
        nodePos: pos,
        nodeTo,
        handleElement: handle
      });
    }
  });
  return handle;
}
const DragHandleWithMenuExtension = Extension.create({
  name: "dragHandleWithMenu",
  addOptions() {
    return {
      onHandleClick: void 0
    };
  },
  addProseMirrorPlugins() {
    const options = this.options;
    return [
      new Plugin({
        key: dragHandleWithMenuKey,
        props: {
          decorations(state2) {
            const decorations = [];
            state2.doc.descendants((node, pos) => {
              const $pos = state2.doc.resolve(pos);
              const parent = $pos.parent;
              if (!shouldShowHandle(node, parent)) {
                return true;
              }
              decorations.push(
                Decoration.widget(
                  pos + 1,
                  (view) => createDragHandle(node, pos, view, options.onHandleClick),
                  {
                    side: -1,
                    stopEvent: (e) => {
                      return e.type === "mousedown" || e.type === "click";
                    }
                  }
                )
              );
              return true;
            });
            return DecorationSet.create(state2.doc, decorations);
          }
        }
      })
    ];
  }
});
async function copyToClipboard(editor, from, to) {
  try {
    const slice = editor.state.doc.slice(from, to);
    const text2 = slice.content.textBetween(0, slice.content.size, "\n");
    await navigator.clipboard.writeText(text2);
    return true;
  } catch (error) {
    console.error("[clipboard] Failed to copy to clipboard:", error);
    return false;
  }
}
async function cutToClipboard(editor, from, to) {
  try {
    const copied = await copyToClipboard(editor, from, to);
    if (copied) {
      editor.chain().deleteRange({ from, to }).run();
      return true;
    }
    return false;
  } catch (error) {
    console.error("[clipboard] Failed to cut to clipboard:", error);
    return false;
  }
}
async function copyBlock(editor, from, to) {
  return await copyToClipboard(editor, from, to);
}
async function cutBlock(editor, from, to) {
  return await cutToClipboard(editor, from, to);
}
function deleteBlock(editor, from, to) {
  try {
    editor.chain().deleteRange({ from, to }).run();
    return true;
  } catch (error) {
    console.error("[clipboard] Failed to delete block:", error);
    return false;
  }
}
function selectNodeContent(editor, from, to) {
  try {
    const contentStart = from + 1;
    const contentEnd = to - 1;
    if (contentStart < contentEnd) {
      editor.chain().setTextSelection({ from: contentStart, to: contentEnd }).run();
      return true;
    }
    return false;
  } catch (error) {
    console.error("[clipboard] Failed to select node content:", error);
    return false;
  }
}
const COLORS$1 = [
  "#000000",
  "#ff0000",
  "#ff9900",
  "#ffff00",
  "#00ff00",
  "#00ffff",
  "#0000ff",
  "#9900ff"
];
function createMenuConfig(editor, nodePos, nodeTo, onClose, t2) {
  const nodeFrom = nodePos;
  const createHeadingItem = (level) => ({
    level,
    title: t2(`editor.h${level}`),
    action: () => {
      editor.chain().focus().setTextSelection(nodeFrom).toggleHeading({ level }).run();
      onClose();
    }
  });
  const createTextFormatItem = (name, icon, titleKey, command) => ({
    name,
    icon,
    title: t2(titleKey),
    action: () => {
      selectNodeContent(editor, nodeFrom, nodeTo);
      command(editor.chain().focus()).run();
      onClose();
    }
  });
  const createListItem = (name, icon, titleKey, command) => ({
    name,
    icon,
    title: t2(titleKey),
    action: () => {
      command(editor.chain().focus().setTextSelection(nodeFrom)).run();
      onClose();
    }
  });
  return {
    // 标题
    headings: [1, 2, 3].map(createHeadingItem),
    // 文本格式
    textFormats: [
      createTextFormatItem("bold", BoldOutlined, "editor.bold", (chain) => chain.toggleBold()),
      createTextFormatItem("italic", ItalicOutlined, "editor.italic", (chain) => chain.toggleItalic()),
      createTextFormatItem("underline", UnderlineOutlined, "editor.underline", (chain) => chain.toggleUnderline()),
      createTextFormatItem("strike", StrikethroughOutlined, "editor.strike", (chain) => chain.toggleStrike())
    ],
    // 列表
    listItems: [
      createListItem("bulletList", UnorderedListOutlined, "editor.bulletList", (chain) => chain.toggleBulletList()),
      createListItem("orderedList", OrderedListOutlined, "editor.orderedList", (chain) => chain.toggleOrderedList()),
      createListItem("taskList", CheckSquareOutlined, "editor.taskList", (chain) => chain.toggleTaskList())
    ]
  };
}
function createEditActions(editor, nodePos, nodeTo, onClose, t2) {
  return [
    {
      icon: ScissorOutlined,
      title: t2("editor.cut"),
      action: async () => {
        await cutBlock(editor, nodePos, nodeTo);
        onClose();
      }
    },
    {
      icon: CopyOutlined,
      title: t2("editor.copy"),
      action: async () => {
        await copyBlock(editor, nodePos, nodeTo);
        onClose();
      }
    },
    {
      icon: DeleteOutlined,
      title: t2("editor.delete"),
      action: () => {
        deleteBlock(editor, nodePos, nodeTo);
        onClose();
      },
      danger: true
    }
  ];
}
const _hoisted_1$3 = { class: "inline-toolbar" };
const _hoisted_2$3 = { class: "inline-group" };
const _hoisted_3$2 = ["onClick", "data-level", "title"];
const _hoisted_4$2 = { class: "inline-group" };
const _hoisted_5$2 = ["onClick", "title"];
const _hoisted_6$2 = { class: "inline-group" };
const _hoisted_7$2 = ["onClick", "title"];
const _hoisted_8$1 = { class: "menu-section compact" };
const _hoisted_9$1 = { class: "menu-item-label" };
const _hoisted_10 = {
  key: 0,
  class: "sub-panel"
};
const _hoisted_11 = { class: "sub-group" };
const _hoisted_12 = ["title"];
const _hoisted_13 = ["title"];
const _hoisted_14 = ["title"];
const _hoisted_15 = { class: "sub-group" };
const _hoisted_16 = ["title"];
const _hoisted_17 = ["title"];
const _hoisted_18 = { class: "menu-section compact" };
const _hoisted_19 = { class: "menu-item-label" };
const _hoisted_20 = {
  key: 0,
  class: "color-picker-panel"
};
const _hoisted_21 = { class: "color-picker-grid" };
const _hoisted_22 = ["onClick"];
const _hoisted_23 = { class: "sub-actions" };
const _hoisted_24 = { class: "menu-section" };
const _hoisted_25 = { class: "menu-section-title" };
const _hoisted_26 = ["onClick"];
const _hoisted_27 = { class: "menu-item-label" };
const HIDE_MENU_DELAY = 160;
const POSITION_SAFE_MARGIN = 8;
const POSITION_GAP = 12;
const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "DragHandleMenu",
  props: {
    editor: {},
    readonly: { type: Boolean, default: false },
    positionStrategy: { default: "auto" }
  },
  setup(__props, { expose: __expose }) {
    const props = __props;
    const menuState = ref({
      visible: false,
      position: { x: 0, y: 0 },
      nodePos: 0,
      nodeTo: 0,
      handleElement: null
    });
    const handleDragHandleClick = (event) => {
      menuState.value = {
        visible: true,
        position: event.position,
        nodePos: event.nodePos,
        nodeTo: event.nodeTo,
        handleElement: event.handleElement
      };
    };
    const hideMenu = () => {
      if (menuState.value.handleElement) {
        menuState.value.handleElement.classList.remove("active");
      }
      menuState.value.visible = false;
      menuState.value.handleElement = null;
    };
    const isMenuVisible = computed(() => menuState.value.visible);
    const menuPosition = computed(() => menuState.value.position);
    const menuRef = ref(null);
    const colorPanelType = ref(null);
    const indentAlignOpen = ref(false);
    let hideTimer = null;
    const editor = computed(() => props.editor ?? null);
    const { isActive, isHeadingActive, isActiveAlign } = createStateCheckers(editor);
    const runCommand = createCommandRunner(editor);
    const menuStyle = computed(() => ({
      position: "fixed",
      left: `${menuPosition.value.x}px`,
      top: `${menuPosition.value.y}px`,
      zIndex: 1002
    }));
    function clamp(n, min, max) {
      return Math.min(Math.max(n, min), max);
    }
    function updateMenuPosition() {
      const handle = menuState.value.handleElement;
      const menuEl = menuRef.value;
      if (!handle || !menuEl) return;
      const handleRect = handle.getBoundingClientRect();
      const menuWidth = menuEl.offsetWidth;
      const menuHeight = menuEl.offsetHeight;
      const viewportWidth = window.innerWidth;
      const viewportHeight = window.innerHeight;
      let x;
      if (props.positionStrategy === "right") {
        x = handleRect.right + POSITION_GAP;
      } else if (props.positionStrategy === "left") {
        x = handleRect.left - menuWidth - POSITION_GAP;
      } else {
        x = handleRect.right + POSITION_GAP;
        if (x + menuWidth + POSITION_SAFE_MARGIN > viewportWidth) {
          x = handleRect.left - menuWidth - POSITION_GAP;
        }
      }
      x = clamp(x, POSITION_SAFE_MARGIN, viewportWidth - menuWidth - POSITION_SAFE_MARGIN);
      let y = handleRect.bottom + POSITION_GAP;
      if (y + menuHeight + POSITION_SAFE_MARGIN > viewportHeight) {
        y = handleRect.top - menuHeight - POSITION_GAP;
      }
      y = clamp(y, POSITION_SAFE_MARGIN, viewportHeight - menuHeight - POSITION_SAFE_MARGIN);
      menuState.value.position = { x, y };
    }
    function scheduleHideMenu() {
      if (indentAlignOpen.value || colorPanelType.value) {
        return;
      }
      const el = menuRef.value;
      if (hideTimer) window.clearTimeout(hideTimer);
      if (el) el.classList.add("closing");
      hideTimer = window.setTimeout(() => {
        hideTimer = null;
        hideMenu();
        if (el) el.classList.remove("closing");
      }, HIDE_MENU_DELAY);
    }
    function cancelHideMenu() {
      const el = menuRef.value;
      if (hideTimer) {
        window.clearTimeout(hideTimer);
        hideTimer = null;
      }
      if (el) el.classList.remove("closing");
    }
    function onReposition() {
      if (!menuState.value.visible) return;
      updateMenuPosition();
    }
    watch(isMenuVisible, async (visible) => {
      if (!visible) return;
      await nextTick();
      updateMenuPosition();
    });
    watch(isMenuVisible, (visible) => {
      if (!visible) {
        colorPanelType.value = null;
        indentAlignOpen.value = false;
      }
    });
    onMounted(() => {
      window.addEventListener("scroll", onReposition, true);
      window.addEventListener("resize", onReposition, true);
      if (editor.value) {
        const handleUpdate = () => {
          if (menuState.value.visible) {
            hideMenu();
          }
        };
        editor.value.on("update", handleUpdate);
        editor.value.on("selectionUpdate", handleUpdate);
      }
    });
    onUnmounted(() => {
      window.removeEventListener("scroll", onReposition, true);
      window.removeEventListener("resize", onReposition, true);
      if (hideTimer) {
        window.clearTimeout(hideTimer);
        hideTimer = null;
      }
      hideMenu();
    });
    const menuConfig = computed(() => {
      if (!editor.value) return null;
      return createMenuConfig(editor.value, menuState.value.nodePos, menuState.value.nodeTo, hideMenu, t);
    });
    const editActions = computed(() => {
      if (!editor.value) return [];
      return createEditActions(editor.value, menuState.value.nodePos, menuState.value.nodeTo, hideMenu, t);
    });
    const headings = computed(() => menuConfig.value?.headings ?? []);
    const textFormats = computed(() => menuConfig.value?.textFormats ?? []);
    const listItems = computed(() => menuConfig.value?.listItems ?? []);
    const selectNodeContent$1 = (from, to) => {
      const e = editor.value;
      if (!e) return;
      selectNodeContent(e, from, to);
    };
    const toggleColorPanel = (type) => {
      colorPanelType.value = colorPanelType.value === type ? null : type;
    };
    const setColorMode = (mode) => {
      colorPanelType.value = mode;
    };
    const applyColor = (color) => {
      selectNodeContent$1(menuState.value.nodePos, menuState.value.nodeTo);
      if (colorPanelType.value === "text") {
        runCommand((chain) => chain.setColor(color))();
      } else if (colorPanelType.value === "highlight") {
        runCommand((chain) => chain.setHighlight({ color }))();
      }
      colorPanelType.value = null;
      hideMenu();
    };
    const toggleIndentAlignPanel = () => {
      indentAlignOpen.value = !indentAlignOpen.value;
    };
    const setAlign = (align) => {
      selectNodeContent$1(menuState.value.nodePos, menuState.value.nodeTo);
      runCommand((chain) => chain.setTextAlign(align))();
    };
    const indentList = () => {
      runCommand((chain) => chain.sinkListItem("listItem"))();
    };
    const outdentList = () => {
      runCommand((chain) => chain.liftListItem("listItem"))();
    };
    __expose({
      handleDragHandleClick
    });
    return (_ctx, _cache) => {
      return openBlock(), createBlock(Teleport, { to: "body" }, [
        isMenuVisible.value ? (openBlock(), createElementBlock("div", {
          key: 0,
          ref_key: "menuRef",
          ref: menuRef,
          class: "drag-handle-menu",
          style: normalizeStyle(menuStyle.value),
          onMouseenter: cancelHideMenu,
          onMouseleave: scheduleHideMenu,
          onClick: _cache[6] || (_cache[6] = withModifiers(() => {
          }, ["stop"]))
        }, [
          createElementVNode("div", _hoisted_1$3, [
            createElementVNode("div", _hoisted_2$3, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(headings.value, (heading) => {
                return openBlock(), createElementBlock("button", {
                  key: heading.level,
                  class: normalizeClass(["icon-btn heading-btn", { active: unref(isHeadingActive)(heading.level) }]),
                  onClick: heading.action,
                  "data-level": heading.level,
                  title: heading.title
                }, " H" + toDisplayString(heading.level), 11, _hoisted_3$2);
              }), 128))
            ]),
            createElementVNode("div", _hoisted_4$2, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(textFormats.value, (format) => {
                return openBlock(), createElementBlock("button", {
                  key: format.name,
                  class: normalizeClass(["icon-btn", { active: unref(isActive)(format.name) }]),
                  onClick: format.action,
                  title: format.title
                }, [
                  (openBlock(), createBlock(resolveDynamicComponent(format.icon)))
                ], 10, _hoisted_5$2);
              }), 128))
            ]),
            createElementVNode("div", _hoisted_6$2, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(listItems.value, (item) => {
                return openBlock(), createElementBlock("button", {
                  key: item.name,
                  class: normalizeClass(["icon-btn", { active: unref(isActive)(item.name) }]),
                  onClick: item.action,
                  title: item.title
                }, [
                  (openBlock(), createBlock(resolveDynamicComponent(item.icon)))
                ], 10, _hoisted_7$2);
              }), 128))
            ])
          ]),
          createElementVNode("div", _hoisted_8$1, [
            createElementVNode("button", {
              class: "menu-item",
              onClick: toggleIndentAlignPanel
            }, [
              createVNode(unref(AlignLeftOutlined), { class: "menu-item-icon" }),
              createElementVNode("span", _hoisted_9$1, toDisplayString(unref(t)("editor.indentAndAlign")), 1),
              _cache[7] || (_cache[7] = createElementVNode("span", { class: "menu-item-chevron" }, "›", -1))
            ]),
            indentAlignOpen.value ? (openBlock(), createElementBlock("div", _hoisted_10, [
              createElementVNode("div", _hoisted_11, [
                createElementVNode("button", {
                  class: normalizeClass(["icon-btn", { active: unref(isActiveAlign)("left") }]),
                  onClick: _cache[0] || (_cache[0] = ($event) => setAlign("left")),
                  title: unref(t)("editor.alignLeft")
                }, [
                  createVNode(unref(AlignLeftOutlined))
                ], 10, _hoisted_12),
                createElementVNode("button", {
                  class: normalizeClass(["icon-btn", { active: unref(isActiveAlign)("center") }]),
                  onClick: _cache[1] || (_cache[1] = ($event) => setAlign("center")),
                  title: unref(t)("editor.alignCenter")
                }, [
                  createVNode(unref(AlignCenterOutlined))
                ], 10, _hoisted_13),
                createElementVNode("button", {
                  class: normalizeClass(["icon-btn", { active: unref(isActiveAlign)("right") }]),
                  onClick: _cache[2] || (_cache[2] = ($event) => setAlign("right")),
                  title: unref(t)("editor.alignRight")
                }, [
                  createVNode(unref(AlignRightOutlined))
                ], 10, _hoisted_14)
              ]),
              createElementVNode("div", _hoisted_15, [
                createElementVNode("button", {
                  class: "icon-btn",
                  onClick: indentList,
                  title: unref(t)("editor.indent")
                }, [
                  createVNode(unref(MenuUnfoldOutlined))
                ], 8, _hoisted_16),
                createElementVNode("button", {
                  class: "icon-btn",
                  onClick: outdentList,
                  title: unref(t)("editor.outdent")
                }, [
                  createVNode(unref(MenuFoldOutlined))
                ], 8, _hoisted_17)
              ])
            ])) : createCommentVNode("", true)
          ]),
          createElementVNode("div", _hoisted_18, [
            createElementVNode("button", {
              class: "menu-item",
              onClick: _cache[3] || (_cache[3] = ($event) => toggleColorPanel("text"))
            }, [
              createVNode(unref(FontColorsOutlined), { class: "menu-item-icon" }),
              createElementVNode("span", _hoisted_19, toDisplayString(unref(t)("editor.colors")), 1),
              _cache[8] || (_cache[8] = createElementVNode("span", { class: "menu-item-chevron" }, "›", -1))
            ]),
            colorPanelType.value ? (openBlock(), createElementBlock("div", _hoisted_20, [
              createElementVNode("div", _hoisted_21, [
                (openBlock(true), createElementBlock(Fragment, null, renderList(unref(COLORS$1), (c) => {
                  return openBlock(), createElementBlock("div", {
                    key: c,
                    class: "color-picker-item",
                    style: normalizeStyle({ background: c }),
                    onClick: ($event) => applyColor(c)
                  }, null, 12, _hoisted_22);
                }), 128))
              ]),
              createElementVNode("div", _hoisted_23, [
                createElementVNode("button", {
                  class: "mini-btn",
                  onClick: _cache[4] || (_cache[4] = ($event) => setColorMode("text"))
                }, toDisplayString(unref(t)("editor.text")), 1),
                createElementVNode("button", {
                  class: "mini-btn",
                  onClick: _cache[5] || (_cache[5] = ($event) => setColorMode("highlight"))
                }, toDisplayString(unref(t)("editor.highlight")), 1)
              ])
            ])) : createCommentVNode("", true)
          ]),
          createElementVNode("div", _hoisted_24, [
            createElementVNode("div", _hoisted_25, toDisplayString(unref(t)("editor.actions")), 1),
            (openBlock(true), createElementBlock(Fragment, null, renderList(editActions.value, (action) => {
              return openBlock(), createElementBlock("button", {
                key: action.title,
                class: normalizeClass(["menu-item", { "menu-item-danger": action.danger }]),
                onClick: action.action
              }, [
                (openBlock(), createBlock(resolveDynamicComponent(action.icon), { class: "menu-item-icon" })),
                createElementVNode("span", _hoisted_27, toDisplayString(action.title), 1)
              ], 10, _hoisted_26);
            }), 128))
          ])
        ], 36)) : createCommentVNode("", true),
        isMenuVisible.value ? (openBlock(), createElementBlock("div", {
          key: 1,
          class: "drag-handle-menu-backdrop",
          onClick: hideMenu
        })) : createCommentVNode("", true)
      ]);
    };
  }
});
const COLORS = [
  "#3b82f6",
  "#ef4444",
  "#10b981",
  "#f59e0b",
  "#8b5cf6",
  "#ec4899",
  "#06b6d4",
  "#f97316"
];
function getRandomColor() {
  return COLORS[Math.floor(Math.random() * COLORS.length)] || "#3b82f6";
}
const noop = (..._args) => {
};
const logger = {
  info: noop,
  warn: noop,
  error: noop,
  success: noop
};
class TimerManager {
  timeouts = [];
  intervals = [];
  setTimeout(fn, delay) {
    const id = setTimeout(() => {
      const idx = this.timeouts.indexOf(id);
      if (idx > -1) this.timeouts.splice(idx, 1);
      fn();
    }, delay);
    this.timeouts.push(id);
    return id;
  }
  setInterval(fn, delay) {
    const id = setInterval(fn, delay);
    this.intervals.push(id);
    return id;
  }
  clearTimeout(id) {
    clearTimeout(id);
    const idx = this.timeouts.indexOf(id);
    if (idx > -1) this.timeouts.splice(idx, 1);
  }
  clearAll() {
    const counts = { timeoutCount: this.timeouts.length, intervalCount: this.intervals.length };
    this.timeouts.forEach(clearTimeout);
    this.intervals.forEach(clearInterval);
    this.timeouts = [];
    this.intervals = [];
    return counts;
  }
}
class EventManager {
  listeners = [];
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  on(target, event, handler) {
    if (target && typeof target.on === "function") {
      target.on(event, handler);
      this.listeners.push({ target, event, handler });
    }
  }
  removeAll() {
    let count = 0;
    this.listeners.forEach(({ target, event, handler }) => {
      try {
        if (typeof target?.off === "function") {
          target.off(event, handler);
          count++;
        }
      } catch {
      }
    });
    this.listeners = [];
    return count;
  }
}
function getUniqueUsers(awareness) {
  const states = awareness.getStates();
  const userMap = /* @__PURE__ */ new Map();
  states.forEach((state2, clientId) => {
    if (state2.user) {
      const id = state2.user.id || clientId;
      if (!userMap.has(id)) {
        userMap.set(id, {
          id,
          name: state2.user.name || `用户${clientId}`,
          color: state2.user.color || "#3b82f6"
        });
      }
    }
  });
  return Array.from(userMap.values());
}
function isDocumentEmpty(content) {
  if (!content || content.type !== "doc") return !content;
  const nodes = content.content;
  if (!Array.isArray(nodes) || nodes.length === 0) return true;
  if (nodes.length > 1) return false;
  const first = nodes[0];
  return first?.type === "paragraph" && (!first?.content || first.content.length === 0);
}
function debounce(fn, delay) {
  let id = null;
  const run = ((...args) => {
    if (id) clearTimeout(id);
    id = setTimeout(() => {
      fn(...args);
      id = null;
    }, delay);
  });
  const cancel = () => {
    if (id) {
      clearTimeout(id);
      id = null;
    }
  };
  return { run, cancel };
}
function normalizeWebSocketUrl(url) {
  if (!url?.trim()) return null;
  const trimmed = url.trim();
  if (trimmed.startsWith("ws://") || trimmed.startsWith("wss://")) {
    return trimmed;
  }
  if (trimmed.startsWith("http://")) {
    return trimmed.replace(/^http:\/\//, "ws://");
  }
  if (trimmed.startsWith("https://")) {
    return trimmed.replace(/^https:\/\//, "wss://");
  }
  if (trimmed.startsWith("/")) {
    const protocol2 = window.location.protocol === "https:" ? "wss:" : "ws:";
    return `${protocol2}//${window.location.host}${trimmed}`;
  }
  const protocol = window.location.protocol === "https:" ? "wss://" : "ws://";
  return `${protocol}${trimmed}`;
}
const EMPTY_DOC = { type: "doc", content: [{ type: "paragraph" }] };
const CONFIG = {
  /** 等待编辑器创建的最大重试次数 */
  MAX_EDITOR_WAIT_RETRIES: 10,
  /** 重试间隔（ms） */
  RETRY_INTERVAL: 500,
  /** 初始化延迟（ms） */
  INIT_DELAY: 1e3,
  /** 防抖延迟（ms） */
  DEBOUNCE_DELAY: 200
};
function normalizeContent(content, options) {
  if (!content) return EMPTY_DOC;
  if (typeof content === "string") return content;
  const log = options?.silent ? (() => {
  }) : logger.info.bind(logger);
  if (Array.isArray(content)) {
    log("数组格式内容，包装为文档对象");
    return { type: "doc", content };
  }
  if (typeof content === "object") {
    if (content.type === "doc") return content;
    if (Array.isArray(content.content)) {
      log("非 doc 类型对象，包装为文档对象");
      return { type: "doc", content: content.content };
    }
    log("单节点对象，包装为文档对象");
    return { type: "doc", content: [content] };
  }
  logger.warn("未知内容格式，使用空文档");
  return EMPTY_DOC;
}
function getContentLength(content) {
  if (Array.isArray(content)) return content.length;
  return content?.content?.length ?? 0;
}
function shouldUseInitialContent(isEmpty, onlineCount, initialContent, currentContent) {
  if (isEmpty) {
    logger.info("文档为空，使用 initialContent");
    return true;
  }
  if (onlineCount <= 1) {
    logger.info("单人编辑，使用 initialContent");
    return true;
  }
  const initialLen = getContentLength(initialContent);
  const currentLen = getContentLength(currentContent);
  if (initialLen > 0 && initialLen !== currentLen) {
    logger.info("内容长度不一致，使用 initialContent", { initialLen, currentLen });
    return true;
  }
  logger.info("多人协同，使用 Yjs 数据");
  return false;
}
async function initCollaboration(options) {
  const {
    documentId,
    readonly: readonly2 = false,
    initialContent,
    editor,
    getUserInfo: getUserInfoFn,
    onCollaboratorsChange,
    onCollaboratorsListChange
  } = options;
  if (readonly2 || !documentId) {
    logger.info("协作功能未启用", { readonly: readonly2, hasDocId: !!documentId });
    return null;
  }
  try {
    logger.info("初始化协作，文档ID:", documentId);
    const [{ getWebSocketUrl }, Y, { WebsocketProvider }] = await Promise.all([
      import("./websocket-DLLOwgDf.js"),
      import("yjs"),
      import("y-websocket")
    ]);
    const wsUrl = normalizeWebSocketUrl(getWebSocketUrl(documentId));
    if (!wsUrl) {
      logger.error("WebSocket URL 无效");
      return null;
    }
    const doc = new Y.Doc();
    const roomName = `document-${documentId}`;
    const wsProvider = new WebsocketProvider(wsUrl, roomName, doc, { connect: true });
    const timerManager = new TimerManager();
    const eventManager = new EventManager();
    const userInfo = getUserInfoFn?.() ?? { id: "anonymous", name: "匿名用户" };
    const userColor = getRandomColor();
    const setUserInfo2 = () => {
      wsProvider.awareness.setLocalStateField("user", {
        id: userInfo.id,
        name: userInfo.name,
        color: userColor
      });
    };
    const getRoomStatus = () => {
      const users = getUniqueUsers(wsProvider.awareness);
      return { users, count: users.length };
    };
    let currentEditor2 = editor;
    let contentInitialized = false;
    let syncProcessed = false;
    let retryCount = 0;
    eventManager.on(wsProvider, "status", ({ status }) => {
      logger.info("连接状态:", status);
      if (status === "connected") setUserInfo2();
    });
    const handleSync = (isSynced) => {
      if (!isSynced || syncProcessed && contentInitialized) return;
      if (!currentEditor2) {
        if (retryCount >= CONFIG.MAX_EDITOR_WAIT_RETRIES) {
          logger.warn("编辑器等待超时");
          syncProcessed = true;
          return;
        }
        retryCount++;
        timerManager.setTimeout(() => {
          currentEditor2 = options.editor ?? currentEditor2;
          handleSync(true);
        }, CONFIG.RETRY_INTERVAL);
        return;
      }
      if (initialContent && !contentInitialized && !syncProcessed) {
        syncProcessed = true;
        timerManager.setTimeout(() => {
          if (contentInitialized) return;
          currentEditor2 = currentEditor2 || options.editor;
          if (!currentEditor2) {
            logger.warn("编辑器未创建，跳过内容设置");
            return;
          }
          const { count } = getRoomStatus();
          const currentContent = currentEditor2.getJSON();
          const isEmpty = isDocumentEmpty(currentContent);
          contentInitialized = true;
          if (shouldUseInitialContent(isEmpty, count, initialContent, currentContent)) {
            currentEditor2.commands.setContent(normalizeContent(initialContent));
          }
        }, CONFIG.RETRY_INTERVAL);
      }
    };
    eventManager.on(wsProvider, "sync", handleSync);
    const debouncedUpdate = debounce(() => {
      const { users, count } = getRoomStatus();
      onCollaboratorsChange?.(count);
      onCollaboratorsListChange?.(users);
    }, CONFIG.DEBOUNCE_DELAY);
    eventManager.on(wsProvider.awareness, "change", debouncedUpdate.run);
    const cleanup = () => {
      debouncedUpdate.cancel();
      timerManager.clearAll();
      eventManager.removeAll();
    };
    const originalDestroy = wsProvider.destroy?.bind(wsProvider);
    wsProvider.destroy = () => {
      cleanup();
      originalDestroy?.();
    };
    setUserInfo2();
    timerManager.setTimeout(() => {
      const { users, count } = getRoomStatus();
      onCollaboratorsChange?.(count);
      onCollaboratorsListChange?.(users);
    }, CONFIG.INIT_DELAY);
    logger.success("协作初始化成功，房间:", roomName);
    return {
      doc,
      provider: wsProvider,
      setEditor: (newEditor) => {
        currentEditor2 = newEditor;
        if (wsProvider.synced && !contentInitialized) {
          handleSync(true);
        }
      },
      destroy: () => {
        cleanup();
        try {
          wsProvider.destroy();
        } catch {
        }
        try {
          doc.destroy();
        } catch {
        }
        logger.success("协作实例已销毁");
      }
    };
  } catch (error) {
    logger.error("初始化失败:", error);
    return null;
  }
}
async function createCollaborationExtensions(instance, getUserInfo) {
  if (!instance) return [];
  const [Collaboration, CollaborationCursor] = await Promise.all([
    import("@tiptap/extension-collaboration").then((m) => m.default),
    import("@tiptap/extension-collaboration-cursor").then((m) => m.default)
  ]);
  const user = getUserInfo?.() ?? { id: "anonymous", name: "匿名用户" };
  return [
    Collaboration.configure({ document: instance.doc }),
    CollaborationCursor.configure({
      provider: instance.provider,
      user: { id: user.id, name: user.name, color: getRandomColor() }
    })
  ];
}
function useCollaboration(options = {}) {
  const enabled = ref(false);
  const instance = shallowRef(null);
  const initializing = ref(false);
  const connected = computed(() => !!instance.value);
  const collaboratorsCount = ref(0);
  const collaboratorsList = ref([]);
  const onCountChange = (count) => {
    collaboratorsCount.value = count;
    options.onCollaboratorsChange?.(count);
  };
  const onListChange = (users) => {
    collaboratorsList.value = users;
    options.onCollaboratorsListChange?.(users);
  };
  const enable = async (initOptions) => {
    if (enabled.value && instance.value) {
      logger.info("协作已启用，跳过");
      return instance.value;
    }
    if (initializing.value) {
      logger.info("正在初始化中");
      return null;
    }
    try {
      initializing.value = true;
      enabled.value = true;
      const result = await initCollaboration({
        ...initOptions,
        getUserInfo: initOptions.getUserInfo ?? options.getUserInfo,
        onCollaboratorsChange: onCountChange,
        onCollaboratorsListChange: onListChange
      });
      if (result) {
        instance.value = result;
        logger.success("协作已启用");
      } else {
        enabled.value = false;
        logger.warn("协作初始化失败");
      }
      return result;
    } catch (error) {
      enabled.value = false;
      logger.error("启用协作失败:", error);
      return null;
    } finally {
      initializing.value = false;
    }
  };
  const disable = () => {
    if (instance.value) {
      try {
        instance.value.destroy();
        logger.success("协作已关闭");
      } catch (error) {
        logger.error("关闭协作失败:", error);
      }
      instance.value = null;
    }
    enabled.value = false;
    initializing.value = false;
    collaboratorsCount.value = 0;
    collaboratorsList.value = [];
  };
  const initWithExtensions = async (initOptions) => {
    const result = await enable(initOptions);
    if (!result) return [];
    return createCollaborationExtensions(result, initOptions.getUserInfo ?? options.getUserInfo);
  };
  const setEditor = (editor) => {
    instance.value?.setEditor?.(editor);
  };
  return {
    // 只读状态
    enabled: readonly(enabled),
    connected,
    initializing: readonly(initializing),
    instance: readonly(instance),
    collaboratorsCount: readonly(collaboratorsCount),
    collaboratorsList: readonly(collaboratorsList),
    // 方法
    enable,
    disable,
    initWithExtensions,
    setEditor,
    reset: disable
  };
}
const _hoisted_1$2 = { class: "all-collaborators-popover" };
const _hoisted_2$2 = { class: "popover-title" };
const _hoisted_3$1 = { class: "popover-users" };
const _hoisted_4$1 = { class: "popover-user-name" };
const _hoisted_5$1 = { class: "collaboration-toggle" };
const _hoisted_6$1 = { class: "toggle-text enabled" };
const _hoisted_7$1 = {
  key: 1,
  class: "collaboration-toggle"
};
const _hoisted_8 = {
  key: 0,
  class: "toggle-text"
};
const _hoisted_9 = {
  key: 1,
  class: "toggle-text enabled"
};
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "CollaborationToggle",
  props: {
    modelValue: { type: Boolean, default: false },
    showLabel: { type: Boolean, default: false },
    collaboratorsCount: { default: 0 },
    collaboratorsList: { default: () => [] }
  },
  emits: ["update:modelValue", "change"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const enabled = computed({
      get: () => props.modelValue,
      set: (value) => {
        emit("update:modelValue", value);
        emit("change", value);
      }
    });
    const collaboratorsList = computed(() => props.collaboratorsList);
    const firstUser = computed(() => collaboratorsList.value[0] || null);
    const getAvatarText = (name) => {
      if (!name?.trim()) return "?";
      const trimmed = name.trim();
      return /[\u4e00-\u9fa5]/.test(trimmed) ? trimmed.slice(0, 2) : trimmed.charAt(0).toUpperCase();
    };
    return (_ctx, _cache) => {
      return enabled.value && collaboratorsList.value.length > 0 ? (openBlock(), createBlock(unref(Popover), {
        key: 0,
        placement: "bottomRight",
        "overlay-style": { maxWidth: "300px" }
      }, {
        content: withCtx(() => [
          createElementVNode("div", _hoisted_1$2, [
            createElementVNode("div", _hoisted_2$2, "在线用户 (" + toDisplayString(collaboratorsList.value.length) + ")", 1),
            createElementVNode("div", _hoisted_3$1, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(collaboratorsList.value, (user) => {
                return openBlock(), createElementBlock("div", {
                  key: user.id,
                  class: "popover-user-item"
                }, [
                  createElementVNode("div", {
                    class: "popover-avatar",
                    style: normalizeStyle({ backgroundColor: user.color })
                  }, toDisplayString(getAvatarText(user.name)), 5),
                  createElementVNode("span", _hoisted_4$1, toDisplayString(user.name), 1)
                ]);
              }), 128))
            ])
          ])
        ]),
        default: withCtx(() => [
          createElementVNode("div", _hoisted_5$1, [
            _cache[0] || (_cache[0] = createElementVNode("span", { class: "toggle-label" }, "协作", -1)),
            createElementVNode("span", _hoisted_6$1, "已开启 (" + toDisplayString(collaboratorsList.value.length) + ")", 1),
            firstUser.value ? (openBlock(), createElementBlock("div", {
              key: 0,
              class: "avatar-item",
              style: normalizeStyle({ backgroundColor: firstUser.value.color })
            }, toDisplayString(getAvatarText(firstUser.value.name)), 5)) : createCommentVNode("", true)
          ])
        ]),
        _: 1
      })) : (openBlock(), createElementBlock("div", _hoisted_7$1, [
        _cache[1] || (_cache[1] = createElementVNode("span", { class: "toggle-label" }, "协作", -1)),
        !enabled.value ? (openBlock(), createElementBlock("span", _hoisted_8, "已关闭")) : (openBlock(), createElementBlock("span", _hoisted_9, "已开启 (0)"))
      ]));
    };
  }
});
const CollaborationToggle = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-f62fb6fc"]]);
const PasteImage = Extension.create({
  name: "pasteImage",
  addProseMirrorPlugins() {
    return [
      new Plugin({
        key: new PluginKey("pasteImage"),
        props: {
          handlePaste: (view, event) => {
            if (!view || !event.clipboardData) {
              return false;
            }
            const items = Array.from(event.clipboardData.items);
            const imageItem = items.find((item) => item.type.indexOf("image") !== -1);
            if (imageItem) {
              const file = imageItem.getAsFile();
              if (file) {
                const reader = new FileReader();
                reader.onload = (e) => {
                  if (!e.target?.result) return;
                  const src = e.target.result;
                  const { state: state2, dispatch } = view;
                  const { schema } = state2;
                  if (schema.nodes.image) {
                    const imageNode = schema.nodes.image.create({ src });
                    const transaction = state2.tr.replaceSelectionWith(imageNode);
                    dispatch(transaction);
                  }
                };
                reader.readAsDataURL(file);
                return true;
              }
            }
            return false;
          }
        }
      })
    ];
  }
});
const PasteWord = Extension.create({
  name: "pasteWord",
  addProseMirrorPlugins() {
    return [
      new Plugin({
        key: new PluginKey("pasteWord"),
        props: {
          transformPastedHTML: (html) => {
            if (!html) return html;
            return html.replace(/<o:p>[\s\S]*?<\/o:p>/gi, "").replace(/<!--[\s\S]*?-->/gi, "").replace(/<style>[\s\S]*?<\/style>/gi, "").replace(/<meta[\s\S]*?>/gi, "").replace(/<link[\s\S]*?>/gi, "");
          }
        }
      })
    ];
  }
});
const ListShortcuts = Extension.create({
  name: "listShortcuts",
  addKeyboardShortcuts() {
    return {
      // Enter 键在列表项中创建新项
      Enter: ({ editor }) => {
        const { state: state2 } = editor;
        const { selection } = state2;
        const { $from } = selection;
        if ($from.node(-1)?.type.name === "taskItem") {
          return editor.commands.splitListItem("taskItem");
        }
        if ($from.node(-1)?.type.name === "listItem") {
          return editor.commands.splitListItem("listItem");
        }
        return false;
      },
      // Shift+Enter 在列表项中创建新行
      "Shift-Enter": ({ editor }) => {
        return editor.commands.first([
          () => editor.commands.newlineInCode(),
          () => editor.commands.createParagraphNear()
        ]);
      }
    };
  }
});
const DEFAULT_KATEX_OPTIONS = {
  throwOnError: false,
  errorColor: "#cc0000",
  strict: false,
  trust: false
};
class SourceLocation {
  // The + prefix indicates that these fields aren't writeable
  // Lexer holding the input string.
  // Start offset, zero-based inclusive.
  // End offset, zero-based exclusive.
  constructor(lexer, start, end) {
    this.lexer = void 0;
    this.start = void 0;
    this.end = void 0;
    this.lexer = lexer;
    this.start = start;
    this.end = end;
  }
  /**
   * Merges two `SourceLocation`s from location providers, given they are
   * provided in order of appearance.
   * - Returns the first one's location if only the first is provided.
   * - Returns a merged range of the first and the last if both are provided
   *   and their lexers match.
   * - Otherwise, returns null.
   */
  static range(first, second) {
    if (!second) {
      return first && first.loc;
    } else if (!first || !first.loc || !second.loc || first.loc.lexer !== second.loc.lexer) {
      return null;
    } else {
      return new SourceLocation(first.loc.lexer, first.loc.start, second.loc.end);
    }
  }
}
class Token {
  // don't expand the token
  // used in \noexpand
  constructor(text2, loc) {
    this.text = void 0;
    this.loc = void 0;
    this.noexpand = void 0;
    this.treatAsRelax = void 0;
    this.text = text2;
    this.loc = loc;
  }
  /**
   * Given a pair of tokens (this and endToken), compute a `Token` encompassing
   * the whole input range enclosed by these two.
   */
  range(endToken, text2) {
    return new Token(text2, SourceLocation.range(this, endToken));
  }
}
class ParseError {
  // Error start position based on passed-in Token or ParseNode.
  // Length of affected text based on passed-in Token or ParseNode.
  // The underlying error message without any context added.
  constructor(message2, token) {
    this.name = void 0;
    this.position = void 0;
    this.length = void 0;
    this.rawMessage = void 0;
    var error = "KaTeX parse error: " + message2;
    var start;
    var end;
    var loc = token && token.loc;
    if (loc && loc.start <= loc.end) {
      var input = loc.lexer.input;
      start = loc.start;
      end = loc.end;
      if (start === input.length) {
        error += " at end of input: ";
      } else {
        error += " at position " + (start + 1) + ": ";
      }
      var underlined = input.slice(start, end).replace(/[^]/g, "$&̲");
      var left;
      if (start > 15) {
        left = "…" + input.slice(start - 15, start);
      } else {
        left = input.slice(0, start);
      }
      var right;
      if (end + 15 < input.length) {
        right = input.slice(end, end + 15) + "…";
      } else {
        right = input.slice(end);
      }
      error += left + underlined + right;
    }
    var self = new Error(error);
    self.name = "ParseError";
    self.__proto__ = ParseError.prototype;
    self.position = start;
    if (start != null && end != null) {
      self.length = end - start;
    }
    self.rawMessage = message2;
    return self;
  }
}
ParseError.prototype.__proto__ = Error.prototype;
var deflt = function deflt2(setting, defaultIfUndefined) {
  return setting === void 0 ? defaultIfUndefined : setting;
};
var uppercase = /([A-Z])/g;
var hyphenate = function hyphenate2(str) {
  return str.replace(uppercase, "-$1").toLowerCase();
};
var ESCAPE_LOOKUP = {
  "&": "&amp;",
  ">": "&gt;",
  "<": "&lt;",
  '"': "&quot;",
  "'": "&#x27;"
};
var ESCAPE_REGEX = /[&><"']/g;
function escape(text2) {
  return String(text2).replace(ESCAPE_REGEX, (match) => ESCAPE_LOOKUP[match]);
}
var getBaseElem = function getBaseElem2(group) {
  if (group.type === "ordgroup") {
    if (group.body.length === 1) {
      return getBaseElem2(group.body[0]);
    } else {
      return group;
    }
  } else if (group.type === "color") {
    if (group.body.length === 1) {
      return getBaseElem2(group.body[0]);
    } else {
      return group;
    }
  } else if (group.type === "font") {
    return getBaseElem2(group.body);
  } else {
    return group;
  }
};
var isCharacterBox = function isCharacterBox2(group) {
  var baseElem = getBaseElem(group);
  return baseElem.type === "mathord" || baseElem.type === "textord" || baseElem.type === "atom";
};
var assert = function assert2(value) {
  if (!value) {
    throw new Error("Expected non-null, but got " + String(value));
  }
  return value;
};
var protocolFromUrl = function protocolFromUrl2(url) {
  var protocol = /^[\x00-\x20]*([^\\/#?]*?)(:|&#0*58|&#x0*3a|&colon)/i.exec(url);
  if (!protocol) {
    return "_relative";
  }
  if (protocol[2] !== ":") {
    return null;
  }
  if (!/^[a-zA-Z][a-zA-Z0-9+\-.]*$/.test(protocol[1])) {
    return null;
  }
  return protocol[1].toLowerCase();
};
var utils = {
  deflt,
  escape,
  hyphenate,
  getBaseElem,
  isCharacterBox,
  protocolFromUrl
};
var SETTINGS_SCHEMA = {
  displayMode: {
    type: "boolean",
    description: "Render math in display mode, which puts the math in display style (so \\int and \\sum are large, for example), and centers the math on the page on its own line.",
    cli: "-d, --display-mode"
  },
  output: {
    type: {
      enum: ["htmlAndMathml", "html", "mathml"]
    },
    description: "Determines the markup language of the output.",
    cli: "-F, --format <type>"
  },
  leqno: {
    type: "boolean",
    description: "Render display math in leqno style (left-justified tags)."
  },
  fleqn: {
    type: "boolean",
    description: "Render display math flush left."
  },
  throwOnError: {
    type: "boolean",
    default: true,
    cli: "-t, --no-throw-on-error",
    cliDescription: "Render errors (in the color given by --error-color) instead of throwing a ParseError exception when encountering an error."
  },
  errorColor: {
    type: "string",
    default: "#cc0000",
    cli: "-c, --error-color <color>",
    cliDescription: "A color string given in the format 'rgb' or 'rrggbb' (no #). This option determines the color of errors rendered by the -t option.",
    cliProcessor: (color) => "#" + color
  },
  macros: {
    type: "object",
    cli: "-m, --macro <def>",
    cliDescription: "Define custom macro of the form '\\foo:expansion' (use multiple -m arguments for multiple macros).",
    cliDefault: [],
    cliProcessor: (def, defs) => {
      defs.push(def);
      return defs;
    }
  },
  minRuleThickness: {
    type: "number",
    description: "Specifies a minimum thickness, in ems, for fraction lines, `\\sqrt` top lines, `{array}` vertical lines, `\\hline`, `\\hdashline`, `\\underline`, `\\overline`, and the borders of `\\fbox`, `\\boxed`, and `\\fcolorbox`.",
    processor: (t2) => Math.max(0, t2),
    cli: "--min-rule-thickness <size>",
    cliProcessor: parseFloat
  },
  colorIsTextColor: {
    type: "boolean",
    description: "Makes \\color behave like LaTeX's 2-argument \\textcolor, instead of LaTeX's one-argument \\color mode change.",
    cli: "-b, --color-is-text-color"
  },
  strict: {
    type: [{
      enum: ["warn", "ignore", "error"]
    }, "boolean", "function"],
    description: "Turn on strict / LaTeX faithfulness mode, which throws an error if the input uses features that are not supported by LaTeX.",
    cli: "-S, --strict",
    cliDefault: false
  },
  trust: {
    type: ["boolean", "function"],
    description: "Trust the input, enabling all HTML features such as \\url.",
    cli: "-T, --trust"
  },
  maxSize: {
    type: "number",
    default: Infinity,
    description: "If non-zero, all user-specified sizes, e.g. in \\rule{500em}{500em}, will be capped to maxSize ems. Otherwise, elements and spaces can be arbitrarily large",
    processor: (s) => Math.max(0, s),
    cli: "-s, --max-size <n>",
    cliProcessor: parseInt
  },
  maxExpand: {
    type: "number",
    default: 1e3,
    description: "Limit the number of macro expansions to the specified number, to prevent e.g. infinite macro loops. If set to Infinity, the macro expander will try to fully expand as in LaTeX.",
    processor: (n) => Math.max(0, n),
    cli: "-e, --max-expand <n>",
    cliProcessor: (n) => n === "Infinity" ? Infinity : parseInt(n)
  },
  globalGroup: {
    type: "boolean",
    cli: false
  }
};
function getDefaultValue(schema) {
  if (schema.default) {
    return schema.default;
  }
  var type = schema.type;
  var defaultType = Array.isArray(type) ? type[0] : type;
  if (typeof defaultType !== "string") {
    return defaultType.enum[0];
  }
  switch (defaultType) {
    case "boolean":
      return false;
    case "string":
      return "";
    case "number":
      return 0;
    case "object":
      return {};
  }
}
class Settings {
  constructor(options) {
    this.displayMode = void 0;
    this.output = void 0;
    this.leqno = void 0;
    this.fleqn = void 0;
    this.throwOnError = void 0;
    this.errorColor = void 0;
    this.macros = void 0;
    this.minRuleThickness = void 0;
    this.colorIsTextColor = void 0;
    this.strict = void 0;
    this.trust = void 0;
    this.maxSize = void 0;
    this.maxExpand = void 0;
    this.globalGroup = void 0;
    options = options || {};
    for (var prop in SETTINGS_SCHEMA) {
      if (SETTINGS_SCHEMA.hasOwnProperty(prop)) {
        var schema = SETTINGS_SCHEMA[prop];
        this[prop] = options[prop] !== void 0 ? schema.processor ? schema.processor(options[prop]) : options[prop] : getDefaultValue(schema);
      }
    }
  }
  /**
   * Report nonstrict (non-LaTeX-compatible) input.
   * Can safely not be called if `this.strict` is false in JavaScript.
   */
  reportNonstrict(errorCode, errorMsg, token) {
    var strict = this.strict;
    if (typeof strict === "function") {
      strict = strict(errorCode, errorMsg, token);
    }
    if (!strict || strict === "ignore") {
      return;
    } else if (strict === true || strict === "error") {
      throw new ParseError("LaTeX-incompatible input and strict mode is set to 'error': " + (errorMsg + " [" + errorCode + "]"), token);
    } else if (strict === "warn") {
      typeof console !== "undefined" && console.warn("LaTeX-incompatible input and strict mode is set to 'warn': " + (errorMsg + " [" + errorCode + "]"));
    } else {
      typeof console !== "undefined" && console.warn("LaTeX-incompatible input and strict mode is set to " + ("unrecognized '" + strict + "': " + errorMsg + " [" + errorCode + "]"));
    }
  }
  /**
   * Check whether to apply strict (LaTeX-adhering) behavior for unusual
   * input (like `\\`).  Unlike `nonstrict`, will not throw an error;
   * instead, "error" translates to a return value of `true`, while "ignore"
   * translates to a return value of `false`.  May still print a warning:
   * "warn" prints a warning and returns `false`.
   * This is for the second category of `errorCode`s listed in the README.
   */
  useStrictBehavior(errorCode, errorMsg, token) {
    var strict = this.strict;
    if (typeof strict === "function") {
      try {
        strict = strict(errorCode, errorMsg, token);
      } catch (error) {
        strict = "error";
      }
    }
    if (!strict || strict === "ignore") {
      return false;
    } else if (strict === true || strict === "error") {
      return true;
    } else if (strict === "warn") {
      typeof console !== "undefined" && console.warn("LaTeX-incompatible input and strict mode is set to 'warn': " + (errorMsg + " [" + errorCode + "]"));
      return false;
    } else {
      typeof console !== "undefined" && console.warn("LaTeX-incompatible input and strict mode is set to " + ("unrecognized '" + strict + "': " + errorMsg + " [" + errorCode + "]"));
      return false;
    }
  }
  /**
   * Check whether to test potentially dangerous input, and return
   * `true` (trusted) or `false` (untrusted).  The sole argument `context`
   * should be an object with `command` field specifying the relevant LaTeX
   * command (as a string starting with `\`), and any other arguments, etc.
   * If `context` has a `url` field, a `protocol` field will automatically
   * get added by this function (changing the specified object).
   */
  isTrusted(context) {
    if (context.url && !context.protocol) {
      var protocol = utils.protocolFromUrl(context.url);
      if (protocol == null) {
        return false;
      }
      context.protocol = protocol;
    }
    var trust = typeof this.trust === "function" ? this.trust(context) : this.trust;
    return Boolean(trust);
  }
}
class Style {
  constructor(id, size, cramped) {
    this.id = void 0;
    this.size = void 0;
    this.cramped = void 0;
    this.id = id;
    this.size = size;
    this.cramped = cramped;
  }
  /**
   * Get the style of a superscript given a base in the current style.
   */
  sup() {
    return styles[sup[this.id]];
  }
  /**
   * Get the style of a subscript given a base in the current style.
   */
  sub() {
    return styles[sub[this.id]];
  }
  /**
   * Get the style of a fraction numerator given the fraction in the current
   * style.
   */
  fracNum() {
    return styles[fracNum[this.id]];
  }
  /**
   * Get the style of a fraction denominator given the fraction in the current
   * style.
   */
  fracDen() {
    return styles[fracDen[this.id]];
  }
  /**
   * Get the cramped version of a style (in particular, cramping a cramped style
   * doesn't change the style).
   */
  cramp() {
    return styles[cramp[this.id]];
  }
  /**
   * Get a text or display version of this style.
   */
  text() {
    return styles[text$1[this.id]];
  }
  /**
   * Return true if this style is tightly spaced (scriptstyle/scriptscriptstyle)
   */
  isTight() {
    return this.size >= 2;
  }
}
var D = 0;
var Dc = 1;
var T = 2;
var Tc = 3;
var S = 4;
var Sc = 5;
var SS = 6;
var SSc = 7;
var styles = [new Style(D, 0, false), new Style(Dc, 0, true), new Style(T, 1, false), new Style(Tc, 1, true), new Style(S, 2, false), new Style(Sc, 2, true), new Style(SS, 3, false), new Style(SSc, 3, true)];
var sup = [S, Sc, S, Sc, SS, SSc, SS, SSc];
var sub = [Sc, Sc, Sc, Sc, SSc, SSc, SSc, SSc];
var fracNum = [T, Tc, S, Sc, SS, SSc, SS, SSc];
var fracDen = [Tc, Tc, Sc, Sc, SSc, SSc, SSc, SSc];
var cramp = [Dc, Dc, Tc, Tc, Sc, Sc, SSc, SSc];
var text$1 = [D, Dc, T, Tc, T, Tc, T, Tc];
var Style$1 = {
  DISPLAY: styles[D],
  TEXT: styles[T],
  SCRIPT: styles[S],
  SCRIPTSCRIPT: styles[SS]
};
var scriptData = [{
  // Latin characters beyond the Latin-1 characters we have metrics for.
  // Needed for Czech, Hungarian and Turkish text, for example.
  name: "latin",
  blocks: [
    [256, 591],
    // Latin Extended-A and Latin Extended-B
    [768, 879]
    // Combining Diacritical marks
  ]
}, {
  // The Cyrillic script used by Russian and related languages.
  // A Cyrillic subset used to be supported as explicitly defined
  // symbols in symbols.js
  name: "cyrillic",
  blocks: [[1024, 1279]]
}, {
  // Armenian
  name: "armenian",
  blocks: [[1328, 1423]]
}, {
  // The Brahmic scripts of South and Southeast Asia
  // Devanagari (0900–097F)
  // Bengali (0980–09FF)
  // Gurmukhi (0A00–0A7F)
  // Gujarati (0A80–0AFF)
  // Oriya (0B00–0B7F)
  // Tamil (0B80–0BFF)
  // Telugu (0C00–0C7F)
  // Kannada (0C80–0CFF)
  // Malayalam (0D00–0D7F)
  // Sinhala (0D80–0DFF)
  // Thai (0E00–0E7F)
  // Lao (0E80–0EFF)
  // Tibetan (0F00–0FFF)
  // Myanmar (1000–109F)
  name: "brahmic",
  blocks: [[2304, 4255]]
}, {
  name: "georgian",
  blocks: [[4256, 4351]]
}, {
  // Chinese and Japanese.
  // The "k" in cjk is for Korean, but we've separated Korean out
  name: "cjk",
  blocks: [
    [12288, 12543],
    // CJK symbols and punctuation, Hiragana, Katakana
    [19968, 40879],
    // CJK ideograms
    [65280, 65376]
    // Fullwidth punctuation
    // TODO: add halfwidth Katakana and Romanji glyphs
  ]
}, {
  // Korean
  name: "hangul",
  blocks: [[44032, 55215]]
}];
function scriptFromCodepoint(codepoint) {
  for (var i = 0; i < scriptData.length; i++) {
    var script = scriptData[i];
    for (var _i = 0; _i < script.blocks.length; _i++) {
      var block = script.blocks[_i];
      if (codepoint >= block[0] && codepoint <= block[1]) {
        return script.name;
      }
    }
  }
  return null;
}
var allBlocks = [];
scriptData.forEach((s) => s.blocks.forEach((b) => allBlocks.push(...b)));
function supportedCodepoint(codepoint) {
  for (var i = 0; i < allBlocks.length; i += 2) {
    if (codepoint >= allBlocks[i] && codepoint <= allBlocks[i + 1]) {
      return true;
    }
  }
  return false;
}
var hLinePad = 80;
var sqrtMain = function sqrtMain2(extraVinculum, hLinePad2) {
  return "M95," + (622 + extraVinculum + hLinePad2) + "\nc-2.7,0,-7.17,-2.7,-13.5,-8c-5.8,-5.3,-9.5,-10,-9.5,-14\nc0,-2,0.3,-3.3,1,-4c1.3,-2.7,23.83,-20.7,67.5,-54\nc44.2,-33.3,65.8,-50.3,66.5,-51c1.3,-1.3,3,-2,5,-2c4.7,0,8.7,3.3,12,10\ns173,378,173,378c0.7,0,35.3,-71,104,-213c68.7,-142,137.5,-285,206.5,-429\nc69,-144,104.5,-217.7,106.5,-221\nl" + extraVinculum / 2.075 + " -" + extraVinculum + "\nc5.3,-9.3,12,-14,20,-14\nH400000v" + (40 + extraVinculum) + "H845.2724\ns-225.272,467,-225.272,467s-235,486,-235,486c-2.7,4.7,-9,7,-19,7\nc-6,0,-10,-1,-12,-3s-194,-422,-194,-422s-65,47,-65,47z\nM" + (834 + extraVinculum) + " " + hLinePad2 + "h400000v" + (40 + extraVinculum) + "h-400000z";
};
var sqrtSize1 = function sqrtSize12(extraVinculum, hLinePad2) {
  return "M263," + (601 + extraVinculum + hLinePad2) + "c0.7,0,18,39.7,52,119\nc34,79.3,68.167,158.7,102.5,238c34.3,79.3,51.8,119.3,52.5,120\nc340,-704.7,510.7,-1060.3,512,-1067\nl" + extraVinculum / 2.084 + " -" + extraVinculum + "\nc4.7,-7.3,11,-11,19,-11\nH40000v" + (40 + extraVinculum) + "H1012.3\ns-271.3,567,-271.3,567c-38.7,80.7,-84,175,-136,283c-52,108,-89.167,185.3,-111.5,232\nc-22.3,46.7,-33.8,70.3,-34.5,71c-4.7,4.7,-12.3,7,-23,7s-12,-1,-12,-1\ns-109,-253,-109,-253c-72.7,-168,-109.3,-252,-110,-252c-10.7,8,-22,16.7,-34,26\nc-22,17.3,-33.3,26,-34,26s-26,-26,-26,-26s76,-59,76,-59s76,-60,76,-60z\nM" + (1001 + extraVinculum) + " " + hLinePad2 + "h400000v" + (40 + extraVinculum) + "h-400000z";
};
var sqrtSize2 = function sqrtSize22(extraVinculum, hLinePad2) {
  return "M983 " + (10 + extraVinculum + hLinePad2) + "\nl" + extraVinculum / 3.13 + " -" + extraVinculum + "\nc4,-6.7,10,-10,18,-10 H400000v" + (40 + extraVinculum) + "\nH1013.1s-83.4,268,-264.1,840c-180.7,572,-277,876.3,-289,913c-4.7,4.7,-12.7,7,-24,7\ns-12,0,-12,0c-1.3,-3.3,-3.7,-11.7,-7,-25c-35.3,-125.3,-106.7,-373.3,-214,-744\nc-10,12,-21,25,-33,39s-32,39,-32,39c-6,-5.3,-15,-14,-27,-26s25,-30,25,-30\nc26.7,-32.7,52,-63,76,-91s52,-60,52,-60s208,722,208,722\nc56,-175.3,126.3,-397.3,211,-666c84.7,-268.7,153.8,-488.2,207.5,-658.5\nc53.7,-170.3,84.5,-266.8,92.5,-289.5z\nM" + (1001 + extraVinculum) + " " + hLinePad2 + "h400000v" + (40 + extraVinculum) + "h-400000z";
};
var sqrtSize3 = function sqrtSize32(extraVinculum, hLinePad2) {
  return "M424," + (2398 + extraVinculum + hLinePad2) + "\nc-1.3,-0.7,-38.5,-172,-111.5,-514c-73,-342,-109.8,-513.3,-110.5,-514\nc0,-2,-10.7,14.3,-32,49c-4.7,7.3,-9.8,15.7,-15.5,25c-5.7,9.3,-9.8,16,-12.5,20\ns-5,7,-5,7c-4,-3.3,-8.3,-7.7,-13,-13s-13,-13,-13,-13s76,-122,76,-122s77,-121,77,-121\ns209,968,209,968c0,-2,84.7,-361.7,254,-1079c169.3,-717.3,254.7,-1077.7,256,-1081\nl" + extraVinculum / 4.223 + " -" + extraVinculum + "c4,-6.7,10,-10,18,-10 H400000\nv" + (40 + extraVinculum) + "H1014.6\ns-87.3,378.7,-272.6,1166c-185.3,787.3,-279.3,1182.3,-282,1185\nc-2,6,-10,9,-24,9\nc-8,0,-12,-0.7,-12,-2z M" + (1001 + extraVinculum) + " " + hLinePad2 + "\nh400000v" + (40 + extraVinculum) + "h-400000z";
};
var sqrtSize4 = function sqrtSize42(extraVinculum, hLinePad2) {
  return "M473," + (2713 + extraVinculum + hLinePad2) + "\nc339.3,-1799.3,509.3,-2700,510,-2702 l" + extraVinculum / 5.298 + " -" + extraVinculum + "\nc3.3,-7.3,9.3,-11,18,-11 H400000v" + (40 + extraVinculum) + "H1017.7\ns-90.5,478,-276.2,1466c-185.7,988,-279.5,1483,-281.5,1485c-2,6,-10,9,-24,9\nc-8,0,-12,-0.7,-12,-2c0,-1.3,-5.3,-32,-16,-92c-50.7,-293.3,-119.7,-693.3,-207,-1200\nc0,-1.3,-5.3,8.7,-16,30c-10.7,21.3,-21.3,42.7,-32,64s-16,33,-16,33s-26,-26,-26,-26\ns76,-153,76,-153s77,-151,77,-151c0.7,0.7,35.7,202,105,604c67.3,400.7,102,602.7,104,\n606zM" + (1001 + extraVinculum) + " " + hLinePad2 + "h400000v" + (40 + extraVinculum) + "H1017.7z";
};
var phasePath = function phasePath2(y) {
  var x = y / 2;
  return "M400000 " + y + " H0 L" + x + " 0 l65 45 L145 " + (y - 80) + " H400000z";
};
var sqrtTall = function sqrtTall2(extraVinculum, hLinePad2, viewBoxHeight) {
  var vertSegment = viewBoxHeight - 54 - hLinePad2 - extraVinculum;
  return "M702 " + (extraVinculum + hLinePad2) + "H400000" + (40 + extraVinculum) + "\nH742v" + vertSegment + "l-4 4-4 4c-.667.7 -2 1.5-4 2.5s-4.167 1.833-6.5 2.5-5.5 1-9.5 1\nh-12l-28-84c-16.667-52-96.667 -294.333-240-727l-212 -643 -85 170\nc-4-3.333-8.333-7.667-13 -13l-13-13l77-155 77-156c66 199.333 139 419.667\n219 661 l218 661zM702 " + hLinePad2 + "H400000v" + (40 + extraVinculum) + "H742z";
};
var sqrtPath = function sqrtPath2(size, extraVinculum, viewBoxHeight) {
  extraVinculum = 1e3 * extraVinculum;
  var path2 = "";
  switch (size) {
    case "sqrtMain":
      path2 = sqrtMain(extraVinculum, hLinePad);
      break;
    case "sqrtSize1":
      path2 = sqrtSize1(extraVinculum, hLinePad);
      break;
    case "sqrtSize2":
      path2 = sqrtSize2(extraVinculum, hLinePad);
      break;
    case "sqrtSize3":
      path2 = sqrtSize3(extraVinculum, hLinePad);
      break;
    case "sqrtSize4":
      path2 = sqrtSize4(extraVinculum, hLinePad);
      break;
    case "sqrtTall":
      path2 = sqrtTall(extraVinculum, hLinePad, viewBoxHeight);
  }
  return path2;
};
var innerPath = function innerPath2(name, height) {
  switch (name) {
    case "⎜":
      return "M291 0 H417 V" + height + " H291z M291 0 H417 V" + height + " H291z";
    case "∣":
      return "M145 0 H188 V" + height + " H145z M145 0 H188 V" + height + " H145z";
    case "∥":
      return "M145 0 H188 V" + height + " H145z M145 0 H188 V" + height + " H145z" + ("M367 0 H410 V" + height + " H367z M367 0 H410 V" + height + " H367z");
    case "⎟":
      return "M457 0 H583 V" + height + " H457z M457 0 H583 V" + height + " H457z";
    case "⎢":
      return "M319 0 H403 V" + height + " H319z M319 0 H403 V" + height + " H319z";
    case "⎥":
      return "M263 0 H347 V" + height + " H263z M263 0 H347 V" + height + " H263z";
    case "⎪":
      return "M384 0 H504 V" + height + " H384z M384 0 H504 V" + height + " H384z";
    case "⏐":
      return "M312 0 H355 V" + height + " H312z M312 0 H355 V" + height + " H312z";
    case "‖":
      return "M257 0 H300 V" + height + " H257z M257 0 H300 V" + height + " H257z" + ("M478 0 H521 V" + height + " H478z M478 0 H521 V" + height + " H478z");
    default:
      return "";
  }
};
var path = {
  // The doubleleftarrow geometry is from glyph U+21D0 in the font KaTeX Main
  doubleleftarrow: "M262 157\nl10-10c34-36 62.7-77 86-123 3.3-8 5-13.3 5-16 0-5.3-6.7-8-20-8-7.3\n 0-12.2.5-14.5 1.5-2.3 1-4.8 4.5-7.5 10.5-49.3 97.3-121.7 169.3-217 216-28\n 14-57.3 25-88 33-6.7 2-11 3.8-13 5.5-2 1.7-3 4.2-3 7.5s1 5.8 3 7.5\nc2 1.7 6.3 3.5 13 5.5 68 17.3 128.2 47.8 180.5 91.5 52.3 43.7 93.8 96.2 124.5\n 157.5 9.3 8 15.3 12.3 18 13h6c12-.7 18-4 18-10 0-2-1.7-7-5-15-23.3-46-52-87\n-86-123l-10-10h399738v-40H218c328 0 0 0 0 0l-10-8c-26.7-20-65.7-43-117-69 2.7\n-2 6-3.7 10-5 36.7-16 72.3-37.3 107-64l10-8h399782v-40z\nm8 0v40h399730v-40zm0 194v40h399730v-40z",
  // doublerightarrow is from glyph U+21D2 in font KaTeX Main
  doublerightarrow: "M399738 392l\n-10 10c-34 36-62.7 77-86 123-3.3 8-5 13.3-5 16 0 5.3 6.7 8 20 8 7.3 0 12.2-.5\n 14.5-1.5 2.3-1 4.8-4.5 7.5-10.5 49.3-97.3 121.7-169.3 217-216 28-14 57.3-25 88\n-33 6.7-2 11-3.8 13-5.5 2-1.7 3-4.2 3-7.5s-1-5.8-3-7.5c-2-1.7-6.3-3.5-13-5.5-68\n-17.3-128.2-47.8-180.5-91.5-52.3-43.7-93.8-96.2-124.5-157.5-9.3-8-15.3-12.3-18\n-13h-6c-12 .7-18 4-18 10 0 2 1.7 7 5 15 23.3 46 52 87 86 123l10 10H0v40h399782\nc-328 0 0 0 0 0l10 8c26.7 20 65.7 43 117 69-2.7 2-6 3.7-10 5-36.7 16-72.3 37.3\n-107 64l-10 8H0v40zM0 157v40h399730v-40zm0 194v40h399730v-40z",
  // leftarrow is from glyph U+2190 in font KaTeX Main
  leftarrow: "M400000 241H110l3-3c68.7-52.7 113.7-120\n 135-202 4-14.7 6-23 6-25 0-7.3-7-11-21-11-8 0-13.2.8-15.5 2.5-2.3 1.7-4.2 5.8\n-5.5 12.5-1.3 4.7-2.7 10.3-4 17-12 48.7-34.8 92-68.5 130S65.3 228.3 18 247\nc-10 4-16 7.7-18 11 0 8.7 6 14.3 18 17 47.3 18.7 87.8 47 121.5 85S196 441.3 208\n 490c.7 2 1.3 5 2 9s1.2 6.7 1.5 8c.3 1.3 1 3.3 2 6s2.2 4.5 3.5 5.5c1.3 1 3.3\n 1.8 6 2.5s6 1 10 1c14 0 21-3.7 21-11 0-2-2-10.3-6-25-20-79.3-65-146.7-135-202\n l-3-3h399890zM100 241v40h399900v-40z",
  // overbrace is from glyphs U+23A9/23A8/23A7 in font KaTeX_Size4-Regular
  leftbrace: "M6 548l-6-6v-35l6-11c56-104 135.3-181.3 238-232 57.3-28.7 117\n-45 179-50h399577v120H403c-43.3 7-81 15-113 26-100.7 33-179.7 91-237 174-2.7\n 5-6 9-10 13-.7 1-7.3 1-20 1H6z",
  leftbraceunder: "M0 6l6-6h17c12.688 0 19.313.3 20 1 4 4 7.313 8.3 10 13\n 35.313 51.3 80.813 93.8 136.5 127.5 55.688 33.7 117.188 55.8 184.5 66.5.688\n 0 2 .3 4 1 18.688 2.7 76 4.3 172 5h399450v120H429l-6-1c-124.688-8-235-61.7\n-331-161C60.687 138.7 32.312 99.3 7 54L0 41V6z",
  // overgroup is from the MnSymbol package (public domain)
  leftgroup: "M400000 80\nH435C64 80 168.3 229.4 21 260c-5.9 1.2-18 0-18 0-2 0-3-1-3-3v-38C76 61 257 0\n 435 0h399565z",
  leftgroupunder: "M400000 262\nH435C64 262 168.3 112.6 21 82c-5.9-1.2-18 0-18 0-2 0-3 1-3 3v38c76 158 257 219\n 435 219h399565z",
  // Harpoons are from glyph U+21BD in font KaTeX Main
  leftharpoon: "M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3\n-3.3 10.2-9.5 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5\n-18.3 3-21-1.3-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7\n-196 228-6.7 4.7-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40z",
  leftharpoonplus: "M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3-3.3 10.2-9.5\n 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5-18.3 3-21-1.3\n-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7-196 228-6.7 4.7\n-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40zM0 435v40h400000v-40z\nm0 0v40h400000v-40z",
  leftharpoondown: "M7 241c-4 4-6.333 8.667-7 14 0 5.333.667 9 2 11s5.333\n 5.333 12 10c90.667 54 156 130 196 228 3.333 10.667 6.333 16.333 9 17 2 .667 5\n 1 9 1h5c10.667 0 16.667-2 18-6 2-2.667 1-9.667-3-21-32-87.333-82.667-157.667\n-152-211l-3-3h399907v-40zM93 281 H400000 v-40L7 241z",
  leftharpoondownplus: "M7 435c-4 4-6.3 8.7-7 14 0 5.3.7 9 2 11s5.3 5.3 12\n 10c90.7 54 156 130 196 228 3.3 10.7 6.3 16.3 9 17 2 .7 5 1 9 1h5c10.7 0 16.7\n-2 18-6 2-2.7 1-9.7-3-21-32-87.3-82.7-157.7-152-211l-3-3h399907v-40H7zm93 0\nv40h399900v-40zM0 241v40h399900v-40zm0 0v40h399900v-40z",
  // hook is from glyph U+21A9 in font KaTeX Main
  lefthook: "M400000 281 H103s-33-11.2-61-33.5S0 197.3 0 164s14.2-61.2 42.5\n-83.5C70.8 58.2 104 47 142 47 c16.7 0 25 6.7 25 20 0 12-8.7 18.7-26 20-40 3.3\n-68.7 15.7-86 37-10 12-15 25.3-15 40 0 22.7 9.8 40.7 29.5 54 19.7 13.3 43.5 21\n 71.5 23h399859zM103 281v-40h399897v40z",
  leftlinesegment: "M40 281 V428 H0 V94 H40 V241 H400000 v40z\nM40 281 V428 H0 V94 H40 V241 H400000 v40z",
  leftmapsto: "M40 281 V448H0V74H40V241H400000v40z\nM40 281 V448H0V74H40V241H400000v40z",
  // tofrom is from glyph U+21C4 in font KaTeX AMS Regular
  leftToFrom: "M0 147h400000v40H0zm0 214c68 40 115.7 95.7 143 167h22c15.3 0 23\n-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69-70-101l-7-8h399905v-40H95l7-8\nc28.7-32 52-65.7 70-101 10.7-23.3 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 265.3\n 68 321 0 361zm0-174v-40h399900v40zm100 154v40h399900v-40z",
  longequal: "M0 50 h400000 v40H0z m0 194h40000v40H0z\nM0 50 h400000 v40H0z m0 194h40000v40H0z",
  midbrace: "M200428 334\nc-100.7-8.3-195.3-44-280-108-55.3-42-101.7-93-139-153l-9-14c-2.7 4-5.7 8.7-9 14\n-53.3 86.7-123.7 153-211 199-66.7 36-137.3 56.3-212 62H0V214h199568c178.3-11.7\n 311.7-78.3 403-201 6-8 9.7-12 11-12 .7-.7 6.7-1 18-1s17.3.3 18 1c1.3 0 5 4 11\n 12 44.7 59.3 101.3 106.3 170 141s145.3 54.3 229 60h199572v120z",
  midbraceunder: "M199572 214\nc100.7 8.3 195.3 44 280 108 55.3 42 101.7 93 139 153l9 14c2.7-4 5.7-8.7 9-14\n 53.3-86.7 123.7-153 211-199 66.7-36 137.3-56.3 212-62h199568v120H200432c-178.3\n 11.7-311.7 78.3-403 201-6 8-9.7 12-11 12-.7.7-6.7 1-18 1s-17.3-.3-18-1c-1.3 0\n-5-4-11-12-44.7-59.3-101.3-106.3-170-141s-145.3-54.3-229-60H0V214z",
  oiintSize1: "M512.6 71.6c272.6 0 320.3 106.8 320.3 178.2 0 70.8-47.7 177.6\n-320.3 177.6S193.1 320.6 193.1 249.8c0-71.4 46.9-178.2 319.5-178.2z\nm368.1 178.2c0-86.4-60.9-215.4-368.1-215.4-306.4 0-367.3 129-367.3 215.4 0 85.8\n60.9 214.8 367.3 214.8 307.2 0 368.1-129 368.1-214.8z",
  oiintSize2: "M757.8 100.1c384.7 0 451.1 137.6 451.1 230 0 91.3-66.4 228.8\n-451.1 228.8-386.3 0-452.7-137.5-452.7-228.8 0-92.4 66.4-230 452.7-230z\nm502.4 230c0-111.2-82.4-277.2-502.4-277.2s-504 166-504 277.2\nc0 110 84 276 504 276s502.4-166 502.4-276z",
  oiiintSize1: "M681.4 71.6c408.9 0 480.5 106.8 480.5 178.2 0 70.8-71.6 177.6\n-480.5 177.6S202.1 320.6 202.1 249.8c0-71.4 70.5-178.2 479.3-178.2z\nm525.8 178.2c0-86.4-86.8-215.4-525.7-215.4-437.9 0-524.7 129-524.7 215.4 0\n85.8 86.8 214.8 524.7 214.8 438.9 0 525.7-129 525.7-214.8z",
  oiiintSize2: "M1021.2 53c603.6 0 707.8 165.8 707.8 277.2 0 110-104.2 275.8\n-707.8 275.8-606 0-710.2-165.8-710.2-275.8C311 218.8 415.2 53 1021.2 53z\nm770.4 277.1c0-131.2-126.4-327.6-770.5-327.6S248.4 198.9 248.4 330.1\nc0 130 128.8 326.4 772.7 326.4s770.5-196.4 770.5-326.4z",
  rightarrow: "M0 241v40h399891c-47.3 35.3-84 78-110 128\n-16.7 32-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20\n 11 8 0 13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7\n 39-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85\n-40.5-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5\n-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67\n 151.7 139 205zm0 0v40h399900v-40z",
  rightbrace: "M400000 542l\n-6 6h-17c-12.7 0-19.3-.3-20-1-4-4-7.3-8.3-10-13-35.3-51.3-80.8-93.8-136.5-127.5\ns-117.2-55.8-184.5-66.5c-.7 0-2-.3-4-1-18.7-2.7-76-4.3-172-5H0V214h399571l6 1\nc124.7 8 235 61.7 331 161 31.3 33.3 59.7 72.7 85 118l7 13v35z",
  rightbraceunder: "M399994 0l6 6v35l-6 11c-56 104-135.3 181.3-238 232-57.3\n 28.7-117 45-179 50H-300V214h399897c43.3-7 81-15 113-26 100.7-33 179.7-91 237\n-174 2.7-5 6-9 10-13 .7-1 7.3-1 20-1h17z",
  rightgroup: "M0 80h399565c371 0 266.7 149.4 414 180 5.9 1.2 18 0 18 0 2 0\n 3-1 3-3v-38c-76-158-257-219-435-219H0z",
  rightgroupunder: "M0 262h399565c371 0 266.7-149.4 414-180 5.9-1.2 18 0 18\n 0 2 0 3 1 3 3v38c-76 158-257 219-435 219H0z",
  rightharpoon: "M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3\n-3.7-15.3-11-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2\n-10.7 0-16.7 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58\n 69.2 92 94.5zm0 0v40h399900v-40z",
  rightharpoonplus: "M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3-3.7-15.3-11\n-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2-10.7 0-16.7\n 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58 69.2 92 94.5z\nm0 0v40h399900v-40z m100 194v40h399900v-40zm0 0v40h399900v-40z",
  rightharpoondown: "M399747 511c0 7.3 6.7 11 20 11 8 0 13-.8 15-2.5s4.7-6.8\n 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3 8.5-5.8 9.5\n-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3-64.7 57-92 95\n-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 241v40h399900v-40z",
  rightharpoondownplus: "M399747 705c0 7.3 6.7 11 20 11 8 0 13-.8\n 15-2.5s4.7-6.8 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3\n 8.5-5.8 9.5-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3\n-64.7 57-92 95-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 435v40h399900v-40z\nm0-194v40h400000v-40zm0 0v40h400000v-40z",
  righthook: "M399859 241c-764 0 0 0 0 0 40-3.3 68.7-15.7 86-37 10-12 15-25.3\n 15-40 0-22.7-9.8-40.7-29.5-54-19.7-13.3-43.5-21-71.5-23-17.3-1.3-26-8-26-20 0\n-13.3 8.7-20 26-20 38 0 71 11.2 99 33.5 0 0 7 5.6 21 16.7 14 11.2 21 33.5 21\n 66.8s-14 61.2-42 83.5c-28 22.3-61 33.5-99 33.5L0 241z M0 281v-40h399859v40z",
  rightlinesegment: "M399960 241 V94 h40 V428 h-40 V281 H0 v-40z\nM399960 241 V94 h40 V428 h-40 V281 H0 v-40z",
  rightToFrom: "M400000 167c-70.7-42-118-97.7-142-167h-23c-15.3 0-23 .3-23\n 1 0 1.3 5.3 13.7 16 37 18 35.3 41.3 69 70 101l7 8H0v40h399905l-7 8c-28.7 32\n-52 65.7-70 101-10.7 23.3-16 35.7-16 37 0 .7 7.7 1 23 1h23c24-69.3 71.3-125 142\n-167z M100 147v40h399900v-40zM0 341v40h399900v-40z",
  // twoheadleftarrow is from glyph U+219E in font KaTeX AMS Regular
  twoheadleftarrow: "M0 167c68 40\n 115.7 95.7 143 167h22c15.3 0 23-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69\n-70-101l-7-8h125l9 7c50.7 39.3 85 86 103 140h46c0-4.7-6.3-18.7-19-42-18-35.3\n-40-67.3-66-96l-9-9h399716v-40H284l9-9c26-28.7 48-60.7 66-96 12.7-23.333 19\n-37.333 19-42h-46c-18 54-52.3 100.7-103 140l-9 7H95l7-8c28.7-32 52-65.7 70-101\n 10.7-23.333 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 71.3 68 127 0 167z",
  twoheadrightarrow: "M400000 167\nc-68-40-115.7-95.7-143-167h-22c-15.3 0-23 .3-23 1 0 1.3 5.3 13.7 16 37 18 35.3\n 41.3 69 70 101l7 8h-125l-9-7c-50.7-39.3-85-86-103-140h-46c0 4.7 6.3 18.7 19 42\n 18 35.3 40 67.3 66 96l9 9H0v40h399716l-9 9c-26 28.7-48 60.7-66 96-12.7 23.333\n-19 37.333-19 42h46c18-54 52.3-100.7 103-140l9-7h125l-7 8c-28.7 32-52 65.7-70\n 101-10.7 23.333-16 35.7-16 37 0 .7 7.7 1 23 1h22c27.3-71.3 75-127 143-167z",
  // tilde1 is a modified version of a glyph from the MnSymbol package
  tilde1: "M200 55.538c-77 0-168 73.953-177 73.953-3 0-7\n-2.175-9-5.437L2 97c-1-2-2-4-2-6 0-4 2-7 5-9l20-12C116 12 171 0 207 0c86 0\n 114 68 191 68 78 0 168-68 177-68 4 0 7 2 9 5l12 19c1 2.175 2 4.35 2 6.525 0\n 4.35-2 7.613-5 9.788l-19 13.05c-92 63.077-116.937 75.308-183 76.128\n-68.267.847-113-73.952-191-73.952z",
  // ditto tilde2, tilde3, & tilde4
  tilde2: "M344 55.266c-142 0-300.638 81.316-311.5 86.418\n-8.01 3.762-22.5 10.91-23.5 5.562L1 120c-1-2-1-3-1-4 0-5 3-9 8-10l18.4-9C160.9\n 31.9 283 0 358 0c148 0 188 122 331 122s314-97 326-97c4 0 8 2 10 7l7 21.114\nc1 2.14 1 3.21 1 4.28 0 5.347-3 9.626-7 10.696l-22.3 12.622C852.6 158.372 751\n 181.476 676 181.476c-149 0-189-126.21-332-126.21z",
  tilde3: "M786 59C457 59 32 175.242 13 175.242c-6 0-10-3.457\n-11-10.37L.15 138c-1-7 3-12 10-13l19.2-6.4C378.4 40.7 634.3 0 804.3 0c337 0\n 411.8 157 746.8 157 328 0 754-112 773-112 5 0 10 3 11 9l1 14.075c1 8.066-.697\n 16.595-6.697 17.492l-21.052 7.31c-367.9 98.146-609.15 122.696-778.15 122.696\n -338 0-409-156.573-744-156.573z",
  tilde4: "M786 58C457 58 32 177.487 13 177.487c-6 0-10-3.345\n-11-10.035L.15 143c-1-7 3-12 10-13l22-6.7C381.2 35 637.15 0 807.15 0c337 0 409\n 177 744 177 328 0 754-127 773-127 5 0 10 3 11 9l1 14.794c1 7.805-3 13.38-9\n 14.495l-20.7 5.574c-366.85 99.79-607.3 139.372-776.3 139.372-338 0-409\n -175.236-744-175.236z",
  // vec is from glyph U+20D7 in font KaTeX Main
  vec: "M377 20c0-5.333 1.833-10 5.5-14S391 0 397 0c4.667 0 8.667 1.667 12 5\n3.333 2.667 6.667 9 10 19 6.667 24.667 20.333 43.667 41 57 7.333 4.667 11\n10.667 11 18 0 6-1 10-3 12s-6.667 5-14 9c-28.667 14.667-53.667 35.667-75 63\n-1.333 1.333-3.167 3.5-5.5 6.5s-4 4.833-5 5.5c-1 .667-2.5 1.333-4.5 2s-4.333 1\n-7 1c-4.667 0-9.167-1.833-13.5-5.5S337 184 337 178c0-12.667 15.667-32.333 47-59\nH213l-171-1c-8.667-6-13-12.333-13-19 0-4.667 4.333-11.333 13-20h359\nc-16-25.333-24-45-24-59z",
  // widehat1 is a modified version of a glyph from the MnSymbol package
  widehat1: "M529 0h5l519 115c5 1 9 5 9 10 0 1-1 2-1 3l-4 22\nc-1 5-5 9-11 9h-2L532 67 19 159h-2c-5 0-9-4-11-9l-5-22c-1-6 2-12 8-13z",
  // ditto widehat2, widehat3, & widehat4
  widehat2: "M1181 0h2l1171 176c6 0 10 5 10 11l-2 23c-1 6-5 10\n-11 10h-1L1182 67 15 220h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z",
  widehat3: "M1181 0h2l1171 236c6 0 10 5 10 11l-2 23c-1 6-5 10\n-11 10h-1L1182 67 15 280h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z",
  widehat4: "M1181 0h2l1171 296c6 0 10 5 10 11l-2 23c-1 6-5 10\n-11 10h-1L1182 67 15 340h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z",
  // widecheck paths are all inverted versions of widehat
  widecheck1: "M529,159h5l519,-115c5,-1,9,-5,9,-10c0,-1,-1,-2,-1,-3l-4,-22c-1,\n-5,-5,-9,-11,-9h-2l-512,92l-513,-92h-2c-5,0,-9,4,-11,9l-5,22c-1,6,2,12,8,13z",
  widecheck2: "M1181,220h2l1171,-176c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,\n-11,-10h-1l-1168,153l-1167,-153h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z",
  widecheck3: "M1181,280h2l1171,-236c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,\n-11,-10h-1l-1168,213l-1167,-213h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z",
  widecheck4: "M1181,340h2l1171,-296c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,\n-11,-10h-1l-1168,273l-1167,-273h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z",
  // The next ten paths support reaction arrows from the mhchem package.
  // Arrows for \ce{<-->} are offset from xAxis by 0.22ex, per mhchem in LaTeX
  // baraboveleftarrow is mostly from glyph U+2190 in font KaTeX Main
  baraboveleftarrow: "M400000 620h-399890l3 -3c68.7 -52.7 113.7 -120 135 -202\nc4 -14.7 6 -23 6 -25c0 -7.3 -7 -11 -21 -11c-8 0 -13.2 0.8 -15.5 2.5\nc-2.3 1.7 -4.2 5.8 -5.5 12.5c-1.3 4.7 -2.7 10.3 -4 17c-12 48.7 -34.8 92 -68.5 130\ns-74.2 66.3 -121.5 85c-10 4 -16 7.7 -18 11c0 8.7 6 14.3 18 17c47.3 18.7 87.8 47\n121.5 85s56.5 81.3 68.5 130c0.7 2 1.3 5 2 9s1.2 6.7 1.5 8c0.3 1.3 1 3.3 2 6\ns2.2 4.5 3.5 5.5c1.3 1 3.3 1.8 6 2.5s6 1 10 1c14 0 21 -3.7 21 -11\nc0 -2 -2 -10.3 -6 -25c-20 -79.3 -65 -146.7 -135 -202l-3 -3h399890z\nM100 620v40h399900v-40z M0 241v40h399900v-40zM0 241v40h399900v-40z",
  // rightarrowabovebar is mostly from glyph U+2192, KaTeX Main
  rightarrowabovebar: "M0 241v40h399891c-47.3 35.3-84 78-110 128-16.7 32\n-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20 11 8 0\n13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7 39\n-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85-40.5\n-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5\n-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67\n151.7 139 205zm96 379h399894v40H0zm0 0h399904v40H0z",
  // The short left harpoon has 0.5em (i.e. 500 units) kern on the left end.
  // Ref from mhchem.sty: \rlap{\raisebox{-.22ex}{$\kern0.5em
  baraboveshortleftharpoon: "M507,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11\nc1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17\nc2,0.7,5,1,9,1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21\nc-32,-87.3,-82.7,-157.7,-152,-211c0,0,-3,-3,-3,-3l399351,0l0,-40\nc-398570,0,-399437,0,-399437,0z M593 435 v40 H399500 v-40z\nM0 281 v-40 H399908 v40z M0 281 v-40 H399908 v40z",
  rightharpoonaboveshortbar: "M0,241 l0,40c399126,0,399993,0,399993,0\nc4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,\n-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6\nc-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z\nM0 241 v40 H399908 v-40z M0 475 v-40 H399500 v40z M0 475 v-40 H399500 v40z",
  shortbaraboveleftharpoon: "M7,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11\nc1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17c2,0.7,5,1,9,\n1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21c-32,-87.3,-82.7,-157.7,\n-152,-211c0,0,-3,-3,-3,-3l399907,0l0,-40c-399126,0,-399993,0,-399993,0z\nM93 435 v40 H400000 v-40z M500 241 v40 H400000 v-40z M500 241 v40 H400000 v-40z",
  shortrightharpoonabovebar: "M53,241l0,40c398570,0,399437,0,399437,0\nc4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,\n-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6\nc-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z\nM500 241 v40 H399408 v-40z M500 435 v40 H400000 v-40z"
};
var tallDelim = function tallDelim2(label, midHeight) {
  switch (label) {
    case "lbrack":
      return "M403 1759 V84 H666 V0 H319 V1759 v" + midHeight + " v1759 h347 v-84\nH403z M403 1759 V0 H319 V1759 v" + midHeight + " v1759 h84z";
    case "rbrack":
      return "M347 1759 V0 H0 V84 H263 V1759 v" + midHeight + " v1759 H0 v84 H347z\nM347 1759 V0 H263 V1759 v" + midHeight + " v1759 h84z";
    case "vert":
      return "M145 15 v585 v" + midHeight + " v585 c2.667,10,9.667,15,21,15\nc10,0,16.667,-5,20,-15 v-585 v" + -midHeight + " v-585 c-2.667,-10,-9.667,-15,-21,-15\nc-10,0,-16.667,5,-20,15z M188 15 H145 v585 v" + midHeight + " v585 h43z";
    case "doublevert":
      return "M145 15 v585 v" + midHeight + " v585 c2.667,10,9.667,15,21,15\nc10,0,16.667,-5,20,-15 v-585 v" + -midHeight + " v-585 c-2.667,-10,-9.667,-15,-21,-15\nc-10,0,-16.667,5,-20,15z M188 15 H145 v585 v" + midHeight + " v585 h43z\nM367 15 v585 v" + midHeight + " v585 c2.667,10,9.667,15,21,15\nc10,0,16.667,-5,20,-15 v-585 v" + -midHeight + " v-585 c-2.667,-10,-9.667,-15,-21,-15\nc-10,0,-16.667,5,-20,15z M410 15 H367 v585 v" + midHeight + " v585 h43z";
    case "lfloor":
      return "M319 602 V0 H403 V602 v" + midHeight + " v1715 h263 v84 H319z\nMM319 602 V0 H403 V602 v" + midHeight + " v1715 H319z";
    case "rfloor":
      return "M319 602 V0 H403 V602 v" + midHeight + " v1799 H0 v-84 H319z\nMM319 602 V0 H403 V602 v" + midHeight + " v1715 H319z";
    case "lceil":
      return "M403 1759 V84 H666 V0 H319 V1759 v" + midHeight + " v602 h84z\nM403 1759 V0 H319 V1759 v" + midHeight + " v602 h84z";
    case "rceil":
      return "M347 1759 V0 H0 V84 H263 V1759 v" + midHeight + " v602 h84z\nM347 1759 V0 h-84 V1759 v" + midHeight + " v602 h84z";
    case "lparen":
      return "M863,9c0,-2,-2,-5,-6,-9c0,0,-17,0,-17,0c-12.7,0,-19.3,0.3,-20,1\nc-5.3,5.3,-10.3,11,-15,17c-242.7,294.7,-395.3,682,-458,1162c-21.3,163.3,-33.3,349,\n-36,557 l0," + (midHeight + 84) + "c0.2,6,0,26,0,60c2,159.3,10,310.7,24,454c53.3,528,210,\n949.7,470,1265c4.7,6,9.7,11.7,15,17c0.7,0.7,7,1,19,1c0,0,18,0,18,0c4,-4,6,-7,6,-9\nc0,-2.7,-3.3,-8.7,-10,-18c-135.3,-192.7,-235.5,-414.3,-300.5,-665c-65,-250.7,-102.5,\n-544.7,-112.5,-882c-2,-104,-3,-167,-3,-189\nl0,-" + (midHeight + 92) + "c0,-162.7,5.7,-314,17,-454c20.7,-272,63.7,-513,129,-723c65.3,\n-210,155.3,-396.3,270,-559c6.7,-9.3,10,-15.3,10,-18z";
    case "rparen":
      return "M76,0c-16.7,0,-25,3,-25,9c0,2,2,6.3,6,13c21.3,28.7,42.3,60.3,\n63,95c96.7,156.7,172.8,332.5,228.5,527.5c55.7,195,92.8,416.5,111.5,664.5\nc11.3,139.3,17,290.7,17,454c0,28,1.7,43,3.3,45l0," + (midHeight + 9) + "\nc-3,4,-3.3,16.7,-3.3,38c0,162,-5.7,313.7,-17,455c-18.7,248,-55.8,469.3,-111.5,664\nc-55.7,194.7,-131.8,370.3,-228.5,527c-20.7,34.7,-41.7,66.3,-63,95c-2,3.3,-4,7,-6,11\nc0,7.3,5.7,11,17,11c0,0,11,0,11,0c9.3,0,14.3,-0.3,15,-1c5.3,-5.3,10.3,-11,15,-17\nc242.7,-294.7,395.3,-681.7,458,-1161c21.3,-164.7,33.3,-350.7,36,-558\nl0,-" + (midHeight + 144) + "c-2,-159.3,-10,-310.7,-24,-454c-53.3,-528,-210,-949.7,\n-470,-1265c-4.7,-6,-9.7,-11.7,-15,-17c-0.7,-0.7,-6.7,-1,-18,-1z";
    default:
      throw new Error("Unknown stretchy delimiter.");
  }
};
class DocumentFragment {
  // Never used; needed for satisfying interface.
  constructor(children) {
    this.children = void 0;
    this.classes = void 0;
    this.height = void 0;
    this.depth = void 0;
    this.maxFontSize = void 0;
    this.style = void 0;
    this.children = children;
    this.classes = [];
    this.height = 0;
    this.depth = 0;
    this.maxFontSize = 0;
    this.style = {};
  }
  hasClass(className) {
    return this.classes.includes(className);
  }
  /** Convert the fragment into a node. */
  toNode() {
    var frag = document.createDocumentFragment();
    for (var i = 0; i < this.children.length; i++) {
      frag.appendChild(this.children[i].toNode());
    }
    return frag;
  }
  /** Convert the fragment into HTML markup. */
  toMarkup() {
    var markup = "";
    for (var i = 0; i < this.children.length; i++) {
      markup += this.children[i].toMarkup();
    }
    return markup;
  }
  /**
   * Converts the math node into a string, similar to innerText. Applies to
   * MathDomNode's only.
   */
  toText() {
    var toText = (child) => child.toText();
    return this.children.map(toText).join("");
  }
}
var fontMetricsData = {
  "AMS-Regular": {
    "32": [0, 0, 0, 0, 0.25],
    "65": [0, 0.68889, 0, 0, 0.72222],
    "66": [0, 0.68889, 0, 0, 0.66667],
    "67": [0, 0.68889, 0, 0, 0.72222],
    "68": [0, 0.68889, 0, 0, 0.72222],
    "69": [0, 0.68889, 0, 0, 0.66667],
    "70": [0, 0.68889, 0, 0, 0.61111],
    "71": [0, 0.68889, 0, 0, 0.77778],
    "72": [0, 0.68889, 0, 0, 0.77778],
    "73": [0, 0.68889, 0, 0, 0.38889],
    "74": [0.16667, 0.68889, 0, 0, 0.5],
    "75": [0, 0.68889, 0, 0, 0.77778],
    "76": [0, 0.68889, 0, 0, 0.66667],
    "77": [0, 0.68889, 0, 0, 0.94445],
    "78": [0, 0.68889, 0, 0, 0.72222],
    "79": [0.16667, 0.68889, 0, 0, 0.77778],
    "80": [0, 0.68889, 0, 0, 0.61111],
    "81": [0.16667, 0.68889, 0, 0, 0.77778],
    "82": [0, 0.68889, 0, 0, 0.72222],
    "83": [0, 0.68889, 0, 0, 0.55556],
    "84": [0, 0.68889, 0, 0, 0.66667],
    "85": [0, 0.68889, 0, 0, 0.72222],
    "86": [0, 0.68889, 0, 0, 0.72222],
    "87": [0, 0.68889, 0, 0, 1],
    "88": [0, 0.68889, 0, 0, 0.72222],
    "89": [0, 0.68889, 0, 0, 0.72222],
    "90": [0, 0.68889, 0, 0, 0.66667],
    "107": [0, 0.68889, 0, 0, 0.55556],
    "160": [0, 0, 0, 0, 0.25],
    "165": [0, 0.675, 0.025, 0, 0.75],
    "174": [0.15559, 0.69224, 0, 0, 0.94666],
    "240": [0, 0.68889, 0, 0, 0.55556],
    "295": [0, 0.68889, 0, 0, 0.54028],
    "710": [0, 0.825, 0, 0, 2.33334],
    "732": [0, 0.9, 0, 0, 2.33334],
    "770": [0, 0.825, 0, 0, 2.33334],
    "771": [0, 0.9, 0, 0, 2.33334],
    "989": [0.08167, 0.58167, 0, 0, 0.77778],
    "1008": [0, 0.43056, 0.04028, 0, 0.66667],
    "8245": [0, 0.54986, 0, 0, 0.275],
    "8463": [0, 0.68889, 0, 0, 0.54028],
    "8487": [0, 0.68889, 0, 0, 0.72222],
    "8498": [0, 0.68889, 0, 0, 0.55556],
    "8502": [0, 0.68889, 0, 0, 0.66667],
    "8503": [0, 0.68889, 0, 0, 0.44445],
    "8504": [0, 0.68889, 0, 0, 0.66667],
    "8513": [0, 0.68889, 0, 0, 0.63889],
    "8592": [-0.03598, 0.46402, 0, 0, 0.5],
    "8594": [-0.03598, 0.46402, 0, 0, 0.5],
    "8602": [-0.13313, 0.36687, 0, 0, 1],
    "8603": [-0.13313, 0.36687, 0, 0, 1],
    "8606": [0.01354, 0.52239, 0, 0, 1],
    "8608": [0.01354, 0.52239, 0, 0, 1],
    "8610": [0.01354, 0.52239, 0, 0, 1.11111],
    "8611": [0.01354, 0.52239, 0, 0, 1.11111],
    "8619": [0, 0.54986, 0, 0, 1],
    "8620": [0, 0.54986, 0, 0, 1],
    "8621": [-0.13313, 0.37788, 0, 0, 1.38889],
    "8622": [-0.13313, 0.36687, 0, 0, 1],
    "8624": [0, 0.69224, 0, 0, 0.5],
    "8625": [0, 0.69224, 0, 0, 0.5],
    "8630": [0, 0.43056, 0, 0, 1],
    "8631": [0, 0.43056, 0, 0, 1],
    "8634": [0.08198, 0.58198, 0, 0, 0.77778],
    "8635": [0.08198, 0.58198, 0, 0, 0.77778],
    "8638": [0.19444, 0.69224, 0, 0, 0.41667],
    "8639": [0.19444, 0.69224, 0, 0, 0.41667],
    "8642": [0.19444, 0.69224, 0, 0, 0.41667],
    "8643": [0.19444, 0.69224, 0, 0, 0.41667],
    "8644": [0.1808, 0.675, 0, 0, 1],
    "8646": [0.1808, 0.675, 0, 0, 1],
    "8647": [0.1808, 0.675, 0, 0, 1],
    "8648": [0.19444, 0.69224, 0, 0, 0.83334],
    "8649": [0.1808, 0.675, 0, 0, 1],
    "8650": [0.19444, 0.69224, 0, 0, 0.83334],
    "8651": [0.01354, 0.52239, 0, 0, 1],
    "8652": [0.01354, 0.52239, 0, 0, 1],
    "8653": [-0.13313, 0.36687, 0, 0, 1],
    "8654": [-0.13313, 0.36687, 0, 0, 1],
    "8655": [-0.13313, 0.36687, 0, 0, 1],
    "8666": [0.13667, 0.63667, 0, 0, 1],
    "8667": [0.13667, 0.63667, 0, 0, 1],
    "8669": [-0.13313, 0.37788, 0, 0, 1],
    "8672": [-0.064, 0.437, 0, 0, 1.334],
    "8674": [-0.064, 0.437, 0, 0, 1.334],
    "8705": [0, 0.825, 0, 0, 0.5],
    "8708": [0, 0.68889, 0, 0, 0.55556],
    "8709": [0.08167, 0.58167, 0, 0, 0.77778],
    "8717": [0, 0.43056, 0, 0, 0.42917],
    "8722": [-0.03598, 0.46402, 0, 0, 0.5],
    "8724": [0.08198, 0.69224, 0, 0, 0.77778],
    "8726": [0.08167, 0.58167, 0, 0, 0.77778],
    "8733": [0, 0.69224, 0, 0, 0.77778],
    "8736": [0, 0.69224, 0, 0, 0.72222],
    "8737": [0, 0.69224, 0, 0, 0.72222],
    "8738": [0.03517, 0.52239, 0, 0, 0.72222],
    "8739": [0.08167, 0.58167, 0, 0, 0.22222],
    "8740": [0.25142, 0.74111, 0, 0, 0.27778],
    "8741": [0.08167, 0.58167, 0, 0, 0.38889],
    "8742": [0.25142, 0.74111, 0, 0, 0.5],
    "8756": [0, 0.69224, 0, 0, 0.66667],
    "8757": [0, 0.69224, 0, 0, 0.66667],
    "8764": [-0.13313, 0.36687, 0, 0, 0.77778],
    "8765": [-0.13313, 0.37788, 0, 0, 0.77778],
    "8769": [-0.13313, 0.36687, 0, 0, 0.77778],
    "8770": [-0.03625, 0.46375, 0, 0, 0.77778],
    "8774": [0.30274, 0.79383, 0, 0, 0.77778],
    "8776": [-0.01688, 0.48312, 0, 0, 0.77778],
    "8778": [0.08167, 0.58167, 0, 0, 0.77778],
    "8782": [0.06062, 0.54986, 0, 0, 0.77778],
    "8783": [0.06062, 0.54986, 0, 0, 0.77778],
    "8785": [0.08198, 0.58198, 0, 0, 0.77778],
    "8786": [0.08198, 0.58198, 0, 0, 0.77778],
    "8787": [0.08198, 0.58198, 0, 0, 0.77778],
    "8790": [0, 0.69224, 0, 0, 0.77778],
    "8791": [0.22958, 0.72958, 0, 0, 0.77778],
    "8796": [0.08198, 0.91667, 0, 0, 0.77778],
    "8806": [0.25583, 0.75583, 0, 0, 0.77778],
    "8807": [0.25583, 0.75583, 0, 0, 0.77778],
    "8808": [0.25142, 0.75726, 0, 0, 0.77778],
    "8809": [0.25142, 0.75726, 0, 0, 0.77778],
    "8812": [0.25583, 0.75583, 0, 0, 0.5],
    "8814": [0.20576, 0.70576, 0, 0, 0.77778],
    "8815": [0.20576, 0.70576, 0, 0, 0.77778],
    "8816": [0.30274, 0.79383, 0, 0, 0.77778],
    "8817": [0.30274, 0.79383, 0, 0, 0.77778],
    "8818": [0.22958, 0.72958, 0, 0, 0.77778],
    "8819": [0.22958, 0.72958, 0, 0, 0.77778],
    "8822": [0.1808, 0.675, 0, 0, 0.77778],
    "8823": [0.1808, 0.675, 0, 0, 0.77778],
    "8828": [0.13667, 0.63667, 0, 0, 0.77778],
    "8829": [0.13667, 0.63667, 0, 0, 0.77778],
    "8830": [0.22958, 0.72958, 0, 0, 0.77778],
    "8831": [0.22958, 0.72958, 0, 0, 0.77778],
    "8832": [0.20576, 0.70576, 0, 0, 0.77778],
    "8833": [0.20576, 0.70576, 0, 0, 0.77778],
    "8840": [0.30274, 0.79383, 0, 0, 0.77778],
    "8841": [0.30274, 0.79383, 0, 0, 0.77778],
    "8842": [0.13597, 0.63597, 0, 0, 0.77778],
    "8843": [0.13597, 0.63597, 0, 0, 0.77778],
    "8847": [0.03517, 0.54986, 0, 0, 0.77778],
    "8848": [0.03517, 0.54986, 0, 0, 0.77778],
    "8858": [0.08198, 0.58198, 0, 0, 0.77778],
    "8859": [0.08198, 0.58198, 0, 0, 0.77778],
    "8861": [0.08198, 0.58198, 0, 0, 0.77778],
    "8862": [0, 0.675, 0, 0, 0.77778],
    "8863": [0, 0.675, 0, 0, 0.77778],
    "8864": [0, 0.675, 0, 0, 0.77778],
    "8865": [0, 0.675, 0, 0, 0.77778],
    "8872": [0, 0.69224, 0, 0, 0.61111],
    "8873": [0, 0.69224, 0, 0, 0.72222],
    "8874": [0, 0.69224, 0, 0, 0.88889],
    "8876": [0, 0.68889, 0, 0, 0.61111],
    "8877": [0, 0.68889, 0, 0, 0.61111],
    "8878": [0, 0.68889, 0, 0, 0.72222],
    "8879": [0, 0.68889, 0, 0, 0.72222],
    "8882": [0.03517, 0.54986, 0, 0, 0.77778],
    "8883": [0.03517, 0.54986, 0, 0, 0.77778],
    "8884": [0.13667, 0.63667, 0, 0, 0.77778],
    "8885": [0.13667, 0.63667, 0, 0, 0.77778],
    "8888": [0, 0.54986, 0, 0, 1.11111],
    "8890": [0.19444, 0.43056, 0, 0, 0.55556],
    "8891": [0.19444, 0.69224, 0, 0, 0.61111],
    "8892": [0.19444, 0.69224, 0, 0, 0.61111],
    "8901": [0, 0.54986, 0, 0, 0.27778],
    "8903": [0.08167, 0.58167, 0, 0, 0.77778],
    "8905": [0.08167, 0.58167, 0, 0, 0.77778],
    "8906": [0.08167, 0.58167, 0, 0, 0.77778],
    "8907": [0, 0.69224, 0, 0, 0.77778],
    "8908": [0, 0.69224, 0, 0, 0.77778],
    "8909": [-0.03598, 0.46402, 0, 0, 0.77778],
    "8910": [0, 0.54986, 0, 0, 0.76042],
    "8911": [0, 0.54986, 0, 0, 0.76042],
    "8912": [0.03517, 0.54986, 0, 0, 0.77778],
    "8913": [0.03517, 0.54986, 0, 0, 0.77778],
    "8914": [0, 0.54986, 0, 0, 0.66667],
    "8915": [0, 0.54986, 0, 0, 0.66667],
    "8916": [0, 0.69224, 0, 0, 0.66667],
    "8918": [0.0391, 0.5391, 0, 0, 0.77778],
    "8919": [0.0391, 0.5391, 0, 0, 0.77778],
    "8920": [0.03517, 0.54986, 0, 0, 1.33334],
    "8921": [0.03517, 0.54986, 0, 0, 1.33334],
    "8922": [0.38569, 0.88569, 0, 0, 0.77778],
    "8923": [0.38569, 0.88569, 0, 0, 0.77778],
    "8926": [0.13667, 0.63667, 0, 0, 0.77778],
    "8927": [0.13667, 0.63667, 0, 0, 0.77778],
    "8928": [0.30274, 0.79383, 0, 0, 0.77778],
    "8929": [0.30274, 0.79383, 0, 0, 0.77778],
    "8934": [0.23222, 0.74111, 0, 0, 0.77778],
    "8935": [0.23222, 0.74111, 0, 0, 0.77778],
    "8936": [0.23222, 0.74111, 0, 0, 0.77778],
    "8937": [0.23222, 0.74111, 0, 0, 0.77778],
    "8938": [0.20576, 0.70576, 0, 0, 0.77778],
    "8939": [0.20576, 0.70576, 0, 0, 0.77778],
    "8940": [0.30274, 0.79383, 0, 0, 0.77778],
    "8941": [0.30274, 0.79383, 0, 0, 0.77778],
    "8994": [0.19444, 0.69224, 0, 0, 0.77778],
    "8995": [0.19444, 0.69224, 0, 0, 0.77778],
    "9416": [0.15559, 0.69224, 0, 0, 0.90222],
    "9484": [0, 0.69224, 0, 0, 0.5],
    "9488": [0, 0.69224, 0, 0, 0.5],
    "9492": [0, 0.37788, 0, 0, 0.5],
    "9496": [0, 0.37788, 0, 0, 0.5],
    "9585": [0.19444, 0.68889, 0, 0, 0.88889],
    "9586": [0.19444, 0.74111, 0, 0, 0.88889],
    "9632": [0, 0.675, 0, 0, 0.77778],
    "9633": [0, 0.675, 0, 0, 0.77778],
    "9650": [0, 0.54986, 0, 0, 0.72222],
    "9651": [0, 0.54986, 0, 0, 0.72222],
    "9654": [0.03517, 0.54986, 0, 0, 0.77778],
    "9660": [0, 0.54986, 0, 0, 0.72222],
    "9661": [0, 0.54986, 0, 0, 0.72222],
    "9664": [0.03517, 0.54986, 0, 0, 0.77778],
    "9674": [0.11111, 0.69224, 0, 0, 0.66667],
    "9733": [0.19444, 0.69224, 0, 0, 0.94445],
    "10003": [0, 0.69224, 0, 0, 0.83334],
    "10016": [0, 0.69224, 0, 0, 0.83334],
    "10731": [0.11111, 0.69224, 0, 0, 0.66667],
    "10846": [0.19444, 0.75583, 0, 0, 0.61111],
    "10877": [0.13667, 0.63667, 0, 0, 0.77778],
    "10878": [0.13667, 0.63667, 0, 0, 0.77778],
    "10885": [0.25583, 0.75583, 0, 0, 0.77778],
    "10886": [0.25583, 0.75583, 0, 0, 0.77778],
    "10887": [0.13597, 0.63597, 0, 0, 0.77778],
    "10888": [0.13597, 0.63597, 0, 0, 0.77778],
    "10889": [0.26167, 0.75726, 0, 0, 0.77778],
    "10890": [0.26167, 0.75726, 0, 0, 0.77778],
    "10891": [0.48256, 0.98256, 0, 0, 0.77778],
    "10892": [0.48256, 0.98256, 0, 0, 0.77778],
    "10901": [0.13667, 0.63667, 0, 0, 0.77778],
    "10902": [0.13667, 0.63667, 0, 0, 0.77778],
    "10933": [0.25142, 0.75726, 0, 0, 0.77778],
    "10934": [0.25142, 0.75726, 0, 0, 0.77778],
    "10935": [0.26167, 0.75726, 0, 0, 0.77778],
    "10936": [0.26167, 0.75726, 0, 0, 0.77778],
    "10937": [0.26167, 0.75726, 0, 0, 0.77778],
    "10938": [0.26167, 0.75726, 0, 0, 0.77778],
    "10949": [0.25583, 0.75583, 0, 0, 0.77778],
    "10950": [0.25583, 0.75583, 0, 0, 0.77778],
    "10955": [0.28481, 0.79383, 0, 0, 0.77778],
    "10956": [0.28481, 0.79383, 0, 0, 0.77778],
    "57350": [0.08167, 0.58167, 0, 0, 0.22222],
    "57351": [0.08167, 0.58167, 0, 0, 0.38889],
    "57352": [0.08167, 0.58167, 0, 0, 0.77778],
    "57353": [0, 0.43056, 0.04028, 0, 0.66667],
    "57356": [0.25142, 0.75726, 0, 0, 0.77778],
    "57357": [0.25142, 0.75726, 0, 0, 0.77778],
    "57358": [0.41951, 0.91951, 0, 0, 0.77778],
    "57359": [0.30274, 0.79383, 0, 0, 0.77778],
    "57360": [0.30274, 0.79383, 0, 0, 0.77778],
    "57361": [0.41951, 0.91951, 0, 0, 0.77778],
    "57366": [0.25142, 0.75726, 0, 0, 0.77778],
    "57367": [0.25142, 0.75726, 0, 0, 0.77778],
    "57368": [0.25142, 0.75726, 0, 0, 0.77778],
    "57369": [0.25142, 0.75726, 0, 0, 0.77778],
    "57370": [0.13597, 0.63597, 0, 0, 0.77778],
    "57371": [0.13597, 0.63597, 0, 0, 0.77778]
  },
  "Caligraphic-Regular": {
    "32": [0, 0, 0, 0, 0.25],
    "65": [0, 0.68333, 0, 0.19445, 0.79847],
    "66": [0, 0.68333, 0.03041, 0.13889, 0.65681],
    "67": [0, 0.68333, 0.05834, 0.13889, 0.52653],
    "68": [0, 0.68333, 0.02778, 0.08334, 0.77139],
    "69": [0, 0.68333, 0.08944, 0.11111, 0.52778],
    "70": [0, 0.68333, 0.09931, 0.11111, 0.71875],
    "71": [0.09722, 0.68333, 0.0593, 0.11111, 0.59487],
    "72": [0, 0.68333, 965e-5, 0.11111, 0.84452],
    "73": [0, 0.68333, 0.07382, 0, 0.54452],
    "74": [0.09722, 0.68333, 0.18472, 0.16667, 0.67778],
    "75": [0, 0.68333, 0.01445, 0.05556, 0.76195],
    "76": [0, 0.68333, 0, 0.13889, 0.68972],
    "77": [0, 0.68333, 0, 0.13889, 1.2009],
    "78": [0, 0.68333, 0.14736, 0.08334, 0.82049],
    "79": [0, 0.68333, 0.02778, 0.11111, 0.79611],
    "80": [0, 0.68333, 0.08222, 0.08334, 0.69556],
    "81": [0.09722, 0.68333, 0, 0.11111, 0.81667],
    "82": [0, 0.68333, 0, 0.08334, 0.8475],
    "83": [0, 0.68333, 0.075, 0.13889, 0.60556],
    "84": [0, 0.68333, 0.25417, 0, 0.54464],
    "85": [0, 0.68333, 0.09931, 0.08334, 0.62583],
    "86": [0, 0.68333, 0.08222, 0, 0.61278],
    "87": [0, 0.68333, 0.08222, 0.08334, 0.98778],
    "88": [0, 0.68333, 0.14643, 0.13889, 0.7133],
    "89": [0.09722, 0.68333, 0.08222, 0.08334, 0.66834],
    "90": [0, 0.68333, 0.07944, 0.13889, 0.72473],
    "160": [0, 0, 0, 0, 0.25]
  },
  "Fraktur-Regular": {
    "32": [0, 0, 0, 0, 0.25],
    "33": [0, 0.69141, 0, 0, 0.29574],
    "34": [0, 0.69141, 0, 0, 0.21471],
    "38": [0, 0.69141, 0, 0, 0.73786],
    "39": [0, 0.69141, 0, 0, 0.21201],
    "40": [0.24982, 0.74947, 0, 0, 0.38865],
    "41": [0.24982, 0.74947, 0, 0, 0.38865],
    "42": [0, 0.62119, 0, 0, 0.27764],
    "43": [0.08319, 0.58283, 0, 0, 0.75623],
    "44": [0, 0.10803, 0, 0, 0.27764],
    "45": [0.08319, 0.58283, 0, 0, 0.75623],
    "46": [0, 0.10803, 0, 0, 0.27764],
    "47": [0.24982, 0.74947, 0, 0, 0.50181],
    "48": [0, 0.47534, 0, 0, 0.50181],
    "49": [0, 0.47534, 0, 0, 0.50181],
    "50": [0, 0.47534, 0, 0, 0.50181],
    "51": [0.18906, 0.47534, 0, 0, 0.50181],
    "52": [0.18906, 0.47534, 0, 0, 0.50181],
    "53": [0.18906, 0.47534, 0, 0, 0.50181],
    "54": [0, 0.69141, 0, 0, 0.50181],
    "55": [0.18906, 0.47534, 0, 0, 0.50181],
    "56": [0, 0.69141, 0, 0, 0.50181],
    "57": [0.18906, 0.47534, 0, 0, 0.50181],
    "58": [0, 0.47534, 0, 0, 0.21606],
    "59": [0.12604, 0.47534, 0, 0, 0.21606],
    "61": [-0.13099, 0.36866, 0, 0, 0.75623],
    "63": [0, 0.69141, 0, 0, 0.36245],
    "65": [0, 0.69141, 0, 0, 0.7176],
    "66": [0, 0.69141, 0, 0, 0.88397],
    "67": [0, 0.69141, 0, 0, 0.61254],
    "68": [0, 0.69141, 0, 0, 0.83158],
    "69": [0, 0.69141, 0, 0, 0.66278],
    "70": [0.12604, 0.69141, 0, 0, 0.61119],
    "71": [0, 0.69141, 0, 0, 0.78539],
    "72": [0.06302, 0.69141, 0, 0, 0.7203],
    "73": [0, 0.69141, 0, 0, 0.55448],
    "74": [0.12604, 0.69141, 0, 0, 0.55231],
    "75": [0, 0.69141, 0, 0, 0.66845],
    "76": [0, 0.69141, 0, 0, 0.66602],
    "77": [0, 0.69141, 0, 0, 1.04953],
    "78": [0, 0.69141, 0, 0, 0.83212],
    "79": [0, 0.69141, 0, 0, 0.82699],
    "80": [0.18906, 0.69141, 0, 0, 0.82753],
    "81": [0.03781, 0.69141, 0, 0, 0.82699],
    "82": [0, 0.69141, 0, 0, 0.82807],
    "83": [0, 0.69141, 0, 0, 0.82861],
    "84": [0, 0.69141, 0, 0, 0.66899],
    "85": [0, 0.69141, 0, 0, 0.64576],
    "86": [0, 0.69141, 0, 0, 0.83131],
    "87": [0, 0.69141, 0, 0, 1.04602],
    "88": [0, 0.69141, 0, 0, 0.71922],
    "89": [0.18906, 0.69141, 0, 0, 0.83293],
    "90": [0.12604, 0.69141, 0, 0, 0.60201],
    "91": [0.24982, 0.74947, 0, 0, 0.27764],
    "93": [0.24982, 0.74947, 0, 0, 0.27764],
    "94": [0, 0.69141, 0, 0, 0.49965],
    "97": [0, 0.47534, 0, 0, 0.50046],
    "98": [0, 0.69141, 0, 0, 0.51315],
    "99": [0, 0.47534, 0, 0, 0.38946],
    "100": [0, 0.62119, 0, 0, 0.49857],
    "101": [0, 0.47534, 0, 0, 0.40053],
    "102": [0.18906, 0.69141, 0, 0, 0.32626],
    "103": [0.18906, 0.47534, 0, 0, 0.5037],
    "104": [0.18906, 0.69141, 0, 0, 0.52126],
    "105": [0, 0.69141, 0, 0, 0.27899],
    "106": [0, 0.69141, 0, 0, 0.28088],
    "107": [0, 0.69141, 0, 0, 0.38946],
    "108": [0, 0.69141, 0, 0, 0.27953],
    "109": [0, 0.47534, 0, 0, 0.76676],
    "110": [0, 0.47534, 0, 0, 0.52666],
    "111": [0, 0.47534, 0, 0, 0.48885],
    "112": [0.18906, 0.52396, 0, 0, 0.50046],
    "113": [0.18906, 0.47534, 0, 0, 0.48912],
    "114": [0, 0.47534, 0, 0, 0.38919],
    "115": [0, 0.47534, 0, 0, 0.44266],
    "116": [0, 0.62119, 0, 0, 0.33301],
    "117": [0, 0.47534, 0, 0, 0.5172],
    "118": [0, 0.52396, 0, 0, 0.5118],
    "119": [0, 0.52396, 0, 0, 0.77351],
    "120": [0.18906, 0.47534, 0, 0, 0.38865],
    "121": [0.18906, 0.47534, 0, 0, 0.49884],
    "122": [0.18906, 0.47534, 0, 0, 0.39054],
    "160": [0, 0, 0, 0, 0.25],
    "8216": [0, 0.69141, 0, 0, 0.21471],
    "8217": [0, 0.69141, 0, 0, 0.21471],
    "58112": [0, 0.62119, 0, 0, 0.49749],
    "58113": [0, 0.62119, 0, 0, 0.4983],
    "58114": [0.18906, 0.69141, 0, 0, 0.33328],
    "58115": [0.18906, 0.69141, 0, 0, 0.32923],
    "58116": [0.18906, 0.47534, 0, 0, 0.50343],
    "58117": [0, 0.69141, 0, 0, 0.33301],
    "58118": [0, 0.62119, 0, 0, 0.33409],
    "58119": [0, 0.47534, 0, 0, 0.50073]
  },
  "Main-Bold": {
    "32": [0, 0, 0, 0, 0.25],
    "33": [0, 0.69444, 0, 0, 0.35],
    "34": [0, 0.69444, 0, 0, 0.60278],
    "35": [0.19444, 0.69444, 0, 0, 0.95833],
    "36": [0.05556, 0.75, 0, 0, 0.575],
    "37": [0.05556, 0.75, 0, 0, 0.95833],
    "38": [0, 0.69444, 0, 0, 0.89444],
    "39": [0, 0.69444, 0, 0, 0.31944],
    "40": [0.25, 0.75, 0, 0, 0.44722],
    "41": [0.25, 0.75, 0, 0, 0.44722],
    "42": [0, 0.75, 0, 0, 0.575],
    "43": [0.13333, 0.63333, 0, 0, 0.89444],
    "44": [0.19444, 0.15556, 0, 0, 0.31944],
    "45": [0, 0.44444, 0, 0, 0.38333],
    "46": [0, 0.15556, 0, 0, 0.31944],
    "47": [0.25, 0.75, 0, 0, 0.575],
    "48": [0, 0.64444, 0, 0, 0.575],
    "49": [0, 0.64444, 0, 0, 0.575],
    "50": [0, 0.64444, 0, 0, 0.575],
    "51": [0, 0.64444, 0, 0, 0.575],
    "52": [0, 0.64444, 0, 0, 0.575],
    "53": [0, 0.64444, 0, 0, 0.575],
    "54": [0, 0.64444, 0, 0, 0.575],
    "55": [0, 0.64444, 0, 0, 0.575],
    "56": [0, 0.64444, 0, 0, 0.575],
    "57": [0, 0.64444, 0, 0, 0.575],
    "58": [0, 0.44444, 0, 0, 0.31944],
    "59": [0.19444, 0.44444, 0, 0, 0.31944],
    "60": [0.08556, 0.58556, 0, 0, 0.89444],
    "61": [-0.10889, 0.39111, 0, 0, 0.89444],
    "62": [0.08556, 0.58556, 0, 0, 0.89444],
    "63": [0, 0.69444, 0, 0, 0.54305],
    "64": [0, 0.69444, 0, 0, 0.89444],
    "65": [0, 0.68611, 0, 0, 0.86944],
    "66": [0, 0.68611, 0, 0, 0.81805],
    "67": [0, 0.68611, 0, 0, 0.83055],
    "68": [0, 0.68611, 0, 0, 0.88194],
    "69": [0, 0.68611, 0, 0, 0.75555],
    "70": [0, 0.68611, 0, 0, 0.72361],
    "71": [0, 0.68611, 0, 0, 0.90416],
    "72": [0, 0.68611, 0, 0, 0.9],
    "73": [0, 0.68611, 0, 0, 0.43611],
    "74": [0, 0.68611, 0, 0, 0.59444],
    "75": [0, 0.68611, 0, 0, 0.90138],
    "76": [0, 0.68611, 0, 0, 0.69166],
    "77": [0, 0.68611, 0, 0, 1.09166],
    "78": [0, 0.68611, 0, 0, 0.9],
    "79": [0, 0.68611, 0, 0, 0.86388],
    "80": [0, 0.68611, 0, 0, 0.78611],
    "81": [0.19444, 0.68611, 0, 0, 0.86388],
    "82": [0, 0.68611, 0, 0, 0.8625],
    "83": [0, 0.68611, 0, 0, 0.63889],
    "84": [0, 0.68611, 0, 0, 0.8],
    "85": [0, 0.68611, 0, 0, 0.88472],
    "86": [0, 0.68611, 0.01597, 0, 0.86944],
    "87": [0, 0.68611, 0.01597, 0, 1.18888],
    "88": [0, 0.68611, 0, 0, 0.86944],
    "89": [0, 0.68611, 0.02875, 0, 0.86944],
    "90": [0, 0.68611, 0, 0, 0.70277],
    "91": [0.25, 0.75, 0, 0, 0.31944],
    "92": [0.25, 0.75, 0, 0, 0.575],
    "93": [0.25, 0.75, 0, 0, 0.31944],
    "94": [0, 0.69444, 0, 0, 0.575],
    "95": [0.31, 0.13444, 0.03194, 0, 0.575],
    "97": [0, 0.44444, 0, 0, 0.55902],
    "98": [0, 0.69444, 0, 0, 0.63889],
    "99": [0, 0.44444, 0, 0, 0.51111],
    "100": [0, 0.69444, 0, 0, 0.63889],
    "101": [0, 0.44444, 0, 0, 0.52708],
    "102": [0, 0.69444, 0.10903, 0, 0.35139],
    "103": [0.19444, 0.44444, 0.01597, 0, 0.575],
    "104": [0, 0.69444, 0, 0, 0.63889],
    "105": [0, 0.69444, 0, 0, 0.31944],
    "106": [0.19444, 0.69444, 0, 0, 0.35139],
    "107": [0, 0.69444, 0, 0, 0.60694],
    "108": [0, 0.69444, 0, 0, 0.31944],
    "109": [0, 0.44444, 0, 0, 0.95833],
    "110": [0, 0.44444, 0, 0, 0.63889],
    "111": [0, 0.44444, 0, 0, 0.575],
    "112": [0.19444, 0.44444, 0, 0, 0.63889],
    "113": [0.19444, 0.44444, 0, 0, 0.60694],
    "114": [0, 0.44444, 0, 0, 0.47361],
    "115": [0, 0.44444, 0, 0, 0.45361],
    "116": [0, 0.63492, 0, 0, 0.44722],
    "117": [0, 0.44444, 0, 0, 0.63889],
    "118": [0, 0.44444, 0.01597, 0, 0.60694],
    "119": [0, 0.44444, 0.01597, 0, 0.83055],
    "120": [0, 0.44444, 0, 0, 0.60694],
    "121": [0.19444, 0.44444, 0.01597, 0, 0.60694],
    "122": [0, 0.44444, 0, 0, 0.51111],
    "123": [0.25, 0.75, 0, 0, 0.575],
    "124": [0.25, 0.75, 0, 0, 0.31944],
    "125": [0.25, 0.75, 0, 0, 0.575],
    "126": [0.35, 0.34444, 0, 0, 0.575],
    "160": [0, 0, 0, 0, 0.25],
    "163": [0, 0.69444, 0, 0, 0.86853],
    "168": [0, 0.69444, 0, 0, 0.575],
    "172": [0, 0.44444, 0, 0, 0.76666],
    "176": [0, 0.69444, 0, 0, 0.86944],
    "177": [0.13333, 0.63333, 0, 0, 0.89444],
    "184": [0.17014, 0, 0, 0, 0.51111],
    "198": [0, 0.68611, 0, 0, 1.04166],
    "215": [0.13333, 0.63333, 0, 0, 0.89444],
    "216": [0.04861, 0.73472, 0, 0, 0.89444],
    "223": [0, 0.69444, 0, 0, 0.59722],
    "230": [0, 0.44444, 0, 0, 0.83055],
    "247": [0.13333, 0.63333, 0, 0, 0.89444],
    "248": [0.09722, 0.54167, 0, 0, 0.575],
    "305": [0, 0.44444, 0, 0, 0.31944],
    "338": [0, 0.68611, 0, 0, 1.16944],
    "339": [0, 0.44444, 0, 0, 0.89444],
    "567": [0.19444, 0.44444, 0, 0, 0.35139],
    "710": [0, 0.69444, 0, 0, 0.575],
    "711": [0, 0.63194, 0, 0, 0.575],
    "713": [0, 0.59611, 0, 0, 0.575],
    "714": [0, 0.69444, 0, 0, 0.575],
    "715": [0, 0.69444, 0, 0, 0.575],
    "728": [0, 0.69444, 0, 0, 0.575],
    "729": [0, 0.69444, 0, 0, 0.31944],
    "730": [0, 0.69444, 0, 0, 0.86944],
    "732": [0, 0.69444, 0, 0, 0.575],
    "733": [0, 0.69444, 0, 0, 0.575],
    "915": [0, 0.68611, 0, 0, 0.69166],
    "916": [0, 0.68611, 0, 0, 0.95833],
    "920": [0, 0.68611, 0, 0, 0.89444],
    "923": [0, 0.68611, 0, 0, 0.80555],
    "926": [0, 0.68611, 0, 0, 0.76666],
    "928": [0, 0.68611, 0, 0, 0.9],
    "931": [0, 0.68611, 0, 0, 0.83055],
    "933": [0, 0.68611, 0, 0, 0.89444],
    "934": [0, 0.68611, 0, 0, 0.83055],
    "936": [0, 0.68611, 0, 0, 0.89444],
    "937": [0, 0.68611, 0, 0, 0.83055],
    "8211": [0, 0.44444, 0.03194, 0, 0.575],
    "8212": [0, 0.44444, 0.03194, 0, 1.14999],
    "8216": [0, 0.69444, 0, 0, 0.31944],
    "8217": [0, 0.69444, 0, 0, 0.31944],
    "8220": [0, 0.69444, 0, 0, 0.60278],
    "8221": [0, 0.69444, 0, 0, 0.60278],
    "8224": [0.19444, 0.69444, 0, 0, 0.51111],
    "8225": [0.19444, 0.69444, 0, 0, 0.51111],
    "8242": [0, 0.55556, 0, 0, 0.34444],
    "8407": [0, 0.72444, 0.15486, 0, 0.575],
    "8463": [0, 0.69444, 0, 0, 0.66759],
    "8465": [0, 0.69444, 0, 0, 0.83055],
    "8467": [0, 0.69444, 0, 0, 0.47361],
    "8472": [0.19444, 0.44444, 0, 0, 0.74027],
    "8476": [0, 0.69444, 0, 0, 0.83055],
    "8501": [0, 0.69444, 0, 0, 0.70277],
    "8592": [-0.10889, 0.39111, 0, 0, 1.14999],
    "8593": [0.19444, 0.69444, 0, 0, 0.575],
    "8594": [-0.10889, 0.39111, 0, 0, 1.14999],
    "8595": [0.19444, 0.69444, 0, 0, 0.575],
    "8596": [-0.10889, 0.39111, 0, 0, 1.14999],
    "8597": [0.25, 0.75, 0, 0, 0.575],
    "8598": [0.19444, 0.69444, 0, 0, 1.14999],
    "8599": [0.19444, 0.69444, 0, 0, 1.14999],
    "8600": [0.19444, 0.69444, 0, 0, 1.14999],
    "8601": [0.19444, 0.69444, 0, 0, 1.14999],
    "8636": [-0.10889, 0.39111, 0, 0, 1.14999],
    "8637": [-0.10889, 0.39111, 0, 0, 1.14999],
    "8640": [-0.10889, 0.39111, 0, 0, 1.14999],
    "8641": [-0.10889, 0.39111, 0, 0, 1.14999],
    "8656": [-0.10889, 0.39111, 0, 0, 1.14999],
    "8657": [0.19444, 0.69444, 0, 0, 0.70277],
    "8658": [-0.10889, 0.39111, 0, 0, 1.14999],
    "8659": [0.19444, 0.69444, 0, 0, 0.70277],
    "8660": [-0.10889, 0.39111, 0, 0, 1.14999],
    "8661": [0.25, 0.75, 0, 0, 0.70277],
    "8704": [0, 0.69444, 0, 0, 0.63889],
    "8706": [0, 0.69444, 0.06389, 0, 0.62847],
    "8707": [0, 0.69444, 0, 0, 0.63889],
    "8709": [0.05556, 0.75, 0, 0, 0.575],
    "8711": [0, 0.68611, 0, 0, 0.95833],
    "8712": [0.08556, 0.58556, 0, 0, 0.76666],
    "8715": [0.08556, 0.58556, 0, 0, 0.76666],
    "8722": [0.13333, 0.63333, 0, 0, 0.89444],
    "8723": [0.13333, 0.63333, 0, 0, 0.89444],
    "8725": [0.25, 0.75, 0, 0, 0.575],
    "8726": [0.25, 0.75, 0, 0, 0.575],
    "8727": [-0.02778, 0.47222, 0, 0, 0.575],
    "8728": [-0.02639, 0.47361, 0, 0, 0.575],
    "8729": [-0.02639, 0.47361, 0, 0, 0.575],
    "8730": [0.18, 0.82, 0, 0, 0.95833],
    "8733": [0, 0.44444, 0, 0, 0.89444],
    "8734": [0, 0.44444, 0, 0, 1.14999],
    "8736": [0, 0.69224, 0, 0, 0.72222],
    "8739": [0.25, 0.75, 0, 0, 0.31944],
    "8741": [0.25, 0.75, 0, 0, 0.575],
    "8743": [0, 0.55556, 0, 0, 0.76666],
    "8744": [0, 0.55556, 0, 0, 0.76666],
    "8745": [0, 0.55556, 0, 0, 0.76666],
    "8746": [0, 0.55556, 0, 0, 0.76666],
    "8747": [0.19444, 0.69444, 0.12778, 0, 0.56875],
    "8764": [-0.10889, 0.39111, 0, 0, 0.89444],
    "8768": [0.19444, 0.69444, 0, 0, 0.31944],
    "8771": [222e-5, 0.50222, 0, 0, 0.89444],
    "8773": [0.027, 0.638, 0, 0, 0.894],
    "8776": [0.02444, 0.52444, 0, 0, 0.89444],
    "8781": [222e-5, 0.50222, 0, 0, 0.89444],
    "8801": [222e-5, 0.50222, 0, 0, 0.89444],
    "8804": [0.19667, 0.69667, 0, 0, 0.89444],
    "8805": [0.19667, 0.69667, 0, 0, 0.89444],
    "8810": [0.08556, 0.58556, 0, 0, 1.14999],
    "8811": [0.08556, 0.58556, 0, 0, 1.14999],
    "8826": [0.08556, 0.58556, 0, 0, 0.89444],
    "8827": [0.08556, 0.58556, 0, 0, 0.89444],
    "8834": [0.08556, 0.58556, 0, 0, 0.89444],
    "8835": [0.08556, 0.58556, 0, 0, 0.89444],
    "8838": [0.19667, 0.69667, 0, 0, 0.89444],
    "8839": [0.19667, 0.69667, 0, 0, 0.89444],
    "8846": [0, 0.55556, 0, 0, 0.76666],
    "8849": [0.19667, 0.69667, 0, 0, 0.89444],
    "8850": [0.19667, 0.69667, 0, 0, 0.89444],
    "8851": [0, 0.55556, 0, 0, 0.76666],
    "8852": [0, 0.55556, 0, 0, 0.76666],
    "8853": [0.13333, 0.63333, 0, 0, 0.89444],
    "8854": [0.13333, 0.63333, 0, 0, 0.89444],
    "8855": [0.13333, 0.63333, 0, 0, 0.89444],
    "8856": [0.13333, 0.63333, 0, 0, 0.89444],
    "8857": [0.13333, 0.63333, 0, 0, 0.89444],
    "8866": [0, 0.69444, 0, 0, 0.70277],
    "8867": [0, 0.69444, 0, 0, 0.70277],
    "8868": [0, 0.69444, 0, 0, 0.89444],
    "8869": [0, 0.69444, 0, 0, 0.89444],
    "8900": [-0.02639, 0.47361, 0, 0, 0.575],
    "8901": [-0.02639, 0.47361, 0, 0, 0.31944],
    "8902": [-0.02778, 0.47222, 0, 0, 0.575],
    "8968": [0.25, 0.75, 0, 0, 0.51111],
    "8969": [0.25, 0.75, 0, 0, 0.51111],
    "8970": [0.25, 0.75, 0, 0, 0.51111],
    "8971": [0.25, 0.75, 0, 0, 0.51111],
    "8994": [-0.13889, 0.36111, 0, 0, 1.14999],
    "8995": [-0.13889, 0.36111, 0, 0, 1.14999],
    "9651": [0.19444, 0.69444, 0, 0, 1.02222],
    "9657": [-0.02778, 0.47222, 0, 0, 0.575],
    "9661": [0.19444, 0.69444, 0, 0, 1.02222],
    "9667": [-0.02778, 0.47222, 0, 0, 0.575],
    "9711": [0.19444, 0.69444, 0, 0, 1.14999],
    "9824": [0.12963, 0.69444, 0, 0, 0.89444],
    "9825": [0.12963, 0.69444, 0, 0, 0.89444],
    "9826": [0.12963, 0.69444, 0, 0, 0.89444],
    "9827": [0.12963, 0.69444, 0, 0, 0.89444],
    "9837": [0, 0.75, 0, 0, 0.44722],
    "9838": [0.19444, 0.69444, 0, 0, 0.44722],
    "9839": [0.19444, 0.69444, 0, 0, 0.44722],
    "10216": [0.25, 0.75, 0, 0, 0.44722],
    "10217": [0.25, 0.75, 0, 0, 0.44722],
    "10815": [0, 0.68611, 0, 0, 0.9],
    "10927": [0.19667, 0.69667, 0, 0, 0.89444],
    "10928": [0.19667, 0.69667, 0, 0, 0.89444],
    "57376": [0.19444, 0.69444, 0, 0, 0]
  },
  "Main-BoldItalic": {
    "32": [0, 0, 0, 0, 0.25],
    "33": [0, 0.69444, 0.11417, 0, 0.38611],
    "34": [0, 0.69444, 0.07939, 0, 0.62055],
    "35": [0.19444, 0.69444, 0.06833, 0, 0.94444],
    "37": [0.05556, 0.75, 0.12861, 0, 0.94444],
    "38": [0, 0.69444, 0.08528, 0, 0.88555],
    "39": [0, 0.69444, 0.12945, 0, 0.35555],
    "40": [0.25, 0.75, 0.15806, 0, 0.47333],
    "41": [0.25, 0.75, 0.03306, 0, 0.47333],
    "42": [0, 0.75, 0.14333, 0, 0.59111],
    "43": [0.10333, 0.60333, 0.03306, 0, 0.88555],
    "44": [0.19444, 0.14722, 0, 0, 0.35555],
    "45": [0, 0.44444, 0.02611, 0, 0.41444],
    "46": [0, 0.14722, 0, 0, 0.35555],
    "47": [0.25, 0.75, 0.15806, 0, 0.59111],
    "48": [0, 0.64444, 0.13167, 0, 0.59111],
    "49": [0, 0.64444, 0.13167, 0, 0.59111],
    "50": [0, 0.64444, 0.13167, 0, 0.59111],
    "51": [0, 0.64444, 0.13167, 0, 0.59111],
    "52": [0.19444, 0.64444, 0.13167, 0, 0.59111],
    "53": [0, 0.64444, 0.13167, 0, 0.59111],
    "54": [0, 0.64444, 0.13167, 0, 0.59111],
    "55": [0.19444, 0.64444, 0.13167, 0, 0.59111],
    "56": [0, 0.64444, 0.13167, 0, 0.59111],
    "57": [0, 0.64444, 0.13167, 0, 0.59111],
    "58": [0, 0.44444, 0.06695, 0, 0.35555],
    "59": [0.19444, 0.44444, 0.06695, 0, 0.35555],
    "61": [-0.10889, 0.39111, 0.06833, 0, 0.88555],
    "63": [0, 0.69444, 0.11472, 0, 0.59111],
    "64": [0, 0.69444, 0.09208, 0, 0.88555],
    "65": [0, 0.68611, 0, 0, 0.86555],
    "66": [0, 0.68611, 0.0992, 0, 0.81666],
    "67": [0, 0.68611, 0.14208, 0, 0.82666],
    "68": [0, 0.68611, 0.09062, 0, 0.87555],
    "69": [0, 0.68611, 0.11431, 0, 0.75666],
    "70": [0, 0.68611, 0.12903, 0, 0.72722],
    "71": [0, 0.68611, 0.07347, 0, 0.89527],
    "72": [0, 0.68611, 0.17208, 0, 0.8961],
    "73": [0, 0.68611, 0.15681, 0, 0.47166],
    "74": [0, 0.68611, 0.145, 0, 0.61055],
    "75": [0, 0.68611, 0.14208, 0, 0.89499],
    "76": [0, 0.68611, 0, 0, 0.69777],
    "77": [0, 0.68611, 0.17208, 0, 1.07277],
    "78": [0, 0.68611, 0.17208, 0, 0.8961],
    "79": [0, 0.68611, 0.09062, 0, 0.85499],
    "80": [0, 0.68611, 0.0992, 0, 0.78721],
    "81": [0.19444, 0.68611, 0.09062, 0, 0.85499],
    "82": [0, 0.68611, 0.02559, 0, 0.85944],
    "83": [0, 0.68611, 0.11264, 0, 0.64999],
    "84": [0, 0.68611, 0.12903, 0, 0.7961],
    "85": [0, 0.68611, 0.17208, 0, 0.88083],
    "86": [0, 0.68611, 0.18625, 0, 0.86555],
    "87": [0, 0.68611, 0.18625, 0, 1.15999],
    "88": [0, 0.68611, 0.15681, 0, 0.86555],
    "89": [0, 0.68611, 0.19803, 0, 0.86555],
    "90": [0, 0.68611, 0.14208, 0, 0.70888],
    "91": [0.25, 0.75, 0.1875, 0, 0.35611],
    "93": [0.25, 0.75, 0.09972, 0, 0.35611],
    "94": [0, 0.69444, 0.06709, 0, 0.59111],
    "95": [0.31, 0.13444, 0.09811, 0, 0.59111],
    "97": [0, 0.44444, 0.09426, 0, 0.59111],
    "98": [0, 0.69444, 0.07861, 0, 0.53222],
    "99": [0, 0.44444, 0.05222, 0, 0.53222],
    "100": [0, 0.69444, 0.10861, 0, 0.59111],
    "101": [0, 0.44444, 0.085, 0, 0.53222],
    "102": [0.19444, 0.69444, 0.21778, 0, 0.4],
    "103": [0.19444, 0.44444, 0.105, 0, 0.53222],
    "104": [0, 0.69444, 0.09426, 0, 0.59111],
    "105": [0, 0.69326, 0.11387, 0, 0.35555],
    "106": [0.19444, 0.69326, 0.1672, 0, 0.35555],
    "107": [0, 0.69444, 0.11111, 0, 0.53222],
    "108": [0, 0.69444, 0.10861, 0, 0.29666],
    "109": [0, 0.44444, 0.09426, 0, 0.94444],
    "110": [0, 0.44444, 0.09426, 0, 0.64999],
    "111": [0, 0.44444, 0.07861, 0, 0.59111],
    "112": [0.19444, 0.44444, 0.07861, 0, 0.59111],
    "113": [0.19444, 0.44444, 0.105, 0, 0.53222],
    "114": [0, 0.44444, 0.11111, 0, 0.50167],
    "115": [0, 0.44444, 0.08167, 0, 0.48694],
    "116": [0, 0.63492, 0.09639, 0, 0.385],
    "117": [0, 0.44444, 0.09426, 0, 0.62055],
    "118": [0, 0.44444, 0.11111, 0, 0.53222],
    "119": [0, 0.44444, 0.11111, 0, 0.76777],
    "120": [0, 0.44444, 0.12583, 0, 0.56055],
    "121": [0.19444, 0.44444, 0.105, 0, 0.56166],
    "122": [0, 0.44444, 0.13889, 0, 0.49055],
    "126": [0.35, 0.34444, 0.11472, 0, 0.59111],
    "160": [0, 0, 0, 0, 0.25],
    "168": [0, 0.69444, 0.11473, 0, 0.59111],
    "176": [0, 0.69444, 0, 0, 0.94888],
    "184": [0.17014, 0, 0, 0, 0.53222],
    "198": [0, 0.68611, 0.11431, 0, 1.02277],
    "216": [0.04861, 0.73472, 0.09062, 0, 0.88555],
    "223": [0.19444, 0.69444, 0.09736, 0, 0.665],
    "230": [0, 0.44444, 0.085, 0, 0.82666],
    "248": [0.09722, 0.54167, 0.09458, 0, 0.59111],
    "305": [0, 0.44444, 0.09426, 0, 0.35555],
    "338": [0, 0.68611, 0.11431, 0, 1.14054],
    "339": [0, 0.44444, 0.085, 0, 0.82666],
    "567": [0.19444, 0.44444, 0.04611, 0, 0.385],
    "710": [0, 0.69444, 0.06709, 0, 0.59111],
    "711": [0, 0.63194, 0.08271, 0, 0.59111],
    "713": [0, 0.59444, 0.10444, 0, 0.59111],
    "714": [0, 0.69444, 0.08528, 0, 0.59111],
    "715": [0, 0.69444, 0, 0, 0.59111],
    "728": [0, 0.69444, 0.10333, 0, 0.59111],
    "729": [0, 0.69444, 0.12945, 0, 0.35555],
    "730": [0, 0.69444, 0, 0, 0.94888],
    "732": [0, 0.69444, 0.11472, 0, 0.59111],
    "733": [0, 0.69444, 0.11472, 0, 0.59111],
    "915": [0, 0.68611, 0.12903, 0, 0.69777],
    "916": [0, 0.68611, 0, 0, 0.94444],
    "920": [0, 0.68611, 0.09062, 0, 0.88555],
    "923": [0, 0.68611, 0, 0, 0.80666],
    "926": [0, 0.68611, 0.15092, 0, 0.76777],
    "928": [0, 0.68611, 0.17208, 0, 0.8961],
    "931": [0, 0.68611, 0.11431, 0, 0.82666],
    "933": [0, 0.68611, 0.10778, 0, 0.88555],
    "934": [0, 0.68611, 0.05632, 0, 0.82666],
    "936": [0, 0.68611, 0.10778, 0, 0.88555],
    "937": [0, 0.68611, 0.0992, 0, 0.82666],
    "8211": [0, 0.44444, 0.09811, 0, 0.59111],
    "8212": [0, 0.44444, 0.09811, 0, 1.18221],
    "8216": [0, 0.69444, 0.12945, 0, 0.35555],
    "8217": [0, 0.69444, 0.12945, 0, 0.35555],
    "8220": [0, 0.69444, 0.16772, 0, 0.62055],
    "8221": [0, 0.69444, 0.07939, 0, 0.62055]
  },
  "Main-Italic": {
    "32": [0, 0, 0, 0, 0.25],
    "33": [0, 0.69444, 0.12417, 0, 0.30667],
    "34": [0, 0.69444, 0.06961, 0, 0.51444],
    "35": [0.19444, 0.69444, 0.06616, 0, 0.81777],
    "37": [0.05556, 0.75, 0.13639, 0, 0.81777],
    "38": [0, 0.69444, 0.09694, 0, 0.76666],
    "39": [0, 0.69444, 0.12417, 0, 0.30667],
    "40": [0.25, 0.75, 0.16194, 0, 0.40889],
    "41": [0.25, 0.75, 0.03694, 0, 0.40889],
    "42": [0, 0.75, 0.14917, 0, 0.51111],
    "43": [0.05667, 0.56167, 0.03694, 0, 0.76666],
    "44": [0.19444, 0.10556, 0, 0, 0.30667],
    "45": [0, 0.43056, 0.02826, 0, 0.35778],
    "46": [0, 0.10556, 0, 0, 0.30667],
    "47": [0.25, 0.75, 0.16194, 0, 0.51111],
    "48": [0, 0.64444, 0.13556, 0, 0.51111],
    "49": [0, 0.64444, 0.13556, 0, 0.51111],
    "50": [0, 0.64444, 0.13556, 0, 0.51111],
    "51": [0, 0.64444, 0.13556, 0, 0.51111],
    "52": [0.19444, 0.64444, 0.13556, 0, 0.51111],
    "53": [0, 0.64444, 0.13556, 0, 0.51111],
    "54": [0, 0.64444, 0.13556, 0, 0.51111],
    "55": [0.19444, 0.64444, 0.13556, 0, 0.51111],
    "56": [0, 0.64444, 0.13556, 0, 0.51111],
    "57": [0, 0.64444, 0.13556, 0, 0.51111],
    "58": [0, 0.43056, 0.0582, 0, 0.30667],
    "59": [0.19444, 0.43056, 0.0582, 0, 0.30667],
    "61": [-0.13313, 0.36687, 0.06616, 0, 0.76666],
    "63": [0, 0.69444, 0.1225, 0, 0.51111],
    "64": [0, 0.69444, 0.09597, 0, 0.76666],
    "65": [0, 0.68333, 0, 0, 0.74333],
    "66": [0, 0.68333, 0.10257, 0, 0.70389],
    "67": [0, 0.68333, 0.14528, 0, 0.71555],
    "68": [0, 0.68333, 0.09403, 0, 0.755],
    "69": [0, 0.68333, 0.12028, 0, 0.67833],
    "70": [0, 0.68333, 0.13305, 0, 0.65277],
    "71": [0, 0.68333, 0.08722, 0, 0.77361],
    "72": [0, 0.68333, 0.16389, 0, 0.74333],
    "73": [0, 0.68333, 0.15806, 0, 0.38555],
    "74": [0, 0.68333, 0.14028, 0, 0.525],
    "75": [0, 0.68333, 0.14528, 0, 0.76888],
    "76": [0, 0.68333, 0, 0, 0.62722],
    "77": [0, 0.68333, 0.16389, 0, 0.89666],
    "78": [0, 0.68333, 0.16389, 0, 0.74333],
    "79": [0, 0.68333, 0.09403, 0, 0.76666],
    "80": [0, 0.68333, 0.10257, 0, 0.67833],
    "81": [0.19444, 0.68333, 0.09403, 0, 0.76666],
    "82": [0, 0.68333, 0.03868, 0, 0.72944],
    "83": [0, 0.68333, 0.11972, 0, 0.56222],
    "84": [0, 0.68333, 0.13305, 0, 0.71555],
    "85": [0, 0.68333, 0.16389, 0, 0.74333],
    "86": [0, 0.68333, 0.18361, 0, 0.74333],
    "87": [0, 0.68333, 0.18361, 0, 0.99888],
    "88": [0, 0.68333, 0.15806, 0, 0.74333],
    "89": [0, 0.68333, 0.19383, 0, 0.74333],
    "90": [0, 0.68333, 0.14528, 0, 0.61333],
    "91": [0.25, 0.75, 0.1875, 0, 0.30667],
    "93": [0.25, 0.75, 0.10528, 0, 0.30667],
    "94": [0, 0.69444, 0.06646, 0, 0.51111],
    "95": [0.31, 0.12056, 0.09208, 0, 0.51111],
    "97": [0, 0.43056, 0.07671, 0, 0.51111],
    "98": [0, 0.69444, 0.06312, 0, 0.46],
    "99": [0, 0.43056, 0.05653, 0, 0.46],
    "100": [0, 0.69444, 0.10333, 0, 0.51111],
    "101": [0, 0.43056, 0.07514, 0, 0.46],
    "102": [0.19444, 0.69444, 0.21194, 0, 0.30667],
    "103": [0.19444, 0.43056, 0.08847, 0, 0.46],
    "104": [0, 0.69444, 0.07671, 0, 0.51111],
    "105": [0, 0.65536, 0.1019, 0, 0.30667],
    "106": [0.19444, 0.65536, 0.14467, 0, 0.30667],
    "107": [0, 0.69444, 0.10764, 0, 0.46],
    "108": [0, 0.69444, 0.10333, 0, 0.25555],
    "109": [0, 0.43056, 0.07671, 0, 0.81777],
    "110": [0, 0.43056, 0.07671, 0, 0.56222],
    "111": [0, 0.43056, 0.06312, 0, 0.51111],
    "112": [0.19444, 0.43056, 0.06312, 0, 0.51111],
    "113": [0.19444, 0.43056, 0.08847, 0, 0.46],
    "114": [0, 0.43056, 0.10764, 0, 0.42166],
    "115": [0, 0.43056, 0.08208, 0, 0.40889],
    "116": [0, 0.61508, 0.09486, 0, 0.33222],
    "117": [0, 0.43056, 0.07671, 0, 0.53666],
    "118": [0, 0.43056, 0.10764, 0, 0.46],
    "119": [0, 0.43056, 0.10764, 0, 0.66444],
    "120": [0, 0.43056, 0.12042, 0, 0.46389],
    "121": [0.19444, 0.43056, 0.08847, 0, 0.48555],
    "122": [0, 0.43056, 0.12292, 0, 0.40889],
    "126": [0.35, 0.31786, 0.11585, 0, 0.51111],
    "160": [0, 0, 0, 0, 0.25],
    "168": [0, 0.66786, 0.10474, 0, 0.51111],
    "176": [0, 0.69444, 0, 0, 0.83129],
    "184": [0.17014, 0, 0, 0, 0.46],
    "198": [0, 0.68333, 0.12028, 0, 0.88277],
    "216": [0.04861, 0.73194, 0.09403, 0, 0.76666],
    "223": [0.19444, 0.69444, 0.10514, 0, 0.53666],
    "230": [0, 0.43056, 0.07514, 0, 0.71555],
    "248": [0.09722, 0.52778, 0.09194, 0, 0.51111],
    "338": [0, 0.68333, 0.12028, 0, 0.98499],
    "339": [0, 0.43056, 0.07514, 0, 0.71555],
    "710": [0, 0.69444, 0.06646, 0, 0.51111],
    "711": [0, 0.62847, 0.08295, 0, 0.51111],
    "713": [0, 0.56167, 0.10333, 0, 0.51111],
    "714": [0, 0.69444, 0.09694, 0, 0.51111],
    "715": [0, 0.69444, 0, 0, 0.51111],
    "728": [0, 0.69444, 0.10806, 0, 0.51111],
    "729": [0, 0.66786, 0.11752, 0, 0.30667],
    "730": [0, 0.69444, 0, 0, 0.83129],
    "732": [0, 0.66786, 0.11585, 0, 0.51111],
    "733": [0, 0.69444, 0.1225, 0, 0.51111],
    "915": [0, 0.68333, 0.13305, 0, 0.62722],
    "916": [0, 0.68333, 0, 0, 0.81777],
    "920": [0, 0.68333, 0.09403, 0, 0.76666],
    "923": [0, 0.68333, 0, 0, 0.69222],
    "926": [0, 0.68333, 0.15294, 0, 0.66444],
    "928": [0, 0.68333, 0.16389, 0, 0.74333],
    "931": [0, 0.68333, 0.12028, 0, 0.71555],
    "933": [0, 0.68333, 0.11111, 0, 0.76666],
    "934": [0, 0.68333, 0.05986, 0, 0.71555],
    "936": [0, 0.68333, 0.11111, 0, 0.76666],
    "937": [0, 0.68333, 0.10257, 0, 0.71555],
    "8211": [0, 0.43056, 0.09208, 0, 0.51111],
    "8212": [0, 0.43056, 0.09208, 0, 1.02222],
    "8216": [0, 0.69444, 0.12417, 0, 0.30667],
    "8217": [0, 0.69444, 0.12417, 0, 0.30667],
    "8220": [0, 0.69444, 0.1685, 0, 0.51444],
    "8221": [0, 0.69444, 0.06961, 0, 0.51444],
    "8463": [0, 0.68889, 0, 0, 0.54028]
  },
  "Main-Regular": {
    "32": [0, 0, 0, 0, 0.25],
    "33": [0, 0.69444, 0, 0, 0.27778],
    "34": [0, 0.69444, 0, 0, 0.5],
    "35": [0.19444, 0.69444, 0, 0, 0.83334],
    "36": [0.05556, 0.75, 0, 0, 0.5],
    "37": [0.05556, 0.75, 0, 0, 0.83334],
    "38": [0, 0.69444, 0, 0, 0.77778],
    "39": [0, 0.69444, 0, 0, 0.27778],
    "40": [0.25, 0.75, 0, 0, 0.38889],
    "41": [0.25, 0.75, 0, 0, 0.38889],
    "42": [0, 0.75, 0, 0, 0.5],
    "43": [0.08333, 0.58333, 0, 0, 0.77778],
    "44": [0.19444, 0.10556, 0, 0, 0.27778],
    "45": [0, 0.43056, 0, 0, 0.33333],
    "46": [0, 0.10556, 0, 0, 0.27778],
    "47": [0.25, 0.75, 0, 0, 0.5],
    "48": [0, 0.64444, 0, 0, 0.5],
    "49": [0, 0.64444, 0, 0, 0.5],
    "50": [0, 0.64444, 0, 0, 0.5],
    "51": [0, 0.64444, 0, 0, 0.5],
    "52": [0, 0.64444, 0, 0, 0.5],
    "53": [0, 0.64444, 0, 0, 0.5],
    "54": [0, 0.64444, 0, 0, 0.5],
    "55": [0, 0.64444, 0, 0, 0.5],
    "56": [0, 0.64444, 0, 0, 0.5],
    "57": [0, 0.64444, 0, 0, 0.5],
    "58": [0, 0.43056, 0, 0, 0.27778],
    "59": [0.19444, 0.43056, 0, 0, 0.27778],
    "60": [0.0391, 0.5391, 0, 0, 0.77778],
    "61": [-0.13313, 0.36687, 0, 0, 0.77778],
    "62": [0.0391, 0.5391, 0, 0, 0.77778],
    "63": [0, 0.69444, 0, 0, 0.47222],
    "64": [0, 0.69444, 0, 0, 0.77778],
    "65": [0, 0.68333, 0, 0, 0.75],
    "66": [0, 0.68333, 0, 0, 0.70834],
    "67": [0, 0.68333, 0, 0, 0.72222],
    "68": [0, 0.68333, 0, 0, 0.76389],
    "69": [0, 0.68333, 0, 0, 0.68056],
    "70": [0, 0.68333, 0, 0, 0.65278],
    "71": [0, 0.68333, 0, 0, 0.78472],
    "72": [0, 0.68333, 0, 0, 0.75],
    "73": [0, 0.68333, 0, 0, 0.36111],
    "74": [0, 0.68333, 0, 0, 0.51389],
    "75": [0, 0.68333, 0, 0, 0.77778],
    "76": [0, 0.68333, 0, 0, 0.625],
    "77": [0, 0.68333, 0, 0, 0.91667],
    "78": [0, 0.68333, 0, 0, 0.75],
    "79": [0, 0.68333, 0, 0, 0.77778],
    "80": [0, 0.68333, 0, 0, 0.68056],
    "81": [0.19444, 0.68333, 0, 0, 0.77778],
    "82": [0, 0.68333, 0, 0, 0.73611],
    "83": [0, 0.68333, 0, 0, 0.55556],
    "84": [0, 0.68333, 0, 0, 0.72222],
    "85": [0, 0.68333, 0, 0, 0.75],
    "86": [0, 0.68333, 0.01389, 0, 0.75],
    "87": [0, 0.68333, 0.01389, 0, 1.02778],
    "88": [0, 0.68333, 0, 0, 0.75],
    "89": [0, 0.68333, 0.025, 0, 0.75],
    "90": [0, 0.68333, 0, 0, 0.61111],
    "91": [0.25, 0.75, 0, 0, 0.27778],
    "92": [0.25, 0.75, 0, 0, 0.5],
    "93": [0.25, 0.75, 0, 0, 0.27778],
    "94": [0, 0.69444, 0, 0, 0.5],
    "95": [0.31, 0.12056, 0.02778, 0, 0.5],
    "97": [0, 0.43056, 0, 0, 0.5],
    "98": [0, 0.69444, 0, 0, 0.55556],
    "99": [0, 0.43056, 0, 0, 0.44445],
    "100": [0, 0.69444, 0, 0, 0.55556],
    "101": [0, 0.43056, 0, 0, 0.44445],
    "102": [0, 0.69444, 0.07778, 0, 0.30556],
    "103": [0.19444, 0.43056, 0.01389, 0, 0.5],
    "104": [0, 0.69444, 0, 0, 0.55556],
    "105": [0, 0.66786, 0, 0, 0.27778],
    "106": [0.19444, 0.66786, 0, 0, 0.30556],
    "107": [0, 0.69444, 0, 0, 0.52778],
    "108": [0, 0.69444, 0, 0, 0.27778],
    "109": [0, 0.43056, 0, 0, 0.83334],
    "110": [0, 0.43056, 0, 0, 0.55556],
    "111": [0, 0.43056, 0, 0, 0.5],
    "112": [0.19444, 0.43056, 0, 0, 0.55556],
    "113": [0.19444, 0.43056, 0, 0, 0.52778],
    "114": [0, 0.43056, 0, 0, 0.39167],
    "115": [0, 0.43056, 0, 0, 0.39445],
    "116": [0, 0.61508, 0, 0, 0.38889],
    "117": [0, 0.43056, 0, 0, 0.55556],
    "118": [0, 0.43056, 0.01389, 0, 0.52778],
    "119": [0, 0.43056, 0.01389, 0, 0.72222],
    "120": [0, 0.43056, 0, 0, 0.52778],
    "121": [0.19444, 0.43056, 0.01389, 0, 0.52778],
    "122": [0, 0.43056, 0, 0, 0.44445],
    "123": [0.25, 0.75, 0, 0, 0.5],
    "124": [0.25, 0.75, 0, 0, 0.27778],
    "125": [0.25, 0.75, 0, 0, 0.5],
    "126": [0.35, 0.31786, 0, 0, 0.5],
    "160": [0, 0, 0, 0, 0.25],
    "163": [0, 0.69444, 0, 0, 0.76909],
    "167": [0.19444, 0.69444, 0, 0, 0.44445],
    "168": [0, 0.66786, 0, 0, 0.5],
    "172": [0, 0.43056, 0, 0, 0.66667],
    "176": [0, 0.69444, 0, 0, 0.75],
    "177": [0.08333, 0.58333, 0, 0, 0.77778],
    "182": [0.19444, 0.69444, 0, 0, 0.61111],
    "184": [0.17014, 0, 0, 0, 0.44445],
    "198": [0, 0.68333, 0, 0, 0.90278],
    "215": [0.08333, 0.58333, 0, 0, 0.77778],
    "216": [0.04861, 0.73194, 0, 0, 0.77778],
    "223": [0, 0.69444, 0, 0, 0.5],
    "230": [0, 0.43056, 0, 0, 0.72222],
    "247": [0.08333, 0.58333, 0, 0, 0.77778],
    "248": [0.09722, 0.52778, 0, 0, 0.5],
    "305": [0, 0.43056, 0, 0, 0.27778],
    "338": [0, 0.68333, 0, 0, 1.01389],
    "339": [0, 0.43056, 0, 0, 0.77778],
    "567": [0.19444, 0.43056, 0, 0, 0.30556],
    "710": [0, 0.69444, 0, 0, 0.5],
    "711": [0, 0.62847, 0, 0, 0.5],
    "713": [0, 0.56778, 0, 0, 0.5],
    "714": [0, 0.69444, 0, 0, 0.5],
    "715": [0, 0.69444, 0, 0, 0.5],
    "728": [0, 0.69444, 0, 0, 0.5],
    "729": [0, 0.66786, 0, 0, 0.27778],
    "730": [0, 0.69444, 0, 0, 0.75],
    "732": [0, 0.66786, 0, 0, 0.5],
    "733": [0, 0.69444, 0, 0, 0.5],
    "915": [0, 0.68333, 0, 0, 0.625],
    "916": [0, 0.68333, 0, 0, 0.83334],
    "920": [0, 0.68333, 0, 0, 0.77778],
    "923": [0, 0.68333, 0, 0, 0.69445],
    "926": [0, 0.68333, 0, 0, 0.66667],
    "928": [0, 0.68333, 0, 0, 0.75],
    "931": [0, 0.68333, 0, 0, 0.72222],
    "933": [0, 0.68333, 0, 0, 0.77778],
    "934": [0, 0.68333, 0, 0, 0.72222],
    "936": [0, 0.68333, 0, 0, 0.77778],
    "937": [0, 0.68333, 0, 0, 0.72222],
    "8211": [0, 0.43056, 0.02778, 0, 0.5],
    "8212": [0, 0.43056, 0.02778, 0, 1],
    "8216": [0, 0.69444, 0, 0, 0.27778],
    "8217": [0, 0.69444, 0, 0, 0.27778],
    "8220": [0, 0.69444, 0, 0, 0.5],
    "8221": [0, 0.69444, 0, 0, 0.5],
    "8224": [0.19444, 0.69444, 0, 0, 0.44445],
    "8225": [0.19444, 0.69444, 0, 0, 0.44445],
    "8230": [0, 0.123, 0, 0, 1.172],
    "8242": [0, 0.55556, 0, 0, 0.275],
    "8407": [0, 0.71444, 0.15382, 0, 0.5],
    "8463": [0, 0.68889, 0, 0, 0.54028],
    "8465": [0, 0.69444, 0, 0, 0.72222],
    "8467": [0, 0.69444, 0, 0.11111, 0.41667],
    "8472": [0.19444, 0.43056, 0, 0.11111, 0.63646],
    "8476": [0, 0.69444, 0, 0, 0.72222],
    "8501": [0, 0.69444, 0, 0, 0.61111],
    "8592": [-0.13313, 0.36687, 0, 0, 1],
    "8593": [0.19444, 0.69444, 0, 0, 0.5],
    "8594": [-0.13313, 0.36687, 0, 0, 1],
    "8595": [0.19444, 0.69444, 0, 0, 0.5],
    "8596": [-0.13313, 0.36687, 0, 0, 1],
    "8597": [0.25, 0.75, 0, 0, 0.5],
    "8598": [0.19444, 0.69444, 0, 0, 1],
    "8599": [0.19444, 0.69444, 0, 0, 1],
    "8600": [0.19444, 0.69444, 0, 0, 1],
    "8601": [0.19444, 0.69444, 0, 0, 1],
    "8614": [0.011, 0.511, 0, 0, 1],
    "8617": [0.011, 0.511, 0, 0, 1.126],
    "8618": [0.011, 0.511, 0, 0, 1.126],
    "8636": [-0.13313, 0.36687, 0, 0, 1],
    "8637": [-0.13313, 0.36687, 0, 0, 1],
    "8640": [-0.13313, 0.36687, 0, 0, 1],
    "8641": [-0.13313, 0.36687, 0, 0, 1],
    "8652": [0.011, 0.671, 0, 0, 1],
    "8656": [-0.13313, 0.36687, 0, 0, 1],
    "8657": [0.19444, 0.69444, 0, 0, 0.61111],
    "8658": [-0.13313, 0.36687, 0, 0, 1],
    "8659": [0.19444, 0.69444, 0, 0, 0.61111],
    "8660": [-0.13313, 0.36687, 0, 0, 1],
    "8661": [0.25, 0.75, 0, 0, 0.61111],
    "8704": [0, 0.69444, 0, 0, 0.55556],
    "8706": [0, 0.69444, 0.05556, 0.08334, 0.5309],
    "8707": [0, 0.69444, 0, 0, 0.55556],
    "8709": [0.05556, 0.75, 0, 0, 0.5],
    "8711": [0, 0.68333, 0, 0, 0.83334],
    "8712": [0.0391, 0.5391, 0, 0, 0.66667],
    "8715": [0.0391, 0.5391, 0, 0, 0.66667],
    "8722": [0.08333, 0.58333, 0, 0, 0.77778],
    "8723": [0.08333, 0.58333, 0, 0, 0.77778],
    "8725": [0.25, 0.75, 0, 0, 0.5],
    "8726": [0.25, 0.75, 0, 0, 0.5],
    "8727": [-0.03472, 0.46528, 0, 0, 0.5],
    "8728": [-0.05555, 0.44445, 0, 0, 0.5],
    "8729": [-0.05555, 0.44445, 0, 0, 0.5],
    "8730": [0.2, 0.8, 0, 0, 0.83334],
    "8733": [0, 0.43056, 0, 0, 0.77778],
    "8734": [0, 0.43056, 0, 0, 1],
    "8736": [0, 0.69224, 0, 0, 0.72222],
    "8739": [0.25, 0.75, 0, 0, 0.27778],
    "8741": [0.25, 0.75, 0, 0, 0.5],
    "8743": [0, 0.55556, 0, 0, 0.66667],
    "8744": [0, 0.55556, 0, 0, 0.66667],
    "8745": [0, 0.55556, 0, 0, 0.66667],
    "8746": [0, 0.55556, 0, 0, 0.66667],
    "8747": [0.19444, 0.69444, 0.11111, 0, 0.41667],
    "8764": [-0.13313, 0.36687, 0, 0, 0.77778],
    "8768": [0.19444, 0.69444, 0, 0, 0.27778],
    "8771": [-0.03625, 0.46375, 0, 0, 0.77778],
    "8773": [-0.022, 0.589, 0, 0, 0.778],
    "8776": [-0.01688, 0.48312, 0, 0, 0.77778],
    "8781": [-0.03625, 0.46375, 0, 0, 0.77778],
    "8784": [-0.133, 0.673, 0, 0, 0.778],
    "8801": [-0.03625, 0.46375, 0, 0, 0.77778],
    "8804": [0.13597, 0.63597, 0, 0, 0.77778],
    "8805": [0.13597, 0.63597, 0, 0, 0.77778],
    "8810": [0.0391, 0.5391, 0, 0, 1],
    "8811": [0.0391, 0.5391, 0, 0, 1],
    "8826": [0.0391, 0.5391, 0, 0, 0.77778],
    "8827": [0.0391, 0.5391, 0, 0, 0.77778],
    "8834": [0.0391, 0.5391, 0, 0, 0.77778],
    "8835": [0.0391, 0.5391, 0, 0, 0.77778],
    "8838": [0.13597, 0.63597, 0, 0, 0.77778],
    "8839": [0.13597, 0.63597, 0, 0, 0.77778],
    "8846": [0, 0.55556, 0, 0, 0.66667],
    "8849": [0.13597, 0.63597, 0, 0, 0.77778],
    "8850": [0.13597, 0.63597, 0, 0, 0.77778],
    "8851": [0, 0.55556, 0, 0, 0.66667],
    "8852": [0, 0.55556, 0, 0, 0.66667],
    "8853": [0.08333, 0.58333, 0, 0, 0.77778],
    "8854": [0.08333, 0.58333, 0, 0, 0.77778],
    "8855": [0.08333, 0.58333, 0, 0, 0.77778],
    "8856": [0.08333, 0.58333, 0, 0, 0.77778],
    "8857": [0.08333, 0.58333, 0, 0, 0.77778],
    "8866": [0, 0.69444, 0, 0, 0.61111],
    "8867": [0, 0.69444, 0, 0, 0.61111],
    "8868": [0, 0.69444, 0, 0, 0.77778],
    "8869": [0, 0.69444, 0, 0, 0.77778],
    "8872": [0.249, 0.75, 0, 0, 0.867],
    "8900": [-0.05555, 0.44445, 0, 0, 0.5],
    "8901": [-0.05555, 0.44445, 0, 0, 0.27778],
    "8902": [-0.03472, 0.46528, 0, 0, 0.5],
    "8904": [5e-3, 0.505, 0, 0, 0.9],
    "8942": [0.03, 0.903, 0, 0, 0.278],
    "8943": [-0.19, 0.313, 0, 0, 1.172],
    "8945": [-0.1, 0.823, 0, 0, 1.282],
    "8968": [0.25, 0.75, 0, 0, 0.44445],
    "8969": [0.25, 0.75, 0, 0, 0.44445],
    "8970": [0.25, 0.75, 0, 0, 0.44445],
    "8971": [0.25, 0.75, 0, 0, 0.44445],
    "8994": [-0.14236, 0.35764, 0, 0, 1],
    "8995": [-0.14236, 0.35764, 0, 0, 1],
    "9136": [0.244, 0.744, 0, 0, 0.412],
    "9137": [0.244, 0.745, 0, 0, 0.412],
    "9651": [0.19444, 0.69444, 0, 0, 0.88889],
    "9657": [-0.03472, 0.46528, 0, 0, 0.5],
    "9661": [0.19444, 0.69444, 0, 0, 0.88889],
    "9667": [-0.03472, 0.46528, 0, 0, 0.5],
    "9711": [0.19444, 0.69444, 0, 0, 1],
    "9824": [0.12963, 0.69444, 0, 0, 0.77778],
    "9825": [0.12963, 0.69444, 0, 0, 0.77778],
    "9826": [0.12963, 0.69444, 0, 0, 0.77778],
    "9827": [0.12963, 0.69444, 0, 0, 0.77778],
    "9837": [0, 0.75, 0, 0, 0.38889],
    "9838": [0.19444, 0.69444, 0, 0, 0.38889],
    "9839": [0.19444, 0.69444, 0, 0, 0.38889],
    "10216": [0.25, 0.75, 0, 0, 0.38889],
    "10217": [0.25, 0.75, 0, 0, 0.38889],
    "10222": [0.244, 0.744, 0, 0, 0.412],
    "10223": [0.244, 0.745, 0, 0, 0.412],
    "10229": [0.011, 0.511, 0, 0, 1.609],
    "10230": [0.011, 0.511, 0, 0, 1.638],
    "10231": [0.011, 0.511, 0, 0, 1.859],
    "10232": [0.024, 0.525, 0, 0, 1.609],
    "10233": [0.024, 0.525, 0, 0, 1.638],
    "10234": [0.024, 0.525, 0, 0, 1.858],
    "10236": [0.011, 0.511, 0, 0, 1.638],
    "10815": [0, 0.68333, 0, 0, 0.75],
    "10927": [0.13597, 0.63597, 0, 0, 0.77778],
    "10928": [0.13597, 0.63597, 0, 0, 0.77778],
    "57376": [0.19444, 0.69444, 0, 0, 0]
  },
  "Math-BoldItalic": {
    "32": [0, 0, 0, 0, 0.25],
    "48": [0, 0.44444, 0, 0, 0.575],
    "49": [0, 0.44444, 0, 0, 0.575],
    "50": [0, 0.44444, 0, 0, 0.575],
    "51": [0.19444, 0.44444, 0, 0, 0.575],
    "52": [0.19444, 0.44444, 0, 0, 0.575],
    "53": [0.19444, 0.44444, 0, 0, 0.575],
    "54": [0, 0.64444, 0, 0, 0.575],
    "55": [0.19444, 0.44444, 0, 0, 0.575],
    "56": [0, 0.64444, 0, 0, 0.575],
    "57": [0.19444, 0.44444, 0, 0, 0.575],
    "65": [0, 0.68611, 0, 0, 0.86944],
    "66": [0, 0.68611, 0.04835, 0, 0.8664],
    "67": [0, 0.68611, 0.06979, 0, 0.81694],
    "68": [0, 0.68611, 0.03194, 0, 0.93812],
    "69": [0, 0.68611, 0.05451, 0, 0.81007],
    "70": [0, 0.68611, 0.15972, 0, 0.68889],
    "71": [0, 0.68611, 0, 0, 0.88673],
    "72": [0, 0.68611, 0.08229, 0, 0.98229],
    "73": [0, 0.68611, 0.07778, 0, 0.51111],
    "74": [0, 0.68611, 0.10069, 0, 0.63125],
    "75": [0, 0.68611, 0.06979, 0, 0.97118],
    "76": [0, 0.68611, 0, 0, 0.75555],
    "77": [0, 0.68611, 0.11424, 0, 1.14201],
    "78": [0, 0.68611, 0.11424, 0, 0.95034],
    "79": [0, 0.68611, 0.03194, 0, 0.83666],
    "80": [0, 0.68611, 0.15972, 0, 0.72309],
    "81": [0.19444, 0.68611, 0, 0, 0.86861],
    "82": [0, 0.68611, 421e-5, 0, 0.87235],
    "83": [0, 0.68611, 0.05382, 0, 0.69271],
    "84": [0, 0.68611, 0.15972, 0, 0.63663],
    "85": [0, 0.68611, 0.11424, 0, 0.80027],
    "86": [0, 0.68611, 0.25555, 0, 0.67778],
    "87": [0, 0.68611, 0.15972, 0, 1.09305],
    "88": [0, 0.68611, 0.07778, 0, 0.94722],
    "89": [0, 0.68611, 0.25555, 0, 0.67458],
    "90": [0, 0.68611, 0.06979, 0, 0.77257],
    "97": [0, 0.44444, 0, 0, 0.63287],
    "98": [0, 0.69444, 0, 0, 0.52083],
    "99": [0, 0.44444, 0, 0, 0.51342],
    "100": [0, 0.69444, 0, 0, 0.60972],
    "101": [0, 0.44444, 0, 0, 0.55361],
    "102": [0.19444, 0.69444, 0.11042, 0, 0.56806],
    "103": [0.19444, 0.44444, 0.03704, 0, 0.5449],
    "104": [0, 0.69444, 0, 0, 0.66759],
    "105": [0, 0.69326, 0, 0, 0.4048],
    "106": [0.19444, 0.69326, 0.0622, 0, 0.47083],
    "107": [0, 0.69444, 0.01852, 0, 0.6037],
    "108": [0, 0.69444, 88e-4, 0, 0.34815],
    "109": [0, 0.44444, 0, 0, 1.0324],
    "110": [0, 0.44444, 0, 0, 0.71296],
    "111": [0, 0.44444, 0, 0, 0.58472],
    "112": [0.19444, 0.44444, 0, 0, 0.60092],
    "113": [0.19444, 0.44444, 0.03704, 0, 0.54213],
    "114": [0, 0.44444, 0.03194, 0, 0.5287],
    "115": [0, 0.44444, 0, 0, 0.53125],
    "116": [0, 0.63492, 0, 0, 0.41528],
    "117": [0, 0.44444, 0, 0, 0.68102],
    "118": [0, 0.44444, 0.03704, 0, 0.56666],
    "119": [0, 0.44444, 0.02778, 0, 0.83148],
    "120": [0, 0.44444, 0, 0, 0.65903],
    "121": [0.19444, 0.44444, 0.03704, 0, 0.59028],
    "122": [0, 0.44444, 0.04213, 0, 0.55509],
    "160": [0, 0, 0, 0, 0.25],
    "915": [0, 0.68611, 0.15972, 0, 0.65694],
    "916": [0, 0.68611, 0, 0, 0.95833],
    "920": [0, 0.68611, 0.03194, 0, 0.86722],
    "923": [0, 0.68611, 0, 0, 0.80555],
    "926": [0, 0.68611, 0.07458, 0, 0.84125],
    "928": [0, 0.68611, 0.08229, 0, 0.98229],
    "931": [0, 0.68611, 0.05451, 0, 0.88507],
    "933": [0, 0.68611, 0.15972, 0, 0.67083],
    "934": [0, 0.68611, 0, 0, 0.76666],
    "936": [0, 0.68611, 0.11653, 0, 0.71402],
    "937": [0, 0.68611, 0.04835, 0, 0.8789],
    "945": [0, 0.44444, 0, 0, 0.76064],
    "946": [0.19444, 0.69444, 0.03403, 0, 0.65972],
    "947": [0.19444, 0.44444, 0.06389, 0, 0.59003],
    "948": [0, 0.69444, 0.03819, 0, 0.52222],
    "949": [0, 0.44444, 0, 0, 0.52882],
    "950": [0.19444, 0.69444, 0.06215, 0, 0.50833],
    "951": [0.19444, 0.44444, 0.03704, 0, 0.6],
    "952": [0, 0.69444, 0.03194, 0, 0.5618],
    "953": [0, 0.44444, 0, 0, 0.41204],
    "954": [0, 0.44444, 0, 0, 0.66759],
    "955": [0, 0.69444, 0, 0, 0.67083],
    "956": [0.19444, 0.44444, 0, 0, 0.70787],
    "957": [0, 0.44444, 0.06898, 0, 0.57685],
    "958": [0.19444, 0.69444, 0.03021, 0, 0.50833],
    "959": [0, 0.44444, 0, 0, 0.58472],
    "960": [0, 0.44444, 0.03704, 0, 0.68241],
    "961": [0.19444, 0.44444, 0, 0, 0.6118],
    "962": [0.09722, 0.44444, 0.07917, 0, 0.42361],
    "963": [0, 0.44444, 0.03704, 0, 0.68588],
    "964": [0, 0.44444, 0.13472, 0, 0.52083],
    "965": [0, 0.44444, 0.03704, 0, 0.63055],
    "966": [0.19444, 0.44444, 0, 0, 0.74722],
    "967": [0.19444, 0.44444, 0, 0, 0.71805],
    "968": [0.19444, 0.69444, 0.03704, 0, 0.75833],
    "969": [0, 0.44444, 0.03704, 0, 0.71782],
    "977": [0, 0.69444, 0, 0, 0.69155],
    "981": [0.19444, 0.69444, 0, 0, 0.7125],
    "982": [0, 0.44444, 0.03194, 0, 0.975],
    "1009": [0.19444, 0.44444, 0, 0, 0.6118],
    "1013": [0, 0.44444, 0, 0, 0.48333],
    "57649": [0, 0.44444, 0, 0, 0.39352],
    "57911": [0.19444, 0.44444, 0, 0, 0.43889]
  },
  "Math-Italic": {
    "32": [0, 0, 0, 0, 0.25],
    "48": [0, 0.43056, 0, 0, 0.5],
    "49": [0, 0.43056, 0, 0, 0.5],
    "50": [0, 0.43056, 0, 0, 0.5],
    "51": [0.19444, 0.43056, 0, 0, 0.5],
    "52": [0.19444, 0.43056, 0, 0, 0.5],
    "53": [0.19444, 0.43056, 0, 0, 0.5],
    "54": [0, 0.64444, 0, 0, 0.5],
    "55": [0.19444, 0.43056, 0, 0, 0.5],
    "56": [0, 0.64444, 0, 0, 0.5],
    "57": [0.19444, 0.43056, 0, 0, 0.5],
    "65": [0, 0.68333, 0, 0.13889, 0.75],
    "66": [0, 0.68333, 0.05017, 0.08334, 0.75851],
    "67": [0, 0.68333, 0.07153, 0.08334, 0.71472],
    "68": [0, 0.68333, 0.02778, 0.05556, 0.82792],
    "69": [0, 0.68333, 0.05764, 0.08334, 0.7382],
    "70": [0, 0.68333, 0.13889, 0.08334, 0.64306],
    "71": [0, 0.68333, 0, 0.08334, 0.78625],
    "72": [0, 0.68333, 0.08125, 0.05556, 0.83125],
    "73": [0, 0.68333, 0.07847, 0.11111, 0.43958],
    "74": [0, 0.68333, 0.09618, 0.16667, 0.55451],
    "75": [0, 0.68333, 0.07153, 0.05556, 0.84931],
    "76": [0, 0.68333, 0, 0.02778, 0.68056],
    "77": [0, 0.68333, 0.10903, 0.08334, 0.97014],
    "78": [0, 0.68333, 0.10903, 0.08334, 0.80347],
    "79": [0, 0.68333, 0.02778, 0.08334, 0.76278],
    "80": [0, 0.68333, 0.13889, 0.08334, 0.64201],
    "81": [0.19444, 0.68333, 0, 0.08334, 0.79056],
    "82": [0, 0.68333, 773e-5, 0.08334, 0.75929],
    "83": [0, 0.68333, 0.05764, 0.08334, 0.6132],
    "84": [0, 0.68333, 0.13889, 0.08334, 0.58438],
    "85": [0, 0.68333, 0.10903, 0.02778, 0.68278],
    "86": [0, 0.68333, 0.22222, 0, 0.58333],
    "87": [0, 0.68333, 0.13889, 0, 0.94445],
    "88": [0, 0.68333, 0.07847, 0.08334, 0.82847],
    "89": [0, 0.68333, 0.22222, 0, 0.58056],
    "90": [0, 0.68333, 0.07153, 0.08334, 0.68264],
    "97": [0, 0.43056, 0, 0, 0.52859],
    "98": [0, 0.69444, 0, 0, 0.42917],
    "99": [0, 0.43056, 0, 0.05556, 0.43276],
    "100": [0, 0.69444, 0, 0.16667, 0.52049],
    "101": [0, 0.43056, 0, 0.05556, 0.46563],
    "102": [0.19444, 0.69444, 0.10764, 0.16667, 0.48959],
    "103": [0.19444, 0.43056, 0.03588, 0.02778, 0.47697],
    "104": [0, 0.69444, 0, 0, 0.57616],
    "105": [0, 0.65952, 0, 0, 0.34451],
    "106": [0.19444, 0.65952, 0.05724, 0, 0.41181],
    "107": [0, 0.69444, 0.03148, 0, 0.5206],
    "108": [0, 0.69444, 0.01968, 0.08334, 0.29838],
    "109": [0, 0.43056, 0, 0, 0.87801],
    "110": [0, 0.43056, 0, 0, 0.60023],
    "111": [0, 0.43056, 0, 0.05556, 0.48472],
    "112": [0.19444, 0.43056, 0, 0.08334, 0.50313],
    "113": [0.19444, 0.43056, 0.03588, 0.08334, 0.44641],
    "114": [0, 0.43056, 0.02778, 0.05556, 0.45116],
    "115": [0, 0.43056, 0, 0.05556, 0.46875],
    "116": [0, 0.61508, 0, 0.08334, 0.36111],
    "117": [0, 0.43056, 0, 0.02778, 0.57246],
    "118": [0, 0.43056, 0.03588, 0.02778, 0.48472],
    "119": [0, 0.43056, 0.02691, 0.08334, 0.71592],
    "120": [0, 0.43056, 0, 0.02778, 0.57153],
    "121": [0.19444, 0.43056, 0.03588, 0.05556, 0.49028],
    "122": [0, 0.43056, 0.04398, 0.05556, 0.46505],
    "160": [0, 0, 0, 0, 0.25],
    "915": [0, 0.68333, 0.13889, 0.08334, 0.61528],
    "916": [0, 0.68333, 0, 0.16667, 0.83334],
    "920": [0, 0.68333, 0.02778, 0.08334, 0.76278],
    "923": [0, 0.68333, 0, 0.16667, 0.69445],
    "926": [0, 0.68333, 0.07569, 0.08334, 0.74236],
    "928": [0, 0.68333, 0.08125, 0.05556, 0.83125],
    "931": [0, 0.68333, 0.05764, 0.08334, 0.77986],
    "933": [0, 0.68333, 0.13889, 0.05556, 0.58333],
    "934": [0, 0.68333, 0, 0.08334, 0.66667],
    "936": [0, 0.68333, 0.11, 0.05556, 0.61222],
    "937": [0, 0.68333, 0.05017, 0.08334, 0.7724],
    "945": [0, 0.43056, 37e-4, 0.02778, 0.6397],
    "946": [0.19444, 0.69444, 0.05278, 0.08334, 0.56563],
    "947": [0.19444, 0.43056, 0.05556, 0, 0.51773],
    "948": [0, 0.69444, 0.03785, 0.05556, 0.44444],
    "949": [0, 0.43056, 0, 0.08334, 0.46632],
    "950": [0.19444, 0.69444, 0.07378, 0.08334, 0.4375],
    "951": [0.19444, 0.43056, 0.03588, 0.05556, 0.49653],
    "952": [0, 0.69444, 0.02778, 0.08334, 0.46944],
    "953": [0, 0.43056, 0, 0.05556, 0.35394],
    "954": [0, 0.43056, 0, 0, 0.57616],
    "955": [0, 0.69444, 0, 0, 0.58334],
    "956": [0.19444, 0.43056, 0, 0.02778, 0.60255],
    "957": [0, 0.43056, 0.06366, 0.02778, 0.49398],
    "958": [0.19444, 0.69444, 0.04601, 0.11111, 0.4375],
    "959": [0, 0.43056, 0, 0.05556, 0.48472],
    "960": [0, 0.43056, 0.03588, 0, 0.57003],
    "961": [0.19444, 0.43056, 0, 0.08334, 0.51702],
    "962": [0.09722, 0.43056, 0.07986, 0.08334, 0.36285],
    "963": [0, 0.43056, 0.03588, 0, 0.57141],
    "964": [0, 0.43056, 0.1132, 0.02778, 0.43715],
    "965": [0, 0.43056, 0.03588, 0.02778, 0.54028],
    "966": [0.19444, 0.43056, 0, 0.08334, 0.65417],
    "967": [0.19444, 0.43056, 0, 0.05556, 0.62569],
    "968": [0.19444, 0.69444, 0.03588, 0.11111, 0.65139],
    "969": [0, 0.43056, 0.03588, 0, 0.62245],
    "977": [0, 0.69444, 0, 0.08334, 0.59144],
    "981": [0.19444, 0.69444, 0, 0.08334, 0.59583],
    "982": [0, 0.43056, 0.02778, 0, 0.82813],
    "1009": [0.19444, 0.43056, 0, 0.08334, 0.51702],
    "1013": [0, 0.43056, 0, 0.05556, 0.4059],
    "57649": [0, 0.43056, 0, 0.02778, 0.32246],
    "57911": [0.19444, 0.43056, 0, 0.08334, 0.38403]
  },
  "SansSerif-Bold": {
    "32": [0, 0, 0, 0, 0.25],
    "33": [0, 0.69444, 0, 0, 0.36667],
    "34": [0, 0.69444, 0, 0, 0.55834],
    "35": [0.19444, 0.69444, 0, 0, 0.91667],
    "36": [0.05556, 0.75, 0, 0, 0.55],
    "37": [0.05556, 0.75, 0, 0, 1.02912],
    "38": [0, 0.69444, 0, 0, 0.83056],
    "39": [0, 0.69444, 0, 0, 0.30556],
    "40": [0.25, 0.75, 0, 0, 0.42778],
    "41": [0.25, 0.75, 0, 0, 0.42778],
    "42": [0, 0.75, 0, 0, 0.55],
    "43": [0.11667, 0.61667, 0, 0, 0.85556],
    "44": [0.10556, 0.13056, 0, 0, 0.30556],
    "45": [0, 0.45833, 0, 0, 0.36667],
    "46": [0, 0.13056, 0, 0, 0.30556],
    "47": [0.25, 0.75, 0, 0, 0.55],
    "48": [0, 0.69444, 0, 0, 0.55],
    "49": [0, 0.69444, 0, 0, 0.55],
    "50": [0, 0.69444, 0, 0, 0.55],
    "51": [0, 0.69444, 0, 0, 0.55],
    "52": [0, 0.69444, 0, 0, 0.55],
    "53": [0, 0.69444, 0, 0, 0.55],
    "54": [0, 0.69444, 0, 0, 0.55],
    "55": [0, 0.69444, 0, 0, 0.55],
    "56": [0, 0.69444, 0, 0, 0.55],
    "57": [0, 0.69444, 0, 0, 0.55],
    "58": [0, 0.45833, 0, 0, 0.30556],
    "59": [0.10556, 0.45833, 0, 0, 0.30556],
    "61": [-0.09375, 0.40625, 0, 0, 0.85556],
    "63": [0, 0.69444, 0, 0, 0.51945],
    "64": [0, 0.69444, 0, 0, 0.73334],
    "65": [0, 0.69444, 0, 0, 0.73334],
    "66": [0, 0.69444, 0, 0, 0.73334],
    "67": [0, 0.69444, 0, 0, 0.70278],
    "68": [0, 0.69444, 0, 0, 0.79445],
    "69": [0, 0.69444, 0, 0, 0.64167],
    "70": [0, 0.69444, 0, 0, 0.61111],
    "71": [0, 0.69444, 0, 0, 0.73334],
    "72": [0, 0.69444, 0, 0, 0.79445],
    "73": [0, 0.69444, 0, 0, 0.33056],
    "74": [0, 0.69444, 0, 0, 0.51945],
    "75": [0, 0.69444, 0, 0, 0.76389],
    "76": [0, 0.69444, 0, 0, 0.58056],
    "77": [0, 0.69444, 0, 0, 0.97778],
    "78": [0, 0.69444, 0, 0, 0.79445],
    "79": [0, 0.69444, 0, 0, 0.79445],
    "80": [0, 0.69444, 0, 0, 0.70278],
    "81": [0.10556, 0.69444, 0, 0, 0.79445],
    "82": [0, 0.69444, 0, 0, 0.70278],
    "83": [0, 0.69444, 0, 0, 0.61111],
    "84": [0, 0.69444, 0, 0, 0.73334],
    "85": [0, 0.69444, 0, 0, 0.76389],
    "86": [0, 0.69444, 0.01528, 0, 0.73334],
    "87": [0, 0.69444, 0.01528, 0, 1.03889],
    "88": [0, 0.69444, 0, 0, 0.73334],
    "89": [0, 0.69444, 0.0275, 0, 0.73334],
    "90": [0, 0.69444, 0, 0, 0.67223],
    "91": [0.25, 0.75, 0, 0, 0.34306],
    "93": [0.25, 0.75, 0, 0, 0.34306],
    "94": [0, 0.69444, 0, 0, 0.55],
    "95": [0.35, 0.10833, 0.03056, 0, 0.55],
    "97": [0, 0.45833, 0, 0, 0.525],
    "98": [0, 0.69444, 0, 0, 0.56111],
    "99": [0, 0.45833, 0, 0, 0.48889],
    "100": [0, 0.69444, 0, 0, 0.56111],
    "101": [0, 0.45833, 0, 0, 0.51111],
    "102": [0, 0.69444, 0.07639, 0, 0.33611],
    "103": [0.19444, 0.45833, 0.01528, 0, 0.55],
    "104": [0, 0.69444, 0, 0, 0.56111],
    "105": [0, 0.69444, 0, 0, 0.25556],
    "106": [0.19444, 0.69444, 0, 0, 0.28611],
    "107": [0, 0.69444, 0, 0, 0.53056],
    "108": [0, 0.69444, 0, 0, 0.25556],
    "109": [0, 0.45833, 0, 0, 0.86667],
    "110": [0, 0.45833, 0, 0, 0.56111],
    "111": [0, 0.45833, 0, 0, 0.55],
    "112": [0.19444, 0.45833, 0, 0, 0.56111],
    "113": [0.19444, 0.45833, 0, 0, 0.56111],
    "114": [0, 0.45833, 0.01528, 0, 0.37222],
    "115": [0, 0.45833, 0, 0, 0.42167],
    "116": [0, 0.58929, 0, 0, 0.40417],
    "117": [0, 0.45833, 0, 0, 0.56111],
    "118": [0, 0.45833, 0.01528, 0, 0.5],
    "119": [0, 0.45833, 0.01528, 0, 0.74445],
    "120": [0, 0.45833, 0, 0, 0.5],
    "121": [0.19444, 0.45833, 0.01528, 0, 0.5],
    "122": [0, 0.45833, 0, 0, 0.47639],
    "126": [0.35, 0.34444, 0, 0, 0.55],
    "160": [0, 0, 0, 0, 0.25],
    "168": [0, 0.69444, 0, 0, 0.55],
    "176": [0, 0.69444, 0, 0, 0.73334],
    "180": [0, 0.69444, 0, 0, 0.55],
    "184": [0.17014, 0, 0, 0, 0.48889],
    "305": [0, 0.45833, 0, 0, 0.25556],
    "567": [0.19444, 0.45833, 0, 0, 0.28611],
    "710": [0, 0.69444, 0, 0, 0.55],
    "711": [0, 0.63542, 0, 0, 0.55],
    "713": [0, 0.63778, 0, 0, 0.55],
    "728": [0, 0.69444, 0, 0, 0.55],
    "729": [0, 0.69444, 0, 0, 0.30556],
    "730": [0, 0.69444, 0, 0, 0.73334],
    "732": [0, 0.69444, 0, 0, 0.55],
    "733": [0, 0.69444, 0, 0, 0.55],
    "915": [0, 0.69444, 0, 0, 0.58056],
    "916": [0, 0.69444, 0, 0, 0.91667],
    "920": [0, 0.69444, 0, 0, 0.85556],
    "923": [0, 0.69444, 0, 0, 0.67223],
    "926": [0, 0.69444, 0, 0, 0.73334],
    "928": [0, 0.69444, 0, 0, 0.79445],
    "931": [0, 0.69444, 0, 0, 0.79445],
    "933": [0, 0.69444, 0, 0, 0.85556],
    "934": [0, 0.69444, 0, 0, 0.79445],
    "936": [0, 0.69444, 0, 0, 0.85556],
    "937": [0, 0.69444, 0, 0, 0.79445],
    "8211": [0, 0.45833, 0.03056, 0, 0.55],
    "8212": [0, 0.45833, 0.03056, 0, 1.10001],
    "8216": [0, 0.69444, 0, 0, 0.30556],
    "8217": [0, 0.69444, 0, 0, 0.30556],
    "8220": [0, 0.69444, 0, 0, 0.55834],
    "8221": [0, 0.69444, 0, 0, 0.55834]
  },
  "SansSerif-Italic": {
    "32": [0, 0, 0, 0, 0.25],
    "33": [0, 0.69444, 0.05733, 0, 0.31945],
    "34": [0, 0.69444, 316e-5, 0, 0.5],
    "35": [0.19444, 0.69444, 0.05087, 0, 0.83334],
    "36": [0.05556, 0.75, 0.11156, 0, 0.5],
    "37": [0.05556, 0.75, 0.03126, 0, 0.83334],
    "38": [0, 0.69444, 0.03058, 0, 0.75834],
    "39": [0, 0.69444, 0.07816, 0, 0.27778],
    "40": [0.25, 0.75, 0.13164, 0, 0.38889],
    "41": [0.25, 0.75, 0.02536, 0, 0.38889],
    "42": [0, 0.75, 0.11775, 0, 0.5],
    "43": [0.08333, 0.58333, 0.02536, 0, 0.77778],
    "44": [0.125, 0.08333, 0, 0, 0.27778],
    "45": [0, 0.44444, 0.01946, 0, 0.33333],
    "46": [0, 0.08333, 0, 0, 0.27778],
    "47": [0.25, 0.75, 0.13164, 0, 0.5],
    "48": [0, 0.65556, 0.11156, 0, 0.5],
    "49": [0, 0.65556, 0.11156, 0, 0.5],
    "50": [0, 0.65556, 0.11156, 0, 0.5],
    "51": [0, 0.65556, 0.11156, 0, 0.5],
    "52": [0, 0.65556, 0.11156, 0, 0.5],
    "53": [0, 0.65556, 0.11156, 0, 0.5],
    "54": [0, 0.65556, 0.11156, 0, 0.5],
    "55": [0, 0.65556, 0.11156, 0, 0.5],
    "56": [0, 0.65556, 0.11156, 0, 0.5],
    "57": [0, 0.65556, 0.11156, 0, 0.5],
    "58": [0, 0.44444, 0.02502, 0, 0.27778],
    "59": [0.125, 0.44444, 0.02502, 0, 0.27778],
    "61": [-0.13, 0.37, 0.05087, 0, 0.77778],
    "63": [0, 0.69444, 0.11809, 0, 0.47222],
    "64": [0, 0.69444, 0.07555, 0, 0.66667],
    "65": [0, 0.69444, 0, 0, 0.66667],
    "66": [0, 0.69444, 0.08293, 0, 0.66667],
    "67": [0, 0.69444, 0.11983, 0, 0.63889],
    "68": [0, 0.69444, 0.07555, 0, 0.72223],
    "69": [0, 0.69444, 0.11983, 0, 0.59722],
    "70": [0, 0.69444, 0.13372, 0, 0.56945],
    "71": [0, 0.69444, 0.11983, 0, 0.66667],
    "72": [0, 0.69444, 0.08094, 0, 0.70834],
    "73": [0, 0.69444, 0.13372, 0, 0.27778],
    "74": [0, 0.69444, 0.08094, 0, 0.47222],
    "75": [0, 0.69444, 0.11983, 0, 0.69445],
    "76": [0, 0.69444, 0, 0, 0.54167],
    "77": [0, 0.69444, 0.08094, 0, 0.875],
    "78": [0, 0.69444, 0.08094, 0, 0.70834],
    "79": [0, 0.69444, 0.07555, 0, 0.73611],
    "80": [0, 0.69444, 0.08293, 0, 0.63889],
    "81": [0.125, 0.69444, 0.07555, 0, 0.73611],
    "82": [0, 0.69444, 0.08293, 0, 0.64584],
    "83": [0, 0.69444, 0.09205, 0, 0.55556],
    "84": [0, 0.69444, 0.13372, 0, 0.68056],
    "85": [0, 0.69444, 0.08094, 0, 0.6875],
    "86": [0, 0.69444, 0.1615, 0, 0.66667],
    "87": [0, 0.69444, 0.1615, 0, 0.94445],
    "88": [0, 0.69444, 0.13372, 0, 0.66667],
    "89": [0, 0.69444, 0.17261, 0, 0.66667],
    "90": [0, 0.69444, 0.11983, 0, 0.61111],
    "91": [0.25, 0.75, 0.15942, 0, 0.28889],
    "93": [0.25, 0.75, 0.08719, 0, 0.28889],
    "94": [0, 0.69444, 0.0799, 0, 0.5],
    "95": [0.35, 0.09444, 0.08616, 0, 0.5],
    "97": [0, 0.44444, 981e-5, 0, 0.48056],
    "98": [0, 0.69444, 0.03057, 0, 0.51667],
    "99": [0, 0.44444, 0.08336, 0, 0.44445],
    "100": [0, 0.69444, 0.09483, 0, 0.51667],
    "101": [0, 0.44444, 0.06778, 0, 0.44445],
    "102": [0, 0.69444, 0.21705, 0, 0.30556],
    "103": [0.19444, 0.44444, 0.10836, 0, 0.5],
    "104": [0, 0.69444, 0.01778, 0, 0.51667],
    "105": [0, 0.67937, 0.09718, 0, 0.23889],
    "106": [0.19444, 0.67937, 0.09162, 0, 0.26667],
    "107": [0, 0.69444, 0.08336, 0, 0.48889],
    "108": [0, 0.69444, 0.09483, 0, 0.23889],
    "109": [0, 0.44444, 0.01778, 0, 0.79445],
    "110": [0, 0.44444, 0.01778, 0, 0.51667],
    "111": [0, 0.44444, 0.06613, 0, 0.5],
    "112": [0.19444, 0.44444, 0.0389, 0, 0.51667],
    "113": [0.19444, 0.44444, 0.04169, 0, 0.51667],
    "114": [0, 0.44444, 0.10836, 0, 0.34167],
    "115": [0, 0.44444, 0.0778, 0, 0.38333],
    "116": [0, 0.57143, 0.07225, 0, 0.36111],
    "117": [0, 0.44444, 0.04169, 0, 0.51667],
    "118": [0, 0.44444, 0.10836, 0, 0.46111],
    "119": [0, 0.44444, 0.10836, 0, 0.68334],
    "120": [0, 0.44444, 0.09169, 0, 0.46111],
    "121": [0.19444, 0.44444, 0.10836, 0, 0.46111],
    "122": [0, 0.44444, 0.08752, 0, 0.43472],
    "126": [0.35, 0.32659, 0.08826, 0, 0.5],
    "160": [0, 0, 0, 0, 0.25],
    "168": [0, 0.67937, 0.06385, 0, 0.5],
    "176": [0, 0.69444, 0, 0, 0.73752],
    "184": [0.17014, 0, 0, 0, 0.44445],
    "305": [0, 0.44444, 0.04169, 0, 0.23889],
    "567": [0.19444, 0.44444, 0.04169, 0, 0.26667],
    "710": [0, 0.69444, 0.0799, 0, 0.5],
    "711": [0, 0.63194, 0.08432, 0, 0.5],
    "713": [0, 0.60889, 0.08776, 0, 0.5],
    "714": [0, 0.69444, 0.09205, 0, 0.5],
    "715": [0, 0.69444, 0, 0, 0.5],
    "728": [0, 0.69444, 0.09483, 0, 0.5],
    "729": [0, 0.67937, 0.07774, 0, 0.27778],
    "730": [0, 0.69444, 0, 0, 0.73752],
    "732": [0, 0.67659, 0.08826, 0, 0.5],
    "733": [0, 0.69444, 0.09205, 0, 0.5],
    "915": [0, 0.69444, 0.13372, 0, 0.54167],
    "916": [0, 0.69444, 0, 0, 0.83334],
    "920": [0, 0.69444, 0.07555, 0, 0.77778],
    "923": [0, 0.69444, 0, 0, 0.61111],
    "926": [0, 0.69444, 0.12816, 0, 0.66667],
    "928": [0, 0.69444, 0.08094, 0, 0.70834],
    "931": [0, 0.69444, 0.11983, 0, 0.72222],
    "933": [0, 0.69444, 0.09031, 0, 0.77778],
    "934": [0, 0.69444, 0.04603, 0, 0.72222],
    "936": [0, 0.69444, 0.09031, 0, 0.77778],
    "937": [0, 0.69444, 0.08293, 0, 0.72222],
    "8211": [0, 0.44444, 0.08616, 0, 0.5],
    "8212": [0, 0.44444, 0.08616, 0, 1],
    "8216": [0, 0.69444, 0.07816, 0, 0.27778],
    "8217": [0, 0.69444, 0.07816, 0, 0.27778],
    "8220": [0, 0.69444, 0.14205, 0, 0.5],
    "8221": [0, 0.69444, 316e-5, 0, 0.5]
  },
  "SansSerif-Regular": {
    "32": [0, 0, 0, 0, 0.25],
    "33": [0, 0.69444, 0, 0, 0.31945],
    "34": [0, 0.69444, 0, 0, 0.5],
    "35": [0.19444, 0.69444, 0, 0, 0.83334],
    "36": [0.05556, 0.75, 0, 0, 0.5],
    "37": [0.05556, 0.75, 0, 0, 0.83334],
    "38": [0, 0.69444, 0, 0, 0.75834],
    "39": [0, 0.69444, 0, 0, 0.27778],
    "40": [0.25, 0.75, 0, 0, 0.38889],
    "41": [0.25, 0.75, 0, 0, 0.38889],
    "42": [0, 0.75, 0, 0, 0.5],
    "43": [0.08333, 0.58333, 0, 0, 0.77778],
    "44": [0.125, 0.08333, 0, 0, 0.27778],
    "45": [0, 0.44444, 0, 0, 0.33333],
    "46": [0, 0.08333, 0, 0, 0.27778],
    "47": [0.25, 0.75, 0, 0, 0.5],
    "48": [0, 0.65556, 0, 0, 0.5],
    "49": [0, 0.65556, 0, 0, 0.5],
    "50": [0, 0.65556, 0, 0, 0.5],
    "51": [0, 0.65556, 0, 0, 0.5],
    "52": [0, 0.65556, 0, 0, 0.5],
    "53": [0, 0.65556, 0, 0, 0.5],
    "54": [0, 0.65556, 0, 0, 0.5],
    "55": [0, 0.65556, 0, 0, 0.5],
    "56": [0, 0.65556, 0, 0, 0.5],
    "57": [0, 0.65556, 0, 0, 0.5],
    "58": [0, 0.44444, 0, 0, 0.27778],
    "59": [0.125, 0.44444, 0, 0, 0.27778],
    "61": [-0.13, 0.37, 0, 0, 0.77778],
    "63": [0, 0.69444, 0, 0, 0.47222],
    "64": [0, 0.69444, 0, 0, 0.66667],
    "65": [0, 0.69444, 0, 0, 0.66667],
    "66": [0, 0.69444, 0, 0, 0.66667],
    "67": [0, 0.69444, 0, 0, 0.63889],
    "68": [0, 0.69444, 0, 0, 0.72223],
    "69": [0, 0.69444, 0, 0, 0.59722],
    "70": [0, 0.69444, 0, 0, 0.56945],
    "71": [0, 0.69444, 0, 0, 0.66667],
    "72": [0, 0.69444, 0, 0, 0.70834],
    "73": [0, 0.69444, 0, 0, 0.27778],
    "74": [0, 0.69444, 0, 0, 0.47222],
    "75": [0, 0.69444, 0, 0, 0.69445],
    "76": [0, 0.69444, 0, 0, 0.54167],
    "77": [0, 0.69444, 0, 0, 0.875],
    "78": [0, 0.69444, 0, 0, 0.70834],
    "79": [0, 0.69444, 0, 0, 0.73611],
    "80": [0, 0.69444, 0, 0, 0.63889],
    "81": [0.125, 0.69444, 0, 0, 0.73611],
    "82": [0, 0.69444, 0, 0, 0.64584],
    "83": [0, 0.69444, 0, 0, 0.55556],
    "84": [0, 0.69444, 0, 0, 0.68056],
    "85": [0, 0.69444, 0, 0, 0.6875],
    "86": [0, 0.69444, 0.01389, 0, 0.66667],
    "87": [0, 0.69444, 0.01389, 0, 0.94445],
    "88": [0, 0.69444, 0, 0, 0.66667],
    "89": [0, 0.69444, 0.025, 0, 0.66667],
    "90": [0, 0.69444, 0, 0, 0.61111],
    "91": [0.25, 0.75, 0, 0, 0.28889],
    "93": [0.25, 0.75, 0, 0, 0.28889],
    "94": [0, 0.69444, 0, 0, 0.5],
    "95": [0.35, 0.09444, 0.02778, 0, 0.5],
    "97": [0, 0.44444, 0, 0, 0.48056],
    "98": [0, 0.69444, 0, 0, 0.51667],
    "99": [0, 0.44444, 0, 0, 0.44445],
    "100": [0, 0.69444, 0, 0, 0.51667],
    "101": [0, 0.44444, 0, 0, 0.44445],
    "102": [0, 0.69444, 0.06944, 0, 0.30556],
    "103": [0.19444, 0.44444, 0.01389, 0, 0.5],
    "104": [0, 0.69444, 0, 0, 0.51667],
    "105": [0, 0.67937, 0, 0, 0.23889],
    "106": [0.19444, 0.67937, 0, 0, 0.26667],
    "107": [0, 0.69444, 0, 0, 0.48889],
    "108": [0, 0.69444, 0, 0, 0.23889],
    "109": [0, 0.44444, 0, 0, 0.79445],
    "110": [0, 0.44444, 0, 0, 0.51667],
    "111": [0, 0.44444, 0, 0, 0.5],
    "112": [0.19444, 0.44444, 0, 0, 0.51667],
    "113": [0.19444, 0.44444, 0, 0, 0.51667],
    "114": [0, 0.44444, 0.01389, 0, 0.34167],
    "115": [0, 0.44444, 0, 0, 0.38333],
    "116": [0, 0.57143, 0, 0, 0.36111],
    "117": [0, 0.44444, 0, 0, 0.51667],
    "118": [0, 0.44444, 0.01389, 0, 0.46111],
    "119": [0, 0.44444, 0.01389, 0, 0.68334],
    "120": [0, 0.44444, 0, 0, 0.46111],
    "121": [0.19444, 0.44444, 0.01389, 0, 0.46111],
    "122": [0, 0.44444, 0, 0, 0.43472],
    "126": [0.35, 0.32659, 0, 0, 0.5],
    "160": [0, 0, 0, 0, 0.25],
    "168": [0, 0.67937, 0, 0, 0.5],
    "176": [0, 0.69444, 0, 0, 0.66667],
    "184": [0.17014, 0, 0, 0, 0.44445],
    "305": [0, 0.44444, 0, 0, 0.23889],
    "567": [0.19444, 0.44444, 0, 0, 0.26667],
    "710": [0, 0.69444, 0, 0, 0.5],
    "711": [0, 0.63194, 0, 0, 0.5],
    "713": [0, 0.60889, 0, 0, 0.5],
    "714": [0, 0.69444, 0, 0, 0.5],
    "715": [0, 0.69444, 0, 0, 0.5],
    "728": [0, 0.69444, 0, 0, 0.5],
    "729": [0, 0.67937, 0, 0, 0.27778],
    "730": [0, 0.69444, 0, 0, 0.66667],
    "732": [0, 0.67659, 0, 0, 0.5],
    "733": [0, 0.69444, 0, 0, 0.5],
    "915": [0, 0.69444, 0, 0, 0.54167],
    "916": [0, 0.69444, 0, 0, 0.83334],
    "920": [0, 0.69444, 0, 0, 0.77778],
    "923": [0, 0.69444, 0, 0, 0.61111],
    "926": [0, 0.69444, 0, 0, 0.66667],
    "928": [0, 0.69444, 0, 0, 0.70834],
    "931": [0, 0.69444, 0, 0, 0.72222],
    "933": [0, 0.69444, 0, 0, 0.77778],
    "934": [0, 0.69444, 0, 0, 0.72222],
    "936": [0, 0.69444, 0, 0, 0.77778],
    "937": [0, 0.69444, 0, 0, 0.72222],
    "8211": [0, 0.44444, 0.02778, 0, 0.5],
    "8212": [0, 0.44444, 0.02778, 0, 1],
    "8216": [0, 0.69444, 0, 0, 0.27778],
    "8217": [0, 0.69444, 0, 0, 0.27778],
    "8220": [0, 0.69444, 0, 0, 0.5],
    "8221": [0, 0.69444, 0, 0, 0.5]
  },
  "Script-Regular": {
    "32": [0, 0, 0, 0, 0.25],
    "65": [0, 0.7, 0.22925, 0, 0.80253],
    "66": [0, 0.7, 0.04087, 0, 0.90757],
    "67": [0, 0.7, 0.1689, 0, 0.66619],
    "68": [0, 0.7, 0.09371, 0, 0.77443],
    "69": [0, 0.7, 0.18583, 0, 0.56162],
    "70": [0, 0.7, 0.13634, 0, 0.89544],
    "71": [0, 0.7, 0.17322, 0, 0.60961],
    "72": [0, 0.7, 0.29694, 0, 0.96919],
    "73": [0, 0.7, 0.19189, 0, 0.80907],
    "74": [0.27778, 0.7, 0.19189, 0, 1.05159],
    "75": [0, 0.7, 0.31259, 0, 0.91364],
    "76": [0, 0.7, 0.19189, 0, 0.87373],
    "77": [0, 0.7, 0.15981, 0, 1.08031],
    "78": [0, 0.7, 0.3525, 0, 0.9015],
    "79": [0, 0.7, 0.08078, 0, 0.73787],
    "80": [0, 0.7, 0.08078, 0, 1.01262],
    "81": [0, 0.7, 0.03305, 0, 0.88282],
    "82": [0, 0.7, 0.06259, 0, 0.85],
    "83": [0, 0.7, 0.19189, 0, 0.86767],
    "84": [0, 0.7, 0.29087, 0, 0.74697],
    "85": [0, 0.7, 0.25815, 0, 0.79996],
    "86": [0, 0.7, 0.27523, 0, 0.62204],
    "87": [0, 0.7, 0.27523, 0, 0.80532],
    "88": [0, 0.7, 0.26006, 0, 0.94445],
    "89": [0, 0.7, 0.2939, 0, 0.70961],
    "90": [0, 0.7, 0.24037, 0, 0.8212],
    "160": [0, 0, 0, 0, 0.25]
  },
  "Size1-Regular": {
    "32": [0, 0, 0, 0, 0.25],
    "40": [0.35001, 0.85, 0, 0, 0.45834],
    "41": [0.35001, 0.85, 0, 0, 0.45834],
    "47": [0.35001, 0.85, 0, 0, 0.57778],
    "91": [0.35001, 0.85, 0, 0, 0.41667],
    "92": [0.35001, 0.85, 0, 0, 0.57778],
    "93": [0.35001, 0.85, 0, 0, 0.41667],
    "123": [0.35001, 0.85, 0, 0, 0.58334],
    "125": [0.35001, 0.85, 0, 0, 0.58334],
    "160": [0, 0, 0, 0, 0.25],
    "710": [0, 0.72222, 0, 0, 0.55556],
    "732": [0, 0.72222, 0, 0, 0.55556],
    "770": [0, 0.72222, 0, 0, 0.55556],
    "771": [0, 0.72222, 0, 0, 0.55556],
    "8214": [-99e-5, 0.601, 0, 0, 0.77778],
    "8593": [1e-5, 0.6, 0, 0, 0.66667],
    "8595": [1e-5, 0.6, 0, 0, 0.66667],
    "8657": [1e-5, 0.6, 0, 0, 0.77778],
    "8659": [1e-5, 0.6, 0, 0, 0.77778],
    "8719": [0.25001, 0.75, 0, 0, 0.94445],
    "8720": [0.25001, 0.75, 0, 0, 0.94445],
    "8721": [0.25001, 0.75, 0, 0, 1.05556],
    "8730": [0.35001, 0.85, 0, 0, 1],
    "8739": [-599e-5, 0.606, 0, 0, 0.33333],
    "8741": [-599e-5, 0.606, 0, 0, 0.55556],
    "8747": [0.30612, 0.805, 0.19445, 0, 0.47222],
    "8748": [0.306, 0.805, 0.19445, 0, 0.47222],
    "8749": [0.306, 0.805, 0.19445, 0, 0.47222],
    "8750": [0.30612, 0.805, 0.19445, 0, 0.47222],
    "8896": [0.25001, 0.75, 0, 0, 0.83334],
    "8897": [0.25001, 0.75, 0, 0, 0.83334],
    "8898": [0.25001, 0.75, 0, 0, 0.83334],
    "8899": [0.25001, 0.75, 0, 0, 0.83334],
    "8968": [0.35001, 0.85, 0, 0, 0.47222],
    "8969": [0.35001, 0.85, 0, 0, 0.47222],
    "8970": [0.35001, 0.85, 0, 0, 0.47222],
    "8971": [0.35001, 0.85, 0, 0, 0.47222],
    "9168": [-99e-5, 0.601, 0, 0, 0.66667],
    "10216": [0.35001, 0.85, 0, 0, 0.47222],
    "10217": [0.35001, 0.85, 0, 0, 0.47222],
    "10752": [0.25001, 0.75, 0, 0, 1.11111],
    "10753": [0.25001, 0.75, 0, 0, 1.11111],
    "10754": [0.25001, 0.75, 0, 0, 1.11111],
    "10756": [0.25001, 0.75, 0, 0, 0.83334],
    "10758": [0.25001, 0.75, 0, 0, 0.83334]
  },
  "Size2-Regular": {
    "32": [0, 0, 0, 0, 0.25],
    "40": [0.65002, 1.15, 0, 0, 0.59722],
    "41": [0.65002, 1.15, 0, 0, 0.59722],
    "47": [0.65002, 1.15, 0, 0, 0.81111],
    "91": [0.65002, 1.15, 0, 0, 0.47222],
    "92": [0.65002, 1.15, 0, 0, 0.81111],
    "93": [0.65002, 1.15, 0, 0, 0.47222],
    "123": [0.65002, 1.15, 0, 0, 0.66667],
    "125": [0.65002, 1.15, 0, 0, 0.66667],
    "160": [0, 0, 0, 0, 0.25],
    "710": [0, 0.75, 0, 0, 1],
    "732": [0, 0.75, 0, 0, 1],
    "770": [0, 0.75, 0, 0, 1],
    "771": [0, 0.75, 0, 0, 1],
    "8719": [0.55001, 1.05, 0, 0, 1.27778],
    "8720": [0.55001, 1.05, 0, 0, 1.27778],
    "8721": [0.55001, 1.05, 0, 0, 1.44445],
    "8730": [0.65002, 1.15, 0, 0, 1],
    "8747": [0.86225, 1.36, 0.44445, 0, 0.55556],
    "8748": [0.862, 1.36, 0.44445, 0, 0.55556],
    "8749": [0.862, 1.36, 0.44445, 0, 0.55556],
    "8750": [0.86225, 1.36, 0.44445, 0, 0.55556],
    "8896": [0.55001, 1.05, 0, 0, 1.11111],
    "8897": [0.55001, 1.05, 0, 0, 1.11111],
    "8898": [0.55001, 1.05, 0, 0, 1.11111],
    "8899": [0.55001, 1.05, 0, 0, 1.11111],
    "8968": [0.65002, 1.15, 0, 0, 0.52778],
    "8969": [0.65002, 1.15, 0, 0, 0.52778],
    "8970": [0.65002, 1.15, 0, 0, 0.52778],
    "8971": [0.65002, 1.15, 0, 0, 0.52778],
    "10216": [0.65002, 1.15, 0, 0, 0.61111],
    "10217": [0.65002, 1.15, 0, 0, 0.61111],
    "10752": [0.55001, 1.05, 0, 0, 1.51112],
    "10753": [0.55001, 1.05, 0, 0, 1.51112],
    "10754": [0.55001, 1.05, 0, 0, 1.51112],
    "10756": [0.55001, 1.05, 0, 0, 1.11111],
    "10758": [0.55001, 1.05, 0, 0, 1.11111]
  },
  "Size3-Regular": {
    "32": [0, 0, 0, 0, 0.25],
    "40": [0.95003, 1.45, 0, 0, 0.73611],
    "41": [0.95003, 1.45, 0, 0, 0.73611],
    "47": [0.95003, 1.45, 0, 0, 1.04445],
    "91": [0.95003, 1.45, 0, 0, 0.52778],
    "92": [0.95003, 1.45, 0, 0, 1.04445],
    "93": [0.95003, 1.45, 0, 0, 0.52778],
    "123": [0.95003, 1.45, 0, 0, 0.75],
    "125": [0.95003, 1.45, 0, 0, 0.75],
    "160": [0, 0, 0, 0, 0.25],
    "710": [0, 0.75, 0, 0, 1.44445],
    "732": [0, 0.75, 0, 0, 1.44445],
    "770": [0, 0.75, 0, 0, 1.44445],
    "771": [0, 0.75, 0, 0, 1.44445],
    "8730": [0.95003, 1.45, 0, 0, 1],
    "8968": [0.95003, 1.45, 0, 0, 0.58334],
    "8969": [0.95003, 1.45, 0, 0, 0.58334],
    "8970": [0.95003, 1.45, 0, 0, 0.58334],
    "8971": [0.95003, 1.45, 0, 0, 0.58334],
    "10216": [0.95003, 1.45, 0, 0, 0.75],
    "10217": [0.95003, 1.45, 0, 0, 0.75]
  },
  "Size4-Regular": {
    "32": [0, 0, 0, 0, 0.25],
    "40": [1.25003, 1.75, 0, 0, 0.79167],
    "41": [1.25003, 1.75, 0, 0, 0.79167],
    "47": [1.25003, 1.75, 0, 0, 1.27778],
    "91": [1.25003, 1.75, 0, 0, 0.58334],
    "92": [1.25003, 1.75, 0, 0, 1.27778],
    "93": [1.25003, 1.75, 0, 0, 0.58334],
    "123": [1.25003, 1.75, 0, 0, 0.80556],
    "125": [1.25003, 1.75, 0, 0, 0.80556],
    "160": [0, 0, 0, 0, 0.25],
    "710": [0, 0.825, 0, 0, 1.8889],
    "732": [0, 0.825, 0, 0, 1.8889],
    "770": [0, 0.825, 0, 0, 1.8889],
    "771": [0, 0.825, 0, 0, 1.8889],
    "8730": [1.25003, 1.75, 0, 0, 1],
    "8968": [1.25003, 1.75, 0, 0, 0.63889],
    "8969": [1.25003, 1.75, 0, 0, 0.63889],
    "8970": [1.25003, 1.75, 0, 0, 0.63889],
    "8971": [1.25003, 1.75, 0, 0, 0.63889],
    "9115": [0.64502, 1.155, 0, 0, 0.875],
    "9116": [1e-5, 0.6, 0, 0, 0.875],
    "9117": [0.64502, 1.155, 0, 0, 0.875],
    "9118": [0.64502, 1.155, 0, 0, 0.875],
    "9119": [1e-5, 0.6, 0, 0, 0.875],
    "9120": [0.64502, 1.155, 0, 0, 0.875],
    "9121": [0.64502, 1.155, 0, 0, 0.66667],
    "9122": [-99e-5, 0.601, 0, 0, 0.66667],
    "9123": [0.64502, 1.155, 0, 0, 0.66667],
    "9124": [0.64502, 1.155, 0, 0, 0.66667],
    "9125": [-99e-5, 0.601, 0, 0, 0.66667],
    "9126": [0.64502, 1.155, 0, 0, 0.66667],
    "9127": [1e-5, 0.9, 0, 0, 0.88889],
    "9128": [0.65002, 1.15, 0, 0, 0.88889],
    "9129": [0.90001, 0, 0, 0, 0.88889],
    "9130": [0, 0.3, 0, 0, 0.88889],
    "9131": [1e-5, 0.9, 0, 0, 0.88889],
    "9132": [0.65002, 1.15, 0, 0, 0.88889],
    "9133": [0.90001, 0, 0, 0, 0.88889],
    "9143": [0.88502, 0.915, 0, 0, 1.05556],
    "10216": [1.25003, 1.75, 0, 0, 0.80556],
    "10217": [1.25003, 1.75, 0, 0, 0.80556],
    "57344": [-499e-5, 0.605, 0, 0, 1.05556],
    "57345": [-499e-5, 0.605, 0, 0, 1.05556],
    "57680": [0, 0.12, 0, 0, 0.45],
    "57681": [0, 0.12, 0, 0, 0.45],
    "57682": [0, 0.12, 0, 0, 0.45],
    "57683": [0, 0.12, 0, 0, 0.45]
  },
  "Typewriter-Regular": {
    "32": [0, 0, 0, 0, 0.525],
    "33": [0, 0.61111, 0, 0, 0.525],
    "34": [0, 0.61111, 0, 0, 0.525],
    "35": [0, 0.61111, 0, 0, 0.525],
    "36": [0.08333, 0.69444, 0, 0, 0.525],
    "37": [0.08333, 0.69444, 0, 0, 0.525],
    "38": [0, 0.61111, 0, 0, 0.525],
    "39": [0, 0.61111, 0, 0, 0.525],
    "40": [0.08333, 0.69444, 0, 0, 0.525],
    "41": [0.08333, 0.69444, 0, 0, 0.525],
    "42": [0, 0.52083, 0, 0, 0.525],
    "43": [-0.08056, 0.53055, 0, 0, 0.525],
    "44": [0.13889, 0.125, 0, 0, 0.525],
    "45": [-0.08056, 0.53055, 0, 0, 0.525],
    "46": [0, 0.125, 0, 0, 0.525],
    "47": [0.08333, 0.69444, 0, 0, 0.525],
    "48": [0, 0.61111, 0, 0, 0.525],
    "49": [0, 0.61111, 0, 0, 0.525],
    "50": [0, 0.61111, 0, 0, 0.525],
    "51": [0, 0.61111, 0, 0, 0.525],
    "52": [0, 0.61111, 0, 0, 0.525],
    "53": [0, 0.61111, 0, 0, 0.525],
    "54": [0, 0.61111, 0, 0, 0.525],
    "55": [0, 0.61111, 0, 0, 0.525],
    "56": [0, 0.61111, 0, 0, 0.525],
    "57": [0, 0.61111, 0, 0, 0.525],
    "58": [0, 0.43056, 0, 0, 0.525],
    "59": [0.13889, 0.43056, 0, 0, 0.525],
    "60": [-0.05556, 0.55556, 0, 0, 0.525],
    "61": [-0.19549, 0.41562, 0, 0, 0.525],
    "62": [-0.05556, 0.55556, 0, 0, 0.525],
    "63": [0, 0.61111, 0, 0, 0.525],
    "64": [0, 0.61111, 0, 0, 0.525],
    "65": [0, 0.61111, 0, 0, 0.525],
    "66": [0, 0.61111, 0, 0, 0.525],
    "67": [0, 0.61111, 0, 0, 0.525],
    "68": [0, 0.61111, 0, 0, 0.525],
    "69": [0, 0.61111, 0, 0, 0.525],
    "70": [0, 0.61111, 0, 0, 0.525],
    "71": [0, 0.61111, 0, 0, 0.525],
    "72": [0, 0.61111, 0, 0, 0.525],
    "73": [0, 0.61111, 0, 0, 0.525],
    "74": [0, 0.61111, 0, 0, 0.525],
    "75": [0, 0.61111, 0, 0, 0.525],
    "76": [0, 0.61111, 0, 0, 0.525],
    "77": [0, 0.61111, 0, 0, 0.525],
    "78": [0, 0.61111, 0, 0, 0.525],
    "79": [0, 0.61111, 0, 0, 0.525],
    "80": [0, 0.61111, 0, 0, 0.525],
    "81": [0.13889, 0.61111, 0, 0, 0.525],
    "82": [0, 0.61111, 0, 0, 0.525],
    "83": [0, 0.61111, 0, 0, 0.525],
    "84": [0, 0.61111, 0, 0, 0.525],
    "85": [0, 0.61111, 0, 0, 0.525],
    "86": [0, 0.61111, 0, 0, 0.525],
    "87": [0, 0.61111, 0, 0, 0.525],
    "88": [0, 0.61111, 0, 0, 0.525],
    "89": [0, 0.61111, 0, 0, 0.525],
    "90": [0, 0.61111, 0, 0, 0.525],
    "91": [0.08333, 0.69444, 0, 0, 0.525],
    "92": [0.08333, 0.69444, 0, 0, 0.525],
    "93": [0.08333, 0.69444, 0, 0, 0.525],
    "94": [0, 0.61111, 0, 0, 0.525],
    "95": [0.09514, 0, 0, 0, 0.525],
    "96": [0, 0.61111, 0, 0, 0.525],
    "97": [0, 0.43056, 0, 0, 0.525],
    "98": [0, 0.61111, 0, 0, 0.525],
    "99": [0, 0.43056, 0, 0, 0.525],
    "100": [0, 0.61111, 0, 0, 0.525],
    "101": [0, 0.43056, 0, 0, 0.525],
    "102": [0, 0.61111, 0, 0, 0.525],
    "103": [0.22222, 0.43056, 0, 0, 0.525],
    "104": [0, 0.61111, 0, 0, 0.525],
    "105": [0, 0.61111, 0, 0, 0.525],
    "106": [0.22222, 0.61111, 0, 0, 0.525],
    "107": [0, 0.61111, 0, 0, 0.525],
    "108": [0, 0.61111, 0, 0, 0.525],
    "109": [0, 0.43056, 0, 0, 0.525],
    "110": [0, 0.43056, 0, 0, 0.525],
    "111": [0, 0.43056, 0, 0, 0.525],
    "112": [0.22222, 0.43056, 0, 0, 0.525],
    "113": [0.22222, 0.43056, 0, 0, 0.525],
    "114": [0, 0.43056, 0, 0, 0.525],
    "115": [0, 0.43056, 0, 0, 0.525],
    "116": [0, 0.55358, 0, 0, 0.525],
    "117": [0, 0.43056, 0, 0, 0.525],
    "118": [0, 0.43056, 0, 0, 0.525],
    "119": [0, 0.43056, 0, 0, 0.525],
    "120": [0, 0.43056, 0, 0, 0.525],
    "121": [0.22222, 0.43056, 0, 0, 0.525],
    "122": [0, 0.43056, 0, 0, 0.525],
    "123": [0.08333, 0.69444, 0, 0, 0.525],
    "124": [0.08333, 0.69444, 0, 0, 0.525],
    "125": [0.08333, 0.69444, 0, 0, 0.525],
    "126": [0, 0.61111, 0, 0, 0.525],
    "127": [0, 0.61111, 0, 0, 0.525],
    "160": [0, 0, 0, 0, 0.525],
    "176": [0, 0.61111, 0, 0, 0.525],
    "184": [0.19445, 0, 0, 0, 0.525],
    "305": [0, 0.43056, 0, 0, 0.525],
    "567": [0.22222, 0.43056, 0, 0, 0.525],
    "711": [0, 0.56597, 0, 0, 0.525],
    "713": [0, 0.56555, 0, 0, 0.525],
    "714": [0, 0.61111, 0, 0, 0.525],
    "715": [0, 0.61111, 0, 0, 0.525],
    "728": [0, 0.61111, 0, 0, 0.525],
    "730": [0, 0.61111, 0, 0, 0.525],
    "770": [0, 0.61111, 0, 0, 0.525],
    "771": [0, 0.61111, 0, 0, 0.525],
    "776": [0, 0.61111, 0, 0, 0.525],
    "915": [0, 0.61111, 0, 0, 0.525],
    "916": [0, 0.61111, 0, 0, 0.525],
    "920": [0, 0.61111, 0, 0, 0.525],
    "923": [0, 0.61111, 0, 0, 0.525],
    "926": [0, 0.61111, 0, 0, 0.525],
    "928": [0, 0.61111, 0, 0, 0.525],
    "931": [0, 0.61111, 0, 0, 0.525],
    "933": [0, 0.61111, 0, 0, 0.525],
    "934": [0, 0.61111, 0, 0, 0.525],
    "936": [0, 0.61111, 0, 0, 0.525],
    "937": [0, 0.61111, 0, 0, 0.525],
    "8216": [0, 0.61111, 0, 0, 0.525],
    "8217": [0, 0.61111, 0, 0, 0.525],
    "8242": [0, 0.61111, 0, 0, 0.525],
    "9251": [0.11111, 0.21944, 0, 0, 0.525]
  }
};
var sigmasAndXis = {
  slant: [0.25, 0.25, 0.25],
  // sigma1
  space: [0, 0, 0],
  // sigma2
  stretch: [0, 0, 0],
  // sigma3
  shrink: [0, 0, 0],
  // sigma4
  xHeight: [0.431, 0.431, 0.431],
  // sigma5
  quad: [1, 1.171, 1.472],
  // sigma6
  extraSpace: [0, 0, 0],
  // sigma7
  num1: [0.677, 0.732, 0.925],
  // sigma8
  num2: [0.394, 0.384, 0.387],
  // sigma9
  num3: [0.444, 0.471, 0.504],
  // sigma10
  denom1: [0.686, 0.752, 1.025],
  // sigma11
  denom2: [0.345, 0.344, 0.532],
  // sigma12
  sup1: [0.413, 0.503, 0.504],
  // sigma13
  sup2: [0.363, 0.431, 0.404],
  // sigma14
  sup3: [0.289, 0.286, 0.294],
  // sigma15
  sub1: [0.15, 0.143, 0.2],
  // sigma16
  sub2: [0.247, 0.286, 0.4],
  // sigma17
  supDrop: [0.386, 0.353, 0.494],
  // sigma18
  subDrop: [0.05, 0.071, 0.1],
  // sigma19
  delim1: [2.39, 1.7, 1.98],
  // sigma20
  delim2: [1.01, 1.157, 1.42],
  // sigma21
  axisHeight: [0.25, 0.25, 0.25],
  // sigma22
  // These font metrics are extracted from TeX by using tftopl on cmex10.tfm;
  // they correspond to the font parameters of the extension fonts (family 3).
  // See the TeXbook, page 441. In AMSTeX, the extension fonts scale; to
  // match cmex7, we'd use cmex7.tfm values for script and scriptscript
  // values.
  defaultRuleThickness: [0.04, 0.049, 0.049],
  // xi8; cmex7: 0.049
  bigOpSpacing1: [0.111, 0.111, 0.111],
  // xi9
  bigOpSpacing2: [0.166, 0.166, 0.166],
  // xi10
  bigOpSpacing3: [0.2, 0.2, 0.2],
  // xi11
  bigOpSpacing4: [0.6, 0.611, 0.611],
  // xi12; cmex7: 0.611
  bigOpSpacing5: [0.1, 0.143, 0.143],
  // xi13; cmex7: 0.143
  // The \sqrt rule width is taken from the height of the surd character.
  // Since we use the same font at all sizes, this thickness doesn't scale.
  sqrtRuleThickness: [0.04, 0.04, 0.04],
  // This value determines how large a pt is, for metrics which are defined
  // in terms of pts.
  // This value is also used in katex.scss; if you change it make sure the
  // values match.
  ptPerEm: [10, 10, 10],
  // The space between adjacent `|` columns in an array definition. From
  // `\showthe\doublerulesep` in LaTeX. Equals 2.0 / ptPerEm.
  doubleRuleSep: [0.2, 0.2, 0.2],
  // The width of separator lines in {array} environments. From
  // `\showthe\arrayrulewidth` in LaTeX. Equals 0.4 / ptPerEm.
  arrayRuleWidth: [0.04, 0.04, 0.04],
  // Two values from LaTeX source2e:
  fboxsep: [0.3, 0.3, 0.3],
  //        3 pt / ptPerEm
  fboxrule: [0.04, 0.04, 0.04]
  // 0.4 pt / ptPerEm
};
var extraCharacterMap = {
  // Latin-1
  "Å": "A",
  "Ð": "D",
  "Þ": "o",
  "å": "a",
  "ð": "d",
  "þ": "o",
  // Cyrillic
  "А": "A",
  "Б": "B",
  "В": "B",
  "Г": "F",
  "Д": "A",
  "Е": "E",
  "Ж": "K",
  "З": "3",
  "И": "N",
  "Й": "N",
  "К": "K",
  "Л": "N",
  "М": "M",
  "Н": "H",
  "О": "O",
  "П": "N",
  "Р": "P",
  "С": "C",
  "Т": "T",
  "У": "y",
  "Ф": "O",
  "Х": "X",
  "Ц": "U",
  "Ч": "h",
  "Ш": "W",
  "Щ": "W",
  "Ъ": "B",
  "Ы": "X",
  "Ь": "B",
  "Э": "3",
  "Ю": "X",
  "Я": "R",
  "а": "a",
  "б": "b",
  "в": "a",
  "г": "r",
  "д": "y",
  "е": "e",
  "ж": "m",
  "з": "e",
  "и": "n",
  "й": "n",
  "к": "n",
  "л": "n",
  "м": "m",
  "н": "n",
  "о": "o",
  "п": "n",
  "р": "p",
  "с": "c",
  "т": "o",
  "у": "y",
  "ф": "b",
  "х": "x",
  "ц": "n",
  "ч": "n",
  "ш": "w",
  "щ": "w",
  "ъ": "a",
  "ы": "m",
  "ь": "a",
  "э": "e",
  "ю": "m",
  "я": "r"
};
function setFontMetrics(fontName, metrics) {
  fontMetricsData[fontName] = metrics;
}
function getCharacterMetrics(character, font, mode) {
  if (!fontMetricsData[font]) {
    throw new Error("Font metrics not found for font: " + font + ".");
  }
  var ch = character.charCodeAt(0);
  var metrics = fontMetricsData[font][ch];
  if (!metrics && character[0] in extraCharacterMap) {
    ch = extraCharacterMap[character[0]].charCodeAt(0);
    metrics = fontMetricsData[font][ch];
  }
  if (!metrics && mode === "text") {
    if (supportedCodepoint(ch)) {
      metrics = fontMetricsData[font][77];
    }
  }
  if (metrics) {
    return {
      depth: metrics[0],
      height: metrics[1],
      italic: metrics[2],
      skew: metrics[3],
      width: metrics[4]
    };
  }
}
var fontMetricsBySizeIndex = {};
function getGlobalMetrics(size) {
  var sizeIndex;
  if (size >= 5) {
    sizeIndex = 0;
  } else if (size >= 3) {
    sizeIndex = 1;
  } else {
    sizeIndex = 2;
  }
  if (!fontMetricsBySizeIndex[sizeIndex]) {
    var metrics = fontMetricsBySizeIndex[sizeIndex] = {
      cssEmPerMu: sigmasAndXis.quad[sizeIndex] / 18
    };
    for (var key in sigmasAndXis) {
      if (sigmasAndXis.hasOwnProperty(key)) {
        metrics[key] = sigmasAndXis[key][sizeIndex];
      }
    }
  }
  return fontMetricsBySizeIndex[sizeIndex];
}
var sizeStyleMap = [
  // Each element contains [textsize, scriptsize, scriptscriptsize].
  // The size mappings are taken from TeX with \normalsize=10pt.
  [1, 1, 1],
  // size1: [5, 5, 5]              \tiny
  [2, 1, 1],
  // size2: [6, 5, 5]
  [3, 1, 1],
  // size3: [7, 5, 5]              \scriptsize
  [4, 2, 1],
  // size4: [8, 6, 5]              \footnotesize
  [5, 2, 1],
  // size5: [9, 6, 5]              \small
  [6, 3, 1],
  // size6: [10, 7, 5]             \normalsize
  [7, 4, 2],
  // size7: [12, 8, 6]             \large
  [8, 6, 3],
  // size8: [14.4, 10, 7]          \Large
  [9, 7, 6],
  // size9: [17.28, 12, 10]        \LARGE
  [10, 8, 7],
  // size10: [20.74, 14.4, 12]     \huge
  [11, 10, 9]
  // size11: [24.88, 20.74, 17.28] \HUGE
];
var sizeMultipliers = [
  // fontMetrics.js:getGlobalMetrics also uses size indexes, so if
  // you change size indexes, change that function.
  0.5,
  0.6,
  0.7,
  0.8,
  0.9,
  1,
  1.2,
  1.44,
  1.728,
  2.074,
  2.488
];
var sizeAtStyle = function sizeAtStyle2(size, style) {
  return style.size < 2 ? size : sizeStyleMap[size - 1][style.size - 1];
};
class Options {
  // A font family applies to a group of fonts (i.e. SansSerif), while a font
  // represents a specific font (i.e. SansSerif Bold).
  // See: https://tex.stackexchange.com/questions/22350/difference-between-textrm-and-mathrm
  /**
   * The base size index.
   */
  constructor(data) {
    this.style = void 0;
    this.color = void 0;
    this.size = void 0;
    this.textSize = void 0;
    this.phantom = void 0;
    this.font = void 0;
    this.fontFamily = void 0;
    this.fontWeight = void 0;
    this.fontShape = void 0;
    this.sizeMultiplier = void 0;
    this.maxSize = void 0;
    this.minRuleThickness = void 0;
    this._fontMetrics = void 0;
    this.style = data.style;
    this.color = data.color;
    this.size = data.size || Options.BASESIZE;
    this.textSize = data.textSize || this.size;
    this.phantom = !!data.phantom;
    this.font = data.font || "";
    this.fontFamily = data.fontFamily || "";
    this.fontWeight = data.fontWeight || "";
    this.fontShape = data.fontShape || "";
    this.sizeMultiplier = sizeMultipliers[this.size - 1];
    this.maxSize = data.maxSize;
    this.minRuleThickness = data.minRuleThickness;
    this._fontMetrics = void 0;
  }
  /**
   * Returns a new options object with the same properties as "this".  Properties
   * from "extension" will be copied to the new options object.
   */
  extend(extension) {
    var data = {
      style: this.style,
      size: this.size,
      textSize: this.textSize,
      color: this.color,
      phantom: this.phantom,
      font: this.font,
      fontFamily: this.fontFamily,
      fontWeight: this.fontWeight,
      fontShape: this.fontShape,
      maxSize: this.maxSize,
      minRuleThickness: this.minRuleThickness
    };
    for (var key in extension) {
      if (extension.hasOwnProperty(key)) {
        data[key] = extension[key];
      }
    }
    return new Options(data);
  }
  /**
   * Return an options object with the given style. If `this.style === style`,
   * returns `this`.
   */
  havingStyle(style) {
    if (this.style === style) {
      return this;
    } else {
      return this.extend({
        style,
        size: sizeAtStyle(this.textSize, style)
      });
    }
  }
  /**
   * Return an options object with a cramped version of the current style. If
   * the current style is cramped, returns `this`.
   */
  havingCrampedStyle() {
    return this.havingStyle(this.style.cramp());
  }
  /**
   * Return an options object with the given size and in at least `\textstyle`.
   * Returns `this` if appropriate.
   */
  havingSize(size) {
    if (this.size === size && this.textSize === size) {
      return this;
    } else {
      return this.extend({
        style: this.style.text(),
        size,
        textSize: size,
        sizeMultiplier: sizeMultipliers[size - 1]
      });
    }
  }
  /**
   * Like `this.havingSize(BASESIZE).havingStyle(style)`. If `style` is omitted,
   * changes to at least `\textstyle`.
   */
  havingBaseStyle(style) {
    style = style || this.style.text();
    var wantSize = sizeAtStyle(Options.BASESIZE, style);
    if (this.size === wantSize && this.textSize === Options.BASESIZE && this.style === style) {
      return this;
    } else {
      return this.extend({
        style,
        size: wantSize
      });
    }
  }
  /**
   * Remove the effect of sizing changes such as \Huge.
   * Keep the effect of the current style, such as \scriptstyle.
   */
  havingBaseSizing() {
    var size;
    switch (this.style.id) {
      case 4:
      case 5:
        size = 3;
        break;
      case 6:
      case 7:
        size = 1;
        break;
      default:
        size = 6;
    }
    return this.extend({
      style: this.style.text(),
      size
    });
  }
  /**
   * Create a new options object with the given color.
   */
  withColor(color) {
    return this.extend({
      color
    });
  }
  /**
   * Create a new options object with "phantom" set to true.
   */
  withPhantom() {
    return this.extend({
      phantom: true
    });
  }
  /**
   * Creates a new options object with the given math font or old text font.
   * @type {[type]}
   */
  withFont(font) {
    return this.extend({
      font
    });
  }
  /**
   * Create a new options objects with the given fontFamily.
   */
  withTextFontFamily(fontFamily) {
    return this.extend({
      fontFamily,
      font: ""
    });
  }
  /**
   * Creates a new options object with the given font weight
   */
  withTextFontWeight(fontWeight) {
    return this.extend({
      fontWeight,
      font: ""
    });
  }
  /**
   * Creates a new options object with the given font weight
   */
  withTextFontShape(fontShape) {
    return this.extend({
      fontShape,
      font: ""
    });
  }
  /**
   * Return the CSS sizing classes required to switch from enclosing options
   * `oldOptions` to `this`. Returns an array of classes.
   */
  sizingClasses(oldOptions) {
    if (oldOptions.size !== this.size) {
      return ["sizing", "reset-size" + oldOptions.size, "size" + this.size];
    } else {
      return [];
    }
  }
  /**
   * Return the CSS sizing classes required to switch to the base size. Like
   * `this.havingSize(BASESIZE).sizingClasses(this)`.
   */
  baseSizingClasses() {
    if (this.size !== Options.BASESIZE) {
      return ["sizing", "reset-size" + this.size, "size" + Options.BASESIZE];
    } else {
      return [];
    }
  }
  /**
   * Return the font metrics for this size.
   */
  fontMetrics() {
    if (!this._fontMetrics) {
      this._fontMetrics = getGlobalMetrics(this.size);
    }
    return this._fontMetrics;
  }
  /**
   * Gets the CSS color of the current options object
   */
  getColor() {
    if (this.phantom) {
      return "transparent";
    } else {
      return this.color;
    }
  }
}
Options.BASESIZE = 6;
var ptPerUnit = {
  // https://en.wikibooks.org/wiki/LaTeX/Lengths and
  // https://tex.stackexchange.com/a/8263
  "pt": 1,
  // TeX point
  "mm": 7227 / 2540,
  // millimeter
  "cm": 7227 / 254,
  // centimeter
  "in": 72.27,
  // inch
  "bp": 803 / 800,
  // big (PostScript) points
  "pc": 12,
  // pica
  "dd": 1238 / 1157,
  // didot
  "cc": 14856 / 1157,
  // cicero (12 didot)
  "nd": 685 / 642,
  // new didot
  "nc": 1370 / 107,
  // new cicero (12 new didot)
  "sp": 1 / 65536,
  // scaled point (TeX's internal smallest unit)
  // https://tex.stackexchange.com/a/41371
  "px": 803 / 800
  // \pdfpxdimen defaults to 1 bp in pdfTeX and LuaTeX
};
var relativeUnit = {
  "ex": true,
  "em": true,
  "mu": true
};
var validUnit = function validUnit2(unit) {
  if (typeof unit !== "string") {
    unit = unit.unit;
  }
  return unit in ptPerUnit || unit in relativeUnit || unit === "ex";
};
var calculateSize = function calculateSize2(sizeValue, options) {
  var scale;
  if (sizeValue.unit in ptPerUnit) {
    scale = ptPerUnit[sizeValue.unit] / options.fontMetrics().ptPerEm / options.sizeMultiplier;
  } else if (sizeValue.unit === "mu") {
    scale = options.fontMetrics().cssEmPerMu;
  } else {
    var unitOptions;
    if (options.style.isTight()) {
      unitOptions = options.havingStyle(options.style.text());
    } else {
      unitOptions = options;
    }
    if (sizeValue.unit === "ex") {
      scale = unitOptions.fontMetrics().xHeight;
    } else if (sizeValue.unit === "em") {
      scale = unitOptions.fontMetrics().quad;
    } else {
      throw new ParseError("Invalid unit: '" + sizeValue.unit + "'");
    }
    if (unitOptions !== options) {
      scale *= unitOptions.sizeMultiplier / options.sizeMultiplier;
    }
  }
  return Math.min(sizeValue.number * scale, options.maxSize);
};
var makeEm = function makeEm2(n) {
  return +n.toFixed(4) + "em";
};
var createClass = function createClass2(classes) {
  return classes.filter((cls) => cls).join(" ");
};
var initNode = function initNode2(classes, options, style) {
  this.classes = classes || [];
  this.attributes = {};
  this.height = 0;
  this.depth = 0;
  this.maxFontSize = 0;
  this.style = style || {};
  if (options) {
    if (options.style.isTight()) {
      this.classes.push("mtight");
    }
    var color = options.getColor();
    if (color) {
      this.style.color = color;
    }
  }
};
var toNode = function toNode2(tagName) {
  var node = document.createElement(tagName);
  node.className = createClass(this.classes);
  for (var style in this.style) {
    if (this.style.hasOwnProperty(style)) {
      node.style[style] = this.style[style];
    }
  }
  for (var attr in this.attributes) {
    if (this.attributes.hasOwnProperty(attr)) {
      node.setAttribute(attr, this.attributes[attr]);
    }
  }
  for (var i = 0; i < this.children.length; i++) {
    node.appendChild(this.children[i].toNode());
  }
  return node;
};
var invalidAttributeNameRegex = /[\s"'>/=\x00-\x1f]/;
var toMarkup = function toMarkup2(tagName) {
  var markup = "<" + tagName;
  if (this.classes.length) {
    markup += ' class="' + utils.escape(createClass(this.classes)) + '"';
  }
  var styles2 = "";
  for (var style in this.style) {
    if (this.style.hasOwnProperty(style)) {
      styles2 += utils.hyphenate(style) + ":" + this.style[style] + ";";
    }
  }
  if (styles2) {
    markup += ' style="' + utils.escape(styles2) + '"';
  }
  for (var attr in this.attributes) {
    if (this.attributes.hasOwnProperty(attr)) {
      if (invalidAttributeNameRegex.test(attr)) {
        throw new ParseError("Invalid attribute name '" + attr + "'");
      }
      markup += " " + attr + '="' + utils.escape(this.attributes[attr]) + '"';
    }
  }
  markup += ">";
  for (var i = 0; i < this.children.length; i++) {
    markup += this.children[i].toMarkup();
  }
  markup += "</" + tagName + ">";
  return markup;
};
class Span {
  constructor(classes, children, options, style) {
    this.children = void 0;
    this.attributes = void 0;
    this.classes = void 0;
    this.height = void 0;
    this.depth = void 0;
    this.width = void 0;
    this.maxFontSize = void 0;
    this.style = void 0;
    initNode.call(this, classes, options, style);
    this.children = children || [];
  }
  /**
   * Sets an arbitrary attribute on the span. Warning: use this wisely. Not
   * all browsers support attributes the same, and having too many custom
   * attributes is probably bad.
   */
  setAttribute(attribute, value) {
    this.attributes[attribute] = value;
  }
  hasClass(className) {
    return this.classes.includes(className);
  }
  toNode() {
    return toNode.call(this, "span");
  }
  toMarkup() {
    return toMarkup.call(this, "span");
  }
}
class Anchor {
  constructor(href, classes, children, options) {
    this.children = void 0;
    this.attributes = void 0;
    this.classes = void 0;
    this.height = void 0;
    this.depth = void 0;
    this.maxFontSize = void 0;
    this.style = void 0;
    initNode.call(this, classes, options);
    this.children = children || [];
    this.setAttribute("href", href);
  }
  setAttribute(attribute, value) {
    this.attributes[attribute] = value;
  }
  hasClass(className) {
    return this.classes.includes(className);
  }
  toNode() {
    return toNode.call(this, "a");
  }
  toMarkup() {
    return toMarkup.call(this, "a");
  }
}
class Img {
  constructor(src, alt, style) {
    this.src = void 0;
    this.alt = void 0;
    this.classes = void 0;
    this.height = void 0;
    this.depth = void 0;
    this.maxFontSize = void 0;
    this.style = void 0;
    this.alt = alt;
    this.src = src;
    this.classes = ["mord"];
    this.style = style;
  }
  hasClass(className) {
    return this.classes.includes(className);
  }
  toNode() {
    var node = document.createElement("img");
    node.src = this.src;
    node.alt = this.alt;
    node.className = "mord";
    for (var style in this.style) {
      if (this.style.hasOwnProperty(style)) {
        node.style[style] = this.style[style];
      }
    }
    return node;
  }
  toMarkup() {
    var markup = '<img src="' + utils.escape(this.src) + '"' + (' alt="' + utils.escape(this.alt) + '"');
    var styles2 = "";
    for (var style in this.style) {
      if (this.style.hasOwnProperty(style)) {
        styles2 += utils.hyphenate(style) + ":" + this.style[style] + ";";
      }
    }
    if (styles2) {
      markup += ' style="' + utils.escape(styles2) + '"';
    }
    markup += "'/>";
    return markup;
  }
}
var iCombinations = {
  "î": "ı̂",
  "ï": "ı̈",
  "í": "ı́",
  // 'ī': '\u0131\u0304', // enable when we add Extended Latin
  "ì": "ı̀"
};
class SymbolNode {
  constructor(text2, height, depth, italic, skew, width, classes, style) {
    this.text = void 0;
    this.height = void 0;
    this.depth = void 0;
    this.italic = void 0;
    this.skew = void 0;
    this.width = void 0;
    this.maxFontSize = void 0;
    this.classes = void 0;
    this.style = void 0;
    this.text = text2;
    this.height = height || 0;
    this.depth = depth || 0;
    this.italic = italic || 0;
    this.skew = skew || 0;
    this.width = width || 0;
    this.classes = classes || [];
    this.style = style || {};
    this.maxFontSize = 0;
    var script = scriptFromCodepoint(this.text.charCodeAt(0));
    if (script) {
      this.classes.push(script + "_fallback");
    }
    if (/[îïíì]/.test(this.text)) {
      this.text = iCombinations[this.text];
    }
  }
  hasClass(className) {
    return this.classes.includes(className);
  }
  /**
   * Creates a text node or span from a symbol node. Note that a span is only
   * created if it is needed.
   */
  toNode() {
    var node = document.createTextNode(this.text);
    var span = null;
    if (this.italic > 0) {
      span = document.createElement("span");
      span.style.marginRight = makeEm(this.italic);
    }
    if (this.classes.length > 0) {
      span = span || document.createElement("span");
      span.className = createClass(this.classes);
    }
    for (var style in this.style) {
      if (this.style.hasOwnProperty(style)) {
        span = span || document.createElement("span");
        span.style[style] = this.style[style];
      }
    }
    if (span) {
      span.appendChild(node);
      return span;
    } else {
      return node;
    }
  }
  /**
   * Creates markup for a symbol node.
   */
  toMarkup() {
    var needsSpan = false;
    var markup = "<span";
    if (this.classes.length) {
      needsSpan = true;
      markup += ' class="';
      markup += utils.escape(createClass(this.classes));
      markup += '"';
    }
    var styles2 = "";
    if (this.italic > 0) {
      styles2 += "margin-right:" + this.italic + "em;";
    }
    for (var style in this.style) {
      if (this.style.hasOwnProperty(style)) {
        styles2 += utils.hyphenate(style) + ":" + this.style[style] + ";";
      }
    }
    if (styles2) {
      needsSpan = true;
      markup += ' style="' + utils.escape(styles2) + '"';
    }
    var escaped = utils.escape(this.text);
    if (needsSpan) {
      markup += ">";
      markup += escaped;
      markup += "</span>";
      return markup;
    } else {
      return escaped;
    }
  }
}
class SvgNode {
  constructor(children, attributes) {
    this.children = void 0;
    this.attributes = void 0;
    this.children = children || [];
    this.attributes = attributes || {};
  }
  toNode() {
    var svgNS = "http://www.w3.org/2000/svg";
    var node = document.createElementNS(svgNS, "svg");
    for (var attr in this.attributes) {
      if (Object.prototype.hasOwnProperty.call(this.attributes, attr)) {
        node.setAttribute(attr, this.attributes[attr]);
      }
    }
    for (var i = 0; i < this.children.length; i++) {
      node.appendChild(this.children[i].toNode());
    }
    return node;
  }
  toMarkup() {
    var markup = '<svg xmlns="http://www.w3.org/2000/svg"';
    for (var attr in this.attributes) {
      if (Object.prototype.hasOwnProperty.call(this.attributes, attr)) {
        markup += " " + attr + '="' + utils.escape(this.attributes[attr]) + '"';
      }
    }
    markup += ">";
    for (var i = 0; i < this.children.length; i++) {
      markup += this.children[i].toMarkup();
    }
    markup += "</svg>";
    return markup;
  }
}
class PathNode {
  constructor(pathName, alternate) {
    this.pathName = void 0;
    this.alternate = void 0;
    this.pathName = pathName;
    this.alternate = alternate;
  }
  toNode() {
    var svgNS = "http://www.w3.org/2000/svg";
    var node = document.createElementNS(svgNS, "path");
    if (this.alternate) {
      node.setAttribute("d", this.alternate);
    } else {
      node.setAttribute("d", path[this.pathName]);
    }
    return node;
  }
  toMarkup() {
    if (this.alternate) {
      return '<path d="' + utils.escape(this.alternate) + '"/>';
    } else {
      return '<path d="' + utils.escape(path[this.pathName]) + '"/>';
    }
  }
}
class LineNode {
  constructor(attributes) {
    this.attributes = void 0;
    this.attributes = attributes || {};
  }
  toNode() {
    var svgNS = "http://www.w3.org/2000/svg";
    var node = document.createElementNS(svgNS, "line");
    for (var attr in this.attributes) {
      if (Object.prototype.hasOwnProperty.call(this.attributes, attr)) {
        node.setAttribute(attr, this.attributes[attr]);
      }
    }
    return node;
  }
  toMarkup() {
    var markup = "<line";
    for (var attr in this.attributes) {
      if (Object.prototype.hasOwnProperty.call(this.attributes, attr)) {
        markup += " " + attr + '="' + utils.escape(this.attributes[attr]) + '"';
      }
    }
    markup += "/>";
    return markup;
  }
}
function assertSymbolDomNode(group) {
  if (group instanceof SymbolNode) {
    return group;
  } else {
    throw new Error("Expected symbolNode but got " + String(group) + ".");
  }
}
function assertSpan(group) {
  if (group instanceof Span) {
    return group;
  } else {
    throw new Error("Expected span<HtmlDomNode> but got " + String(group) + ".");
  }
}
var ATOMS = {
  "bin": 1,
  "close": 1,
  "inner": 1,
  "open": 1,
  "punct": 1,
  "rel": 1
};
var NON_ATOMS = {
  "accent-token": 1,
  "mathord": 1,
  "op-token": 1,
  "spacing": 1,
  "textord": 1
};
var symbols = {
  "math": {},
  "text": {}
};
function defineSymbol(mode, font, group, replace, name, acceptUnicodeChar) {
  symbols[mode][name] = {
    font,
    group,
    replace
  };
  if (acceptUnicodeChar && replace) {
    symbols[mode][replace] = symbols[mode][name];
  }
}
var math = "math";
var text = "text";
var main = "main";
var ams = "ams";
var accent = "accent-token";
var bin = "bin";
var close = "close";
var inner = "inner";
var mathord = "mathord";
var op = "op-token";
var open = "open";
var punct = "punct";
var rel = "rel";
var spacing = "spacing";
var textord = "textord";
defineSymbol(math, main, rel, "≡", "\\equiv", true);
defineSymbol(math, main, rel, "≺", "\\prec", true);
defineSymbol(math, main, rel, "≻", "\\succ", true);
defineSymbol(math, main, rel, "∼", "\\sim", true);
defineSymbol(math, main, rel, "⊥", "\\perp");
defineSymbol(math, main, rel, "⪯", "\\preceq", true);
defineSymbol(math, main, rel, "⪰", "\\succeq", true);
defineSymbol(math, main, rel, "≃", "\\simeq", true);
defineSymbol(math, main, rel, "∣", "\\mid", true);
defineSymbol(math, main, rel, "≪", "\\ll", true);
defineSymbol(math, main, rel, "≫", "\\gg", true);
defineSymbol(math, main, rel, "≍", "\\asymp", true);
defineSymbol(math, main, rel, "∥", "\\parallel");
defineSymbol(math, main, rel, "⋈", "\\bowtie", true);
defineSymbol(math, main, rel, "⌣", "\\smile", true);
defineSymbol(math, main, rel, "⊑", "\\sqsubseteq", true);
defineSymbol(math, main, rel, "⊒", "\\sqsupseteq", true);
defineSymbol(math, main, rel, "≐", "\\doteq", true);
defineSymbol(math, main, rel, "⌢", "\\frown", true);
defineSymbol(math, main, rel, "∋", "\\ni", true);
defineSymbol(math, main, rel, "∝", "\\propto", true);
defineSymbol(math, main, rel, "⊢", "\\vdash", true);
defineSymbol(math, main, rel, "⊣", "\\dashv", true);
defineSymbol(math, main, rel, "∋", "\\owns");
defineSymbol(math, main, punct, ".", "\\ldotp");
defineSymbol(math, main, punct, "⋅", "\\cdotp");
defineSymbol(math, main, textord, "#", "\\#");
defineSymbol(text, main, textord, "#", "\\#");
defineSymbol(math, main, textord, "&", "\\&");
defineSymbol(text, main, textord, "&", "\\&");
defineSymbol(math, main, textord, "ℵ", "\\aleph", true);
defineSymbol(math, main, textord, "∀", "\\forall", true);
defineSymbol(math, main, textord, "ℏ", "\\hbar", true);
defineSymbol(math, main, textord, "∃", "\\exists", true);
defineSymbol(math, main, textord, "∇", "\\nabla", true);
defineSymbol(math, main, textord, "♭", "\\flat", true);
defineSymbol(math, main, textord, "ℓ", "\\ell", true);
defineSymbol(math, main, textord, "♮", "\\natural", true);
defineSymbol(math, main, textord, "♣", "\\clubsuit", true);
defineSymbol(math, main, textord, "℘", "\\wp", true);
defineSymbol(math, main, textord, "♯", "\\sharp", true);
defineSymbol(math, main, textord, "♢", "\\diamondsuit", true);
defineSymbol(math, main, textord, "ℜ", "\\Re", true);
defineSymbol(math, main, textord, "♡", "\\heartsuit", true);
defineSymbol(math, main, textord, "ℑ", "\\Im", true);
defineSymbol(math, main, textord, "♠", "\\spadesuit", true);
defineSymbol(math, main, textord, "§", "\\S", true);
defineSymbol(text, main, textord, "§", "\\S");
defineSymbol(math, main, textord, "¶", "\\P", true);
defineSymbol(text, main, textord, "¶", "\\P");
defineSymbol(math, main, textord, "†", "\\dag");
defineSymbol(text, main, textord, "†", "\\dag");
defineSymbol(text, main, textord, "†", "\\textdagger");
defineSymbol(math, main, textord, "‡", "\\ddag");
defineSymbol(text, main, textord, "‡", "\\ddag");
defineSymbol(text, main, textord, "‡", "\\textdaggerdbl");
defineSymbol(math, main, close, "⎱", "\\rmoustache", true);
defineSymbol(math, main, open, "⎰", "\\lmoustache", true);
defineSymbol(math, main, close, "⟯", "\\rgroup", true);
defineSymbol(math, main, open, "⟮", "\\lgroup", true);
defineSymbol(math, main, bin, "∓", "\\mp", true);
defineSymbol(math, main, bin, "⊖", "\\ominus", true);
defineSymbol(math, main, bin, "⊎", "\\uplus", true);
defineSymbol(math, main, bin, "⊓", "\\sqcap", true);
defineSymbol(math, main, bin, "∗", "\\ast");
defineSymbol(math, main, bin, "⊔", "\\sqcup", true);
defineSymbol(math, main, bin, "◯", "\\bigcirc", true);
defineSymbol(math, main, bin, "∙", "\\bullet", true);
defineSymbol(math, main, bin, "‡", "\\ddagger");
defineSymbol(math, main, bin, "≀", "\\wr", true);
defineSymbol(math, main, bin, "⨿", "\\amalg");
defineSymbol(math, main, bin, "&", "\\And");
defineSymbol(math, main, rel, "⟵", "\\longleftarrow", true);
defineSymbol(math, main, rel, "⇐", "\\Leftarrow", true);
defineSymbol(math, main, rel, "⟸", "\\Longleftarrow", true);
defineSymbol(math, main, rel, "⟶", "\\longrightarrow", true);
defineSymbol(math, main, rel, "⇒", "\\Rightarrow", true);
defineSymbol(math, main, rel, "⟹", "\\Longrightarrow", true);
defineSymbol(math, main, rel, "↔", "\\leftrightarrow", true);
defineSymbol(math, main, rel, "⟷", "\\longleftrightarrow", true);
defineSymbol(math, main, rel, "⇔", "\\Leftrightarrow", true);
defineSymbol(math, main, rel, "⟺", "\\Longleftrightarrow", true);
defineSymbol(math, main, rel, "↦", "\\mapsto", true);
defineSymbol(math, main, rel, "⟼", "\\longmapsto", true);
defineSymbol(math, main, rel, "↗", "\\nearrow", true);
defineSymbol(math, main, rel, "↩", "\\hookleftarrow", true);
defineSymbol(math, main, rel, "↪", "\\hookrightarrow", true);
defineSymbol(math, main, rel, "↘", "\\searrow", true);
defineSymbol(math, main, rel, "↼", "\\leftharpoonup", true);
defineSymbol(math, main, rel, "⇀", "\\rightharpoonup", true);
defineSymbol(math, main, rel, "↙", "\\swarrow", true);
defineSymbol(math, main, rel, "↽", "\\leftharpoondown", true);
defineSymbol(math, main, rel, "⇁", "\\rightharpoondown", true);
defineSymbol(math, main, rel, "↖", "\\nwarrow", true);
defineSymbol(math, main, rel, "⇌", "\\rightleftharpoons", true);
defineSymbol(math, ams, rel, "≮", "\\nless", true);
defineSymbol(math, ams, rel, "", "\\@nleqslant");
defineSymbol(math, ams, rel, "", "\\@nleqq");
defineSymbol(math, ams, rel, "⪇", "\\lneq", true);
defineSymbol(math, ams, rel, "≨", "\\lneqq", true);
defineSymbol(math, ams, rel, "", "\\@lvertneqq");
defineSymbol(math, ams, rel, "⋦", "\\lnsim", true);
defineSymbol(math, ams, rel, "⪉", "\\lnapprox", true);
defineSymbol(math, ams, rel, "⊀", "\\nprec", true);
defineSymbol(math, ams, rel, "⋠", "\\npreceq", true);
defineSymbol(math, ams, rel, "⋨", "\\precnsim", true);
defineSymbol(math, ams, rel, "⪹", "\\precnapprox", true);
defineSymbol(math, ams, rel, "≁", "\\nsim", true);
defineSymbol(math, ams, rel, "", "\\@nshortmid");
defineSymbol(math, ams, rel, "∤", "\\nmid", true);
defineSymbol(math, ams, rel, "⊬", "\\nvdash", true);
defineSymbol(math, ams, rel, "⊭", "\\nvDash", true);
defineSymbol(math, ams, rel, "⋪", "\\ntriangleleft");
defineSymbol(math, ams, rel, "⋬", "\\ntrianglelefteq", true);
defineSymbol(math, ams, rel, "⊊", "\\subsetneq", true);
defineSymbol(math, ams, rel, "", "\\@varsubsetneq");
defineSymbol(math, ams, rel, "⫋", "\\subsetneqq", true);
defineSymbol(math, ams, rel, "", "\\@varsubsetneqq");
defineSymbol(math, ams, rel, "≯", "\\ngtr", true);
defineSymbol(math, ams, rel, "", "\\@ngeqslant");
defineSymbol(math, ams, rel, "", "\\@ngeqq");
defineSymbol(math, ams, rel, "⪈", "\\gneq", true);
defineSymbol(math, ams, rel, "≩", "\\gneqq", true);
defineSymbol(math, ams, rel, "", "\\@gvertneqq");
defineSymbol(math, ams, rel, "⋧", "\\gnsim", true);
defineSymbol(math, ams, rel, "⪊", "\\gnapprox", true);
defineSymbol(math, ams, rel, "⊁", "\\nsucc", true);
defineSymbol(math, ams, rel, "⋡", "\\nsucceq", true);
defineSymbol(math, ams, rel, "⋩", "\\succnsim", true);
defineSymbol(math, ams, rel, "⪺", "\\succnapprox", true);
defineSymbol(math, ams, rel, "≆", "\\ncong", true);
defineSymbol(math, ams, rel, "", "\\@nshortparallel");
defineSymbol(math, ams, rel, "∦", "\\nparallel", true);
defineSymbol(math, ams, rel, "⊯", "\\nVDash", true);
defineSymbol(math, ams, rel, "⋫", "\\ntriangleright");
defineSymbol(math, ams, rel, "⋭", "\\ntrianglerighteq", true);
defineSymbol(math, ams, rel, "", "\\@nsupseteqq");
defineSymbol(math, ams, rel, "⊋", "\\supsetneq", true);
defineSymbol(math, ams, rel, "", "\\@varsupsetneq");
defineSymbol(math, ams, rel, "⫌", "\\supsetneqq", true);
defineSymbol(math, ams, rel, "", "\\@varsupsetneqq");
defineSymbol(math, ams, rel, "⊮", "\\nVdash", true);
defineSymbol(math, ams, rel, "⪵", "\\precneqq", true);
defineSymbol(math, ams, rel, "⪶", "\\succneqq", true);
defineSymbol(math, ams, rel, "", "\\@nsubseteqq");
defineSymbol(math, ams, bin, "⊴", "\\unlhd");
defineSymbol(math, ams, bin, "⊵", "\\unrhd");
defineSymbol(math, ams, rel, "↚", "\\nleftarrow", true);
defineSymbol(math, ams, rel, "↛", "\\nrightarrow", true);
defineSymbol(math, ams, rel, "⇍", "\\nLeftarrow", true);
defineSymbol(math, ams, rel, "⇏", "\\nRightarrow", true);
defineSymbol(math, ams, rel, "↮", "\\nleftrightarrow", true);
defineSymbol(math, ams, rel, "⇎", "\\nLeftrightarrow", true);
defineSymbol(math, ams, rel, "△", "\\vartriangle");
defineSymbol(math, ams, textord, "ℏ", "\\hslash");
defineSymbol(math, ams, textord, "▽", "\\triangledown");
defineSymbol(math, ams, textord, "◊", "\\lozenge");
defineSymbol(math, ams, textord, "Ⓢ", "\\circledS");
defineSymbol(math, ams, textord, "®", "\\circledR");
defineSymbol(text, ams, textord, "®", "\\circledR");
defineSymbol(math, ams, textord, "∡", "\\measuredangle", true);
defineSymbol(math, ams, textord, "∄", "\\nexists");
defineSymbol(math, ams, textord, "℧", "\\mho");
defineSymbol(math, ams, textord, "Ⅎ", "\\Finv", true);
defineSymbol(math, ams, textord, "⅁", "\\Game", true);
defineSymbol(math, ams, textord, "‵", "\\backprime");
defineSymbol(math, ams, textord, "▲", "\\blacktriangle");
defineSymbol(math, ams, textord, "▼", "\\blacktriangledown");
defineSymbol(math, ams, textord, "■", "\\blacksquare");
defineSymbol(math, ams, textord, "⧫", "\\blacklozenge");
defineSymbol(math, ams, textord, "★", "\\bigstar");
defineSymbol(math, ams, textord, "∢", "\\sphericalangle", true);
defineSymbol(math, ams, textord, "∁", "\\complement", true);
defineSymbol(math, ams, textord, "ð", "\\eth", true);
defineSymbol(text, main, textord, "ð", "ð");
defineSymbol(math, ams, textord, "╱", "\\diagup");
defineSymbol(math, ams, textord, "╲", "\\diagdown");
defineSymbol(math, ams, textord, "□", "\\square");
defineSymbol(math, ams, textord, "□", "\\Box");
defineSymbol(math, ams, textord, "◊", "\\Diamond");
defineSymbol(math, ams, textord, "¥", "\\yen", true);
defineSymbol(text, ams, textord, "¥", "\\yen", true);
defineSymbol(math, ams, textord, "✓", "\\checkmark", true);
defineSymbol(text, ams, textord, "✓", "\\checkmark");
defineSymbol(math, ams, textord, "ℶ", "\\beth", true);
defineSymbol(math, ams, textord, "ℸ", "\\daleth", true);
defineSymbol(math, ams, textord, "ℷ", "\\gimel", true);
defineSymbol(math, ams, textord, "ϝ", "\\digamma", true);
defineSymbol(math, ams, textord, "ϰ", "\\varkappa");
defineSymbol(math, ams, open, "┌", "\\@ulcorner", true);
defineSymbol(math, ams, close, "┐", "\\@urcorner", true);
defineSymbol(math, ams, open, "└", "\\@llcorner", true);
defineSymbol(math, ams, close, "┘", "\\@lrcorner", true);
defineSymbol(math, ams, rel, "≦", "\\leqq", true);
defineSymbol(math, ams, rel, "⩽", "\\leqslant", true);
defineSymbol(math, ams, rel, "⪕", "\\eqslantless", true);
defineSymbol(math, ams, rel, "≲", "\\lesssim", true);
defineSymbol(math, ams, rel, "⪅", "\\lessapprox", true);
defineSymbol(math, ams, rel, "≊", "\\approxeq", true);
defineSymbol(math, ams, bin, "⋖", "\\lessdot");
defineSymbol(math, ams, rel, "⋘", "\\lll", true);
defineSymbol(math, ams, rel, "≶", "\\lessgtr", true);
defineSymbol(math, ams, rel, "⋚", "\\lesseqgtr", true);
defineSymbol(math, ams, rel, "⪋", "\\lesseqqgtr", true);
defineSymbol(math, ams, rel, "≑", "\\doteqdot");
defineSymbol(math, ams, rel, "≓", "\\risingdotseq", true);
defineSymbol(math, ams, rel, "≒", "\\fallingdotseq", true);
defineSymbol(math, ams, rel, "∽", "\\backsim", true);
defineSymbol(math, ams, rel, "⋍", "\\backsimeq", true);
defineSymbol(math, ams, rel, "⫅", "\\subseteqq", true);
defineSymbol(math, ams, rel, "⋐", "\\Subset", true);
defineSymbol(math, ams, rel, "⊏", "\\sqsubset", true);
defineSymbol(math, ams, rel, "≼", "\\preccurlyeq", true);
defineSymbol(math, ams, rel, "⋞", "\\curlyeqprec", true);
defineSymbol(math, ams, rel, "≾", "\\precsim", true);
defineSymbol(math, ams, rel, "⪷", "\\precapprox", true);
defineSymbol(math, ams, rel, "⊲", "\\vartriangleleft");
defineSymbol(math, ams, rel, "⊴", "\\trianglelefteq");
defineSymbol(math, ams, rel, "⊨", "\\vDash", true);
defineSymbol(math, ams, rel, "⊪", "\\Vvdash", true);
defineSymbol(math, ams, rel, "⌣", "\\smallsmile");
defineSymbol(math, ams, rel, "⌢", "\\smallfrown");
defineSymbol(math, ams, rel, "≏", "\\bumpeq", true);
defineSymbol(math, ams, rel, "≎", "\\Bumpeq", true);
defineSymbol(math, ams, rel, "≧", "\\geqq", true);
defineSymbol(math, ams, rel, "⩾", "\\geqslant", true);
defineSymbol(math, ams, rel, "⪖", "\\eqslantgtr", true);
defineSymbol(math, ams, rel, "≳", "\\gtrsim", true);
defineSymbol(math, ams, rel, "⪆", "\\gtrapprox", true);
defineSymbol(math, ams, bin, "⋗", "\\gtrdot");
defineSymbol(math, ams, rel, "⋙", "\\ggg", true);
defineSymbol(math, ams, rel, "≷", "\\gtrless", true);
defineSymbol(math, ams, rel, "⋛", "\\gtreqless", true);
defineSymbol(math, ams, rel, "⪌", "\\gtreqqless", true);
defineSymbol(math, ams, rel, "≖", "\\eqcirc", true);
defineSymbol(math, ams, rel, "≗", "\\circeq", true);
defineSymbol(math, ams, rel, "≜", "\\triangleq", true);
defineSymbol(math, ams, rel, "∼", "\\thicksim");
defineSymbol(math, ams, rel, "≈", "\\thickapprox");
defineSymbol(math, ams, rel, "⫆", "\\supseteqq", true);
defineSymbol(math, ams, rel, "⋑", "\\Supset", true);
defineSymbol(math, ams, rel, "⊐", "\\sqsupset", true);
defineSymbol(math, ams, rel, "≽", "\\succcurlyeq", true);
defineSymbol(math, ams, rel, "⋟", "\\curlyeqsucc", true);
defineSymbol(math, ams, rel, "≿", "\\succsim", true);
defineSymbol(math, ams, rel, "⪸", "\\succapprox", true);
defineSymbol(math, ams, rel, "⊳", "\\vartriangleright");
defineSymbol(math, ams, rel, "⊵", "\\trianglerighteq");
defineSymbol(math, ams, rel, "⊩", "\\Vdash", true);
defineSymbol(math, ams, rel, "∣", "\\shortmid");
defineSymbol(math, ams, rel, "∥", "\\shortparallel");
defineSymbol(math, ams, rel, "≬", "\\between", true);
defineSymbol(math, ams, rel, "⋔", "\\pitchfork", true);
defineSymbol(math, ams, rel, "∝", "\\varpropto");
defineSymbol(math, ams, rel, "◀", "\\blacktriangleleft");
defineSymbol(math, ams, rel, "∴", "\\therefore", true);
defineSymbol(math, ams, rel, "∍", "\\backepsilon");
defineSymbol(math, ams, rel, "▶", "\\blacktriangleright");
defineSymbol(math, ams, rel, "∵", "\\because", true);
defineSymbol(math, ams, rel, "⋘", "\\llless");
defineSymbol(math, ams, rel, "⋙", "\\gggtr");
defineSymbol(math, ams, bin, "⊲", "\\lhd");
defineSymbol(math, ams, bin, "⊳", "\\rhd");
defineSymbol(math, ams, rel, "≂", "\\eqsim", true);
defineSymbol(math, main, rel, "⋈", "\\Join");
defineSymbol(math, ams, rel, "≑", "\\Doteq", true);
defineSymbol(math, ams, bin, "∔", "\\dotplus", true);
defineSymbol(math, ams, bin, "∖", "\\smallsetminus");
defineSymbol(math, ams, bin, "⋒", "\\Cap", true);
defineSymbol(math, ams, bin, "⋓", "\\Cup", true);
defineSymbol(math, ams, bin, "⩞", "\\doublebarwedge", true);
defineSymbol(math, ams, bin, "⊟", "\\boxminus", true);
defineSymbol(math, ams, bin, "⊞", "\\boxplus", true);
defineSymbol(math, ams, bin, "⋇", "\\divideontimes", true);
defineSymbol(math, ams, bin, "⋉", "\\ltimes", true);
defineSymbol(math, ams, bin, "⋊", "\\rtimes", true);
defineSymbol(math, ams, bin, "⋋", "\\leftthreetimes", true);
defineSymbol(math, ams, bin, "⋌", "\\rightthreetimes", true);
defineSymbol(math, ams, bin, "⋏", "\\curlywedge", true);
defineSymbol(math, ams, bin, "⋎", "\\curlyvee", true);
defineSymbol(math, ams, bin, "⊝", "\\circleddash", true);
defineSymbol(math, ams, bin, "⊛", "\\circledast", true);
defineSymbol(math, ams, bin, "⋅", "\\centerdot");
defineSymbol(math, ams, bin, "⊺", "\\intercal", true);
defineSymbol(math, ams, bin, "⋒", "\\doublecap");
defineSymbol(math, ams, bin, "⋓", "\\doublecup");
defineSymbol(math, ams, bin, "⊠", "\\boxtimes", true);
defineSymbol(math, ams, rel, "⇢", "\\dashrightarrow", true);
defineSymbol(math, ams, rel, "⇠", "\\dashleftarrow", true);
defineSymbol(math, ams, rel, "⇇", "\\leftleftarrows", true);
defineSymbol(math, ams, rel, "⇆", "\\leftrightarrows", true);
defineSymbol(math, ams, rel, "⇚", "\\Lleftarrow", true);
defineSymbol(math, ams, rel, "↞", "\\twoheadleftarrow", true);
defineSymbol(math, ams, rel, "↢", "\\leftarrowtail", true);
defineSymbol(math, ams, rel, "↫", "\\looparrowleft", true);
defineSymbol(math, ams, rel, "⇋", "\\leftrightharpoons", true);
defineSymbol(math, ams, rel, "↶", "\\curvearrowleft", true);
defineSymbol(math, ams, rel, "↺", "\\circlearrowleft", true);
defineSymbol(math, ams, rel, "↰", "\\Lsh", true);
defineSymbol(math, ams, rel, "⇈", "\\upuparrows", true);
defineSymbol(math, ams, rel, "↿", "\\upharpoonleft", true);
defineSymbol(math, ams, rel, "⇃", "\\downharpoonleft", true);
defineSymbol(math, main, rel, "⊶", "\\origof", true);
defineSymbol(math, main, rel, "⊷", "\\imageof", true);
defineSymbol(math, ams, rel, "⊸", "\\multimap", true);
defineSymbol(math, ams, rel, "↭", "\\leftrightsquigarrow", true);
defineSymbol(math, ams, rel, "⇉", "\\rightrightarrows", true);
defineSymbol(math, ams, rel, "⇄", "\\rightleftarrows", true);
defineSymbol(math, ams, rel, "↠", "\\twoheadrightarrow", true);
defineSymbol(math, ams, rel, "↣", "\\rightarrowtail", true);
defineSymbol(math, ams, rel, "↬", "\\looparrowright", true);
defineSymbol(math, ams, rel, "↷", "\\curvearrowright", true);
defineSymbol(math, ams, rel, "↻", "\\circlearrowright", true);
defineSymbol(math, ams, rel, "↱", "\\Rsh", true);
defineSymbol(math, ams, rel, "⇊", "\\downdownarrows", true);
defineSymbol(math, ams, rel, "↾", "\\upharpoonright", true);
defineSymbol(math, ams, rel, "⇂", "\\downharpoonright", true);
defineSymbol(math, ams, rel, "⇝", "\\rightsquigarrow", true);
defineSymbol(math, ams, rel, "⇝", "\\leadsto");
defineSymbol(math, ams, rel, "⇛", "\\Rrightarrow", true);
defineSymbol(math, ams, rel, "↾", "\\restriction");
defineSymbol(math, main, textord, "‘", "`");
defineSymbol(math, main, textord, "$", "\\$");
defineSymbol(text, main, textord, "$", "\\$");
defineSymbol(text, main, textord, "$", "\\textdollar");
defineSymbol(math, main, textord, "%", "\\%");
defineSymbol(text, main, textord, "%", "\\%");
defineSymbol(math, main, textord, "_", "\\_");
defineSymbol(text, main, textord, "_", "\\_");
defineSymbol(text, main, textord, "_", "\\textunderscore");
defineSymbol(math, main, textord, "∠", "\\angle", true);
defineSymbol(math, main, textord, "∞", "\\infty", true);
defineSymbol(math, main, textord, "′", "\\prime");
defineSymbol(math, main, textord, "△", "\\triangle");
defineSymbol(math, main, textord, "Γ", "\\Gamma", true);
defineSymbol(math, main, textord, "Δ", "\\Delta", true);
defineSymbol(math, main, textord, "Θ", "\\Theta", true);
defineSymbol(math, main, textord, "Λ", "\\Lambda", true);
defineSymbol(math, main, textord, "Ξ", "\\Xi", true);
defineSymbol(math, main, textord, "Π", "\\Pi", true);
defineSymbol(math, main, textord, "Σ", "\\Sigma", true);
defineSymbol(math, main, textord, "Υ", "\\Upsilon", true);
defineSymbol(math, main, textord, "Φ", "\\Phi", true);
defineSymbol(math, main, textord, "Ψ", "\\Psi", true);
defineSymbol(math, main, textord, "Ω", "\\Omega", true);
defineSymbol(math, main, textord, "A", "Α");
defineSymbol(math, main, textord, "B", "Β");
defineSymbol(math, main, textord, "E", "Ε");
defineSymbol(math, main, textord, "Z", "Ζ");
defineSymbol(math, main, textord, "H", "Η");
defineSymbol(math, main, textord, "I", "Ι");
defineSymbol(math, main, textord, "K", "Κ");
defineSymbol(math, main, textord, "M", "Μ");
defineSymbol(math, main, textord, "N", "Ν");
defineSymbol(math, main, textord, "O", "Ο");
defineSymbol(math, main, textord, "P", "Ρ");
defineSymbol(math, main, textord, "T", "Τ");
defineSymbol(math, main, textord, "X", "Χ");
defineSymbol(math, main, textord, "¬", "\\neg", true);
defineSymbol(math, main, textord, "¬", "\\lnot");
defineSymbol(math, main, textord, "⊤", "\\top");
defineSymbol(math, main, textord, "⊥", "\\bot");
defineSymbol(math, main, textord, "∅", "\\emptyset");
defineSymbol(math, ams, textord, "∅", "\\varnothing");
defineSymbol(math, main, mathord, "α", "\\alpha", true);
defineSymbol(math, main, mathord, "β", "\\beta", true);
defineSymbol(math, main, mathord, "γ", "\\gamma", true);
defineSymbol(math, main, mathord, "δ", "\\delta", true);
defineSymbol(math, main, mathord, "ϵ", "\\epsilon", true);
defineSymbol(math, main, mathord, "ζ", "\\zeta", true);
defineSymbol(math, main, mathord, "η", "\\eta", true);
defineSymbol(math, main, mathord, "θ", "\\theta", true);
defineSymbol(math, main, mathord, "ι", "\\iota", true);
defineSymbol(math, main, mathord, "κ", "\\kappa", true);
defineSymbol(math, main, mathord, "λ", "\\lambda", true);
defineSymbol(math, main, mathord, "μ", "\\mu", true);
defineSymbol(math, main, mathord, "ν", "\\nu", true);
defineSymbol(math, main, mathord, "ξ", "\\xi", true);
defineSymbol(math, main, mathord, "ο", "\\omicron", true);
defineSymbol(math, main, mathord, "π", "\\pi", true);
defineSymbol(math, main, mathord, "ρ", "\\rho", true);
defineSymbol(math, main, mathord, "σ", "\\sigma", true);
defineSymbol(math, main, mathord, "τ", "\\tau", true);
defineSymbol(math, main, mathord, "υ", "\\upsilon", true);
defineSymbol(math, main, mathord, "ϕ", "\\phi", true);
defineSymbol(math, main, mathord, "χ", "\\chi", true);
defineSymbol(math, main, mathord, "ψ", "\\psi", true);
defineSymbol(math, main, mathord, "ω", "\\omega", true);
defineSymbol(math, main, mathord, "ε", "\\varepsilon", true);
defineSymbol(math, main, mathord, "ϑ", "\\vartheta", true);
defineSymbol(math, main, mathord, "ϖ", "\\varpi", true);
defineSymbol(math, main, mathord, "ϱ", "\\varrho", true);
defineSymbol(math, main, mathord, "ς", "\\varsigma", true);
defineSymbol(math, main, mathord, "φ", "\\varphi", true);
defineSymbol(math, main, bin, "∗", "*", true);
defineSymbol(math, main, bin, "+", "+");
defineSymbol(math, main, bin, "−", "-", true);
defineSymbol(math, main, bin, "⋅", "\\cdot", true);
defineSymbol(math, main, bin, "∘", "\\circ", true);
defineSymbol(math, main, bin, "÷", "\\div", true);
defineSymbol(math, main, bin, "±", "\\pm", true);
defineSymbol(math, main, bin, "×", "\\times", true);
defineSymbol(math, main, bin, "∩", "\\cap", true);
defineSymbol(math, main, bin, "∪", "\\cup", true);
defineSymbol(math, main, bin, "∖", "\\setminus", true);
defineSymbol(math, main, bin, "∧", "\\land");
defineSymbol(math, main, bin, "∨", "\\lor");
defineSymbol(math, main, bin, "∧", "\\wedge", true);
defineSymbol(math, main, bin, "∨", "\\vee", true);
defineSymbol(math, main, textord, "√", "\\surd");
defineSymbol(math, main, open, "⟨", "\\langle", true);
defineSymbol(math, main, open, "∣", "\\lvert");
defineSymbol(math, main, open, "∥", "\\lVert");
defineSymbol(math, main, close, "?", "?");
defineSymbol(math, main, close, "!", "!");
defineSymbol(math, main, close, "⟩", "\\rangle", true);
defineSymbol(math, main, close, "∣", "\\rvert");
defineSymbol(math, main, close, "∥", "\\rVert");
defineSymbol(math, main, rel, "=", "=");
defineSymbol(math, main, rel, ":", ":");
defineSymbol(math, main, rel, "≈", "\\approx", true);
defineSymbol(math, main, rel, "≅", "\\cong", true);
defineSymbol(math, main, rel, "≥", "\\ge");
defineSymbol(math, main, rel, "≥", "\\geq", true);
defineSymbol(math, main, rel, "←", "\\gets");
defineSymbol(math, main, rel, ">", "\\gt", true);
defineSymbol(math, main, rel, "∈", "\\in", true);
defineSymbol(math, main, rel, "", "\\@not");
defineSymbol(math, main, rel, "⊂", "\\subset", true);
defineSymbol(math, main, rel, "⊃", "\\supset", true);
defineSymbol(math, main, rel, "⊆", "\\subseteq", true);
defineSymbol(math, main, rel, "⊇", "\\supseteq", true);
defineSymbol(math, ams, rel, "⊈", "\\nsubseteq", true);
defineSymbol(math, ams, rel, "⊉", "\\nsupseteq", true);
defineSymbol(math, main, rel, "⊨", "\\models");
defineSymbol(math, main, rel, "←", "\\leftarrow", true);
defineSymbol(math, main, rel, "≤", "\\le");
defineSymbol(math, main, rel, "≤", "\\leq", true);
defineSymbol(math, main, rel, "<", "\\lt", true);
defineSymbol(math, main, rel, "→", "\\rightarrow", true);
defineSymbol(math, main, rel, "→", "\\to");
defineSymbol(math, ams, rel, "≱", "\\ngeq", true);
defineSymbol(math, ams, rel, "≰", "\\nleq", true);
defineSymbol(math, main, spacing, " ", "\\ ");
defineSymbol(math, main, spacing, " ", "\\space");
defineSymbol(math, main, spacing, " ", "\\nobreakspace");
defineSymbol(text, main, spacing, " ", "\\ ");
defineSymbol(text, main, spacing, " ", " ");
defineSymbol(text, main, spacing, " ", "\\space");
defineSymbol(text, main, spacing, " ", "\\nobreakspace");
defineSymbol(math, main, spacing, null, "\\nobreak");
defineSymbol(math, main, spacing, null, "\\allowbreak");
defineSymbol(math, main, punct, ",", ",");
defineSymbol(math, main, punct, ";", ";");
defineSymbol(math, ams, bin, "⊼", "\\barwedge", true);
defineSymbol(math, ams, bin, "⊻", "\\veebar", true);
defineSymbol(math, main, bin, "⊙", "\\odot", true);
defineSymbol(math, main, bin, "⊕", "\\oplus", true);
defineSymbol(math, main, bin, "⊗", "\\otimes", true);
defineSymbol(math, main, textord, "∂", "\\partial", true);
defineSymbol(math, main, bin, "⊘", "\\oslash", true);
defineSymbol(math, ams, bin, "⊚", "\\circledcirc", true);
defineSymbol(math, ams, bin, "⊡", "\\boxdot", true);
defineSymbol(math, main, bin, "△", "\\bigtriangleup");
defineSymbol(math, main, bin, "▽", "\\bigtriangledown");
defineSymbol(math, main, bin, "†", "\\dagger");
defineSymbol(math, main, bin, "⋄", "\\diamond");
defineSymbol(math, main, bin, "⋆", "\\star");
defineSymbol(math, main, bin, "◃", "\\triangleleft");
defineSymbol(math, main, bin, "▹", "\\triangleright");
defineSymbol(math, main, open, "{", "\\{");
defineSymbol(text, main, textord, "{", "\\{");
defineSymbol(text, main, textord, "{", "\\textbraceleft");
defineSymbol(math, main, close, "}", "\\}");
defineSymbol(text, main, textord, "}", "\\}");
defineSymbol(text, main, textord, "}", "\\textbraceright");
defineSymbol(math, main, open, "{", "\\lbrace");
defineSymbol(math, main, close, "}", "\\rbrace");
defineSymbol(math, main, open, "[", "\\lbrack", true);
defineSymbol(text, main, textord, "[", "\\lbrack", true);
defineSymbol(math, main, close, "]", "\\rbrack", true);
defineSymbol(text, main, textord, "]", "\\rbrack", true);
defineSymbol(math, main, open, "(", "\\lparen", true);
defineSymbol(math, main, close, ")", "\\rparen", true);
defineSymbol(text, main, textord, "<", "\\textless", true);
defineSymbol(text, main, textord, ">", "\\textgreater", true);
defineSymbol(math, main, open, "⌊", "\\lfloor", true);
defineSymbol(math, main, close, "⌋", "\\rfloor", true);
defineSymbol(math, main, open, "⌈", "\\lceil", true);
defineSymbol(math, main, close, "⌉", "\\rceil", true);
defineSymbol(math, main, textord, "\\", "\\backslash");
defineSymbol(math, main, textord, "∣", "|");
defineSymbol(math, main, textord, "∣", "\\vert");
defineSymbol(text, main, textord, "|", "\\textbar", true);
defineSymbol(math, main, textord, "∥", "\\|");
defineSymbol(math, main, textord, "∥", "\\Vert");
defineSymbol(text, main, textord, "∥", "\\textbardbl");
defineSymbol(text, main, textord, "~", "\\textasciitilde");
defineSymbol(text, main, textord, "\\", "\\textbackslash");
defineSymbol(text, main, textord, "^", "\\textasciicircum");
defineSymbol(math, main, rel, "↑", "\\uparrow", true);
defineSymbol(math, main, rel, "⇑", "\\Uparrow", true);
defineSymbol(math, main, rel, "↓", "\\downarrow", true);
defineSymbol(math, main, rel, "⇓", "\\Downarrow", true);
defineSymbol(math, main, rel, "↕", "\\updownarrow", true);
defineSymbol(math, main, rel, "⇕", "\\Updownarrow", true);
defineSymbol(math, main, op, "∐", "\\coprod");
defineSymbol(math, main, op, "⋁", "\\bigvee");
defineSymbol(math, main, op, "⋀", "\\bigwedge");
defineSymbol(math, main, op, "⨄", "\\biguplus");
defineSymbol(math, main, op, "⋂", "\\bigcap");
defineSymbol(math, main, op, "⋃", "\\bigcup");
defineSymbol(math, main, op, "∫", "\\int");
defineSymbol(math, main, op, "∫", "\\intop");
defineSymbol(math, main, op, "∬", "\\iint");
defineSymbol(math, main, op, "∭", "\\iiint");
defineSymbol(math, main, op, "∏", "\\prod");
defineSymbol(math, main, op, "∑", "\\sum");
defineSymbol(math, main, op, "⨂", "\\bigotimes");
defineSymbol(math, main, op, "⨁", "\\bigoplus");
defineSymbol(math, main, op, "⨀", "\\bigodot");
defineSymbol(math, main, op, "∮", "\\oint");
defineSymbol(math, main, op, "∯", "\\oiint");
defineSymbol(math, main, op, "∰", "\\oiiint");
defineSymbol(math, main, op, "⨆", "\\bigsqcup");
defineSymbol(math, main, op, "∫", "\\smallint");
defineSymbol(text, main, inner, "…", "\\textellipsis");
defineSymbol(math, main, inner, "…", "\\mathellipsis");
defineSymbol(text, main, inner, "…", "\\ldots", true);
defineSymbol(math, main, inner, "…", "\\ldots", true);
defineSymbol(math, main, inner, "⋯", "\\@cdots", true);
defineSymbol(math, main, inner, "⋱", "\\ddots", true);
defineSymbol(math, main, textord, "⋮", "\\varvdots");
defineSymbol(text, main, textord, "⋮", "\\varvdots");
defineSymbol(math, main, accent, "ˊ", "\\acute");
defineSymbol(math, main, accent, "ˋ", "\\grave");
defineSymbol(math, main, accent, "¨", "\\ddot");
defineSymbol(math, main, accent, "~", "\\tilde");
defineSymbol(math, main, accent, "ˉ", "\\bar");
defineSymbol(math, main, accent, "˘", "\\breve");
defineSymbol(math, main, accent, "ˇ", "\\check");
defineSymbol(math, main, accent, "^", "\\hat");
defineSymbol(math, main, accent, "⃗", "\\vec");
defineSymbol(math, main, accent, "˙", "\\dot");
defineSymbol(math, main, accent, "˚", "\\mathring");
defineSymbol(math, main, mathord, "", "\\@imath");
defineSymbol(math, main, mathord, "", "\\@jmath");
defineSymbol(math, main, textord, "ı", "ı");
defineSymbol(math, main, textord, "ȷ", "ȷ");
defineSymbol(text, main, textord, "ı", "\\i", true);
defineSymbol(text, main, textord, "ȷ", "\\j", true);
defineSymbol(text, main, textord, "ß", "\\ss", true);
defineSymbol(text, main, textord, "æ", "\\ae", true);
defineSymbol(text, main, textord, "œ", "\\oe", true);
defineSymbol(text, main, textord, "ø", "\\o", true);
defineSymbol(text, main, textord, "Æ", "\\AE", true);
defineSymbol(text, main, textord, "Œ", "\\OE", true);
defineSymbol(text, main, textord, "Ø", "\\O", true);
defineSymbol(text, main, accent, "ˊ", "\\'");
defineSymbol(text, main, accent, "ˋ", "\\`");
defineSymbol(text, main, accent, "ˆ", "\\^");
defineSymbol(text, main, accent, "˜", "\\~");
defineSymbol(text, main, accent, "ˉ", "\\=");
defineSymbol(text, main, accent, "˘", "\\u");
defineSymbol(text, main, accent, "˙", "\\.");
defineSymbol(text, main, accent, "¸", "\\c");
defineSymbol(text, main, accent, "˚", "\\r");
defineSymbol(text, main, accent, "ˇ", "\\v");
defineSymbol(text, main, accent, "¨", '\\"');
defineSymbol(text, main, accent, "˝", "\\H");
defineSymbol(text, main, accent, "◯", "\\textcircled");
var ligatures = {
  "--": true,
  "---": true,
  "``": true,
  "''": true
};
defineSymbol(text, main, textord, "–", "--", true);
defineSymbol(text, main, textord, "–", "\\textendash");
defineSymbol(text, main, textord, "—", "---", true);
defineSymbol(text, main, textord, "—", "\\textemdash");
defineSymbol(text, main, textord, "‘", "`", true);
defineSymbol(text, main, textord, "‘", "\\textquoteleft");
defineSymbol(text, main, textord, "’", "'", true);
defineSymbol(text, main, textord, "’", "\\textquoteright");
defineSymbol(text, main, textord, "“", "``", true);
defineSymbol(text, main, textord, "“", "\\textquotedblleft");
defineSymbol(text, main, textord, "”", "''", true);
defineSymbol(text, main, textord, "”", "\\textquotedblright");
defineSymbol(math, main, textord, "°", "\\degree", true);
defineSymbol(text, main, textord, "°", "\\degree");
defineSymbol(text, main, textord, "°", "\\textdegree", true);
defineSymbol(math, main, textord, "£", "\\pounds");
defineSymbol(math, main, textord, "£", "\\mathsterling", true);
defineSymbol(text, main, textord, "£", "\\pounds");
defineSymbol(text, main, textord, "£", "\\textsterling", true);
defineSymbol(math, ams, textord, "✠", "\\maltese");
defineSymbol(text, ams, textord, "✠", "\\maltese");
var mathTextSymbols = '0123456789/@."';
for (var i = 0; i < mathTextSymbols.length; i++) {
  var ch = mathTextSymbols.charAt(i);
  defineSymbol(math, main, textord, ch, ch);
}
var textSymbols = '0123456789!@*()-=+";:?/.,';
for (var _i = 0; _i < textSymbols.length; _i++) {
  var _ch = textSymbols.charAt(_i);
  defineSymbol(text, main, textord, _ch, _ch);
}
var letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
for (var _i2 = 0; _i2 < letters.length; _i2++) {
  var _ch2 = letters.charAt(_i2);
  defineSymbol(math, main, mathord, _ch2, _ch2);
  defineSymbol(text, main, textord, _ch2, _ch2);
}
defineSymbol(math, ams, textord, "C", "ℂ");
defineSymbol(text, ams, textord, "C", "ℂ");
defineSymbol(math, ams, textord, "H", "ℍ");
defineSymbol(text, ams, textord, "H", "ℍ");
defineSymbol(math, ams, textord, "N", "ℕ");
defineSymbol(text, ams, textord, "N", "ℕ");
defineSymbol(math, ams, textord, "P", "ℙ");
defineSymbol(text, ams, textord, "P", "ℙ");
defineSymbol(math, ams, textord, "Q", "ℚ");
defineSymbol(text, ams, textord, "Q", "ℚ");
defineSymbol(math, ams, textord, "R", "ℝ");
defineSymbol(text, ams, textord, "R", "ℝ");
defineSymbol(math, ams, textord, "Z", "ℤ");
defineSymbol(text, ams, textord, "Z", "ℤ");
defineSymbol(math, main, mathord, "h", "ℎ");
defineSymbol(text, main, mathord, "h", "ℎ");
var wideChar = "";
for (var _i3 = 0; _i3 < letters.length; _i3++) {
  var _ch3 = letters.charAt(_i3);
  wideChar = String.fromCharCode(55349, 56320 + _i3);
  defineSymbol(math, main, mathord, _ch3, wideChar);
  defineSymbol(text, main, textord, _ch3, wideChar);
  wideChar = String.fromCharCode(55349, 56372 + _i3);
  defineSymbol(math, main, mathord, _ch3, wideChar);
  defineSymbol(text, main, textord, _ch3, wideChar);
  wideChar = String.fromCharCode(55349, 56424 + _i3);
  defineSymbol(math, main, mathord, _ch3, wideChar);
  defineSymbol(text, main, textord, _ch3, wideChar);
  wideChar = String.fromCharCode(55349, 56580 + _i3);
  defineSymbol(math, main, mathord, _ch3, wideChar);
  defineSymbol(text, main, textord, _ch3, wideChar);
  wideChar = String.fromCharCode(55349, 56684 + _i3);
  defineSymbol(math, main, mathord, _ch3, wideChar);
  defineSymbol(text, main, textord, _ch3, wideChar);
  wideChar = String.fromCharCode(55349, 56736 + _i3);
  defineSymbol(math, main, mathord, _ch3, wideChar);
  defineSymbol(text, main, textord, _ch3, wideChar);
  wideChar = String.fromCharCode(55349, 56788 + _i3);
  defineSymbol(math, main, mathord, _ch3, wideChar);
  defineSymbol(text, main, textord, _ch3, wideChar);
  wideChar = String.fromCharCode(55349, 56840 + _i3);
  defineSymbol(math, main, mathord, _ch3, wideChar);
  defineSymbol(text, main, textord, _ch3, wideChar);
  wideChar = String.fromCharCode(55349, 56944 + _i3);
  defineSymbol(math, main, mathord, _ch3, wideChar);
  defineSymbol(text, main, textord, _ch3, wideChar);
  if (_i3 < 26) {
    wideChar = String.fromCharCode(55349, 56632 + _i3);
    defineSymbol(math, main, mathord, _ch3, wideChar);
    defineSymbol(text, main, textord, _ch3, wideChar);
    wideChar = String.fromCharCode(55349, 56476 + _i3);
    defineSymbol(math, main, mathord, _ch3, wideChar);
    defineSymbol(text, main, textord, _ch3, wideChar);
  }
}
wideChar = String.fromCharCode(55349, 56668);
defineSymbol(math, main, mathord, "k", wideChar);
defineSymbol(text, main, textord, "k", wideChar);
for (var _i4 = 0; _i4 < 10; _i4++) {
  var _ch4 = _i4.toString();
  wideChar = String.fromCharCode(55349, 57294 + _i4);
  defineSymbol(math, main, mathord, _ch4, wideChar);
  defineSymbol(text, main, textord, _ch4, wideChar);
  wideChar = String.fromCharCode(55349, 57314 + _i4);
  defineSymbol(math, main, mathord, _ch4, wideChar);
  defineSymbol(text, main, textord, _ch4, wideChar);
  wideChar = String.fromCharCode(55349, 57324 + _i4);
  defineSymbol(math, main, mathord, _ch4, wideChar);
  defineSymbol(text, main, textord, _ch4, wideChar);
  wideChar = String.fromCharCode(55349, 57334 + _i4);
  defineSymbol(math, main, mathord, _ch4, wideChar);
  defineSymbol(text, main, textord, _ch4, wideChar);
}
var extraLatin = "ÐÞþ";
for (var _i5 = 0; _i5 < extraLatin.length; _i5++) {
  var _ch5 = extraLatin.charAt(_i5);
  defineSymbol(math, main, mathord, _ch5, _ch5);
  defineSymbol(text, main, textord, _ch5, _ch5);
}
var wideLatinLetterData = [
  ["mathbf", "textbf", "Main-Bold"],
  // A-Z bold upright
  ["mathbf", "textbf", "Main-Bold"],
  // a-z bold upright
  ["mathnormal", "textit", "Math-Italic"],
  // A-Z italic
  ["mathnormal", "textit", "Math-Italic"],
  // a-z italic
  ["boldsymbol", "boldsymbol", "Main-BoldItalic"],
  // A-Z bold italic
  ["boldsymbol", "boldsymbol", "Main-BoldItalic"],
  // a-z bold italic
  // Map fancy A-Z letters to script, not calligraphic.
  // This aligns with unicode-math and math fonts (except Cambria Math).
  ["mathscr", "textscr", "Script-Regular"],
  // A-Z script
  ["", "", ""],
  // a-z script.  No font
  ["", "", ""],
  // A-Z bold script. No font
  ["", "", ""],
  // a-z bold script. No font
  ["mathfrak", "textfrak", "Fraktur-Regular"],
  // A-Z Fraktur
  ["mathfrak", "textfrak", "Fraktur-Regular"],
  // a-z Fraktur
  ["mathbb", "textbb", "AMS-Regular"],
  // A-Z double-struck
  ["mathbb", "textbb", "AMS-Regular"],
  // k double-struck
  // Note that we are using a bold font, but font metrics for regular Fraktur.
  ["mathboldfrak", "textboldfrak", "Fraktur-Regular"],
  // A-Z bold Fraktur
  ["mathboldfrak", "textboldfrak", "Fraktur-Regular"],
  // a-z bold Fraktur
  ["mathsf", "textsf", "SansSerif-Regular"],
  // A-Z sans-serif
  ["mathsf", "textsf", "SansSerif-Regular"],
  // a-z sans-serif
  ["mathboldsf", "textboldsf", "SansSerif-Bold"],
  // A-Z bold sans-serif
  ["mathboldsf", "textboldsf", "SansSerif-Bold"],
  // a-z bold sans-serif
  ["mathitsf", "textitsf", "SansSerif-Italic"],
  // A-Z italic sans-serif
  ["mathitsf", "textitsf", "SansSerif-Italic"],
  // a-z italic sans-serif
  ["", "", ""],
  // A-Z bold italic sans. No font
  ["", "", ""],
  // a-z bold italic sans. No font
  ["mathtt", "texttt", "Typewriter-Regular"],
  // A-Z monospace
  ["mathtt", "texttt", "Typewriter-Regular"]
  // a-z monospace
];
var wideNumeralData = [
  ["mathbf", "textbf", "Main-Bold"],
  // 0-9 bold
  ["", "", ""],
  // 0-9 double-struck. No KaTeX font.
  ["mathsf", "textsf", "SansSerif-Regular"],
  // 0-9 sans-serif
  ["mathboldsf", "textboldsf", "SansSerif-Bold"],
  // 0-9 bold sans-serif
  ["mathtt", "texttt", "Typewriter-Regular"]
  // 0-9 monospace
];
var wideCharacterFont = function wideCharacterFont2(wideChar2, mode) {
  var H = wideChar2.charCodeAt(0);
  var L = wideChar2.charCodeAt(1);
  var codePoint = (H - 55296) * 1024 + (L - 56320) + 65536;
  var j = mode === "math" ? 0 : 1;
  if (119808 <= codePoint && codePoint < 120484) {
    var i = Math.floor((codePoint - 119808) / 26);
    return [wideLatinLetterData[i][2], wideLatinLetterData[i][j]];
  } else if (120782 <= codePoint && codePoint <= 120831) {
    var _i = Math.floor((codePoint - 120782) / 10);
    return [wideNumeralData[_i][2], wideNumeralData[_i][j]];
  } else if (codePoint === 120485 || codePoint === 120486) {
    return [wideLatinLetterData[0][2], wideLatinLetterData[0][j]];
  } else if (120486 < codePoint && codePoint < 120782) {
    return ["", ""];
  } else {
    throw new ParseError("Unsupported character: " + wideChar2);
  }
};
var lookupSymbol = function lookupSymbol2(value, fontName, mode) {
  if (symbols[mode][value] && symbols[mode][value].replace) {
    value = symbols[mode][value].replace;
  }
  return {
    value,
    metrics: getCharacterMetrics(value, fontName, mode)
  };
};
var makeSymbol = function makeSymbol2(value, fontName, mode, options, classes) {
  var lookup = lookupSymbol(value, fontName, mode);
  var metrics = lookup.metrics;
  value = lookup.value;
  var symbolNode;
  if (metrics) {
    var italic = metrics.italic;
    if (mode === "text" || options && options.font === "mathit") {
      italic = 0;
    }
    symbolNode = new SymbolNode(value, metrics.height, metrics.depth, italic, metrics.skew, metrics.width, classes);
  } else {
    typeof console !== "undefined" && console.warn("No character metrics " + ("for '" + value + "' in style '" + fontName + "' and mode '" + mode + "'"));
    symbolNode = new SymbolNode(value, 0, 0, 0, 0, 0, classes);
  }
  if (options) {
    symbolNode.maxFontSize = options.sizeMultiplier;
    if (options.style.isTight()) {
      symbolNode.classes.push("mtight");
    }
    var color = options.getColor();
    if (color) {
      symbolNode.style.color = color;
    }
  }
  return symbolNode;
};
var mathsym = function mathsym2(value, mode, options, classes) {
  if (classes === void 0) {
    classes = [];
  }
  if (options.font === "boldsymbol" && lookupSymbol(value, "Main-Bold", mode).metrics) {
    return makeSymbol(value, "Main-Bold", mode, options, classes.concat(["mathbf"]));
  } else if (value === "\\" || symbols[mode][value].font === "main") {
    return makeSymbol(value, "Main-Regular", mode, options, classes);
  } else {
    return makeSymbol(value, "AMS-Regular", mode, options, classes.concat(["amsrm"]));
  }
};
var boldsymbol = function boldsymbol2(value, mode, options, classes, type) {
  if (type !== "textord" && lookupSymbol(value, "Math-BoldItalic", mode).metrics) {
    return {
      fontName: "Math-BoldItalic",
      fontClass: "boldsymbol"
    };
  } else {
    return {
      fontName: "Main-Bold",
      fontClass: "mathbf"
    };
  }
};
var makeOrd = function makeOrd2(group, options, type) {
  var mode = group.mode;
  var text2 = group.text;
  var classes = ["mord"];
  var isFont = mode === "math" || mode === "text" && options.font;
  var fontOrFamily = isFont ? options.font : options.fontFamily;
  var wideFontName = "";
  var wideFontClass = "";
  if (text2.charCodeAt(0) === 55349) {
    [wideFontName, wideFontClass] = wideCharacterFont(text2, mode);
  }
  if (wideFontName.length > 0) {
    return makeSymbol(text2, wideFontName, mode, options, classes.concat(wideFontClass));
  } else if (fontOrFamily) {
    var fontName;
    var fontClasses;
    if (fontOrFamily === "boldsymbol") {
      var fontData = boldsymbol(text2, mode, options, classes, type);
      fontName = fontData.fontName;
      fontClasses = [fontData.fontClass];
    } else if (isFont) {
      fontName = fontMap[fontOrFamily].fontName;
      fontClasses = [fontOrFamily];
    } else {
      fontName = retrieveTextFontName(fontOrFamily, options.fontWeight, options.fontShape);
      fontClasses = [fontOrFamily, options.fontWeight, options.fontShape];
    }
    if (lookupSymbol(text2, fontName, mode).metrics) {
      return makeSymbol(text2, fontName, mode, options, classes.concat(fontClasses));
    } else if (ligatures.hasOwnProperty(text2) && fontName.slice(0, 10) === "Typewriter") {
      var parts = [];
      for (var i = 0; i < text2.length; i++) {
        parts.push(makeSymbol(text2[i], fontName, mode, options, classes.concat(fontClasses)));
      }
      return makeFragment(parts);
    }
  }
  if (type === "mathord") {
    return makeSymbol(text2, "Math-Italic", mode, options, classes.concat(["mathnormal"]));
  } else if (type === "textord") {
    var font = symbols[mode][text2] && symbols[mode][text2].font;
    if (font === "ams") {
      var _fontName = retrieveTextFontName("amsrm", options.fontWeight, options.fontShape);
      return makeSymbol(text2, _fontName, mode, options, classes.concat("amsrm", options.fontWeight, options.fontShape));
    } else if (font === "main" || !font) {
      var _fontName2 = retrieveTextFontName("textrm", options.fontWeight, options.fontShape);
      return makeSymbol(text2, _fontName2, mode, options, classes.concat(options.fontWeight, options.fontShape));
    } else {
      var _fontName3 = retrieveTextFontName(font, options.fontWeight, options.fontShape);
      return makeSymbol(text2, _fontName3, mode, options, classes.concat(_fontName3, options.fontWeight, options.fontShape));
    }
  } else {
    throw new Error("unexpected type: " + type + " in makeOrd");
  }
};
var canCombine = (prev, next) => {
  if (createClass(prev.classes) !== createClass(next.classes) || prev.skew !== next.skew || prev.maxFontSize !== next.maxFontSize) {
    return false;
  }
  if (prev.classes.length === 1) {
    var cls = prev.classes[0];
    if (cls === "mbin" || cls === "mord") {
      return false;
    }
  }
  for (var style in prev.style) {
    if (prev.style.hasOwnProperty(style) && prev.style[style] !== next.style[style]) {
      return false;
    }
  }
  for (var _style in next.style) {
    if (next.style.hasOwnProperty(_style) && prev.style[_style] !== next.style[_style]) {
      return false;
    }
  }
  return true;
};
var tryCombineChars = (chars) => {
  for (var i = 0; i < chars.length - 1; i++) {
    var prev = chars[i];
    var next = chars[i + 1];
    if (prev instanceof SymbolNode && next instanceof SymbolNode && canCombine(prev, next)) {
      prev.text += next.text;
      prev.height = Math.max(prev.height, next.height);
      prev.depth = Math.max(prev.depth, next.depth);
      prev.italic = next.italic;
      chars.splice(i + 1, 1);
      i--;
    }
  }
  return chars;
};
var sizeElementFromChildren = function sizeElementFromChildren2(elem) {
  var height = 0;
  var depth = 0;
  var maxFontSize = 0;
  for (var i = 0; i < elem.children.length; i++) {
    var child = elem.children[i];
    if (child.height > height) {
      height = child.height;
    }
    if (child.depth > depth) {
      depth = child.depth;
    }
    if (child.maxFontSize > maxFontSize) {
      maxFontSize = child.maxFontSize;
    }
  }
  elem.height = height;
  elem.depth = depth;
  elem.maxFontSize = maxFontSize;
};
var makeSpan$2 = function makeSpan(classes, children, options, style) {
  var span = new Span(classes, children, options, style);
  sizeElementFromChildren(span);
  return span;
};
var makeSvgSpan = (classes, children, options, style) => new Span(classes, children, options, style);
var makeLineSpan = function makeLineSpan2(className, options, thickness) {
  var line = makeSpan$2([className], [], options);
  line.height = Math.max(thickness || options.fontMetrics().defaultRuleThickness, options.minRuleThickness);
  line.style.borderBottomWidth = makeEm(line.height);
  line.maxFontSize = 1;
  return line;
};
var makeAnchor = function makeAnchor2(href, classes, children, options) {
  var anchor = new Anchor(href, classes, children, options);
  sizeElementFromChildren(anchor);
  return anchor;
};
var makeFragment = function makeFragment2(children) {
  var fragment = new DocumentFragment(children);
  sizeElementFromChildren(fragment);
  return fragment;
};
var wrapFragment = function wrapFragment2(group, options) {
  if (group instanceof DocumentFragment) {
    return makeSpan$2([], [group], options);
  }
  return group;
};
var getVListChildrenAndDepth = function getVListChildrenAndDepth2(params) {
  if (params.positionType === "individualShift") {
    var oldChildren = params.children;
    var children = [oldChildren[0]];
    var _depth = -oldChildren[0].shift - oldChildren[0].elem.depth;
    var currPos = _depth;
    for (var i = 1; i < oldChildren.length; i++) {
      var diff = -oldChildren[i].shift - currPos - oldChildren[i].elem.depth;
      var size = diff - (oldChildren[i - 1].elem.height + oldChildren[i - 1].elem.depth);
      currPos = currPos + diff;
      children.push({
        type: "kern",
        size
      });
      children.push(oldChildren[i]);
    }
    return {
      children,
      depth: _depth
    };
  }
  var depth;
  if (params.positionType === "top") {
    var bottom = params.positionData;
    for (var _i = 0; _i < params.children.length; _i++) {
      var child = params.children[_i];
      bottom -= child.type === "kern" ? child.size : child.elem.height + child.elem.depth;
    }
    depth = bottom;
  } else if (params.positionType === "bottom") {
    depth = -params.positionData;
  } else {
    var firstChild = params.children[0];
    if (firstChild.type !== "elem") {
      throw new Error('First child must have type "elem".');
    }
    if (params.positionType === "shift") {
      depth = -firstChild.elem.depth - params.positionData;
    } else if (params.positionType === "firstBaseline") {
      depth = -firstChild.elem.depth;
    } else {
      throw new Error("Invalid positionType " + params.positionType + ".");
    }
  }
  return {
    children: params.children,
    depth
  };
};
var makeVList = function makeVList2(params, options) {
  var {
    children,
    depth
  } = getVListChildrenAndDepth(params);
  var pstrutSize = 0;
  for (var i = 0; i < children.length; i++) {
    var child = children[i];
    if (child.type === "elem") {
      var elem = child.elem;
      pstrutSize = Math.max(pstrutSize, elem.maxFontSize, elem.height);
    }
  }
  pstrutSize += 2;
  var pstrut = makeSpan$2(["pstrut"], []);
  pstrut.style.height = makeEm(pstrutSize);
  var realChildren = [];
  var minPos = depth;
  var maxPos = depth;
  var currPos = depth;
  for (var _i2 = 0; _i2 < children.length; _i2++) {
    var _child = children[_i2];
    if (_child.type === "kern") {
      currPos += _child.size;
    } else {
      var _elem = _child.elem;
      var classes = _child.wrapperClasses || [];
      var style = _child.wrapperStyle || {};
      var childWrap = makeSpan$2(classes, [pstrut, _elem], void 0, style);
      childWrap.style.top = makeEm(-pstrutSize - currPos - _elem.depth);
      if (_child.marginLeft) {
        childWrap.style.marginLeft = _child.marginLeft;
      }
      if (_child.marginRight) {
        childWrap.style.marginRight = _child.marginRight;
      }
      realChildren.push(childWrap);
      currPos += _elem.height + _elem.depth;
    }
    minPos = Math.min(minPos, currPos);
    maxPos = Math.max(maxPos, currPos);
  }
  var vlist = makeSpan$2(["vlist"], realChildren);
  vlist.style.height = makeEm(maxPos);
  var rows;
  if (minPos < 0) {
    var emptySpan = makeSpan$2([], []);
    var depthStrut = makeSpan$2(["vlist"], [emptySpan]);
    depthStrut.style.height = makeEm(-minPos);
    var topStrut = makeSpan$2(["vlist-s"], [new SymbolNode("​")]);
    rows = [makeSpan$2(["vlist-r"], [vlist, topStrut]), makeSpan$2(["vlist-r"], [depthStrut])];
  } else {
    rows = [makeSpan$2(["vlist-r"], [vlist])];
  }
  var vtable = makeSpan$2(["vlist-t"], rows);
  if (rows.length === 2) {
    vtable.classes.push("vlist-t2");
  }
  vtable.height = maxPos;
  vtable.depth = -minPos;
  return vtable;
};
var makeGlue = (measurement, options) => {
  var rule = makeSpan$2(["mspace"], [], options);
  var size = calculateSize(measurement, options);
  rule.style.marginRight = makeEm(size);
  return rule;
};
var retrieveTextFontName = function retrieveTextFontName2(fontFamily, fontWeight, fontShape) {
  var baseFontName = "";
  switch (fontFamily) {
    case "amsrm":
      baseFontName = "AMS";
      break;
    case "textrm":
      baseFontName = "Main";
      break;
    case "textsf":
      baseFontName = "SansSerif";
      break;
    case "texttt":
      baseFontName = "Typewriter";
      break;
    default:
      baseFontName = fontFamily;
  }
  var fontStylesName;
  if (fontWeight === "textbf" && fontShape === "textit") {
    fontStylesName = "BoldItalic";
  } else if (fontWeight === "textbf") {
    fontStylesName = "Bold";
  } else if (fontWeight === "textit") {
    fontStylesName = "Italic";
  } else {
    fontStylesName = "Regular";
  }
  return baseFontName + "-" + fontStylesName;
};
var fontMap = {
  // styles
  "mathbf": {
    variant: "bold",
    fontName: "Main-Bold"
  },
  "mathrm": {
    variant: "normal",
    fontName: "Main-Regular"
  },
  "textit": {
    variant: "italic",
    fontName: "Main-Italic"
  },
  "mathit": {
    variant: "italic",
    fontName: "Main-Italic"
  },
  "mathnormal": {
    variant: "italic",
    fontName: "Math-Italic"
  },
  "mathsfit": {
    variant: "sans-serif-italic",
    fontName: "SansSerif-Italic"
  },
  // "boldsymbol" is missing because they require the use of multiple fonts:
  // Math-BoldItalic and Main-Bold.  This is handled by a special case in
  // makeOrd which ends up calling boldsymbol.
  // families
  "mathbb": {
    variant: "double-struck",
    fontName: "AMS-Regular"
  },
  "mathcal": {
    variant: "script",
    fontName: "Caligraphic-Regular"
  },
  "mathfrak": {
    variant: "fraktur",
    fontName: "Fraktur-Regular"
  },
  "mathscr": {
    variant: "script",
    fontName: "Script-Regular"
  },
  "mathsf": {
    variant: "sans-serif",
    fontName: "SansSerif-Regular"
  },
  "mathtt": {
    variant: "monospace",
    fontName: "Typewriter-Regular"
  }
};
var svgData = {
  //   path, width, height
  vec: ["vec", 0.471, 0.714],
  // values from the font glyph
  oiintSize1: ["oiintSize1", 0.957, 0.499],
  // oval to overlay the integrand
  oiintSize2: ["oiintSize2", 1.472, 0.659],
  oiiintSize1: ["oiiintSize1", 1.304, 0.499],
  oiiintSize2: ["oiiintSize2", 1.98, 0.659]
};
var staticSvg = function staticSvg2(value, options) {
  var [pathName, width, height] = svgData[value];
  var path2 = new PathNode(pathName);
  var svgNode = new SvgNode([path2], {
    "width": makeEm(width),
    "height": makeEm(height),
    // Override CSS rule `.katex svg { width: 100% }`
    "style": "width:" + makeEm(width),
    "viewBox": "0 0 " + 1e3 * width + " " + 1e3 * height,
    "preserveAspectRatio": "xMinYMin"
  });
  var span = makeSvgSpan(["overlay"], [svgNode], options);
  span.height = height;
  span.style.height = makeEm(height);
  span.style.width = makeEm(width);
  return span;
};
var buildCommon = {
  fontMap,
  makeSymbol,
  mathsym,
  makeSpan: makeSpan$2,
  makeSvgSpan,
  makeLineSpan,
  makeAnchor,
  makeFragment,
  wrapFragment,
  makeVList,
  makeOrd,
  makeGlue,
  staticSvg,
  svgData,
  tryCombineChars
};
var thinspace = {
  number: 3,
  unit: "mu"
};
var mediumspace = {
  number: 4,
  unit: "mu"
};
var thickspace = {
  number: 5,
  unit: "mu"
};
var spacings = {
  mord: {
    mop: thinspace,
    mbin: mediumspace,
    mrel: thickspace,
    minner: thinspace
  },
  mop: {
    mord: thinspace,
    mop: thinspace,
    mrel: thickspace,
    minner: thinspace
  },
  mbin: {
    mord: mediumspace,
    mop: mediumspace,
    mopen: mediumspace,
    minner: mediumspace
  },
  mrel: {
    mord: thickspace,
    mop: thickspace,
    mopen: thickspace,
    minner: thickspace
  },
  mopen: {},
  mclose: {
    mop: thinspace,
    mbin: mediumspace,
    mrel: thickspace,
    minner: thinspace
  },
  mpunct: {
    mord: thinspace,
    mop: thinspace,
    mrel: thickspace,
    mopen: thinspace,
    mclose: thinspace,
    mpunct: thinspace,
    minner: thinspace
  },
  minner: {
    mord: thinspace,
    mop: thinspace,
    mbin: mediumspace,
    mrel: thickspace,
    mopen: thinspace,
    mpunct: thinspace,
    minner: thinspace
  }
};
var tightSpacings = {
  mord: {
    mop: thinspace
  },
  mop: {
    mord: thinspace,
    mop: thinspace
  },
  mbin: {},
  mrel: {},
  mopen: {},
  mclose: {
    mop: thinspace
  },
  mpunct: {},
  minner: {
    mop: thinspace
  }
};
var _functions = {};
var _htmlGroupBuilders = {};
var _mathmlGroupBuilders = {};
function defineFunction(_ref) {
  var {
    type,
    names,
    props,
    handler,
    htmlBuilder: htmlBuilder3,
    mathmlBuilder: mathmlBuilder3
  } = _ref;
  var data = {
    type,
    numArgs: props.numArgs,
    argTypes: props.argTypes,
    allowedInArgument: !!props.allowedInArgument,
    allowedInText: !!props.allowedInText,
    allowedInMath: props.allowedInMath === void 0 ? true : props.allowedInMath,
    numOptionalArgs: props.numOptionalArgs || 0,
    infix: !!props.infix,
    primitive: !!props.primitive,
    handler
  };
  for (var i = 0; i < names.length; ++i) {
    _functions[names[i]] = data;
  }
  if (type) {
    if (htmlBuilder3) {
      _htmlGroupBuilders[type] = htmlBuilder3;
    }
    if (mathmlBuilder3) {
      _mathmlGroupBuilders[type] = mathmlBuilder3;
    }
  }
}
function defineFunctionBuilders(_ref2) {
  var {
    type,
    htmlBuilder: htmlBuilder3,
    mathmlBuilder: mathmlBuilder3
  } = _ref2;
  defineFunction({
    type,
    names: [],
    props: {
      numArgs: 0
    },
    handler() {
      throw new Error("Should never be called.");
    },
    htmlBuilder: htmlBuilder3,
    mathmlBuilder: mathmlBuilder3
  });
}
var normalizeArgument = function normalizeArgument2(arg) {
  return arg.type === "ordgroup" && arg.body.length === 1 ? arg.body[0] : arg;
};
var ordargument = function ordargument2(arg) {
  return arg.type === "ordgroup" ? arg.body : [arg];
};
var makeSpan$1 = buildCommon.makeSpan;
var binLeftCanceller = ["leftmost", "mbin", "mopen", "mrel", "mop", "mpunct"];
var binRightCanceller = ["rightmost", "mrel", "mclose", "mpunct"];
var styleMap$1 = {
  "display": Style$1.DISPLAY,
  "text": Style$1.TEXT,
  "script": Style$1.SCRIPT,
  "scriptscript": Style$1.SCRIPTSCRIPT
};
var DomEnum = {
  mord: "mord",
  mop: "mop",
  mbin: "mbin",
  mrel: "mrel",
  mopen: "mopen",
  mclose: "mclose",
  mpunct: "mpunct",
  minner: "minner"
};
var buildExpression$1 = function buildExpression(expression, options, isRealGroup, surrounding) {
  if (surrounding === void 0) {
    surrounding = [null, null];
  }
  var groups = [];
  for (var i = 0; i < expression.length; i++) {
    var output = buildGroup$1(expression[i], options);
    if (output instanceof DocumentFragment) {
      var children = output.children;
      groups.push(...children);
    } else {
      groups.push(output);
    }
  }
  buildCommon.tryCombineChars(groups);
  if (!isRealGroup) {
    return groups;
  }
  var glueOptions = options;
  if (expression.length === 1) {
    var node = expression[0];
    if (node.type === "sizing") {
      glueOptions = options.havingSize(node.size);
    } else if (node.type === "styling") {
      glueOptions = options.havingStyle(styleMap$1[node.style]);
    }
  }
  var dummyPrev = makeSpan$1([surrounding[0] || "leftmost"], [], options);
  var dummyNext = makeSpan$1([surrounding[1] || "rightmost"], [], options);
  var isRoot = isRealGroup === "root";
  traverseNonSpaceNodes(groups, (node2, prev) => {
    var prevType = prev.classes[0];
    var type = node2.classes[0];
    if (prevType === "mbin" && binRightCanceller.includes(type)) {
      prev.classes[0] = "mord";
    } else if (type === "mbin" && binLeftCanceller.includes(prevType)) {
      node2.classes[0] = "mord";
    }
  }, {
    node: dummyPrev
  }, dummyNext, isRoot);
  traverseNonSpaceNodes(groups, (node2, prev) => {
    var prevType = getTypeOfDomTree(prev);
    var type = getTypeOfDomTree(node2);
    var space = prevType && type ? node2.hasClass("mtight") ? tightSpacings[prevType][type] : spacings[prevType][type] : null;
    if (space) {
      return buildCommon.makeGlue(space, glueOptions);
    }
  }, {
    node: dummyPrev
  }, dummyNext, isRoot);
  return groups;
};
var traverseNonSpaceNodes = function traverseNonSpaceNodes2(nodes, callback, prev, next, isRoot) {
  if (next) {
    nodes.push(next);
  }
  var i = 0;
  for (; i < nodes.length; i++) {
    var node = nodes[i];
    var partialGroup = checkPartialGroup(node);
    if (partialGroup) {
      traverseNonSpaceNodes2(partialGroup.children, callback, prev, null, isRoot);
      continue;
    }
    var nonspace = !node.hasClass("mspace");
    if (nonspace) {
      var result = callback(node, prev.node);
      if (result) {
        if (prev.insertAfter) {
          prev.insertAfter(result);
        } else {
          nodes.unshift(result);
          i++;
        }
      }
    }
    if (nonspace) {
      prev.node = node;
    } else if (isRoot && node.hasClass("newline")) {
      prev.node = makeSpan$1(["leftmost"]);
    }
    prev.insertAfter = /* @__PURE__ */ ((index) => (n) => {
      nodes.splice(index + 1, 0, n);
      i++;
    })(i);
  }
  if (next) {
    nodes.pop();
  }
};
var checkPartialGroup = function checkPartialGroup2(node) {
  if (node instanceof DocumentFragment || node instanceof Anchor || node instanceof Span && node.hasClass("enclosing")) {
    return node;
  }
  return null;
};
var getOutermostNode = function getOutermostNode2(node, side) {
  var partialGroup = checkPartialGroup(node);
  if (partialGroup) {
    var children = partialGroup.children;
    if (children.length) {
      if (side === "right") {
        return getOutermostNode2(children[children.length - 1], "right");
      } else if (side === "left") {
        return getOutermostNode2(children[0], "left");
      }
    }
  }
  return node;
};
var getTypeOfDomTree = function getTypeOfDomTree2(node, side) {
  if (!node) {
    return null;
  }
  if (side) {
    node = getOutermostNode(node, side);
  }
  return DomEnum[node.classes[0]] || null;
};
var makeNullDelimiter = function makeNullDelimiter2(options, classes) {
  var moreClasses = ["nulldelimiter"].concat(options.baseSizingClasses());
  return makeSpan$1(classes.concat(moreClasses));
};
var buildGroup$1 = function buildGroup(group, options, baseOptions) {
  if (!group) {
    return makeSpan$1();
  }
  if (_htmlGroupBuilders[group.type]) {
    var groupNode = _htmlGroupBuilders[group.type](group, options);
    if (baseOptions && options.size !== baseOptions.size) {
      groupNode = makeSpan$1(options.sizingClasses(baseOptions), [groupNode], options);
      var multiplier = options.sizeMultiplier / baseOptions.sizeMultiplier;
      groupNode.height *= multiplier;
      groupNode.depth *= multiplier;
    }
    return groupNode;
  } else {
    throw new ParseError("Got group of unknown type: '" + group.type + "'");
  }
};
function buildHTMLUnbreakable(children, options) {
  var body = makeSpan$1(["base"], children, options);
  var strut = makeSpan$1(["strut"]);
  strut.style.height = makeEm(body.height + body.depth);
  if (body.depth) {
    strut.style.verticalAlign = makeEm(-body.depth);
  }
  body.children.unshift(strut);
  return body;
}
function buildHTML(tree, options) {
  var tag = null;
  if (tree.length === 1 && tree[0].type === "tag") {
    tag = tree[0].tag;
    tree = tree[0].body;
  }
  var expression = buildExpression$1(tree, options, "root");
  var eqnNum;
  if (expression.length === 2 && expression[1].hasClass("tag")) {
    eqnNum = expression.pop();
  }
  var children = [];
  var parts = [];
  for (var i = 0; i < expression.length; i++) {
    parts.push(expression[i]);
    if (expression[i].hasClass("mbin") || expression[i].hasClass("mrel") || expression[i].hasClass("allowbreak")) {
      var nobreak = false;
      while (i < expression.length - 1 && expression[i + 1].hasClass("mspace") && !expression[i + 1].hasClass("newline")) {
        i++;
        parts.push(expression[i]);
        if (expression[i].hasClass("nobreak")) {
          nobreak = true;
        }
      }
      if (!nobreak) {
        children.push(buildHTMLUnbreakable(parts, options));
        parts = [];
      }
    } else if (expression[i].hasClass("newline")) {
      parts.pop();
      if (parts.length > 0) {
        children.push(buildHTMLUnbreakable(parts, options));
        parts = [];
      }
      children.push(expression[i]);
    }
  }
  if (parts.length > 0) {
    children.push(buildHTMLUnbreakable(parts, options));
  }
  var tagChild;
  if (tag) {
    tagChild = buildHTMLUnbreakable(buildExpression$1(tag, options, true));
    tagChild.classes = ["tag"];
    children.push(tagChild);
  } else if (eqnNum) {
    children.push(eqnNum);
  }
  var htmlNode = makeSpan$1(["katex-html"], children);
  htmlNode.setAttribute("aria-hidden", "true");
  if (tagChild) {
    var strut = tagChild.children[0];
    strut.style.height = makeEm(htmlNode.height + htmlNode.depth);
    if (htmlNode.depth) {
      strut.style.verticalAlign = makeEm(-htmlNode.depth);
    }
  }
  return htmlNode;
}
function newDocumentFragment(children) {
  return new DocumentFragment(children);
}
class MathNode {
  constructor(type, children, classes) {
    this.type = void 0;
    this.attributes = void 0;
    this.children = void 0;
    this.classes = void 0;
    this.type = type;
    this.attributes = {};
    this.children = children || [];
    this.classes = classes || [];
  }
  /**
   * Sets an attribute on a MathML node. MathML depends on attributes to convey a
   * semantic content, so this is used heavily.
   */
  setAttribute(name, value) {
    this.attributes[name] = value;
  }
  /**
   * Gets an attribute on a MathML node.
   */
  getAttribute(name) {
    return this.attributes[name];
  }
  /**
   * Converts the math node into a MathML-namespaced DOM element.
   */
  toNode() {
    var node = document.createElementNS("http://www.w3.org/1998/Math/MathML", this.type);
    for (var attr in this.attributes) {
      if (Object.prototype.hasOwnProperty.call(this.attributes, attr)) {
        node.setAttribute(attr, this.attributes[attr]);
      }
    }
    if (this.classes.length > 0) {
      node.className = createClass(this.classes);
    }
    for (var i = 0; i < this.children.length; i++) {
      if (this.children[i] instanceof TextNode && this.children[i + 1] instanceof TextNode) {
        var text2 = this.children[i].toText() + this.children[++i].toText();
        while (this.children[i + 1] instanceof TextNode) {
          text2 += this.children[++i].toText();
        }
        node.appendChild(new TextNode(text2).toNode());
      } else {
        node.appendChild(this.children[i].toNode());
      }
    }
    return node;
  }
  /**
   * Converts the math node into an HTML markup string.
   */
  toMarkup() {
    var markup = "<" + this.type;
    for (var attr in this.attributes) {
      if (Object.prototype.hasOwnProperty.call(this.attributes, attr)) {
        markup += " " + attr + '="';
        markup += utils.escape(this.attributes[attr]);
        markup += '"';
      }
    }
    if (this.classes.length > 0) {
      markup += ' class ="' + utils.escape(createClass(this.classes)) + '"';
    }
    markup += ">";
    for (var i = 0; i < this.children.length; i++) {
      markup += this.children[i].toMarkup();
    }
    markup += "</" + this.type + ">";
    return markup;
  }
  /**
   * Converts the math node into a string, similar to innerText, but escaped.
   */
  toText() {
    return this.children.map((child) => child.toText()).join("");
  }
}
class TextNode {
  constructor(text2) {
    this.text = void 0;
    this.text = text2;
  }
  /**
   * Converts the text node into a DOM text node.
   */
  toNode() {
    return document.createTextNode(this.text);
  }
  /**
   * Converts the text node into escaped HTML markup
   * (representing the text itself).
   */
  toMarkup() {
    return utils.escape(this.toText());
  }
  /**
   * Converts the text node into a string
   * (representing the text itself).
   */
  toText() {
    return this.text;
  }
}
class SpaceNode {
  /**
   * Create a Space node with width given in CSS ems.
   */
  constructor(width) {
    this.width = void 0;
    this.character = void 0;
    this.width = width;
    if (width >= 0.05555 && width <= 0.05556) {
      this.character = " ";
    } else if (width >= 0.1666 && width <= 0.1667) {
      this.character = " ";
    } else if (width >= 0.2222 && width <= 0.2223) {
      this.character = " ";
    } else if (width >= 0.2777 && width <= 0.2778) {
      this.character = "  ";
    } else if (width >= -0.05556 && width <= -0.05555) {
      this.character = " ⁣";
    } else if (width >= -0.1667 && width <= -0.1666) {
      this.character = " ⁣";
    } else if (width >= -0.2223 && width <= -0.2222) {
      this.character = " ⁣";
    } else if (width >= -0.2778 && width <= -0.2777) {
      this.character = " ⁣";
    } else {
      this.character = null;
    }
  }
  /**
   * Converts the math node into a MathML-namespaced DOM element.
   */
  toNode() {
    if (this.character) {
      return document.createTextNode(this.character);
    } else {
      var node = document.createElementNS("http://www.w3.org/1998/Math/MathML", "mspace");
      node.setAttribute("width", makeEm(this.width));
      return node;
    }
  }
  /**
   * Converts the math node into an HTML markup string.
   */
  toMarkup() {
    if (this.character) {
      return "<mtext>" + this.character + "</mtext>";
    } else {
      return '<mspace width="' + makeEm(this.width) + '"/>';
    }
  }
  /**
   * Converts the math node into a string, similar to innerText.
   */
  toText() {
    if (this.character) {
      return this.character;
    } else {
      return " ";
    }
  }
}
var mathMLTree = {
  MathNode,
  TextNode,
  SpaceNode,
  newDocumentFragment
};
var makeText = function makeText2(text2, mode, options) {
  if (symbols[mode][text2] && symbols[mode][text2].replace && text2.charCodeAt(0) !== 55349 && !(ligatures.hasOwnProperty(text2) && options && (options.fontFamily && options.fontFamily.slice(4, 6) === "tt" || options.font && options.font.slice(4, 6) === "tt"))) {
    text2 = symbols[mode][text2].replace;
  }
  return new mathMLTree.TextNode(text2);
};
var makeRow = function makeRow2(body) {
  if (body.length === 1) {
    return body[0];
  } else {
    return new mathMLTree.MathNode("mrow", body);
  }
};
var getVariant = function getVariant2(group, options) {
  if (options.fontFamily === "texttt") {
    return "monospace";
  } else if (options.fontFamily === "textsf") {
    if (options.fontShape === "textit" && options.fontWeight === "textbf") {
      return "sans-serif-bold-italic";
    } else if (options.fontShape === "textit") {
      return "sans-serif-italic";
    } else if (options.fontWeight === "textbf") {
      return "bold-sans-serif";
    } else {
      return "sans-serif";
    }
  } else if (options.fontShape === "textit" && options.fontWeight === "textbf") {
    return "bold-italic";
  } else if (options.fontShape === "textit") {
    return "italic";
  } else if (options.fontWeight === "textbf") {
    return "bold";
  }
  var font = options.font;
  if (!font || font === "mathnormal") {
    return null;
  }
  var mode = group.mode;
  if (font === "mathit") {
    return "italic";
  } else if (font === "boldsymbol") {
    return group.type === "textord" ? "bold" : "bold-italic";
  } else if (font === "mathbf") {
    return "bold";
  } else if (font === "mathbb") {
    return "double-struck";
  } else if (font === "mathsfit") {
    return "sans-serif-italic";
  } else if (font === "mathfrak") {
    return "fraktur";
  } else if (font === "mathscr" || font === "mathcal") {
    return "script";
  } else if (font === "mathsf") {
    return "sans-serif";
  } else if (font === "mathtt") {
    return "monospace";
  }
  var text2 = group.text;
  if (["\\imath", "\\jmath"].includes(text2)) {
    return null;
  }
  if (symbols[mode][text2] && symbols[mode][text2].replace) {
    text2 = symbols[mode][text2].replace;
  }
  var fontName = buildCommon.fontMap[font].fontName;
  if (getCharacterMetrics(text2, fontName, mode)) {
    return buildCommon.fontMap[font].variant;
  }
  return null;
};
function isNumberPunctuation(group) {
  if (!group) {
    return false;
  }
  if (group.type === "mi" && group.children.length === 1) {
    var child = group.children[0];
    return child instanceof TextNode && child.text === ".";
  } else if (group.type === "mo" && group.children.length === 1 && group.getAttribute("separator") === "true" && group.getAttribute("lspace") === "0em" && group.getAttribute("rspace") === "0em") {
    var _child = group.children[0];
    return _child instanceof TextNode && _child.text === ",";
  } else {
    return false;
  }
}
var buildExpression2 = function buildExpression3(expression, options, isOrdgroup) {
  if (expression.length === 1) {
    var group = buildGroup2(expression[0], options);
    if (isOrdgroup && group instanceof MathNode && group.type === "mo") {
      group.setAttribute("lspace", "0em");
      group.setAttribute("rspace", "0em");
    }
    return [group];
  }
  var groups = [];
  var lastGroup;
  for (var i = 0; i < expression.length; i++) {
    var _group = buildGroup2(expression[i], options);
    if (_group instanceof MathNode && lastGroup instanceof MathNode) {
      if (_group.type === "mtext" && lastGroup.type === "mtext" && _group.getAttribute("mathvariant") === lastGroup.getAttribute("mathvariant")) {
        lastGroup.children.push(..._group.children);
        continue;
      } else if (_group.type === "mn" && lastGroup.type === "mn") {
        lastGroup.children.push(..._group.children);
        continue;
      } else if (isNumberPunctuation(_group) && lastGroup.type === "mn") {
        lastGroup.children.push(..._group.children);
        continue;
      } else if (_group.type === "mn" && isNumberPunctuation(lastGroup)) {
        _group.children = [...lastGroup.children, ..._group.children];
        groups.pop();
      } else if ((_group.type === "msup" || _group.type === "msub") && _group.children.length >= 1 && (lastGroup.type === "mn" || isNumberPunctuation(lastGroup))) {
        var base = _group.children[0];
        if (base instanceof MathNode && base.type === "mn") {
          base.children = [...lastGroup.children, ...base.children];
          groups.pop();
        }
      } else if (lastGroup.type === "mi" && lastGroup.children.length === 1) {
        var lastChild = lastGroup.children[0];
        if (lastChild instanceof TextNode && lastChild.text === "̸" && (_group.type === "mo" || _group.type === "mi" || _group.type === "mn")) {
          var child = _group.children[0];
          if (child instanceof TextNode && child.text.length > 0) {
            child.text = child.text.slice(0, 1) + "̸" + child.text.slice(1);
            groups.pop();
          }
        }
      }
    }
    groups.push(_group);
    lastGroup = _group;
  }
  return groups;
};
var buildExpressionRow = function buildExpressionRow2(expression, options, isOrdgroup) {
  return makeRow(buildExpression2(expression, options, isOrdgroup));
};
var buildGroup2 = function buildGroup3(group, options) {
  if (!group) {
    return new mathMLTree.MathNode("mrow");
  }
  if (_mathmlGroupBuilders[group.type]) {
    var result = _mathmlGroupBuilders[group.type](group, options);
    return result;
  } else {
    throw new ParseError("Got group of unknown type: '" + group.type + "'");
  }
};
function buildMathML(tree, texExpression, options, isDisplayMode, forMathmlOnly) {
  var expression = buildExpression2(tree, options);
  var wrapper;
  if (expression.length === 1 && expression[0] instanceof MathNode && ["mrow", "mtable"].includes(expression[0].type)) {
    wrapper = expression[0];
  } else {
    wrapper = new mathMLTree.MathNode("mrow", expression);
  }
  var annotation = new mathMLTree.MathNode("annotation", [new mathMLTree.TextNode(texExpression)]);
  annotation.setAttribute("encoding", "application/x-tex");
  var semantics = new mathMLTree.MathNode("semantics", [wrapper, annotation]);
  var math2 = new mathMLTree.MathNode("math", [semantics]);
  math2.setAttribute("xmlns", "http://www.w3.org/1998/Math/MathML");
  if (isDisplayMode) {
    math2.setAttribute("display", "block");
  }
  var wrapperClass = forMathmlOnly ? "katex" : "katex-mathml";
  return buildCommon.makeSpan([wrapperClass], [math2]);
}
var optionsFromSettings = function optionsFromSettings2(settings) {
  return new Options({
    style: settings.displayMode ? Style$1.DISPLAY : Style$1.TEXT,
    maxSize: settings.maxSize,
    minRuleThickness: settings.minRuleThickness
  });
};
var displayWrap = function displayWrap2(node, settings) {
  if (settings.displayMode) {
    var classes = ["katex-display"];
    if (settings.leqno) {
      classes.push("leqno");
    }
    if (settings.fleqn) {
      classes.push("fleqn");
    }
    node = buildCommon.makeSpan(classes, [node]);
  }
  return node;
};
var buildTree = function buildTree2(tree, expression, settings) {
  var options = optionsFromSettings(settings);
  var katexNode;
  if (settings.output === "mathml") {
    return buildMathML(tree, expression, options, settings.displayMode, true);
  } else if (settings.output === "html") {
    var htmlNode = buildHTML(tree, options);
    katexNode = buildCommon.makeSpan(["katex"], [htmlNode]);
  } else {
    var mathMLNode = buildMathML(tree, expression, options, settings.displayMode, false);
    var _htmlNode = buildHTML(tree, options);
    katexNode = buildCommon.makeSpan(["katex"], [mathMLNode, _htmlNode]);
  }
  return displayWrap(katexNode, settings);
};
var buildHTMLTree = function buildHTMLTree2(tree, expression, settings) {
  var options = optionsFromSettings(settings);
  var htmlNode = buildHTML(tree, options);
  var katexNode = buildCommon.makeSpan(["katex"], [htmlNode]);
  return displayWrap(katexNode, settings);
};
var stretchyCodePoint = {
  widehat: "^",
  widecheck: "ˇ",
  widetilde: "~",
  utilde: "~",
  overleftarrow: "←",
  underleftarrow: "←",
  xleftarrow: "←",
  overrightarrow: "→",
  underrightarrow: "→",
  xrightarrow: "→",
  underbrace: "⏟",
  overbrace: "⏞",
  overgroup: "⏠",
  undergroup: "⏡",
  overleftrightarrow: "↔",
  underleftrightarrow: "↔",
  xleftrightarrow: "↔",
  Overrightarrow: "⇒",
  xRightarrow: "⇒",
  overleftharpoon: "↼",
  xleftharpoonup: "↼",
  overrightharpoon: "⇀",
  xrightharpoonup: "⇀",
  xLeftarrow: "⇐",
  xLeftrightarrow: "⇔",
  xhookleftarrow: "↩",
  xhookrightarrow: "↪",
  xmapsto: "↦",
  xrightharpoondown: "⇁",
  xleftharpoondown: "↽",
  xrightleftharpoons: "⇌",
  xleftrightharpoons: "⇋",
  xtwoheadleftarrow: "↞",
  xtwoheadrightarrow: "↠",
  xlongequal: "=",
  xtofrom: "⇄",
  xrightleftarrows: "⇄",
  xrightequilibrium: "⇌",
  // Not a perfect match.
  xleftequilibrium: "⇋",
  // None better available.
  "\\cdrightarrow": "→",
  "\\cdleftarrow": "←",
  "\\cdlongequal": "="
};
var mathMLnode = function mathMLnode2(label) {
  var node = new mathMLTree.MathNode("mo", [new mathMLTree.TextNode(stretchyCodePoint[label.replace(/^\\/, "")])]);
  node.setAttribute("stretchy", "true");
  return node;
};
var katexImagesData = {
  //   path(s), minWidth, height, align
  overrightarrow: [["rightarrow"], 0.888, 522, "xMaxYMin"],
  overleftarrow: [["leftarrow"], 0.888, 522, "xMinYMin"],
  underrightarrow: [["rightarrow"], 0.888, 522, "xMaxYMin"],
  underleftarrow: [["leftarrow"], 0.888, 522, "xMinYMin"],
  xrightarrow: [["rightarrow"], 1.469, 522, "xMaxYMin"],
  "\\cdrightarrow": [["rightarrow"], 3, 522, "xMaxYMin"],
  // CD minwwidth2.5pc
  xleftarrow: [["leftarrow"], 1.469, 522, "xMinYMin"],
  "\\cdleftarrow": [["leftarrow"], 3, 522, "xMinYMin"],
  Overrightarrow: [["doublerightarrow"], 0.888, 560, "xMaxYMin"],
  xRightarrow: [["doublerightarrow"], 1.526, 560, "xMaxYMin"],
  xLeftarrow: [["doubleleftarrow"], 1.526, 560, "xMinYMin"],
  overleftharpoon: [["leftharpoon"], 0.888, 522, "xMinYMin"],
  xleftharpoonup: [["leftharpoon"], 0.888, 522, "xMinYMin"],
  xleftharpoondown: [["leftharpoondown"], 0.888, 522, "xMinYMin"],
  overrightharpoon: [["rightharpoon"], 0.888, 522, "xMaxYMin"],
  xrightharpoonup: [["rightharpoon"], 0.888, 522, "xMaxYMin"],
  xrightharpoondown: [["rightharpoondown"], 0.888, 522, "xMaxYMin"],
  xlongequal: [["longequal"], 0.888, 334, "xMinYMin"],
  "\\cdlongequal": [["longequal"], 3, 334, "xMinYMin"],
  xtwoheadleftarrow: [["twoheadleftarrow"], 0.888, 334, "xMinYMin"],
  xtwoheadrightarrow: [["twoheadrightarrow"], 0.888, 334, "xMaxYMin"],
  overleftrightarrow: [["leftarrow", "rightarrow"], 0.888, 522],
  overbrace: [["leftbrace", "midbrace", "rightbrace"], 1.6, 548],
  underbrace: [["leftbraceunder", "midbraceunder", "rightbraceunder"], 1.6, 548],
  underleftrightarrow: [["leftarrow", "rightarrow"], 0.888, 522],
  xleftrightarrow: [["leftarrow", "rightarrow"], 1.75, 522],
  xLeftrightarrow: [["doubleleftarrow", "doublerightarrow"], 1.75, 560],
  xrightleftharpoons: [["leftharpoondownplus", "rightharpoonplus"], 1.75, 716],
  xleftrightharpoons: [["leftharpoonplus", "rightharpoondownplus"], 1.75, 716],
  xhookleftarrow: [["leftarrow", "righthook"], 1.08, 522],
  xhookrightarrow: [["lefthook", "rightarrow"], 1.08, 522],
  overlinesegment: [["leftlinesegment", "rightlinesegment"], 0.888, 522],
  underlinesegment: [["leftlinesegment", "rightlinesegment"], 0.888, 522],
  overgroup: [["leftgroup", "rightgroup"], 0.888, 342],
  undergroup: [["leftgroupunder", "rightgroupunder"], 0.888, 342],
  xmapsto: [["leftmapsto", "rightarrow"], 1.5, 522],
  xtofrom: [["leftToFrom", "rightToFrom"], 1.75, 528],
  // The next three arrows are from the mhchem package.
  // In mhchem.sty, min-length is 2.0em. But these arrows might appear in the
  // document as \xrightarrow or \xrightleftharpoons. Those have
  // min-length = 1.75em, so we set min-length on these next three to match.
  xrightleftarrows: [["baraboveleftarrow", "rightarrowabovebar"], 1.75, 901],
  xrightequilibrium: [["baraboveshortleftharpoon", "rightharpoonaboveshortbar"], 1.75, 716],
  xleftequilibrium: [["shortbaraboveleftharpoon", "shortrightharpoonabovebar"], 1.75, 716]
};
var groupLength = function groupLength2(arg) {
  if (arg.type === "ordgroup") {
    return arg.body.length;
  } else {
    return 1;
  }
};
var svgSpan = function svgSpan2(group, options) {
  function buildSvgSpan_() {
    var viewBoxWidth = 4e5;
    var label = group.label.slice(1);
    if (["widehat", "widecheck", "widetilde", "utilde"].includes(label)) {
      var grp = group;
      var numChars = groupLength(grp.base);
      var viewBoxHeight;
      var pathName;
      var _height;
      if (numChars > 5) {
        if (label === "widehat" || label === "widecheck") {
          viewBoxHeight = 420;
          viewBoxWidth = 2364;
          _height = 0.42;
          pathName = label + "4";
        } else {
          viewBoxHeight = 312;
          viewBoxWidth = 2340;
          _height = 0.34;
          pathName = "tilde4";
        }
      } else {
        var imgIndex = [1, 1, 2, 2, 3, 3][numChars];
        if (label === "widehat" || label === "widecheck") {
          viewBoxWidth = [0, 1062, 2364, 2364, 2364][imgIndex];
          viewBoxHeight = [0, 239, 300, 360, 420][imgIndex];
          _height = [0, 0.24, 0.3, 0.3, 0.36, 0.42][imgIndex];
          pathName = label + imgIndex;
        } else {
          viewBoxWidth = [0, 600, 1033, 2339, 2340][imgIndex];
          viewBoxHeight = [0, 260, 286, 306, 312][imgIndex];
          _height = [0, 0.26, 0.286, 0.3, 0.306, 0.34][imgIndex];
          pathName = "tilde" + imgIndex;
        }
      }
      var path2 = new PathNode(pathName);
      var svgNode = new SvgNode([path2], {
        "width": "100%",
        "height": makeEm(_height),
        "viewBox": "0 0 " + viewBoxWidth + " " + viewBoxHeight,
        "preserveAspectRatio": "none"
      });
      return {
        span: buildCommon.makeSvgSpan([], [svgNode], options),
        minWidth: 0,
        height: _height
      };
    } else {
      var spans = [];
      var data = katexImagesData[label];
      var [paths, _minWidth, _viewBoxHeight] = data;
      var _height2 = _viewBoxHeight / 1e3;
      var numSvgChildren = paths.length;
      var widthClasses;
      var aligns;
      if (numSvgChildren === 1) {
        var align1 = data[3];
        widthClasses = ["hide-tail"];
        aligns = [align1];
      } else if (numSvgChildren === 2) {
        widthClasses = ["halfarrow-left", "halfarrow-right"];
        aligns = ["xMinYMin", "xMaxYMin"];
      } else if (numSvgChildren === 3) {
        widthClasses = ["brace-left", "brace-center", "brace-right"];
        aligns = ["xMinYMin", "xMidYMin", "xMaxYMin"];
      } else {
        throw new Error("Correct katexImagesData or update code here to support\n                    " + numSvgChildren + " children.");
      }
      for (var i = 0; i < numSvgChildren; i++) {
        var _path = new PathNode(paths[i]);
        var _svgNode = new SvgNode([_path], {
          "width": "400em",
          "height": makeEm(_height2),
          "viewBox": "0 0 " + viewBoxWidth + " " + _viewBoxHeight,
          "preserveAspectRatio": aligns[i] + " slice"
        });
        var _span = buildCommon.makeSvgSpan([widthClasses[i]], [_svgNode], options);
        if (numSvgChildren === 1) {
          return {
            span: _span,
            minWidth: _minWidth,
            height: _height2
          };
        } else {
          _span.style.height = makeEm(_height2);
          spans.push(_span);
        }
      }
      return {
        span: buildCommon.makeSpan(["stretchy"], spans, options),
        minWidth: _minWidth,
        height: _height2
      };
    }
  }
  var {
    span,
    minWidth,
    height
  } = buildSvgSpan_();
  span.height = height;
  span.style.height = makeEm(height);
  if (minWidth > 0) {
    span.style.minWidth = makeEm(minWidth);
  }
  return span;
};
var encloseSpan = function encloseSpan2(inner2, label, topPad, bottomPad, options) {
  var img;
  var totalHeight = inner2.height + inner2.depth + topPad + bottomPad;
  if (/fbox|color|angl/.test(label)) {
    img = buildCommon.makeSpan(["stretchy", label], [], options);
    if (label === "fbox") {
      var color = options.color && options.getColor();
      if (color) {
        img.style.borderColor = color;
      }
    }
  } else {
    var lines = [];
    if (/^[bx]cancel$/.test(label)) {
      lines.push(new LineNode({
        "x1": "0",
        "y1": "0",
        "x2": "100%",
        "y2": "100%",
        "stroke-width": "0.046em"
      }));
    }
    if (/^x?cancel$/.test(label)) {
      lines.push(new LineNode({
        "x1": "0",
        "y1": "100%",
        "x2": "100%",
        "y2": "0",
        "stroke-width": "0.046em"
      }));
    }
    var svgNode = new SvgNode(lines, {
      "width": "100%",
      "height": makeEm(totalHeight)
    });
    img = buildCommon.makeSvgSpan([], [svgNode], options);
  }
  img.height = totalHeight;
  img.style.height = makeEm(totalHeight);
  return img;
};
var stretchy = {
  encloseSpan,
  mathMLnode,
  svgSpan
};
function assertNodeType(node, type) {
  if (!node || node.type !== type) {
    throw new Error("Expected node of type " + type + ", but got " + (node ? "node of type " + node.type : String(node)));
  }
  return node;
}
function assertSymbolNodeType(node) {
  var typedNode = checkSymbolNodeType(node);
  if (!typedNode) {
    throw new Error("Expected node of symbol group type, but got " + (node ? "node of type " + node.type : String(node)));
  }
  return typedNode;
}
function checkSymbolNodeType(node) {
  if (node && (node.type === "atom" || NON_ATOMS.hasOwnProperty(node.type))) {
    return node;
  }
  return null;
}
var htmlBuilder$a = (grp, options) => {
  var base;
  var group;
  var supSubGroup;
  if (grp && grp.type === "supsub") {
    group = assertNodeType(grp.base, "accent");
    base = group.base;
    grp.base = base;
    supSubGroup = assertSpan(buildGroup$1(grp, options));
    grp.base = group;
  } else {
    group = assertNodeType(grp, "accent");
    base = group.base;
  }
  var body = buildGroup$1(base, options.havingCrampedStyle());
  var mustShift = group.isShifty && utils.isCharacterBox(base);
  var skew = 0;
  if (mustShift) {
    var baseChar = utils.getBaseElem(base);
    var baseGroup = buildGroup$1(baseChar, options.havingCrampedStyle());
    skew = assertSymbolDomNode(baseGroup).skew;
  }
  var accentBelow = group.label === "\\c";
  var clearance = accentBelow ? body.height + body.depth : Math.min(body.height, options.fontMetrics().xHeight);
  var accentBody;
  if (!group.isStretchy) {
    var accent2;
    var width;
    if (group.label === "\\vec") {
      accent2 = buildCommon.staticSvg("vec", options);
      width = buildCommon.svgData.vec[1];
    } else {
      accent2 = buildCommon.makeOrd({
        mode: group.mode,
        text: group.label
      }, options, "textord");
      accent2 = assertSymbolDomNode(accent2);
      accent2.italic = 0;
      width = accent2.width;
      if (accentBelow) {
        clearance += accent2.depth;
      }
    }
    accentBody = buildCommon.makeSpan(["accent-body"], [accent2]);
    var accentFull = group.label === "\\textcircled";
    if (accentFull) {
      accentBody.classes.push("accent-full");
      clearance = body.height;
    }
    var left = skew;
    if (!accentFull) {
      left -= width / 2;
    }
    accentBody.style.left = makeEm(left);
    if (group.label === "\\textcircled") {
      accentBody.style.top = ".2em";
    }
    accentBody = buildCommon.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: body
      }, {
        type: "kern",
        size: -clearance
      }, {
        type: "elem",
        elem: accentBody
      }]
    }, options);
  } else {
    accentBody = stretchy.svgSpan(group, options);
    accentBody = buildCommon.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: body
      }, {
        type: "elem",
        elem: accentBody,
        wrapperClasses: ["svg-align"],
        wrapperStyle: skew > 0 ? {
          width: "calc(100% - " + makeEm(2 * skew) + ")",
          marginLeft: makeEm(2 * skew)
        } : void 0
      }]
    }, options);
  }
  var accentWrap = buildCommon.makeSpan(["mord", "accent"], [accentBody], options);
  if (supSubGroup) {
    supSubGroup.children[0] = accentWrap;
    supSubGroup.height = Math.max(accentWrap.height, supSubGroup.height);
    supSubGroup.classes[0] = "mord";
    return supSubGroup;
  } else {
    return accentWrap;
  }
};
var mathmlBuilder$9 = (group, options) => {
  var accentNode = group.isStretchy ? stretchy.mathMLnode(group.label) : new mathMLTree.MathNode("mo", [makeText(group.label, group.mode)]);
  var node = new mathMLTree.MathNode("mover", [buildGroup2(group.base, options), accentNode]);
  node.setAttribute("accent", "true");
  return node;
};
var NON_STRETCHY_ACCENT_REGEX = new RegExp(["\\acute", "\\grave", "\\ddot", "\\tilde", "\\bar", "\\breve", "\\check", "\\hat", "\\vec", "\\dot", "\\mathring"].map((accent2) => "\\" + accent2).join("|"));
defineFunction({
  type: "accent",
  names: ["\\acute", "\\grave", "\\ddot", "\\tilde", "\\bar", "\\breve", "\\check", "\\hat", "\\vec", "\\dot", "\\mathring", "\\widecheck", "\\widehat", "\\widetilde", "\\overrightarrow", "\\overleftarrow", "\\Overrightarrow", "\\overleftrightarrow", "\\overgroup", "\\overlinesegment", "\\overleftharpoon", "\\overrightharpoon"],
  props: {
    numArgs: 1
  },
  handler: (context, args) => {
    var base = normalizeArgument(args[0]);
    var isStretchy = !NON_STRETCHY_ACCENT_REGEX.test(context.funcName);
    var isShifty = !isStretchy || context.funcName === "\\widehat" || context.funcName === "\\widetilde" || context.funcName === "\\widecheck";
    return {
      type: "accent",
      mode: context.parser.mode,
      label: context.funcName,
      isStretchy,
      isShifty,
      base
    };
  },
  htmlBuilder: htmlBuilder$a,
  mathmlBuilder: mathmlBuilder$9
});
defineFunction({
  type: "accent",
  names: ["\\'", "\\`", "\\^", "\\~", "\\=", "\\u", "\\.", '\\"', "\\c", "\\r", "\\H", "\\v", "\\textcircled"],
  props: {
    numArgs: 1,
    allowedInText: true,
    allowedInMath: true,
    // unless in strict mode
    argTypes: ["primitive"]
  },
  handler: (context, args) => {
    var base = args[0];
    var mode = context.parser.mode;
    if (mode === "math") {
      context.parser.settings.reportNonstrict("mathVsTextAccents", "LaTeX's accent " + context.funcName + " works only in text mode");
      mode = "text";
    }
    return {
      type: "accent",
      mode,
      label: context.funcName,
      isStretchy: false,
      isShifty: true,
      base
    };
  },
  htmlBuilder: htmlBuilder$a,
  mathmlBuilder: mathmlBuilder$9
});
defineFunction({
  type: "accentUnder",
  names: ["\\underleftarrow", "\\underrightarrow", "\\underleftrightarrow", "\\undergroup", "\\underlinesegment", "\\utilde"],
  props: {
    numArgs: 1
  },
  handler: (_ref, args) => {
    var {
      parser,
      funcName
    } = _ref;
    var base = args[0];
    return {
      type: "accentUnder",
      mode: parser.mode,
      label: funcName,
      base
    };
  },
  htmlBuilder: (group, options) => {
    var innerGroup = buildGroup$1(group.base, options);
    var accentBody = stretchy.svgSpan(group, options);
    var kern = group.label === "\\utilde" ? 0.12 : 0;
    var vlist = buildCommon.makeVList({
      positionType: "top",
      positionData: innerGroup.height,
      children: [{
        type: "elem",
        elem: accentBody,
        wrapperClasses: ["svg-align"]
      }, {
        type: "kern",
        size: kern
      }, {
        type: "elem",
        elem: innerGroup
      }]
    }, options);
    return buildCommon.makeSpan(["mord", "accentunder"], [vlist], options);
  },
  mathmlBuilder: (group, options) => {
    var accentNode = stretchy.mathMLnode(group.label);
    var node = new mathMLTree.MathNode("munder", [buildGroup2(group.base, options), accentNode]);
    node.setAttribute("accentunder", "true");
    return node;
  }
});
var paddedNode = (group) => {
  var node = new mathMLTree.MathNode("mpadded", group ? [group] : []);
  node.setAttribute("width", "+0.6em");
  node.setAttribute("lspace", "0.3em");
  return node;
};
defineFunction({
  type: "xArrow",
  names: [
    "\\xleftarrow",
    "\\xrightarrow",
    "\\xLeftarrow",
    "\\xRightarrow",
    "\\xleftrightarrow",
    "\\xLeftrightarrow",
    "\\xhookleftarrow",
    "\\xhookrightarrow",
    "\\xmapsto",
    "\\xrightharpoondown",
    "\\xrightharpoonup",
    "\\xleftharpoondown",
    "\\xleftharpoonup",
    "\\xrightleftharpoons",
    "\\xleftrightharpoons",
    "\\xlongequal",
    "\\xtwoheadrightarrow",
    "\\xtwoheadleftarrow",
    "\\xtofrom",
    // The next 3 functions are here to support the mhchem extension.
    // Direct use of these functions is discouraged and may break someday.
    "\\xrightleftarrows",
    "\\xrightequilibrium",
    "\\xleftequilibrium",
    // The next 3 functions are here only to support the {CD} environment.
    "\\\\cdrightarrow",
    "\\\\cdleftarrow",
    "\\\\cdlongequal"
  ],
  props: {
    numArgs: 1,
    numOptionalArgs: 1
  },
  handler(_ref, args, optArgs) {
    var {
      parser,
      funcName
    } = _ref;
    return {
      type: "xArrow",
      mode: parser.mode,
      label: funcName,
      body: args[0],
      below: optArgs[0]
    };
  },
  // Flow is unable to correctly infer the type of `group`, even though it's
  // unambiguously determined from the passed-in `type` above.
  htmlBuilder(group, options) {
    var style = options.style;
    var newOptions = options.havingStyle(style.sup());
    var upperGroup = buildCommon.wrapFragment(buildGroup$1(group.body, newOptions, options), options);
    var arrowPrefix = group.label.slice(0, 2) === "\\x" ? "x" : "cd";
    upperGroup.classes.push(arrowPrefix + "-arrow-pad");
    var lowerGroup;
    if (group.below) {
      newOptions = options.havingStyle(style.sub());
      lowerGroup = buildCommon.wrapFragment(buildGroup$1(group.below, newOptions, options), options);
      lowerGroup.classes.push(arrowPrefix + "-arrow-pad");
    }
    var arrowBody = stretchy.svgSpan(group, options);
    var arrowShift = -options.fontMetrics().axisHeight + 0.5 * arrowBody.height;
    var upperShift = -options.fontMetrics().axisHeight - 0.5 * arrowBody.height - 0.111;
    if (upperGroup.depth > 0.25 || group.label === "\\xleftequilibrium") {
      upperShift -= upperGroup.depth;
    }
    var vlist;
    if (lowerGroup) {
      var lowerShift = -options.fontMetrics().axisHeight + lowerGroup.height + 0.5 * arrowBody.height + 0.111;
      vlist = buildCommon.makeVList({
        positionType: "individualShift",
        children: [{
          type: "elem",
          elem: upperGroup,
          shift: upperShift
        }, {
          type: "elem",
          elem: arrowBody,
          shift: arrowShift
        }, {
          type: "elem",
          elem: lowerGroup,
          shift: lowerShift
        }]
      }, options);
    } else {
      vlist = buildCommon.makeVList({
        positionType: "individualShift",
        children: [{
          type: "elem",
          elem: upperGroup,
          shift: upperShift
        }, {
          type: "elem",
          elem: arrowBody,
          shift: arrowShift
        }]
      }, options);
    }
    vlist.children[0].children[0].children[1].classes.push("svg-align");
    return buildCommon.makeSpan(["mrel", "x-arrow"], [vlist], options);
  },
  mathmlBuilder(group, options) {
    var arrowNode = stretchy.mathMLnode(group.label);
    arrowNode.setAttribute("minsize", group.label.charAt(0) === "x" ? "1.75em" : "3.0em");
    var node;
    if (group.body) {
      var upperNode = paddedNode(buildGroup2(group.body, options));
      if (group.below) {
        var lowerNode = paddedNode(buildGroup2(group.below, options));
        node = new mathMLTree.MathNode("munderover", [arrowNode, lowerNode, upperNode]);
      } else {
        node = new mathMLTree.MathNode("mover", [arrowNode, upperNode]);
      }
    } else if (group.below) {
      var _lowerNode = paddedNode(buildGroup2(group.below, options));
      node = new mathMLTree.MathNode("munder", [arrowNode, _lowerNode]);
    } else {
      node = paddedNode();
      node = new mathMLTree.MathNode("mover", [arrowNode, node]);
    }
    return node;
  }
});
var makeSpan2 = buildCommon.makeSpan;
function htmlBuilder$9(group, options) {
  var elements = buildExpression$1(group.body, options, true);
  return makeSpan2([group.mclass], elements, options);
}
function mathmlBuilder$8(group, options) {
  var node;
  var inner2 = buildExpression2(group.body, options);
  if (group.mclass === "minner") {
    node = new mathMLTree.MathNode("mpadded", inner2);
  } else if (group.mclass === "mord") {
    if (group.isCharacterBox) {
      node = inner2[0];
      node.type = "mi";
    } else {
      node = new mathMLTree.MathNode("mi", inner2);
    }
  } else {
    if (group.isCharacterBox) {
      node = inner2[0];
      node.type = "mo";
    } else {
      node = new mathMLTree.MathNode("mo", inner2);
    }
    if (group.mclass === "mbin") {
      node.attributes.lspace = "0.22em";
      node.attributes.rspace = "0.22em";
    } else if (group.mclass === "mpunct") {
      node.attributes.lspace = "0em";
      node.attributes.rspace = "0.17em";
    } else if (group.mclass === "mopen" || group.mclass === "mclose") {
      node.attributes.lspace = "0em";
      node.attributes.rspace = "0em";
    } else if (group.mclass === "minner") {
      node.attributes.lspace = "0.0556em";
      node.attributes.width = "+0.1111em";
    }
  }
  return node;
}
defineFunction({
  type: "mclass",
  names: ["\\mathord", "\\mathbin", "\\mathrel", "\\mathopen", "\\mathclose", "\\mathpunct", "\\mathinner"],
  props: {
    numArgs: 1,
    primitive: true
  },
  handler(_ref, args) {
    var {
      parser,
      funcName
    } = _ref;
    var body = args[0];
    return {
      type: "mclass",
      mode: parser.mode,
      mclass: "m" + funcName.slice(5),
      // TODO(kevinb): don't prefix with 'm'
      body: ordargument(body),
      isCharacterBox: utils.isCharacterBox(body)
    };
  },
  htmlBuilder: htmlBuilder$9,
  mathmlBuilder: mathmlBuilder$8
});
var binrelClass = (arg) => {
  var atom = arg.type === "ordgroup" && arg.body.length ? arg.body[0] : arg;
  if (atom.type === "atom" && (atom.family === "bin" || atom.family === "rel")) {
    return "m" + atom.family;
  } else {
    return "mord";
  }
};
defineFunction({
  type: "mclass",
  names: ["\\@binrel"],
  props: {
    numArgs: 2
  },
  handler(_ref2, args) {
    var {
      parser
    } = _ref2;
    return {
      type: "mclass",
      mode: parser.mode,
      mclass: binrelClass(args[0]),
      body: ordargument(args[1]),
      isCharacterBox: utils.isCharacterBox(args[1])
    };
  }
});
defineFunction({
  type: "mclass",
  names: ["\\stackrel", "\\overset", "\\underset"],
  props: {
    numArgs: 2
  },
  handler(_ref3, args) {
    var {
      parser,
      funcName
    } = _ref3;
    var baseArg = args[1];
    var shiftedArg = args[0];
    var mclass;
    if (funcName !== "\\stackrel") {
      mclass = binrelClass(baseArg);
    } else {
      mclass = "mrel";
    }
    var baseOp = {
      type: "op",
      mode: baseArg.mode,
      limits: true,
      alwaysHandleSupSub: true,
      parentIsSupSub: false,
      symbol: false,
      suppressBaseShift: funcName !== "\\stackrel",
      body: ordargument(baseArg)
    };
    var supsub = {
      type: "supsub",
      mode: shiftedArg.mode,
      base: baseOp,
      sup: funcName === "\\underset" ? null : shiftedArg,
      sub: funcName === "\\underset" ? shiftedArg : null
    };
    return {
      type: "mclass",
      mode: parser.mode,
      mclass,
      body: [supsub],
      isCharacterBox: utils.isCharacterBox(supsub)
    };
  },
  htmlBuilder: htmlBuilder$9,
  mathmlBuilder: mathmlBuilder$8
});
defineFunction({
  type: "pmb",
  names: ["\\pmb"],
  props: {
    numArgs: 1,
    allowedInText: true
  },
  handler(_ref, args) {
    var {
      parser
    } = _ref;
    return {
      type: "pmb",
      mode: parser.mode,
      mclass: binrelClass(args[0]),
      body: ordargument(args[0])
    };
  },
  htmlBuilder(group, options) {
    var elements = buildExpression$1(group.body, options, true);
    var node = buildCommon.makeSpan([group.mclass], elements, options);
    node.style.textShadow = "0.02em 0.01em 0.04px";
    return node;
  },
  mathmlBuilder(group, style) {
    var inner2 = buildExpression2(group.body, style);
    var node = new mathMLTree.MathNode("mstyle", inner2);
    node.setAttribute("style", "text-shadow: 0.02em 0.01em 0.04px");
    return node;
  }
});
var cdArrowFunctionName = {
  ">": "\\\\cdrightarrow",
  "<": "\\\\cdleftarrow",
  "=": "\\\\cdlongequal",
  "A": "\\uparrow",
  "V": "\\downarrow",
  "|": "\\Vert",
  ".": "no arrow"
};
var newCell = () => {
  return {
    type: "styling",
    body: [],
    mode: "math",
    style: "display"
  };
};
var isStartOfArrow = (node) => {
  return node.type === "textord" && node.text === "@";
};
var isLabelEnd = (node, endChar) => {
  return (node.type === "mathord" || node.type === "atom") && node.text === endChar;
};
function cdArrow(arrowChar, labels, parser) {
  var funcName = cdArrowFunctionName[arrowChar];
  switch (funcName) {
    case "\\\\cdrightarrow":
    case "\\\\cdleftarrow":
      return parser.callFunction(funcName, [labels[0]], [labels[1]]);
    case "\\uparrow":
    case "\\downarrow": {
      var leftLabel = parser.callFunction("\\\\cdleft", [labels[0]], []);
      var bareArrow = {
        type: "atom",
        text: funcName,
        mode: "math",
        family: "rel"
      };
      var sizedArrow = parser.callFunction("\\Big", [bareArrow], []);
      var rightLabel = parser.callFunction("\\\\cdright", [labels[1]], []);
      var arrowGroup = {
        type: "ordgroup",
        mode: "math",
        body: [leftLabel, sizedArrow, rightLabel]
      };
      return parser.callFunction("\\\\cdparent", [arrowGroup], []);
    }
    case "\\\\cdlongequal":
      return parser.callFunction("\\\\cdlongequal", [], []);
    case "\\Vert": {
      var arrow = {
        type: "textord",
        text: "\\Vert",
        mode: "math"
      };
      return parser.callFunction("\\Big", [arrow], []);
    }
    default:
      return {
        type: "textord",
        text: " ",
        mode: "math"
      };
  }
}
function parseCD(parser) {
  var parsedRows = [];
  parser.gullet.beginGroup();
  parser.gullet.macros.set("\\cr", "\\\\\\relax");
  parser.gullet.beginGroup();
  while (true) {
    parsedRows.push(parser.parseExpression(false, "\\\\"));
    parser.gullet.endGroup();
    parser.gullet.beginGroup();
    var next = parser.fetch().text;
    if (next === "&" || next === "\\\\") {
      parser.consume();
    } else if (next === "\\end") {
      if (parsedRows[parsedRows.length - 1].length === 0) {
        parsedRows.pop();
      }
      break;
    } else {
      throw new ParseError("Expected \\\\ or \\cr or \\end", parser.nextToken);
    }
  }
  var row = [];
  var body = [row];
  for (var i = 0; i < parsedRows.length; i++) {
    var rowNodes = parsedRows[i];
    var cell = newCell();
    for (var j = 0; j < rowNodes.length; j++) {
      if (!isStartOfArrow(rowNodes[j])) {
        cell.body.push(rowNodes[j]);
      } else {
        row.push(cell);
        j += 1;
        var arrowChar = assertSymbolNodeType(rowNodes[j]).text;
        var labels = new Array(2);
        labels[0] = {
          type: "ordgroup",
          mode: "math",
          body: []
        };
        labels[1] = {
          type: "ordgroup",
          mode: "math",
          body: []
        };
        if ("=|.".indexOf(arrowChar) > -1) ;
        else if ("<>AV".indexOf(arrowChar) > -1) {
          for (var labelNum = 0; labelNum < 2; labelNum++) {
            var inLabel = true;
            for (var k = j + 1; k < rowNodes.length; k++) {
              if (isLabelEnd(rowNodes[k], arrowChar)) {
                inLabel = false;
                j = k;
                break;
              }
              if (isStartOfArrow(rowNodes[k])) {
                throw new ParseError("Missing a " + arrowChar + " character to complete a CD arrow.", rowNodes[k]);
              }
              labels[labelNum].body.push(rowNodes[k]);
            }
            if (inLabel) {
              throw new ParseError("Missing a " + arrowChar + " character to complete a CD arrow.", rowNodes[j]);
            }
          }
        } else {
          throw new ParseError('Expected one of "<>AV=|." after @', rowNodes[j]);
        }
        var arrow = cdArrow(arrowChar, labels, parser);
        var wrappedArrow = {
          type: "styling",
          body: [arrow],
          mode: "math",
          style: "display"
          // CD is always displaystyle.
        };
        row.push(wrappedArrow);
        cell = newCell();
      }
    }
    if (i % 2 === 0) {
      row.push(cell);
    } else {
      row.shift();
    }
    row = [];
    body.push(row);
  }
  parser.gullet.endGroup();
  parser.gullet.endGroup();
  var cols = new Array(body[0].length).fill({
    type: "align",
    align: "c",
    pregap: 0.25,
    // CD package sets \enskip between columns.
    postgap: 0.25
    // So pre and post each get half an \enskip, i.e. 0.25em.
  });
  return {
    type: "array",
    mode: "math",
    body,
    arraystretch: 1,
    addJot: true,
    rowGaps: [null],
    cols,
    colSeparationType: "CD",
    hLinesBeforeRow: new Array(body.length + 1).fill([])
  };
}
defineFunction({
  type: "cdlabel",
  names: ["\\\\cdleft", "\\\\cdright"],
  props: {
    numArgs: 1
  },
  handler(_ref, args) {
    var {
      parser,
      funcName
    } = _ref;
    return {
      type: "cdlabel",
      mode: parser.mode,
      side: funcName.slice(4),
      label: args[0]
    };
  },
  htmlBuilder(group, options) {
    var newOptions = options.havingStyle(options.style.sup());
    var label = buildCommon.wrapFragment(buildGroup$1(group.label, newOptions, options), options);
    label.classes.push("cd-label-" + group.side);
    label.style.bottom = makeEm(0.8 - label.depth);
    label.height = 0;
    label.depth = 0;
    return label;
  },
  mathmlBuilder(group, options) {
    var label = new mathMLTree.MathNode("mrow", [buildGroup2(group.label, options)]);
    label = new mathMLTree.MathNode("mpadded", [label]);
    label.setAttribute("width", "0");
    if (group.side === "left") {
      label.setAttribute("lspace", "-1width");
    }
    label.setAttribute("voffset", "0.7em");
    label = new mathMLTree.MathNode("mstyle", [label]);
    label.setAttribute("displaystyle", "false");
    label.setAttribute("scriptlevel", "1");
    return label;
  }
});
defineFunction({
  type: "cdlabelparent",
  names: ["\\\\cdparent"],
  props: {
    numArgs: 1
  },
  handler(_ref2, args) {
    var {
      parser
    } = _ref2;
    return {
      type: "cdlabelparent",
      mode: parser.mode,
      fragment: args[0]
    };
  },
  htmlBuilder(group, options) {
    var parent = buildCommon.wrapFragment(buildGroup$1(group.fragment, options), options);
    parent.classes.push("cd-vert-arrow");
    return parent;
  },
  mathmlBuilder(group, options) {
    return new mathMLTree.MathNode("mrow", [buildGroup2(group.fragment, options)]);
  }
});
defineFunction({
  type: "textord",
  names: ["\\@char"],
  props: {
    numArgs: 1,
    allowedInText: true
  },
  handler(_ref, args) {
    var {
      parser
    } = _ref;
    var arg = assertNodeType(args[0], "ordgroup");
    var group = arg.body;
    var number = "";
    for (var i = 0; i < group.length; i++) {
      var node = assertNodeType(group[i], "textord");
      number += node.text;
    }
    var code = parseInt(number);
    var text2;
    if (isNaN(code)) {
      throw new ParseError("\\@char has non-numeric argument " + number);
    } else if (code < 0 || code >= 1114111) {
      throw new ParseError("\\@char with invalid code point " + number);
    } else if (code <= 65535) {
      text2 = String.fromCharCode(code);
    } else {
      code -= 65536;
      text2 = String.fromCharCode((code >> 10) + 55296, (code & 1023) + 56320);
    }
    return {
      type: "textord",
      mode: parser.mode,
      text: text2
    };
  }
});
var htmlBuilder$8 = (group, options) => {
  var elements = buildExpression$1(group.body, options.withColor(group.color), false);
  return buildCommon.makeFragment(elements);
};
var mathmlBuilder$7 = (group, options) => {
  var inner2 = buildExpression2(group.body, options.withColor(group.color));
  var node = new mathMLTree.MathNode("mstyle", inner2);
  node.setAttribute("mathcolor", group.color);
  return node;
};
defineFunction({
  type: "color",
  names: ["\\textcolor"],
  props: {
    numArgs: 2,
    allowedInText: true,
    argTypes: ["color", "original"]
  },
  handler(_ref, args) {
    var {
      parser
    } = _ref;
    var color = assertNodeType(args[0], "color-token").color;
    var body = args[1];
    return {
      type: "color",
      mode: parser.mode,
      color,
      body: ordargument(body)
    };
  },
  htmlBuilder: htmlBuilder$8,
  mathmlBuilder: mathmlBuilder$7
});
defineFunction({
  type: "color",
  names: ["\\color"],
  props: {
    numArgs: 1,
    allowedInText: true,
    argTypes: ["color"]
  },
  handler(_ref2, args) {
    var {
      parser,
      breakOnTokenText
    } = _ref2;
    var color = assertNodeType(args[0], "color-token").color;
    parser.gullet.macros.set("\\current@color", color);
    var body = parser.parseExpression(true, breakOnTokenText);
    return {
      type: "color",
      mode: parser.mode,
      color,
      body
    };
  },
  htmlBuilder: htmlBuilder$8,
  mathmlBuilder: mathmlBuilder$7
});
defineFunction({
  type: "cr",
  names: ["\\\\"],
  props: {
    numArgs: 0,
    numOptionalArgs: 0,
    allowedInText: true
  },
  handler(_ref, args, optArgs) {
    var {
      parser
    } = _ref;
    var size = parser.gullet.future().text === "[" ? parser.parseSizeGroup(true) : null;
    var newLine = !parser.settings.displayMode || !parser.settings.useStrictBehavior("newLineInDisplayMode", "In LaTeX, \\\\ or \\newline does nothing in display mode");
    return {
      type: "cr",
      mode: parser.mode,
      newLine,
      size: size && assertNodeType(size, "size").value
    };
  },
  // The following builders are called only at the top level,
  // not within tabular/array environments.
  htmlBuilder(group, options) {
    var span = buildCommon.makeSpan(["mspace"], [], options);
    if (group.newLine) {
      span.classes.push("newline");
      if (group.size) {
        span.style.marginTop = makeEm(calculateSize(group.size, options));
      }
    }
    return span;
  },
  mathmlBuilder(group, options) {
    var node = new mathMLTree.MathNode("mspace");
    if (group.newLine) {
      node.setAttribute("linebreak", "newline");
      if (group.size) {
        node.setAttribute("height", makeEm(calculateSize(group.size, options)));
      }
    }
    return node;
  }
});
var globalMap = {
  "\\global": "\\global",
  "\\long": "\\\\globallong",
  "\\\\globallong": "\\\\globallong",
  "\\def": "\\gdef",
  "\\gdef": "\\gdef",
  "\\edef": "\\xdef",
  "\\xdef": "\\xdef",
  "\\let": "\\\\globallet",
  "\\futurelet": "\\\\globalfuture"
};
var checkControlSequence = (tok) => {
  var name = tok.text;
  if (/^(?:[\\{}$&#^_]|EOF)$/.test(name)) {
    throw new ParseError("Expected a control sequence", tok);
  }
  return name;
};
var getRHS = (parser) => {
  var tok = parser.gullet.popToken();
  if (tok.text === "=") {
    tok = parser.gullet.popToken();
    if (tok.text === " ") {
      tok = parser.gullet.popToken();
    }
  }
  return tok;
};
var letCommand = (parser, name, tok, global) => {
  var macro = parser.gullet.macros.get(tok.text);
  if (macro == null) {
    tok.noexpand = true;
    macro = {
      tokens: [tok],
      numArgs: 0,
      // reproduce the same behavior in expansion
      unexpandable: !parser.gullet.isExpandable(tok.text)
    };
  }
  parser.gullet.macros.set(name, macro, global);
};
defineFunction({
  type: "internal",
  names: [
    "\\global",
    "\\long",
    "\\\\globallong"
    // can’t be entered directly
  ],
  props: {
    numArgs: 0,
    allowedInText: true
  },
  handler(_ref) {
    var {
      parser,
      funcName
    } = _ref;
    parser.consumeSpaces();
    var token = parser.fetch();
    if (globalMap[token.text]) {
      if (funcName === "\\global" || funcName === "\\\\globallong") {
        token.text = globalMap[token.text];
      }
      return assertNodeType(parser.parseFunction(), "internal");
    }
    throw new ParseError("Invalid token after macro prefix", token);
  }
});
defineFunction({
  type: "internal",
  names: ["\\def", "\\gdef", "\\edef", "\\xdef"],
  props: {
    numArgs: 0,
    allowedInText: true,
    primitive: true
  },
  handler(_ref2) {
    var {
      parser,
      funcName
    } = _ref2;
    var tok = parser.gullet.popToken();
    var name = tok.text;
    if (/^(?:[\\{}$&#^_]|EOF)$/.test(name)) {
      throw new ParseError("Expected a control sequence", tok);
    }
    var numArgs = 0;
    var insert;
    var delimiters2 = [[]];
    while (parser.gullet.future().text !== "{") {
      tok = parser.gullet.popToken();
      if (tok.text === "#") {
        if (parser.gullet.future().text === "{") {
          insert = parser.gullet.future();
          delimiters2[numArgs].push("{");
          break;
        }
        tok = parser.gullet.popToken();
        if (!/^[1-9]$/.test(tok.text)) {
          throw new ParseError('Invalid argument number "' + tok.text + '"');
        }
        if (parseInt(tok.text) !== numArgs + 1) {
          throw new ParseError('Argument number "' + tok.text + '" out of order');
        }
        numArgs++;
        delimiters2.push([]);
      } else if (tok.text === "EOF") {
        throw new ParseError("Expected a macro definition");
      } else {
        delimiters2[numArgs].push(tok.text);
      }
    }
    var {
      tokens
    } = parser.gullet.consumeArg();
    if (insert) {
      tokens.unshift(insert);
    }
    if (funcName === "\\edef" || funcName === "\\xdef") {
      tokens = parser.gullet.expandTokens(tokens);
      tokens.reverse();
    }
    parser.gullet.macros.set(name, {
      tokens,
      numArgs,
      delimiters: delimiters2
    }, funcName === globalMap[funcName]);
    return {
      type: "internal",
      mode: parser.mode
    };
  }
});
defineFunction({
  type: "internal",
  names: [
    "\\let",
    "\\\\globallet"
    // can’t be entered directly
  ],
  props: {
    numArgs: 0,
    allowedInText: true,
    primitive: true
  },
  handler(_ref3) {
    var {
      parser,
      funcName
    } = _ref3;
    var name = checkControlSequence(parser.gullet.popToken());
    parser.gullet.consumeSpaces();
    var tok = getRHS(parser);
    letCommand(parser, name, tok, funcName === "\\\\globallet");
    return {
      type: "internal",
      mode: parser.mode
    };
  }
});
defineFunction({
  type: "internal",
  names: [
    "\\futurelet",
    "\\\\globalfuture"
    // can’t be entered directly
  ],
  props: {
    numArgs: 0,
    allowedInText: true,
    primitive: true
  },
  handler(_ref4) {
    var {
      parser,
      funcName
    } = _ref4;
    var name = checkControlSequence(parser.gullet.popToken());
    var middle = parser.gullet.popToken();
    var tok = parser.gullet.popToken();
    letCommand(parser, name, tok, funcName === "\\\\globalfuture");
    parser.gullet.pushToken(tok);
    parser.gullet.pushToken(middle);
    return {
      type: "internal",
      mode: parser.mode
    };
  }
});
var getMetrics = function getMetrics2(symbol, font, mode) {
  var replace = symbols.math[symbol] && symbols.math[symbol].replace;
  var metrics = getCharacterMetrics(replace || symbol, font, mode);
  if (!metrics) {
    throw new Error("Unsupported symbol " + symbol + " and font size " + font + ".");
  }
  return metrics;
};
var styleWrap = function styleWrap2(delim, toStyle, options, classes) {
  var newOptions = options.havingBaseStyle(toStyle);
  var span = buildCommon.makeSpan(classes.concat(newOptions.sizingClasses(options)), [delim], options);
  var delimSizeMultiplier = newOptions.sizeMultiplier / options.sizeMultiplier;
  span.height *= delimSizeMultiplier;
  span.depth *= delimSizeMultiplier;
  span.maxFontSize = newOptions.sizeMultiplier;
  return span;
};
var centerSpan = function centerSpan2(span, options, style) {
  var newOptions = options.havingBaseStyle(style);
  var shift = (1 - options.sizeMultiplier / newOptions.sizeMultiplier) * options.fontMetrics().axisHeight;
  span.classes.push("delimcenter");
  span.style.top = makeEm(shift);
  span.height -= shift;
  span.depth += shift;
};
var makeSmallDelim = function makeSmallDelim2(delim, style, center, options, mode, classes) {
  var text2 = buildCommon.makeSymbol(delim, "Main-Regular", mode, options);
  var span = styleWrap(text2, style, options, classes);
  if (center) {
    centerSpan(span, options, style);
  }
  return span;
};
var mathrmSize = function mathrmSize2(value, size, mode, options) {
  return buildCommon.makeSymbol(value, "Size" + size + "-Regular", mode, options);
};
var makeLargeDelim = function makeLargeDelim2(delim, size, center, options, mode, classes) {
  var inner2 = mathrmSize(delim, size, mode, options);
  var span = styleWrap(buildCommon.makeSpan(["delimsizing", "size" + size], [inner2], options), Style$1.TEXT, options, classes);
  if (center) {
    centerSpan(span, options, Style$1.TEXT);
  }
  return span;
};
var makeGlyphSpan = function makeGlyphSpan2(symbol, font, mode) {
  var sizeClass;
  if (font === "Size1-Regular") {
    sizeClass = "delim-size1";
  } else {
    sizeClass = "delim-size4";
  }
  var corner = buildCommon.makeSpan(["delimsizinginner", sizeClass], [buildCommon.makeSpan([], [buildCommon.makeSymbol(symbol, font, mode)])]);
  return {
    type: "elem",
    elem: corner
  };
};
var makeInner = function makeInner2(ch, height, options) {
  var width = fontMetricsData["Size4-Regular"][ch.charCodeAt(0)] ? fontMetricsData["Size4-Regular"][ch.charCodeAt(0)][4] : fontMetricsData["Size1-Regular"][ch.charCodeAt(0)][4];
  var path2 = new PathNode("inner", innerPath(ch, Math.round(1e3 * height)));
  var svgNode = new SvgNode([path2], {
    "width": makeEm(width),
    "height": makeEm(height),
    // Override CSS rule `.katex svg { width: 100% }`
    "style": "width:" + makeEm(width),
    "viewBox": "0 0 " + 1e3 * width + " " + Math.round(1e3 * height),
    "preserveAspectRatio": "xMinYMin"
  });
  var span = buildCommon.makeSvgSpan([], [svgNode], options);
  span.height = height;
  span.style.height = makeEm(height);
  span.style.width = makeEm(width);
  return {
    type: "elem",
    elem: span
  };
};
var lapInEms = 8e-3;
var lap = {
  type: "kern",
  size: -1 * lapInEms
};
var verts = ["|", "\\lvert", "\\rvert", "\\vert"];
var doubleVerts = ["\\|", "\\lVert", "\\rVert", "\\Vert"];
var makeStackedDelim = function makeStackedDelim2(delim, heightTotal, center, options, mode, classes) {
  var top;
  var middle;
  var repeat;
  var bottom;
  var svgLabel = "";
  var viewBoxWidth = 0;
  top = repeat = bottom = delim;
  middle = null;
  var font = "Size1-Regular";
  if (delim === "\\uparrow") {
    repeat = bottom = "⏐";
  } else if (delim === "\\Uparrow") {
    repeat = bottom = "‖";
  } else if (delim === "\\downarrow") {
    top = repeat = "⏐";
  } else if (delim === "\\Downarrow") {
    top = repeat = "‖";
  } else if (delim === "\\updownarrow") {
    top = "\\uparrow";
    repeat = "⏐";
    bottom = "\\downarrow";
  } else if (delim === "\\Updownarrow") {
    top = "\\Uparrow";
    repeat = "‖";
    bottom = "\\Downarrow";
  } else if (verts.includes(delim)) {
    repeat = "∣";
    svgLabel = "vert";
    viewBoxWidth = 333;
  } else if (doubleVerts.includes(delim)) {
    repeat = "∥";
    svgLabel = "doublevert";
    viewBoxWidth = 556;
  } else if (delim === "[" || delim === "\\lbrack") {
    top = "⎡";
    repeat = "⎢";
    bottom = "⎣";
    font = "Size4-Regular";
    svgLabel = "lbrack";
    viewBoxWidth = 667;
  } else if (delim === "]" || delim === "\\rbrack") {
    top = "⎤";
    repeat = "⎥";
    bottom = "⎦";
    font = "Size4-Regular";
    svgLabel = "rbrack";
    viewBoxWidth = 667;
  } else if (delim === "\\lfloor" || delim === "⌊") {
    repeat = top = "⎢";
    bottom = "⎣";
    font = "Size4-Regular";
    svgLabel = "lfloor";
    viewBoxWidth = 667;
  } else if (delim === "\\lceil" || delim === "⌈") {
    top = "⎡";
    repeat = bottom = "⎢";
    font = "Size4-Regular";
    svgLabel = "lceil";
    viewBoxWidth = 667;
  } else if (delim === "\\rfloor" || delim === "⌋") {
    repeat = top = "⎥";
    bottom = "⎦";
    font = "Size4-Regular";
    svgLabel = "rfloor";
    viewBoxWidth = 667;
  } else if (delim === "\\rceil" || delim === "⌉") {
    top = "⎤";
    repeat = bottom = "⎥";
    font = "Size4-Regular";
    svgLabel = "rceil";
    viewBoxWidth = 667;
  } else if (delim === "(" || delim === "\\lparen") {
    top = "⎛";
    repeat = "⎜";
    bottom = "⎝";
    font = "Size4-Regular";
    svgLabel = "lparen";
    viewBoxWidth = 875;
  } else if (delim === ")" || delim === "\\rparen") {
    top = "⎞";
    repeat = "⎟";
    bottom = "⎠";
    font = "Size4-Regular";
    svgLabel = "rparen";
    viewBoxWidth = 875;
  } else if (delim === "\\{" || delim === "\\lbrace") {
    top = "⎧";
    middle = "⎨";
    bottom = "⎩";
    repeat = "⎪";
    font = "Size4-Regular";
  } else if (delim === "\\}" || delim === "\\rbrace") {
    top = "⎫";
    middle = "⎬";
    bottom = "⎭";
    repeat = "⎪";
    font = "Size4-Regular";
  } else if (delim === "\\lgroup" || delim === "⟮") {
    top = "⎧";
    bottom = "⎩";
    repeat = "⎪";
    font = "Size4-Regular";
  } else if (delim === "\\rgroup" || delim === "⟯") {
    top = "⎫";
    bottom = "⎭";
    repeat = "⎪";
    font = "Size4-Regular";
  } else if (delim === "\\lmoustache" || delim === "⎰") {
    top = "⎧";
    bottom = "⎭";
    repeat = "⎪";
    font = "Size4-Regular";
  } else if (delim === "\\rmoustache" || delim === "⎱") {
    top = "⎫";
    bottom = "⎩";
    repeat = "⎪";
    font = "Size4-Regular";
  }
  var topMetrics = getMetrics(top, font, mode);
  var topHeightTotal = topMetrics.height + topMetrics.depth;
  var repeatMetrics = getMetrics(repeat, font, mode);
  var repeatHeightTotal = repeatMetrics.height + repeatMetrics.depth;
  var bottomMetrics = getMetrics(bottom, font, mode);
  var bottomHeightTotal = bottomMetrics.height + bottomMetrics.depth;
  var middleHeightTotal = 0;
  var middleFactor = 1;
  if (middle !== null) {
    var middleMetrics = getMetrics(middle, font, mode);
    middleHeightTotal = middleMetrics.height + middleMetrics.depth;
    middleFactor = 2;
  }
  var minHeight = topHeightTotal + bottomHeightTotal + middleHeightTotal;
  var repeatCount = Math.max(0, Math.ceil((heightTotal - minHeight) / (middleFactor * repeatHeightTotal)));
  var realHeightTotal = minHeight + repeatCount * middleFactor * repeatHeightTotal;
  var axisHeight = options.fontMetrics().axisHeight;
  if (center) {
    axisHeight *= options.sizeMultiplier;
  }
  var depth = realHeightTotal / 2 - axisHeight;
  var stack = [];
  if (svgLabel.length > 0) {
    var midHeight = realHeightTotal - topHeightTotal - bottomHeightTotal;
    var viewBoxHeight = Math.round(realHeightTotal * 1e3);
    var pathStr = tallDelim(svgLabel, Math.round(midHeight * 1e3));
    var path2 = new PathNode(svgLabel, pathStr);
    var width = (viewBoxWidth / 1e3).toFixed(3) + "em";
    var height = (viewBoxHeight / 1e3).toFixed(3) + "em";
    var svg = new SvgNode([path2], {
      "width": width,
      "height": height,
      "viewBox": "0 0 " + viewBoxWidth + " " + viewBoxHeight
    });
    var wrapper = buildCommon.makeSvgSpan([], [svg], options);
    wrapper.height = viewBoxHeight / 1e3;
    wrapper.style.width = width;
    wrapper.style.height = height;
    stack.push({
      type: "elem",
      elem: wrapper
    });
  } else {
    stack.push(makeGlyphSpan(bottom, font, mode));
    stack.push(lap);
    if (middle === null) {
      var innerHeight = realHeightTotal - topHeightTotal - bottomHeightTotal + 2 * lapInEms;
      stack.push(makeInner(repeat, innerHeight, options));
    } else {
      var _innerHeight = (realHeightTotal - topHeightTotal - bottomHeightTotal - middleHeightTotal) / 2 + 2 * lapInEms;
      stack.push(makeInner(repeat, _innerHeight, options));
      stack.push(lap);
      stack.push(makeGlyphSpan(middle, font, mode));
      stack.push(lap);
      stack.push(makeInner(repeat, _innerHeight, options));
    }
    stack.push(lap);
    stack.push(makeGlyphSpan(top, font, mode));
  }
  var newOptions = options.havingBaseStyle(Style$1.TEXT);
  var inner2 = buildCommon.makeVList({
    positionType: "bottom",
    positionData: depth,
    children: stack
  }, newOptions);
  return styleWrap(buildCommon.makeSpan(["delimsizing", "mult"], [inner2], newOptions), Style$1.TEXT, options, classes);
};
var vbPad = 80;
var emPad = 0.08;
var sqrtSvg = function sqrtSvg2(sqrtName, height, viewBoxHeight, extraVinculum, options) {
  var path2 = sqrtPath(sqrtName, extraVinculum, viewBoxHeight);
  var pathNode = new PathNode(sqrtName, path2);
  var svg = new SvgNode([pathNode], {
    // Note: 1000:1 ratio of viewBox to document em width.
    "width": "400em",
    "height": makeEm(height),
    "viewBox": "0 0 400000 " + viewBoxHeight,
    "preserveAspectRatio": "xMinYMin slice"
  });
  return buildCommon.makeSvgSpan(["hide-tail"], [svg], options);
};
var makeSqrtImage = function makeSqrtImage2(height, options) {
  var newOptions = options.havingBaseSizing();
  var delim = traverseSequence("\\surd", height * newOptions.sizeMultiplier, stackLargeDelimiterSequence, newOptions);
  var sizeMultiplier = newOptions.sizeMultiplier;
  var extraVinculum = Math.max(0, options.minRuleThickness - options.fontMetrics().sqrtRuleThickness);
  var span;
  var spanHeight = 0;
  var texHeight = 0;
  var viewBoxHeight = 0;
  var advanceWidth;
  if (delim.type === "small") {
    viewBoxHeight = 1e3 + 1e3 * extraVinculum + vbPad;
    if (height < 1) {
      sizeMultiplier = 1;
    } else if (height < 1.4) {
      sizeMultiplier = 0.7;
    }
    spanHeight = (1 + extraVinculum + emPad) / sizeMultiplier;
    texHeight = (1 + extraVinculum) / sizeMultiplier;
    span = sqrtSvg("sqrtMain", spanHeight, viewBoxHeight, extraVinculum, options);
    span.style.minWidth = "0.853em";
    advanceWidth = 0.833 / sizeMultiplier;
  } else if (delim.type === "large") {
    viewBoxHeight = (1e3 + vbPad) * sizeToMaxHeight[delim.size];
    texHeight = (sizeToMaxHeight[delim.size] + extraVinculum) / sizeMultiplier;
    spanHeight = (sizeToMaxHeight[delim.size] + extraVinculum + emPad) / sizeMultiplier;
    span = sqrtSvg("sqrtSize" + delim.size, spanHeight, viewBoxHeight, extraVinculum, options);
    span.style.minWidth = "1.02em";
    advanceWidth = 1 / sizeMultiplier;
  } else {
    spanHeight = height + extraVinculum + emPad;
    texHeight = height + extraVinculum;
    viewBoxHeight = Math.floor(1e3 * height + extraVinculum) + vbPad;
    span = sqrtSvg("sqrtTall", spanHeight, viewBoxHeight, extraVinculum, options);
    span.style.minWidth = "0.742em";
    advanceWidth = 1.056;
  }
  span.height = texHeight;
  span.style.height = makeEm(spanHeight);
  return {
    span,
    advanceWidth,
    // Calculate the actual line width.
    // This actually should depend on the chosen font -- e.g. \boldmath
    // should use the thicker surd symbols from e.g. KaTeX_Main-Bold, and
    // have thicker rules.
    ruleWidth: (options.fontMetrics().sqrtRuleThickness + extraVinculum) * sizeMultiplier
  };
};
var stackLargeDelimiters = ["(", "\\lparen", ")", "\\rparen", "[", "\\lbrack", "]", "\\rbrack", "\\{", "\\lbrace", "\\}", "\\rbrace", "\\lfloor", "\\rfloor", "⌊", "⌋", "\\lceil", "\\rceil", "⌈", "⌉", "\\surd"];
var stackAlwaysDelimiters = ["\\uparrow", "\\downarrow", "\\updownarrow", "\\Uparrow", "\\Downarrow", "\\Updownarrow", "|", "\\|", "\\vert", "\\Vert", "\\lvert", "\\rvert", "\\lVert", "\\rVert", "\\lgroup", "\\rgroup", "⟮", "⟯", "\\lmoustache", "\\rmoustache", "⎰", "⎱"];
var stackNeverDelimiters = ["<", ">", "\\langle", "\\rangle", "/", "\\backslash", "\\lt", "\\gt"];
var sizeToMaxHeight = [0, 1.2, 1.8, 2.4, 3];
var makeSizedDelim = function makeSizedDelim2(delim, size, options, mode, classes) {
  if (delim === "<" || delim === "\\lt" || delim === "⟨") {
    delim = "\\langle";
  } else if (delim === ">" || delim === "\\gt" || delim === "⟩") {
    delim = "\\rangle";
  }
  if (stackLargeDelimiters.includes(delim) || stackNeverDelimiters.includes(delim)) {
    return makeLargeDelim(delim, size, false, options, mode, classes);
  } else if (stackAlwaysDelimiters.includes(delim)) {
    return makeStackedDelim(delim, sizeToMaxHeight[size], false, options, mode, classes);
  } else {
    throw new ParseError("Illegal delimiter: '" + delim + "'");
  }
};
var stackNeverDelimiterSequence = [{
  type: "small",
  style: Style$1.SCRIPTSCRIPT
}, {
  type: "small",
  style: Style$1.SCRIPT
}, {
  type: "small",
  style: Style$1.TEXT
}, {
  type: "large",
  size: 1
}, {
  type: "large",
  size: 2
}, {
  type: "large",
  size: 3
}, {
  type: "large",
  size: 4
}];
var stackAlwaysDelimiterSequence = [{
  type: "small",
  style: Style$1.SCRIPTSCRIPT
}, {
  type: "small",
  style: Style$1.SCRIPT
}, {
  type: "small",
  style: Style$1.TEXT
}, {
  type: "stack"
}];
var stackLargeDelimiterSequence = [{
  type: "small",
  style: Style$1.SCRIPTSCRIPT
}, {
  type: "small",
  style: Style$1.SCRIPT
}, {
  type: "small",
  style: Style$1.TEXT
}, {
  type: "large",
  size: 1
}, {
  type: "large",
  size: 2
}, {
  type: "large",
  size: 3
}, {
  type: "large",
  size: 4
}, {
  type: "stack"
}];
var delimTypeToFont = function delimTypeToFont2(type) {
  if (type.type === "small") {
    return "Main-Regular";
  } else if (type.type === "large") {
    return "Size" + type.size + "-Regular";
  } else if (type.type === "stack") {
    return "Size4-Regular";
  } else {
    throw new Error("Add support for delim type '" + type.type + "' here.");
  }
};
var traverseSequence = function traverseSequence2(delim, height, sequence, options) {
  var start = Math.min(2, 3 - options.style.size);
  for (var i = start; i < sequence.length; i++) {
    if (sequence[i].type === "stack") {
      break;
    }
    var metrics = getMetrics(delim, delimTypeToFont(sequence[i]), "math");
    var heightDepth = metrics.height + metrics.depth;
    if (sequence[i].type === "small") {
      var newOptions = options.havingBaseStyle(sequence[i].style);
      heightDepth *= newOptions.sizeMultiplier;
    }
    if (heightDepth > height) {
      return sequence[i];
    }
  }
  return sequence[sequence.length - 1];
};
var makeCustomSizedDelim = function makeCustomSizedDelim2(delim, height, center, options, mode, classes) {
  if (delim === "<" || delim === "\\lt" || delim === "⟨") {
    delim = "\\langle";
  } else if (delim === ">" || delim === "\\gt" || delim === "⟩") {
    delim = "\\rangle";
  }
  var sequence;
  if (stackNeverDelimiters.includes(delim)) {
    sequence = stackNeverDelimiterSequence;
  } else if (stackLargeDelimiters.includes(delim)) {
    sequence = stackLargeDelimiterSequence;
  } else {
    sequence = stackAlwaysDelimiterSequence;
  }
  var delimType = traverseSequence(delim, height, sequence, options);
  if (delimType.type === "small") {
    return makeSmallDelim(delim, delimType.style, center, options, mode, classes);
  } else if (delimType.type === "large") {
    return makeLargeDelim(delim, delimType.size, center, options, mode, classes);
  } else {
    return makeStackedDelim(delim, height, center, options, mode, classes);
  }
};
var makeLeftRightDelim = function makeLeftRightDelim2(delim, height, depth, options, mode, classes) {
  var axisHeight = options.fontMetrics().axisHeight * options.sizeMultiplier;
  var delimiterFactor = 901;
  var delimiterExtend = 5 / options.fontMetrics().ptPerEm;
  var maxDistFromAxis = Math.max(height - axisHeight, depth + axisHeight);
  var totalHeight = Math.max(
    // In real TeX, calculations are done using integral values which are
    // 65536 per pt, or 655360 per em. So, the division here truncates in
    // TeX but doesn't here, producing different results. If we wanted to
    // exactly match TeX's calculation, we could do
    //   Math.floor(655360 * maxDistFromAxis / 500) *
    //    delimiterFactor / 655360
    // (To see the difference, compare
    //    x^{x^{\left(\rule{0.1em}{0.68em}\right)}}
    // in TeX and KaTeX)
    maxDistFromAxis / 500 * delimiterFactor,
    2 * maxDistFromAxis - delimiterExtend
  );
  return makeCustomSizedDelim(delim, totalHeight, true, options, mode, classes);
};
var delimiter = {
  sqrtImage: makeSqrtImage,
  sizedDelim: makeSizedDelim,
  sizeToMaxHeight,
  customSizedDelim: makeCustomSizedDelim,
  leftRightDelim: makeLeftRightDelim
};
var delimiterSizes = {
  "\\bigl": {
    mclass: "mopen",
    size: 1
  },
  "\\Bigl": {
    mclass: "mopen",
    size: 2
  },
  "\\biggl": {
    mclass: "mopen",
    size: 3
  },
  "\\Biggl": {
    mclass: "mopen",
    size: 4
  },
  "\\bigr": {
    mclass: "mclose",
    size: 1
  },
  "\\Bigr": {
    mclass: "mclose",
    size: 2
  },
  "\\biggr": {
    mclass: "mclose",
    size: 3
  },
  "\\Biggr": {
    mclass: "mclose",
    size: 4
  },
  "\\bigm": {
    mclass: "mrel",
    size: 1
  },
  "\\Bigm": {
    mclass: "mrel",
    size: 2
  },
  "\\biggm": {
    mclass: "mrel",
    size: 3
  },
  "\\Biggm": {
    mclass: "mrel",
    size: 4
  },
  "\\big": {
    mclass: "mord",
    size: 1
  },
  "\\Big": {
    mclass: "mord",
    size: 2
  },
  "\\bigg": {
    mclass: "mord",
    size: 3
  },
  "\\Bigg": {
    mclass: "mord",
    size: 4
  }
};
var delimiters = ["(", "\\lparen", ")", "\\rparen", "[", "\\lbrack", "]", "\\rbrack", "\\{", "\\lbrace", "\\}", "\\rbrace", "\\lfloor", "\\rfloor", "⌊", "⌋", "\\lceil", "\\rceil", "⌈", "⌉", "<", ">", "\\langle", "⟨", "\\rangle", "⟩", "\\lt", "\\gt", "\\lvert", "\\rvert", "\\lVert", "\\rVert", "\\lgroup", "\\rgroup", "⟮", "⟯", "\\lmoustache", "\\rmoustache", "⎰", "⎱", "/", "\\backslash", "|", "\\vert", "\\|", "\\Vert", "\\uparrow", "\\Uparrow", "\\downarrow", "\\Downarrow", "\\updownarrow", "\\Updownarrow", "."];
function checkDelimiter(delim, context) {
  var symDelim = checkSymbolNodeType(delim);
  if (symDelim && delimiters.includes(symDelim.text)) {
    return symDelim;
  } else if (symDelim) {
    throw new ParseError("Invalid delimiter '" + symDelim.text + "' after '" + context.funcName + "'", delim);
  } else {
    throw new ParseError("Invalid delimiter type '" + delim.type + "'", delim);
  }
}
defineFunction({
  type: "delimsizing",
  names: ["\\bigl", "\\Bigl", "\\biggl", "\\Biggl", "\\bigr", "\\Bigr", "\\biggr", "\\Biggr", "\\bigm", "\\Bigm", "\\biggm", "\\Biggm", "\\big", "\\Big", "\\bigg", "\\Bigg"],
  props: {
    numArgs: 1,
    argTypes: ["primitive"]
  },
  handler: (context, args) => {
    var delim = checkDelimiter(args[0], context);
    return {
      type: "delimsizing",
      mode: context.parser.mode,
      size: delimiterSizes[context.funcName].size,
      mclass: delimiterSizes[context.funcName].mclass,
      delim: delim.text
    };
  },
  htmlBuilder: (group, options) => {
    if (group.delim === ".") {
      return buildCommon.makeSpan([group.mclass]);
    }
    return delimiter.sizedDelim(group.delim, group.size, options, group.mode, [group.mclass]);
  },
  mathmlBuilder: (group) => {
    var children = [];
    if (group.delim !== ".") {
      children.push(makeText(group.delim, group.mode));
    }
    var node = new mathMLTree.MathNode("mo", children);
    if (group.mclass === "mopen" || group.mclass === "mclose") {
      node.setAttribute("fence", "true");
    } else {
      node.setAttribute("fence", "false");
    }
    node.setAttribute("stretchy", "true");
    var size = makeEm(delimiter.sizeToMaxHeight[group.size]);
    node.setAttribute("minsize", size);
    node.setAttribute("maxsize", size);
    return node;
  }
});
function assertParsed(group) {
  if (!group.body) {
    throw new Error("Bug: The leftright ParseNode wasn't fully parsed.");
  }
}
defineFunction({
  type: "leftright-right",
  names: ["\\right"],
  props: {
    numArgs: 1,
    primitive: true
  },
  handler: (context, args) => {
    var color = context.parser.gullet.macros.get("\\current@color");
    if (color && typeof color !== "string") {
      throw new ParseError("\\current@color set to non-string in \\right");
    }
    return {
      type: "leftright-right",
      mode: context.parser.mode,
      delim: checkDelimiter(args[0], context).text,
      color
      // undefined if not set via \color
    };
  }
});
defineFunction({
  type: "leftright",
  names: ["\\left"],
  props: {
    numArgs: 1,
    primitive: true
  },
  handler: (context, args) => {
    var delim = checkDelimiter(args[0], context);
    var parser = context.parser;
    ++parser.leftrightDepth;
    var body = parser.parseExpression(false);
    --parser.leftrightDepth;
    parser.expect("\\right", false);
    var right = assertNodeType(parser.parseFunction(), "leftright-right");
    return {
      type: "leftright",
      mode: parser.mode,
      body,
      left: delim.text,
      right: right.delim,
      rightColor: right.color
    };
  },
  htmlBuilder: (group, options) => {
    assertParsed(group);
    var inner2 = buildExpression$1(group.body, options, true, ["mopen", "mclose"]);
    var innerHeight = 0;
    var innerDepth = 0;
    var hadMiddle = false;
    for (var i = 0; i < inner2.length; i++) {
      if (inner2[i].isMiddle) {
        hadMiddle = true;
      } else {
        innerHeight = Math.max(inner2[i].height, innerHeight);
        innerDepth = Math.max(inner2[i].depth, innerDepth);
      }
    }
    innerHeight *= options.sizeMultiplier;
    innerDepth *= options.sizeMultiplier;
    var leftDelim;
    if (group.left === ".") {
      leftDelim = makeNullDelimiter(options, ["mopen"]);
    } else {
      leftDelim = delimiter.leftRightDelim(group.left, innerHeight, innerDepth, options, group.mode, ["mopen"]);
    }
    inner2.unshift(leftDelim);
    if (hadMiddle) {
      for (var _i = 1; _i < inner2.length; _i++) {
        var middleDelim = inner2[_i];
        var isMiddle = middleDelim.isMiddle;
        if (isMiddle) {
          inner2[_i] = delimiter.leftRightDelim(isMiddle.delim, innerHeight, innerDepth, isMiddle.options, group.mode, []);
        }
      }
    }
    var rightDelim;
    if (group.right === ".") {
      rightDelim = makeNullDelimiter(options, ["mclose"]);
    } else {
      var colorOptions = group.rightColor ? options.withColor(group.rightColor) : options;
      rightDelim = delimiter.leftRightDelim(group.right, innerHeight, innerDepth, colorOptions, group.mode, ["mclose"]);
    }
    inner2.push(rightDelim);
    return buildCommon.makeSpan(["minner"], inner2, options);
  },
  mathmlBuilder: (group, options) => {
    assertParsed(group);
    var inner2 = buildExpression2(group.body, options);
    if (group.left !== ".") {
      var leftNode = new mathMLTree.MathNode("mo", [makeText(group.left, group.mode)]);
      leftNode.setAttribute("fence", "true");
      inner2.unshift(leftNode);
    }
    if (group.right !== ".") {
      var rightNode = new mathMLTree.MathNode("mo", [makeText(group.right, group.mode)]);
      rightNode.setAttribute("fence", "true");
      if (group.rightColor) {
        rightNode.setAttribute("mathcolor", group.rightColor);
      }
      inner2.push(rightNode);
    }
    return makeRow(inner2);
  }
});
defineFunction({
  type: "middle",
  names: ["\\middle"],
  props: {
    numArgs: 1,
    primitive: true
  },
  handler: (context, args) => {
    var delim = checkDelimiter(args[0], context);
    if (!context.parser.leftrightDepth) {
      throw new ParseError("\\middle without preceding \\left", delim);
    }
    return {
      type: "middle",
      mode: context.parser.mode,
      delim: delim.text
    };
  },
  htmlBuilder: (group, options) => {
    var middleDelim;
    if (group.delim === ".") {
      middleDelim = makeNullDelimiter(options, []);
    } else {
      middleDelim = delimiter.sizedDelim(group.delim, 1, options, group.mode, []);
      var isMiddle = {
        delim: group.delim,
        options
      };
      middleDelim.isMiddle = isMiddle;
    }
    return middleDelim;
  },
  mathmlBuilder: (group, options) => {
    var textNode = group.delim === "\\vert" || group.delim === "|" ? makeText("|", "text") : makeText(group.delim, group.mode);
    var middleNode = new mathMLTree.MathNode("mo", [textNode]);
    middleNode.setAttribute("fence", "true");
    middleNode.setAttribute("lspace", "0.05em");
    middleNode.setAttribute("rspace", "0.05em");
    return middleNode;
  }
});
var htmlBuilder$7 = (group, options) => {
  var inner2 = buildCommon.wrapFragment(buildGroup$1(group.body, options), options);
  var label = group.label.slice(1);
  var scale = options.sizeMultiplier;
  var img;
  var imgShift = 0;
  var isSingleChar = utils.isCharacterBox(group.body);
  if (label === "sout") {
    img = buildCommon.makeSpan(["stretchy", "sout"]);
    img.height = options.fontMetrics().defaultRuleThickness / scale;
    imgShift = -0.5 * options.fontMetrics().xHeight;
  } else if (label === "phase") {
    var lineWeight = calculateSize({
      number: 0.6,
      unit: "pt"
    }, options);
    var clearance = calculateSize({
      number: 0.35,
      unit: "ex"
    }, options);
    var newOptions = options.havingBaseSizing();
    scale = scale / newOptions.sizeMultiplier;
    var angleHeight = inner2.height + inner2.depth + lineWeight + clearance;
    inner2.style.paddingLeft = makeEm(angleHeight / 2 + lineWeight);
    var viewBoxHeight = Math.floor(1e3 * angleHeight * scale);
    var path2 = phasePath(viewBoxHeight);
    var svgNode = new SvgNode([new PathNode("phase", path2)], {
      "width": "400em",
      "height": makeEm(viewBoxHeight / 1e3),
      "viewBox": "0 0 400000 " + viewBoxHeight,
      "preserveAspectRatio": "xMinYMin slice"
    });
    img = buildCommon.makeSvgSpan(["hide-tail"], [svgNode], options);
    img.style.height = makeEm(angleHeight);
    imgShift = inner2.depth + lineWeight + clearance;
  } else {
    if (/cancel/.test(label)) {
      if (!isSingleChar) {
        inner2.classes.push("cancel-pad");
      }
    } else if (label === "angl") {
      inner2.classes.push("anglpad");
    } else {
      inner2.classes.push("boxpad");
    }
    var topPad = 0;
    var bottomPad = 0;
    var ruleThickness = 0;
    if (/box/.test(label)) {
      ruleThickness = Math.max(
        options.fontMetrics().fboxrule,
        // default
        options.minRuleThickness
        // User override.
      );
      topPad = options.fontMetrics().fboxsep + (label === "colorbox" ? 0 : ruleThickness);
      bottomPad = topPad;
    } else if (label === "angl") {
      ruleThickness = Math.max(options.fontMetrics().defaultRuleThickness, options.minRuleThickness);
      topPad = 4 * ruleThickness;
      bottomPad = Math.max(0, 0.25 - inner2.depth);
    } else {
      topPad = isSingleChar ? 0.2 : 0;
      bottomPad = topPad;
    }
    img = stretchy.encloseSpan(inner2, label, topPad, bottomPad, options);
    if (/fbox|boxed|fcolorbox/.test(label)) {
      img.style.borderStyle = "solid";
      img.style.borderWidth = makeEm(ruleThickness);
    } else if (label === "angl" && ruleThickness !== 0.049) {
      img.style.borderTopWidth = makeEm(ruleThickness);
      img.style.borderRightWidth = makeEm(ruleThickness);
    }
    imgShift = inner2.depth + bottomPad;
    if (group.backgroundColor) {
      img.style.backgroundColor = group.backgroundColor;
      if (group.borderColor) {
        img.style.borderColor = group.borderColor;
      }
    }
  }
  var vlist;
  if (group.backgroundColor) {
    vlist = buildCommon.makeVList({
      positionType: "individualShift",
      children: [
        // Put the color background behind inner;
        {
          type: "elem",
          elem: img,
          shift: imgShift
        },
        {
          type: "elem",
          elem: inner2,
          shift: 0
        }
      ]
    }, options);
  } else {
    var classes = /cancel|phase/.test(label) ? ["svg-align"] : [];
    vlist = buildCommon.makeVList({
      positionType: "individualShift",
      children: [
        // Write the \cancel stroke on top of inner.
        {
          type: "elem",
          elem: inner2,
          shift: 0
        },
        {
          type: "elem",
          elem: img,
          shift: imgShift,
          wrapperClasses: classes
        }
      ]
    }, options);
  }
  if (/cancel/.test(label)) {
    vlist.height = inner2.height;
    vlist.depth = inner2.depth;
  }
  if (/cancel/.test(label) && !isSingleChar) {
    return buildCommon.makeSpan(["mord", "cancel-lap"], [vlist], options);
  } else {
    return buildCommon.makeSpan(["mord"], [vlist], options);
  }
};
var mathmlBuilder$6 = (group, options) => {
  var fboxsep = 0;
  var node = new mathMLTree.MathNode(group.label.indexOf("colorbox") > -1 ? "mpadded" : "menclose", [buildGroup2(group.body, options)]);
  switch (group.label) {
    case "\\cancel":
      node.setAttribute("notation", "updiagonalstrike");
      break;
    case "\\bcancel":
      node.setAttribute("notation", "downdiagonalstrike");
      break;
    case "\\phase":
      node.setAttribute("notation", "phasorangle");
      break;
    case "\\sout":
      node.setAttribute("notation", "horizontalstrike");
      break;
    case "\\fbox":
      node.setAttribute("notation", "box");
      break;
    case "\\angl":
      node.setAttribute("notation", "actuarial");
      break;
    case "\\fcolorbox":
    case "\\colorbox":
      fboxsep = options.fontMetrics().fboxsep * options.fontMetrics().ptPerEm;
      node.setAttribute("width", "+" + 2 * fboxsep + "pt");
      node.setAttribute("height", "+" + 2 * fboxsep + "pt");
      node.setAttribute("lspace", fboxsep + "pt");
      node.setAttribute("voffset", fboxsep + "pt");
      if (group.label === "\\fcolorbox") {
        var thk = Math.max(
          options.fontMetrics().fboxrule,
          // default
          options.minRuleThickness
          // user override
        );
        node.setAttribute("style", "border: " + thk + "em solid " + String(group.borderColor));
      }
      break;
    case "\\xcancel":
      node.setAttribute("notation", "updiagonalstrike downdiagonalstrike");
      break;
  }
  if (group.backgroundColor) {
    node.setAttribute("mathbackground", group.backgroundColor);
  }
  return node;
};
defineFunction({
  type: "enclose",
  names: ["\\colorbox"],
  props: {
    numArgs: 2,
    allowedInText: true,
    argTypes: ["color", "text"]
  },
  handler(_ref, args, optArgs) {
    var {
      parser,
      funcName
    } = _ref;
    var color = assertNodeType(args[0], "color-token").color;
    var body = args[1];
    return {
      type: "enclose",
      mode: parser.mode,
      label: funcName,
      backgroundColor: color,
      body
    };
  },
  htmlBuilder: htmlBuilder$7,
  mathmlBuilder: mathmlBuilder$6
});
defineFunction({
  type: "enclose",
  names: ["\\fcolorbox"],
  props: {
    numArgs: 3,
    allowedInText: true,
    argTypes: ["color", "color", "text"]
  },
  handler(_ref2, args, optArgs) {
    var {
      parser,
      funcName
    } = _ref2;
    var borderColor = assertNodeType(args[0], "color-token").color;
    var backgroundColor = assertNodeType(args[1], "color-token").color;
    var body = args[2];
    return {
      type: "enclose",
      mode: parser.mode,
      label: funcName,
      backgroundColor,
      borderColor,
      body
    };
  },
  htmlBuilder: htmlBuilder$7,
  mathmlBuilder: mathmlBuilder$6
});
defineFunction({
  type: "enclose",
  names: ["\\fbox"],
  props: {
    numArgs: 1,
    argTypes: ["hbox"],
    allowedInText: true
  },
  handler(_ref3, args) {
    var {
      parser
    } = _ref3;
    return {
      type: "enclose",
      mode: parser.mode,
      label: "\\fbox",
      body: args[0]
    };
  }
});
defineFunction({
  type: "enclose",
  names: ["\\cancel", "\\bcancel", "\\xcancel", "\\sout", "\\phase"],
  props: {
    numArgs: 1
  },
  handler(_ref4, args) {
    var {
      parser,
      funcName
    } = _ref4;
    var body = args[0];
    return {
      type: "enclose",
      mode: parser.mode,
      label: funcName,
      body
    };
  },
  htmlBuilder: htmlBuilder$7,
  mathmlBuilder: mathmlBuilder$6
});
defineFunction({
  type: "enclose",
  names: ["\\angl"],
  props: {
    numArgs: 1,
    argTypes: ["hbox"],
    allowedInText: false
  },
  handler(_ref5, args) {
    var {
      parser
    } = _ref5;
    return {
      type: "enclose",
      mode: parser.mode,
      label: "\\angl",
      body: args[0]
    };
  }
});
var _environments = {};
function defineEnvironment(_ref) {
  var {
    type,
    names,
    props,
    handler,
    htmlBuilder: htmlBuilder3,
    mathmlBuilder: mathmlBuilder3
  } = _ref;
  var data = {
    type,
    numArgs: props.numArgs || 0,
    allowedInText: false,
    numOptionalArgs: 0,
    handler
  };
  for (var i = 0; i < names.length; ++i) {
    _environments[names[i]] = data;
  }
  if (htmlBuilder3) {
    _htmlGroupBuilders[type] = htmlBuilder3;
  }
  if (mathmlBuilder3) {
    _mathmlGroupBuilders[type] = mathmlBuilder3;
  }
}
var _macros = {};
function defineMacro(name, body) {
  _macros[name] = body;
}
function getHLines(parser) {
  var hlineInfo = [];
  parser.consumeSpaces();
  var nxt = parser.fetch().text;
  if (nxt === "\\relax") {
    parser.consume();
    parser.consumeSpaces();
    nxt = parser.fetch().text;
  }
  while (nxt === "\\hline" || nxt === "\\hdashline") {
    parser.consume();
    hlineInfo.push(nxt === "\\hdashline");
    parser.consumeSpaces();
    nxt = parser.fetch().text;
  }
  return hlineInfo;
}
var validateAmsEnvironmentContext = (context) => {
  var settings = context.parser.settings;
  if (!settings.displayMode) {
    throw new ParseError("{" + context.envName + "} can be used only in display mode.");
  }
};
function getAutoTag(name) {
  if (name.indexOf("ed") === -1) {
    return name.indexOf("*") === -1;
  }
}
function parseArray(parser, _ref, style) {
  var {
    hskipBeforeAndAfter,
    addJot,
    cols,
    arraystretch,
    colSeparationType,
    autoTag,
    singleRow,
    emptySingleRow,
    maxNumCols,
    leqno
  } = _ref;
  parser.gullet.beginGroup();
  if (!singleRow) {
    parser.gullet.macros.set("\\cr", "\\\\\\relax");
  }
  if (!arraystretch) {
    var stretch = parser.gullet.expandMacroAsText("\\arraystretch");
    if (stretch == null) {
      arraystretch = 1;
    } else {
      arraystretch = parseFloat(stretch);
      if (!arraystretch || arraystretch < 0) {
        throw new ParseError("Invalid \\arraystretch: " + stretch);
      }
    }
  }
  parser.gullet.beginGroup();
  var row = [];
  var body = [row];
  var rowGaps = [];
  var hLinesBeforeRow = [];
  var tags = autoTag != null ? [] : void 0;
  function beginRow() {
    if (autoTag) {
      parser.gullet.macros.set("\\@eqnsw", "1", true);
    }
  }
  function endRow() {
    if (tags) {
      if (parser.gullet.macros.get("\\df@tag")) {
        tags.push(parser.subparse([new Token("\\df@tag")]));
        parser.gullet.macros.set("\\df@tag", void 0, true);
      } else {
        tags.push(Boolean(autoTag) && parser.gullet.macros.get("\\@eqnsw") === "1");
      }
    }
  }
  beginRow();
  hLinesBeforeRow.push(getHLines(parser));
  while (true) {
    var cell = parser.parseExpression(false, singleRow ? "\\end" : "\\\\");
    parser.gullet.endGroup();
    parser.gullet.beginGroup();
    cell = {
      type: "ordgroup",
      mode: parser.mode,
      body: cell
    };
    if (style) {
      cell = {
        type: "styling",
        mode: parser.mode,
        style,
        body: [cell]
      };
    }
    row.push(cell);
    var next = parser.fetch().text;
    if (next === "&") {
      if (maxNumCols && row.length === maxNumCols) {
        if (singleRow || colSeparationType) {
          throw new ParseError("Too many tab characters: &", parser.nextToken);
        } else {
          parser.settings.reportNonstrict("textEnv", "Too few columns specified in the {array} column argument.");
        }
      }
      parser.consume();
    } else if (next === "\\end") {
      endRow();
      if (row.length === 1 && cell.type === "styling" && cell.body[0].body.length === 0 && (body.length > 1 || !emptySingleRow)) {
        body.pop();
      }
      if (hLinesBeforeRow.length < body.length + 1) {
        hLinesBeforeRow.push([]);
      }
      break;
    } else if (next === "\\\\") {
      parser.consume();
      var size = void 0;
      if (parser.gullet.future().text !== " ") {
        size = parser.parseSizeGroup(true);
      }
      rowGaps.push(size ? size.value : null);
      endRow();
      hLinesBeforeRow.push(getHLines(parser));
      row = [];
      body.push(row);
      beginRow();
    } else {
      throw new ParseError("Expected & or \\\\ or \\cr or \\end", parser.nextToken);
    }
  }
  parser.gullet.endGroup();
  parser.gullet.endGroup();
  return {
    type: "array",
    mode: parser.mode,
    addJot,
    arraystretch,
    body,
    cols,
    rowGaps,
    hskipBeforeAndAfter,
    hLinesBeforeRow,
    colSeparationType,
    tags,
    leqno
  };
}
function dCellStyle(envName) {
  if (envName.slice(0, 1) === "d") {
    return "display";
  } else {
    return "text";
  }
}
var htmlBuilder$6 = function htmlBuilder(group, options) {
  var r;
  var c;
  var nr = group.body.length;
  var hLinesBeforeRow = group.hLinesBeforeRow;
  var nc = 0;
  var body = new Array(nr);
  var hlines = [];
  var ruleThickness = Math.max(
    // From LaTeX \showthe\arrayrulewidth. Equals 0.04 em.
    options.fontMetrics().arrayRuleWidth,
    options.minRuleThickness
    // User override.
  );
  var pt = 1 / options.fontMetrics().ptPerEm;
  var arraycolsep = 5 * pt;
  if (group.colSeparationType && group.colSeparationType === "small") {
    var localMultiplier = options.havingStyle(Style$1.SCRIPT).sizeMultiplier;
    arraycolsep = 0.2778 * (localMultiplier / options.sizeMultiplier);
  }
  var baselineskip = group.colSeparationType === "CD" ? calculateSize({
    number: 3,
    unit: "ex"
  }, options) : 12 * pt;
  var jot = 3 * pt;
  var arrayskip = group.arraystretch * baselineskip;
  var arstrutHeight = 0.7 * arrayskip;
  var arstrutDepth = 0.3 * arrayskip;
  var totalHeight = 0;
  function setHLinePos(hlinesInGap) {
    for (var i = 0; i < hlinesInGap.length; ++i) {
      if (i > 0) {
        totalHeight += 0.25;
      }
      hlines.push({
        pos: totalHeight,
        isDashed: hlinesInGap[i]
      });
    }
  }
  setHLinePos(hLinesBeforeRow[0]);
  for (r = 0; r < group.body.length; ++r) {
    var inrow = group.body[r];
    var height = arstrutHeight;
    var depth = arstrutDepth;
    if (nc < inrow.length) {
      nc = inrow.length;
    }
    var outrow = new Array(inrow.length);
    for (c = 0; c < inrow.length; ++c) {
      var elt = buildGroup$1(inrow[c], options);
      if (depth < elt.depth) {
        depth = elt.depth;
      }
      if (height < elt.height) {
        height = elt.height;
      }
      outrow[c] = elt;
    }
    var rowGap = group.rowGaps[r];
    var gap = 0;
    if (rowGap) {
      gap = calculateSize(rowGap, options);
      if (gap > 0) {
        gap += arstrutDepth;
        if (depth < gap) {
          depth = gap;
        }
        gap = 0;
      }
    }
    if (group.addJot) {
      depth += jot;
    }
    outrow.height = height;
    outrow.depth = depth;
    totalHeight += height;
    outrow.pos = totalHeight;
    totalHeight += depth + gap;
    body[r] = outrow;
    setHLinePos(hLinesBeforeRow[r + 1]);
  }
  var offset = totalHeight / 2 + options.fontMetrics().axisHeight;
  var colDescriptions = group.cols || [];
  var cols = [];
  var colSep;
  var colDescrNum;
  var tagSpans = [];
  if (group.tags && group.tags.some((tag2) => tag2)) {
    for (r = 0; r < nr; ++r) {
      var rw = body[r];
      var shift = rw.pos - offset;
      var tag = group.tags[r];
      var tagSpan = void 0;
      if (tag === true) {
        tagSpan = buildCommon.makeSpan(["eqn-num"], [], options);
      } else if (tag === false) {
        tagSpan = buildCommon.makeSpan([], [], options);
      } else {
        tagSpan = buildCommon.makeSpan([], buildExpression$1(tag, options, true), options);
      }
      tagSpan.depth = rw.depth;
      tagSpan.height = rw.height;
      tagSpans.push({
        type: "elem",
        elem: tagSpan,
        shift
      });
    }
  }
  for (
    c = 0, colDescrNum = 0;
    // Continue while either there are more columns or more column
    // descriptions, so trailing separators don't get lost.
    c < nc || colDescrNum < colDescriptions.length;
    ++c, ++colDescrNum
  ) {
    var colDescr = colDescriptions[colDescrNum] || {};
    var firstSeparator = true;
    while (colDescr.type === "separator") {
      if (!firstSeparator) {
        colSep = buildCommon.makeSpan(["arraycolsep"], []);
        colSep.style.width = makeEm(options.fontMetrics().doubleRuleSep);
        cols.push(colSep);
      }
      if (colDescr.separator === "|" || colDescr.separator === ":") {
        var lineType = colDescr.separator === "|" ? "solid" : "dashed";
        var separator = buildCommon.makeSpan(["vertical-separator"], [], options);
        separator.style.height = makeEm(totalHeight);
        separator.style.borderRightWidth = makeEm(ruleThickness);
        separator.style.borderRightStyle = lineType;
        separator.style.margin = "0 " + makeEm(-ruleThickness / 2);
        var _shift = totalHeight - offset;
        if (_shift) {
          separator.style.verticalAlign = makeEm(-_shift);
        }
        cols.push(separator);
      } else {
        throw new ParseError("Invalid separator type: " + colDescr.separator);
      }
      colDescrNum++;
      colDescr = colDescriptions[colDescrNum] || {};
      firstSeparator = false;
    }
    if (c >= nc) {
      continue;
    }
    var sepwidth = void 0;
    if (c > 0 || group.hskipBeforeAndAfter) {
      sepwidth = utils.deflt(colDescr.pregap, arraycolsep);
      if (sepwidth !== 0) {
        colSep = buildCommon.makeSpan(["arraycolsep"], []);
        colSep.style.width = makeEm(sepwidth);
        cols.push(colSep);
      }
    }
    var col = [];
    for (r = 0; r < nr; ++r) {
      var row = body[r];
      var elem = row[c];
      if (!elem) {
        continue;
      }
      var _shift2 = row.pos - offset;
      elem.depth = row.depth;
      elem.height = row.height;
      col.push({
        type: "elem",
        elem,
        shift: _shift2
      });
    }
    col = buildCommon.makeVList({
      positionType: "individualShift",
      children: col
    }, options);
    col = buildCommon.makeSpan(["col-align-" + (colDescr.align || "c")], [col]);
    cols.push(col);
    if (c < nc - 1 || group.hskipBeforeAndAfter) {
      sepwidth = utils.deflt(colDescr.postgap, arraycolsep);
      if (sepwidth !== 0) {
        colSep = buildCommon.makeSpan(["arraycolsep"], []);
        colSep.style.width = makeEm(sepwidth);
        cols.push(colSep);
      }
    }
  }
  body = buildCommon.makeSpan(["mtable"], cols);
  if (hlines.length > 0) {
    var line = buildCommon.makeLineSpan("hline", options, ruleThickness);
    var dashes = buildCommon.makeLineSpan("hdashline", options, ruleThickness);
    var vListElems = [{
      type: "elem",
      elem: body,
      shift: 0
    }];
    while (hlines.length > 0) {
      var hline = hlines.pop();
      var lineShift = hline.pos - offset;
      if (hline.isDashed) {
        vListElems.push({
          type: "elem",
          elem: dashes,
          shift: lineShift
        });
      } else {
        vListElems.push({
          type: "elem",
          elem: line,
          shift: lineShift
        });
      }
    }
    body = buildCommon.makeVList({
      positionType: "individualShift",
      children: vListElems
    }, options);
  }
  if (tagSpans.length === 0) {
    return buildCommon.makeSpan(["mord"], [body], options);
  } else {
    var eqnNumCol = buildCommon.makeVList({
      positionType: "individualShift",
      children: tagSpans
    }, options);
    eqnNumCol = buildCommon.makeSpan(["tag"], [eqnNumCol], options);
    return buildCommon.makeFragment([body, eqnNumCol]);
  }
};
var alignMap = {
  c: "center ",
  l: "left ",
  r: "right "
};
var mathmlBuilder$5 = function mathmlBuilder(group, options) {
  var tbl = [];
  var glue = new mathMLTree.MathNode("mtd", [], ["mtr-glue"]);
  var tag = new mathMLTree.MathNode("mtd", [], ["mml-eqn-num"]);
  for (var i = 0; i < group.body.length; i++) {
    var rw = group.body[i];
    var row = [];
    for (var j = 0; j < rw.length; j++) {
      row.push(new mathMLTree.MathNode("mtd", [buildGroup2(rw[j], options)]));
    }
    if (group.tags && group.tags[i]) {
      row.unshift(glue);
      row.push(glue);
      if (group.leqno) {
        row.unshift(tag);
      } else {
        row.push(tag);
      }
    }
    tbl.push(new mathMLTree.MathNode("mtr", row));
  }
  var table = new mathMLTree.MathNode("mtable", tbl);
  var gap = group.arraystretch === 0.5 ? 0.1 : 0.16 + group.arraystretch - 1 + (group.addJot ? 0.09 : 0);
  table.setAttribute("rowspacing", makeEm(gap));
  var menclose = "";
  var align = "";
  if (group.cols && group.cols.length > 0) {
    var cols = group.cols;
    var columnLines = "";
    var prevTypeWasAlign = false;
    var iStart = 0;
    var iEnd = cols.length;
    if (cols[0].type === "separator") {
      menclose += "top ";
      iStart = 1;
    }
    if (cols[cols.length - 1].type === "separator") {
      menclose += "bottom ";
      iEnd -= 1;
    }
    for (var _i = iStart; _i < iEnd; _i++) {
      if (cols[_i].type === "align") {
        align += alignMap[cols[_i].align];
        if (prevTypeWasAlign) {
          columnLines += "none ";
        }
        prevTypeWasAlign = true;
      } else if (cols[_i].type === "separator") {
        if (prevTypeWasAlign) {
          columnLines += cols[_i].separator === "|" ? "solid " : "dashed ";
          prevTypeWasAlign = false;
        }
      }
    }
    table.setAttribute("columnalign", align.trim());
    if (/[sd]/.test(columnLines)) {
      table.setAttribute("columnlines", columnLines.trim());
    }
  }
  if (group.colSeparationType === "align") {
    var _cols = group.cols || [];
    var spacing2 = "";
    for (var _i2 = 1; _i2 < _cols.length; _i2++) {
      spacing2 += _i2 % 2 ? "0em " : "1em ";
    }
    table.setAttribute("columnspacing", spacing2.trim());
  } else if (group.colSeparationType === "alignat" || group.colSeparationType === "gather") {
    table.setAttribute("columnspacing", "0em");
  } else if (group.colSeparationType === "small") {
    table.setAttribute("columnspacing", "0.2778em");
  } else if (group.colSeparationType === "CD") {
    table.setAttribute("columnspacing", "0.5em");
  } else {
    table.setAttribute("columnspacing", "1em");
  }
  var rowLines = "";
  var hlines = group.hLinesBeforeRow;
  menclose += hlines[0].length > 0 ? "left " : "";
  menclose += hlines[hlines.length - 1].length > 0 ? "right " : "";
  for (var _i3 = 1; _i3 < hlines.length - 1; _i3++) {
    rowLines += hlines[_i3].length === 0 ? "none " : hlines[_i3][0] ? "dashed " : "solid ";
  }
  if (/[sd]/.test(rowLines)) {
    table.setAttribute("rowlines", rowLines.trim());
  }
  if (menclose !== "") {
    table = new mathMLTree.MathNode("menclose", [table]);
    table.setAttribute("notation", menclose.trim());
  }
  if (group.arraystretch && group.arraystretch < 1) {
    table = new mathMLTree.MathNode("mstyle", [table]);
    table.setAttribute("scriptlevel", "1");
  }
  return table;
};
var alignedHandler = function alignedHandler2(context, args) {
  if (context.envName.indexOf("ed") === -1) {
    validateAmsEnvironmentContext(context);
  }
  var cols = [];
  var separationType = context.envName.indexOf("at") > -1 ? "alignat" : "align";
  var isSplit = context.envName === "split";
  var res = parseArray(context.parser, {
    cols,
    addJot: true,
    autoTag: isSplit ? void 0 : getAutoTag(context.envName),
    emptySingleRow: true,
    colSeparationType: separationType,
    maxNumCols: isSplit ? 2 : void 0,
    leqno: context.parser.settings.leqno
  }, "display");
  var numMaths;
  var numCols = 0;
  var emptyGroup = {
    type: "ordgroup",
    mode: context.mode,
    body: []
  };
  if (args[0] && args[0].type === "ordgroup") {
    var arg0 = "";
    for (var i = 0; i < args[0].body.length; i++) {
      var textord2 = assertNodeType(args[0].body[i], "textord");
      arg0 += textord2.text;
    }
    numMaths = Number(arg0);
    numCols = numMaths * 2;
  }
  var isAligned = !numCols;
  res.body.forEach(function(row) {
    for (var _i4 = 1; _i4 < row.length; _i4 += 2) {
      var styling = assertNodeType(row[_i4], "styling");
      var ordgroup = assertNodeType(styling.body[0], "ordgroup");
      ordgroup.body.unshift(emptyGroup);
    }
    if (!isAligned) {
      var curMaths = row.length / 2;
      if (numMaths < curMaths) {
        throw new ParseError("Too many math in a row: " + ("expected " + numMaths + ", but got " + curMaths), row[0]);
      }
    } else if (numCols < row.length) {
      numCols = row.length;
    }
  });
  for (var _i5 = 0; _i5 < numCols; ++_i5) {
    var align = "r";
    var pregap = 0;
    if (_i5 % 2 === 1) {
      align = "l";
    } else if (_i5 > 0 && isAligned) {
      pregap = 1;
    }
    cols[_i5] = {
      type: "align",
      align,
      pregap,
      postgap: 0
    };
  }
  res.colSeparationType = isAligned ? "align" : "alignat";
  return res;
};
defineEnvironment({
  type: "array",
  names: ["array", "darray"],
  props: {
    numArgs: 1
  },
  handler(context, args) {
    var symNode = checkSymbolNodeType(args[0]);
    var colalign = symNode ? [args[0]] : assertNodeType(args[0], "ordgroup").body;
    var cols = colalign.map(function(nde) {
      var node = assertSymbolNodeType(nde);
      var ca = node.text;
      if ("lcr".indexOf(ca) !== -1) {
        return {
          type: "align",
          align: ca
        };
      } else if (ca === "|") {
        return {
          type: "separator",
          separator: "|"
        };
      } else if (ca === ":") {
        return {
          type: "separator",
          separator: ":"
        };
      }
      throw new ParseError("Unknown column alignment: " + ca, nde);
    });
    var res = {
      cols,
      hskipBeforeAndAfter: true,
      // \@preamble in lttab.dtx
      maxNumCols: cols.length
    };
    return parseArray(context.parser, res, dCellStyle(context.envName));
  },
  htmlBuilder: htmlBuilder$6,
  mathmlBuilder: mathmlBuilder$5
});
defineEnvironment({
  type: "array",
  names: ["matrix", "pmatrix", "bmatrix", "Bmatrix", "vmatrix", "Vmatrix", "matrix*", "pmatrix*", "bmatrix*", "Bmatrix*", "vmatrix*", "Vmatrix*"],
  props: {
    numArgs: 0
  },
  handler(context) {
    var delimiters2 = {
      "matrix": null,
      "pmatrix": ["(", ")"],
      "bmatrix": ["[", "]"],
      "Bmatrix": ["\\{", "\\}"],
      "vmatrix": ["|", "|"],
      "Vmatrix": ["\\Vert", "\\Vert"]
    }[context.envName.replace("*", "")];
    var colAlign = "c";
    var payload = {
      hskipBeforeAndAfter: false,
      cols: [{
        type: "align",
        align: colAlign
      }]
    };
    if (context.envName.charAt(context.envName.length - 1) === "*") {
      var parser = context.parser;
      parser.consumeSpaces();
      if (parser.fetch().text === "[") {
        parser.consume();
        parser.consumeSpaces();
        colAlign = parser.fetch().text;
        if ("lcr".indexOf(colAlign) === -1) {
          throw new ParseError("Expected l or c or r", parser.nextToken);
        }
        parser.consume();
        parser.consumeSpaces();
        parser.expect("]");
        parser.consume();
        payload.cols = [{
          type: "align",
          align: colAlign
        }];
      }
    }
    var res = parseArray(context.parser, payload, dCellStyle(context.envName));
    var numCols = Math.max(0, ...res.body.map((row) => row.length));
    res.cols = new Array(numCols).fill({
      type: "align",
      align: colAlign
    });
    return delimiters2 ? {
      type: "leftright",
      mode: context.mode,
      body: [res],
      left: delimiters2[0],
      right: delimiters2[1],
      rightColor: void 0
      // \right uninfluenced by \color in array
    } : res;
  },
  htmlBuilder: htmlBuilder$6,
  mathmlBuilder: mathmlBuilder$5
});
defineEnvironment({
  type: "array",
  names: ["smallmatrix"],
  props: {
    numArgs: 0
  },
  handler(context) {
    var payload = {
      arraystretch: 0.5
    };
    var res = parseArray(context.parser, payload, "script");
    res.colSeparationType = "small";
    return res;
  },
  htmlBuilder: htmlBuilder$6,
  mathmlBuilder: mathmlBuilder$5
});
defineEnvironment({
  type: "array",
  names: ["subarray"],
  props: {
    numArgs: 1
  },
  handler(context, args) {
    var symNode = checkSymbolNodeType(args[0]);
    var colalign = symNode ? [args[0]] : assertNodeType(args[0], "ordgroup").body;
    var cols = colalign.map(function(nde) {
      var node = assertSymbolNodeType(nde);
      var ca = node.text;
      if ("lc".indexOf(ca) !== -1) {
        return {
          type: "align",
          align: ca
        };
      }
      throw new ParseError("Unknown column alignment: " + ca, nde);
    });
    if (cols.length > 1) {
      throw new ParseError("{subarray} can contain only one column");
    }
    var res = {
      cols,
      hskipBeforeAndAfter: false,
      arraystretch: 0.5
    };
    res = parseArray(context.parser, res, "script");
    if (res.body.length > 0 && res.body[0].length > 1) {
      throw new ParseError("{subarray} can contain only one column");
    }
    return res;
  },
  htmlBuilder: htmlBuilder$6,
  mathmlBuilder: mathmlBuilder$5
});
defineEnvironment({
  type: "array",
  names: ["cases", "dcases", "rcases", "drcases"],
  props: {
    numArgs: 0
  },
  handler(context) {
    var payload = {
      arraystretch: 1.2,
      cols: [{
        type: "align",
        align: "l",
        pregap: 0,
        // TODO(kevinb) get the current style.
        // For now we use the metrics for TEXT style which is what we were
        // doing before.  Before attempting to get the current style we
        // should look at TeX's behavior especially for \over and matrices.
        postgap: 1
        /* 1em quad */
      }, {
        type: "align",
        align: "l",
        pregap: 0,
        postgap: 0
      }]
    };
    var res = parseArray(context.parser, payload, dCellStyle(context.envName));
    return {
      type: "leftright",
      mode: context.mode,
      body: [res],
      left: context.envName.indexOf("r") > -1 ? "." : "\\{",
      right: context.envName.indexOf("r") > -1 ? "\\}" : ".",
      rightColor: void 0
    };
  },
  htmlBuilder: htmlBuilder$6,
  mathmlBuilder: mathmlBuilder$5
});
defineEnvironment({
  type: "array",
  names: ["align", "align*", "aligned", "split"],
  props: {
    numArgs: 0
  },
  handler: alignedHandler,
  htmlBuilder: htmlBuilder$6,
  mathmlBuilder: mathmlBuilder$5
});
defineEnvironment({
  type: "array",
  names: ["gathered", "gather", "gather*"],
  props: {
    numArgs: 0
  },
  handler(context) {
    if (["gather", "gather*"].includes(context.envName)) {
      validateAmsEnvironmentContext(context);
    }
    var res = {
      cols: [{
        type: "align",
        align: "c"
      }],
      addJot: true,
      colSeparationType: "gather",
      autoTag: getAutoTag(context.envName),
      emptySingleRow: true,
      leqno: context.parser.settings.leqno
    };
    return parseArray(context.parser, res, "display");
  },
  htmlBuilder: htmlBuilder$6,
  mathmlBuilder: mathmlBuilder$5
});
defineEnvironment({
  type: "array",
  names: ["alignat", "alignat*", "alignedat"],
  props: {
    numArgs: 1
  },
  handler: alignedHandler,
  htmlBuilder: htmlBuilder$6,
  mathmlBuilder: mathmlBuilder$5
});
defineEnvironment({
  type: "array",
  names: ["equation", "equation*"],
  props: {
    numArgs: 0
  },
  handler(context) {
    validateAmsEnvironmentContext(context);
    var res = {
      autoTag: getAutoTag(context.envName),
      emptySingleRow: true,
      singleRow: true,
      maxNumCols: 1,
      leqno: context.parser.settings.leqno
    };
    return parseArray(context.parser, res, "display");
  },
  htmlBuilder: htmlBuilder$6,
  mathmlBuilder: mathmlBuilder$5
});
defineEnvironment({
  type: "array",
  names: ["CD"],
  props: {
    numArgs: 0
  },
  handler(context) {
    validateAmsEnvironmentContext(context);
    return parseCD(context.parser);
  },
  htmlBuilder: htmlBuilder$6,
  mathmlBuilder: mathmlBuilder$5
});
defineMacro("\\nonumber", "\\gdef\\@eqnsw{0}");
defineMacro("\\notag", "\\nonumber");
defineFunction({
  type: "text",
  // Doesn't matter what this is.
  names: ["\\hline", "\\hdashline"],
  props: {
    numArgs: 0,
    allowedInText: true,
    allowedInMath: true
  },
  handler(context, args) {
    throw new ParseError(context.funcName + " valid only within array environment");
  }
});
var environments = _environments;
defineFunction({
  type: "environment",
  names: ["\\begin", "\\end"],
  props: {
    numArgs: 1,
    argTypes: ["text"]
  },
  handler(_ref, args) {
    var {
      parser,
      funcName
    } = _ref;
    var nameGroup = args[0];
    if (nameGroup.type !== "ordgroup") {
      throw new ParseError("Invalid environment name", nameGroup);
    }
    var envName = "";
    for (var i = 0; i < nameGroup.body.length; ++i) {
      envName += assertNodeType(nameGroup.body[i], "textord").text;
    }
    if (funcName === "\\begin") {
      if (!environments.hasOwnProperty(envName)) {
        throw new ParseError("No such environment: " + envName, nameGroup);
      }
      var env = environments[envName];
      var {
        args: _args,
        optArgs
      } = parser.parseArguments("\\begin{" + envName + "}", env);
      var context = {
        mode: parser.mode,
        envName,
        parser
      };
      var result = env.handler(context, _args, optArgs);
      parser.expect("\\end", false);
      var endNameToken = parser.nextToken;
      var end = assertNodeType(parser.parseFunction(), "environment");
      if (end.name !== envName) {
        throw new ParseError("Mismatch: \\begin{" + envName + "} matched by \\end{" + end.name + "}", endNameToken);
      }
      return result;
    }
    return {
      type: "environment",
      mode: parser.mode,
      name: envName,
      nameGroup
    };
  }
});
var htmlBuilder$5 = (group, options) => {
  var font = group.font;
  var newOptions = options.withFont(font);
  return buildGroup$1(group.body, newOptions);
};
var mathmlBuilder$4 = (group, options) => {
  var font = group.font;
  var newOptions = options.withFont(font);
  return buildGroup2(group.body, newOptions);
};
var fontAliases = {
  "\\Bbb": "\\mathbb",
  "\\bold": "\\mathbf",
  "\\frak": "\\mathfrak",
  "\\bm": "\\boldsymbol"
};
defineFunction({
  type: "font",
  names: [
    // styles, except \boldsymbol defined below
    "\\mathrm",
    "\\mathit",
    "\\mathbf",
    "\\mathnormal",
    "\\mathsfit",
    // families
    "\\mathbb",
    "\\mathcal",
    "\\mathfrak",
    "\\mathscr",
    "\\mathsf",
    "\\mathtt",
    // aliases, except \bm defined below
    "\\Bbb",
    "\\bold",
    "\\frak"
  ],
  props: {
    numArgs: 1,
    allowedInArgument: true
  },
  handler: (_ref, args) => {
    var {
      parser,
      funcName
    } = _ref;
    var body = normalizeArgument(args[0]);
    var func = funcName;
    if (func in fontAliases) {
      func = fontAliases[func];
    }
    return {
      type: "font",
      mode: parser.mode,
      font: func.slice(1),
      body
    };
  },
  htmlBuilder: htmlBuilder$5,
  mathmlBuilder: mathmlBuilder$4
});
defineFunction({
  type: "mclass",
  names: ["\\boldsymbol", "\\bm"],
  props: {
    numArgs: 1
  },
  handler: (_ref2, args) => {
    var {
      parser
    } = _ref2;
    var body = args[0];
    var isCharacterBox3 = utils.isCharacterBox(body);
    return {
      type: "mclass",
      mode: parser.mode,
      mclass: binrelClass(body),
      body: [{
        type: "font",
        mode: parser.mode,
        font: "boldsymbol",
        body
      }],
      isCharacterBox: isCharacterBox3
    };
  }
});
defineFunction({
  type: "font",
  names: ["\\rm", "\\sf", "\\tt", "\\bf", "\\it", "\\cal"],
  props: {
    numArgs: 0,
    allowedInText: true
  },
  handler: (_ref3, args) => {
    var {
      parser,
      funcName,
      breakOnTokenText
    } = _ref3;
    var {
      mode
    } = parser;
    var body = parser.parseExpression(true, breakOnTokenText);
    var style = "math" + funcName.slice(1);
    return {
      type: "font",
      mode,
      font: style,
      body: {
        type: "ordgroup",
        mode: parser.mode,
        body
      }
    };
  },
  htmlBuilder: htmlBuilder$5,
  mathmlBuilder: mathmlBuilder$4
});
var adjustStyle = (size, originalStyle) => {
  var style = originalStyle;
  if (size === "display") {
    style = style.id >= Style$1.SCRIPT.id ? style.text() : Style$1.DISPLAY;
  } else if (size === "text" && style.size === Style$1.DISPLAY.size) {
    style = Style$1.TEXT;
  } else if (size === "script") {
    style = Style$1.SCRIPT;
  } else if (size === "scriptscript") {
    style = Style$1.SCRIPTSCRIPT;
  }
  return style;
};
var htmlBuilder$4 = (group, options) => {
  var style = adjustStyle(group.size, options.style);
  var nstyle = style.fracNum();
  var dstyle = style.fracDen();
  var newOptions;
  newOptions = options.havingStyle(nstyle);
  var numerm = buildGroup$1(group.numer, newOptions, options);
  if (group.continued) {
    var hStrut = 8.5 / options.fontMetrics().ptPerEm;
    var dStrut = 3.5 / options.fontMetrics().ptPerEm;
    numerm.height = numerm.height < hStrut ? hStrut : numerm.height;
    numerm.depth = numerm.depth < dStrut ? dStrut : numerm.depth;
  }
  newOptions = options.havingStyle(dstyle);
  var denomm = buildGroup$1(group.denom, newOptions, options);
  var rule;
  var ruleWidth;
  var ruleSpacing;
  if (group.hasBarLine) {
    if (group.barSize) {
      ruleWidth = calculateSize(group.barSize, options);
      rule = buildCommon.makeLineSpan("frac-line", options, ruleWidth);
    } else {
      rule = buildCommon.makeLineSpan("frac-line", options);
    }
    ruleWidth = rule.height;
    ruleSpacing = rule.height;
  } else {
    rule = null;
    ruleWidth = 0;
    ruleSpacing = options.fontMetrics().defaultRuleThickness;
  }
  var numShift;
  var clearance;
  var denomShift;
  if (style.size === Style$1.DISPLAY.size || group.size === "display") {
    numShift = options.fontMetrics().num1;
    if (ruleWidth > 0) {
      clearance = 3 * ruleSpacing;
    } else {
      clearance = 7 * ruleSpacing;
    }
    denomShift = options.fontMetrics().denom1;
  } else {
    if (ruleWidth > 0) {
      numShift = options.fontMetrics().num2;
      clearance = ruleSpacing;
    } else {
      numShift = options.fontMetrics().num3;
      clearance = 3 * ruleSpacing;
    }
    denomShift = options.fontMetrics().denom2;
  }
  var frac;
  if (!rule) {
    var candidateClearance = numShift - numerm.depth - (denomm.height - denomShift);
    if (candidateClearance < clearance) {
      numShift += 0.5 * (clearance - candidateClearance);
      denomShift += 0.5 * (clearance - candidateClearance);
    }
    frac = buildCommon.makeVList({
      positionType: "individualShift",
      children: [{
        type: "elem",
        elem: denomm,
        shift: denomShift
      }, {
        type: "elem",
        elem: numerm,
        shift: -numShift
      }]
    }, options);
  } else {
    var axisHeight = options.fontMetrics().axisHeight;
    if (numShift - numerm.depth - (axisHeight + 0.5 * ruleWidth) < clearance) {
      numShift += clearance - (numShift - numerm.depth - (axisHeight + 0.5 * ruleWidth));
    }
    if (axisHeight - 0.5 * ruleWidth - (denomm.height - denomShift) < clearance) {
      denomShift += clearance - (axisHeight - 0.5 * ruleWidth - (denomm.height - denomShift));
    }
    var midShift = -(axisHeight - 0.5 * ruleWidth);
    frac = buildCommon.makeVList({
      positionType: "individualShift",
      children: [{
        type: "elem",
        elem: denomm,
        shift: denomShift
      }, {
        type: "elem",
        elem: rule,
        shift: midShift
      }, {
        type: "elem",
        elem: numerm,
        shift: -numShift
      }]
    }, options);
  }
  newOptions = options.havingStyle(style);
  frac.height *= newOptions.sizeMultiplier / options.sizeMultiplier;
  frac.depth *= newOptions.sizeMultiplier / options.sizeMultiplier;
  var delimSize;
  if (style.size === Style$1.DISPLAY.size) {
    delimSize = options.fontMetrics().delim1;
  } else if (style.size === Style$1.SCRIPTSCRIPT.size) {
    delimSize = options.havingStyle(Style$1.SCRIPT).fontMetrics().delim2;
  } else {
    delimSize = options.fontMetrics().delim2;
  }
  var leftDelim;
  var rightDelim;
  if (group.leftDelim == null) {
    leftDelim = makeNullDelimiter(options, ["mopen"]);
  } else {
    leftDelim = delimiter.customSizedDelim(group.leftDelim, delimSize, true, options.havingStyle(style), group.mode, ["mopen"]);
  }
  if (group.continued) {
    rightDelim = buildCommon.makeSpan([]);
  } else if (group.rightDelim == null) {
    rightDelim = makeNullDelimiter(options, ["mclose"]);
  } else {
    rightDelim = delimiter.customSizedDelim(group.rightDelim, delimSize, true, options.havingStyle(style), group.mode, ["mclose"]);
  }
  return buildCommon.makeSpan(["mord"].concat(newOptions.sizingClasses(options)), [leftDelim, buildCommon.makeSpan(["mfrac"], [frac]), rightDelim], options);
};
var mathmlBuilder$3 = (group, options) => {
  var node = new mathMLTree.MathNode("mfrac", [buildGroup2(group.numer, options), buildGroup2(group.denom, options)]);
  if (!group.hasBarLine) {
    node.setAttribute("linethickness", "0px");
  } else if (group.barSize) {
    var ruleWidth = calculateSize(group.barSize, options);
    node.setAttribute("linethickness", makeEm(ruleWidth));
  }
  var style = adjustStyle(group.size, options.style);
  if (style.size !== options.style.size) {
    node = new mathMLTree.MathNode("mstyle", [node]);
    var isDisplay = style.size === Style$1.DISPLAY.size ? "true" : "false";
    node.setAttribute("displaystyle", isDisplay);
    node.setAttribute("scriptlevel", "0");
  }
  if (group.leftDelim != null || group.rightDelim != null) {
    var withDelims = [];
    if (group.leftDelim != null) {
      var leftOp = new mathMLTree.MathNode("mo", [new mathMLTree.TextNode(group.leftDelim.replace("\\", ""))]);
      leftOp.setAttribute("fence", "true");
      withDelims.push(leftOp);
    }
    withDelims.push(node);
    if (group.rightDelim != null) {
      var rightOp = new mathMLTree.MathNode("mo", [new mathMLTree.TextNode(group.rightDelim.replace("\\", ""))]);
      rightOp.setAttribute("fence", "true");
      withDelims.push(rightOp);
    }
    return makeRow(withDelims);
  }
  return node;
};
defineFunction({
  type: "genfrac",
  names: [
    "\\dfrac",
    "\\frac",
    "\\tfrac",
    "\\dbinom",
    "\\binom",
    "\\tbinom",
    "\\\\atopfrac",
    // can’t be entered directly
    "\\\\bracefrac",
    "\\\\brackfrac"
    // ditto
  ],
  props: {
    numArgs: 2,
    allowedInArgument: true
  },
  handler: (_ref, args) => {
    var {
      parser,
      funcName
    } = _ref;
    var numer = args[0];
    var denom = args[1];
    var hasBarLine;
    var leftDelim = null;
    var rightDelim = null;
    var size = "auto";
    switch (funcName) {
      case "\\dfrac":
      case "\\frac":
      case "\\tfrac":
        hasBarLine = true;
        break;
      case "\\\\atopfrac":
        hasBarLine = false;
        break;
      case "\\dbinom":
      case "\\binom":
      case "\\tbinom":
        hasBarLine = false;
        leftDelim = "(";
        rightDelim = ")";
        break;
      case "\\\\bracefrac":
        hasBarLine = false;
        leftDelim = "\\{";
        rightDelim = "\\}";
        break;
      case "\\\\brackfrac":
        hasBarLine = false;
        leftDelim = "[";
        rightDelim = "]";
        break;
      default:
        throw new Error("Unrecognized genfrac command");
    }
    switch (funcName) {
      case "\\dfrac":
      case "\\dbinom":
        size = "display";
        break;
      case "\\tfrac":
      case "\\tbinom":
        size = "text";
        break;
    }
    return {
      type: "genfrac",
      mode: parser.mode,
      continued: false,
      numer,
      denom,
      hasBarLine,
      leftDelim,
      rightDelim,
      size,
      barSize: null
    };
  },
  htmlBuilder: htmlBuilder$4,
  mathmlBuilder: mathmlBuilder$3
});
defineFunction({
  type: "genfrac",
  names: ["\\cfrac"],
  props: {
    numArgs: 2
  },
  handler: (_ref2, args) => {
    var {
      parser,
      funcName
    } = _ref2;
    var numer = args[0];
    var denom = args[1];
    return {
      type: "genfrac",
      mode: parser.mode,
      continued: true,
      numer,
      denom,
      hasBarLine: true,
      leftDelim: null,
      rightDelim: null,
      size: "display",
      barSize: null
    };
  }
});
defineFunction({
  type: "infix",
  names: ["\\over", "\\choose", "\\atop", "\\brace", "\\brack"],
  props: {
    numArgs: 0,
    infix: true
  },
  handler(_ref3) {
    var {
      parser,
      funcName,
      token
    } = _ref3;
    var replaceWith;
    switch (funcName) {
      case "\\over":
        replaceWith = "\\frac";
        break;
      case "\\choose":
        replaceWith = "\\binom";
        break;
      case "\\atop":
        replaceWith = "\\\\atopfrac";
        break;
      case "\\brace":
        replaceWith = "\\\\bracefrac";
        break;
      case "\\brack":
        replaceWith = "\\\\brackfrac";
        break;
      default:
        throw new Error("Unrecognized infix genfrac command");
    }
    return {
      type: "infix",
      mode: parser.mode,
      replaceWith,
      token
    };
  }
});
var stylArray = ["display", "text", "script", "scriptscript"];
var delimFromValue = function delimFromValue2(delimString) {
  var delim = null;
  if (delimString.length > 0) {
    delim = delimString;
    delim = delim === "." ? null : delim;
  }
  return delim;
};
defineFunction({
  type: "genfrac",
  names: ["\\genfrac"],
  props: {
    numArgs: 6,
    allowedInArgument: true,
    argTypes: ["math", "math", "size", "text", "math", "math"]
  },
  handler(_ref4, args) {
    var {
      parser
    } = _ref4;
    var numer = args[4];
    var denom = args[5];
    var leftNode = normalizeArgument(args[0]);
    var leftDelim = leftNode.type === "atom" && leftNode.family === "open" ? delimFromValue(leftNode.text) : null;
    var rightNode = normalizeArgument(args[1]);
    var rightDelim = rightNode.type === "atom" && rightNode.family === "close" ? delimFromValue(rightNode.text) : null;
    var barNode = assertNodeType(args[2], "size");
    var hasBarLine;
    var barSize = null;
    if (barNode.isBlank) {
      hasBarLine = true;
    } else {
      barSize = barNode.value;
      hasBarLine = barSize.number > 0;
    }
    var size = "auto";
    var styl = args[3];
    if (styl.type === "ordgroup") {
      if (styl.body.length > 0) {
        var textOrd = assertNodeType(styl.body[0], "textord");
        size = stylArray[Number(textOrd.text)];
      }
    } else {
      styl = assertNodeType(styl, "textord");
      size = stylArray[Number(styl.text)];
    }
    return {
      type: "genfrac",
      mode: parser.mode,
      numer,
      denom,
      continued: false,
      hasBarLine,
      barSize,
      leftDelim,
      rightDelim,
      size
    };
  },
  htmlBuilder: htmlBuilder$4,
  mathmlBuilder: mathmlBuilder$3
});
defineFunction({
  type: "infix",
  names: ["\\above"],
  props: {
    numArgs: 1,
    argTypes: ["size"],
    infix: true
  },
  handler(_ref5, args) {
    var {
      parser,
      funcName,
      token
    } = _ref5;
    return {
      type: "infix",
      mode: parser.mode,
      replaceWith: "\\\\abovefrac",
      size: assertNodeType(args[0], "size").value,
      token
    };
  }
});
defineFunction({
  type: "genfrac",
  names: ["\\\\abovefrac"],
  props: {
    numArgs: 3,
    argTypes: ["math", "size", "math"]
  },
  handler: (_ref6, args) => {
    var {
      parser,
      funcName
    } = _ref6;
    var numer = args[0];
    var barSize = assert(assertNodeType(args[1], "infix").size);
    var denom = args[2];
    var hasBarLine = barSize.number > 0;
    return {
      type: "genfrac",
      mode: parser.mode,
      numer,
      denom,
      continued: false,
      hasBarLine,
      barSize,
      leftDelim: null,
      rightDelim: null,
      size: "auto"
    };
  },
  htmlBuilder: htmlBuilder$4,
  mathmlBuilder: mathmlBuilder$3
});
var htmlBuilder$3 = (grp, options) => {
  var style = options.style;
  var supSubGroup;
  var group;
  if (grp.type === "supsub") {
    supSubGroup = grp.sup ? buildGroup$1(grp.sup, options.havingStyle(style.sup()), options) : buildGroup$1(grp.sub, options.havingStyle(style.sub()), options);
    group = assertNodeType(grp.base, "horizBrace");
  } else {
    group = assertNodeType(grp, "horizBrace");
  }
  var body = buildGroup$1(group.base, options.havingBaseStyle(Style$1.DISPLAY));
  var braceBody = stretchy.svgSpan(group, options);
  var vlist;
  if (group.isOver) {
    vlist = buildCommon.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: body
      }, {
        type: "kern",
        size: 0.1
      }, {
        type: "elem",
        elem: braceBody
      }]
    }, options);
    vlist.children[0].children[0].children[1].classes.push("svg-align");
  } else {
    vlist = buildCommon.makeVList({
      positionType: "bottom",
      positionData: body.depth + 0.1 + braceBody.height,
      children: [{
        type: "elem",
        elem: braceBody
      }, {
        type: "kern",
        size: 0.1
      }, {
        type: "elem",
        elem: body
      }]
    }, options);
    vlist.children[0].children[0].children[0].classes.push("svg-align");
  }
  if (supSubGroup) {
    var vSpan = buildCommon.makeSpan(["mord", group.isOver ? "mover" : "munder"], [vlist], options);
    if (group.isOver) {
      vlist = buildCommon.makeVList({
        positionType: "firstBaseline",
        children: [{
          type: "elem",
          elem: vSpan
        }, {
          type: "kern",
          size: 0.2
        }, {
          type: "elem",
          elem: supSubGroup
        }]
      }, options);
    } else {
      vlist = buildCommon.makeVList({
        positionType: "bottom",
        positionData: vSpan.depth + 0.2 + supSubGroup.height + supSubGroup.depth,
        children: [{
          type: "elem",
          elem: supSubGroup
        }, {
          type: "kern",
          size: 0.2
        }, {
          type: "elem",
          elem: vSpan
        }]
      }, options);
    }
  }
  return buildCommon.makeSpan(["mord", group.isOver ? "mover" : "munder"], [vlist], options);
};
var mathmlBuilder$2 = (group, options) => {
  var accentNode = stretchy.mathMLnode(group.label);
  return new mathMLTree.MathNode(group.isOver ? "mover" : "munder", [buildGroup2(group.base, options), accentNode]);
};
defineFunction({
  type: "horizBrace",
  names: ["\\overbrace", "\\underbrace"],
  props: {
    numArgs: 1
  },
  handler(_ref, args) {
    var {
      parser,
      funcName
    } = _ref;
    return {
      type: "horizBrace",
      mode: parser.mode,
      label: funcName,
      isOver: /^\\over/.test(funcName),
      base: args[0]
    };
  },
  htmlBuilder: htmlBuilder$3,
  mathmlBuilder: mathmlBuilder$2
});
defineFunction({
  type: "href",
  names: ["\\href"],
  props: {
    numArgs: 2,
    argTypes: ["url", "original"],
    allowedInText: true
  },
  handler: (_ref, args) => {
    var {
      parser
    } = _ref;
    var body = args[1];
    var href = assertNodeType(args[0], "url").url;
    if (!parser.settings.isTrusted({
      command: "\\href",
      url: href
    })) {
      return parser.formatUnsupportedCmd("\\href");
    }
    return {
      type: "href",
      mode: parser.mode,
      href,
      body: ordargument(body)
    };
  },
  htmlBuilder: (group, options) => {
    var elements = buildExpression$1(group.body, options, false);
    return buildCommon.makeAnchor(group.href, [], elements, options);
  },
  mathmlBuilder: (group, options) => {
    var math2 = buildExpressionRow(group.body, options);
    if (!(math2 instanceof MathNode)) {
      math2 = new MathNode("mrow", [math2]);
    }
    math2.setAttribute("href", group.href);
    return math2;
  }
});
defineFunction({
  type: "href",
  names: ["\\url"],
  props: {
    numArgs: 1,
    argTypes: ["url"],
    allowedInText: true
  },
  handler: (_ref2, args) => {
    var {
      parser
    } = _ref2;
    var href = assertNodeType(args[0], "url").url;
    if (!parser.settings.isTrusted({
      command: "\\url",
      url: href
    })) {
      return parser.formatUnsupportedCmd("\\url");
    }
    var chars = [];
    for (var i = 0; i < href.length; i++) {
      var c = href[i];
      if (c === "~") {
        c = "\\textasciitilde";
      }
      chars.push({
        type: "textord",
        mode: "text",
        text: c
      });
    }
    var body = {
      type: "text",
      mode: parser.mode,
      font: "\\texttt",
      body: chars
    };
    return {
      type: "href",
      mode: parser.mode,
      href,
      body: ordargument(body)
    };
  }
});
defineFunction({
  type: "hbox",
  names: ["\\hbox"],
  props: {
    numArgs: 1,
    argTypes: ["text"],
    allowedInText: true,
    primitive: true
  },
  handler(_ref, args) {
    var {
      parser
    } = _ref;
    return {
      type: "hbox",
      mode: parser.mode,
      body: ordargument(args[0])
    };
  },
  htmlBuilder(group, options) {
    var elements = buildExpression$1(group.body, options, false);
    return buildCommon.makeFragment(elements);
  },
  mathmlBuilder(group, options) {
    return new mathMLTree.MathNode("mrow", buildExpression2(group.body, options));
  }
});
defineFunction({
  type: "html",
  names: ["\\htmlClass", "\\htmlId", "\\htmlStyle", "\\htmlData"],
  props: {
    numArgs: 2,
    argTypes: ["raw", "original"],
    allowedInText: true
  },
  handler: (_ref, args) => {
    var {
      parser,
      funcName,
      token
    } = _ref;
    var value = assertNodeType(args[0], "raw").string;
    var body = args[1];
    if (parser.settings.strict) {
      parser.settings.reportNonstrict("htmlExtension", "HTML extension is disabled on strict mode");
    }
    var trustContext;
    var attributes = {};
    switch (funcName) {
      case "\\htmlClass":
        attributes.class = value;
        trustContext = {
          command: "\\htmlClass",
          class: value
        };
        break;
      case "\\htmlId":
        attributes.id = value;
        trustContext = {
          command: "\\htmlId",
          id: value
        };
        break;
      case "\\htmlStyle":
        attributes.style = value;
        trustContext = {
          command: "\\htmlStyle",
          style: value
        };
        break;
      case "\\htmlData": {
        var data = value.split(",");
        for (var i = 0; i < data.length; i++) {
          var item = data[i];
          var firstEquals = item.indexOf("=");
          if (firstEquals < 0) {
            throw new ParseError("\\htmlData key/value '" + item + "' missing equals sign");
          }
          var key = item.slice(0, firstEquals);
          var _value = item.slice(firstEquals + 1);
          attributes["data-" + key.trim()] = _value;
        }
        trustContext = {
          command: "\\htmlData",
          attributes
        };
        break;
      }
      default:
        throw new Error("Unrecognized html command");
    }
    if (!parser.settings.isTrusted(trustContext)) {
      return parser.formatUnsupportedCmd(funcName);
    }
    return {
      type: "html",
      mode: parser.mode,
      attributes,
      body: ordargument(body)
    };
  },
  htmlBuilder: (group, options) => {
    var elements = buildExpression$1(group.body, options, false);
    var classes = ["enclosing"];
    if (group.attributes.class) {
      classes.push(...group.attributes.class.trim().split(/\s+/));
    }
    var span = buildCommon.makeSpan(classes, elements, options);
    for (var attr in group.attributes) {
      if (attr !== "class" && group.attributes.hasOwnProperty(attr)) {
        span.setAttribute(attr, group.attributes[attr]);
      }
    }
    return span;
  },
  mathmlBuilder: (group, options) => {
    return buildExpressionRow(group.body, options);
  }
});
defineFunction({
  type: "htmlmathml",
  names: ["\\html@mathml"],
  props: {
    numArgs: 2,
    allowedInText: true
  },
  handler: (_ref, args) => {
    var {
      parser
    } = _ref;
    return {
      type: "htmlmathml",
      mode: parser.mode,
      html: ordargument(args[0]),
      mathml: ordargument(args[1])
    };
  },
  htmlBuilder: (group, options) => {
    var elements = buildExpression$1(group.html, options, false);
    return buildCommon.makeFragment(elements);
  },
  mathmlBuilder: (group, options) => {
    return buildExpressionRow(group.mathml, options);
  }
});
var sizeData = function sizeData2(str) {
  if (/^[-+]? *(\d+(\.\d*)?|\.\d+)$/.test(str)) {
    return {
      number: +str,
      unit: "bp"
    };
  } else {
    var match = /([-+]?) *(\d+(?:\.\d*)?|\.\d+) *([a-z]{2})/.exec(str);
    if (!match) {
      throw new ParseError("Invalid size: '" + str + "' in \\includegraphics");
    }
    var data = {
      number: +(match[1] + match[2]),
      // sign + magnitude, cast to number
      unit: match[3]
    };
    if (!validUnit(data)) {
      throw new ParseError("Invalid unit: '" + data.unit + "' in \\includegraphics.");
    }
    return data;
  }
};
defineFunction({
  type: "includegraphics",
  names: ["\\includegraphics"],
  props: {
    numArgs: 1,
    numOptionalArgs: 1,
    argTypes: ["raw", "url"],
    allowedInText: false
  },
  handler: (_ref, args, optArgs) => {
    var {
      parser
    } = _ref;
    var width = {
      number: 0,
      unit: "em"
    };
    var height = {
      number: 0.9,
      unit: "em"
    };
    var totalheight = {
      number: 0,
      unit: "em"
    };
    var alt = "";
    if (optArgs[0]) {
      var attributeStr = assertNodeType(optArgs[0], "raw").string;
      var attributes = attributeStr.split(",");
      for (var i = 0; i < attributes.length; i++) {
        var keyVal = attributes[i].split("=");
        if (keyVal.length === 2) {
          var str = keyVal[1].trim();
          switch (keyVal[0].trim()) {
            case "alt":
              alt = str;
              break;
            case "width":
              width = sizeData(str);
              break;
            case "height":
              height = sizeData(str);
              break;
            case "totalheight":
              totalheight = sizeData(str);
              break;
            default:
              throw new ParseError("Invalid key: '" + keyVal[0] + "' in \\includegraphics.");
          }
        }
      }
    }
    var src = assertNodeType(args[0], "url").url;
    if (alt === "") {
      alt = src;
      alt = alt.replace(/^.*[\\/]/, "");
      alt = alt.substring(0, alt.lastIndexOf("."));
    }
    if (!parser.settings.isTrusted({
      command: "\\includegraphics",
      url: src
    })) {
      return parser.formatUnsupportedCmd("\\includegraphics");
    }
    return {
      type: "includegraphics",
      mode: parser.mode,
      alt,
      width,
      height,
      totalheight,
      src
    };
  },
  htmlBuilder: (group, options) => {
    var height = calculateSize(group.height, options);
    var depth = 0;
    if (group.totalheight.number > 0) {
      depth = calculateSize(group.totalheight, options) - height;
    }
    var width = 0;
    if (group.width.number > 0) {
      width = calculateSize(group.width, options);
    }
    var style = {
      height: makeEm(height + depth)
    };
    if (width > 0) {
      style.width = makeEm(width);
    }
    if (depth > 0) {
      style.verticalAlign = makeEm(-depth);
    }
    var node = new Img(group.src, group.alt, style);
    node.height = height;
    node.depth = depth;
    return node;
  },
  mathmlBuilder: (group, options) => {
    var node = new mathMLTree.MathNode("mglyph", []);
    node.setAttribute("alt", group.alt);
    var height = calculateSize(group.height, options);
    var depth = 0;
    if (group.totalheight.number > 0) {
      depth = calculateSize(group.totalheight, options) - height;
      node.setAttribute("valign", makeEm(-depth));
    }
    node.setAttribute("height", makeEm(height + depth));
    if (group.width.number > 0) {
      var width = calculateSize(group.width, options);
      node.setAttribute("width", makeEm(width));
    }
    node.setAttribute("src", group.src);
    return node;
  }
});
defineFunction({
  type: "kern",
  names: ["\\kern", "\\mkern", "\\hskip", "\\mskip"],
  props: {
    numArgs: 1,
    argTypes: ["size"],
    primitive: true,
    allowedInText: true
  },
  handler(_ref, args) {
    var {
      parser,
      funcName
    } = _ref;
    var size = assertNodeType(args[0], "size");
    if (parser.settings.strict) {
      var mathFunction = funcName[1] === "m";
      var muUnit = size.value.unit === "mu";
      if (mathFunction) {
        if (!muUnit) {
          parser.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + funcName + " supports only mu units, " + ("not " + size.value.unit + " units"));
        }
        if (parser.mode !== "math") {
          parser.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + funcName + " works only in math mode");
        }
      } else {
        if (muUnit) {
          parser.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + funcName + " doesn't support mu units");
        }
      }
    }
    return {
      type: "kern",
      mode: parser.mode,
      dimension: size.value
    };
  },
  htmlBuilder(group, options) {
    return buildCommon.makeGlue(group.dimension, options);
  },
  mathmlBuilder(group, options) {
    var dimension = calculateSize(group.dimension, options);
    return new mathMLTree.SpaceNode(dimension);
  }
});
defineFunction({
  type: "lap",
  names: ["\\mathllap", "\\mathrlap", "\\mathclap"],
  props: {
    numArgs: 1,
    allowedInText: true
  },
  handler: (_ref, args) => {
    var {
      parser,
      funcName
    } = _ref;
    var body = args[0];
    return {
      type: "lap",
      mode: parser.mode,
      alignment: funcName.slice(5),
      body
    };
  },
  htmlBuilder: (group, options) => {
    var inner2;
    if (group.alignment === "clap") {
      inner2 = buildCommon.makeSpan([], [buildGroup$1(group.body, options)]);
      inner2 = buildCommon.makeSpan(["inner"], [inner2], options);
    } else {
      inner2 = buildCommon.makeSpan(["inner"], [buildGroup$1(group.body, options)]);
    }
    var fix = buildCommon.makeSpan(["fix"], []);
    var node = buildCommon.makeSpan([group.alignment], [inner2, fix], options);
    var strut = buildCommon.makeSpan(["strut"]);
    strut.style.height = makeEm(node.height + node.depth);
    if (node.depth) {
      strut.style.verticalAlign = makeEm(-node.depth);
    }
    node.children.unshift(strut);
    node = buildCommon.makeSpan(["thinbox"], [node], options);
    return buildCommon.makeSpan(["mord", "vbox"], [node], options);
  },
  mathmlBuilder: (group, options) => {
    var node = new mathMLTree.MathNode("mpadded", [buildGroup2(group.body, options)]);
    if (group.alignment !== "rlap") {
      var offset = group.alignment === "llap" ? "-1" : "-0.5";
      node.setAttribute("lspace", offset + "width");
    }
    node.setAttribute("width", "0px");
    return node;
  }
});
defineFunction({
  type: "styling",
  names: ["\\(", "$"],
  props: {
    numArgs: 0,
    allowedInText: true,
    allowedInMath: false
  },
  handler(_ref, args) {
    var {
      funcName,
      parser
    } = _ref;
    var outerMode = parser.mode;
    parser.switchMode("math");
    var close2 = funcName === "\\(" ? "\\)" : "$";
    var body = parser.parseExpression(false, close2);
    parser.expect(close2);
    parser.switchMode(outerMode);
    return {
      type: "styling",
      mode: parser.mode,
      style: "text",
      body
    };
  }
});
defineFunction({
  type: "text",
  // Doesn't matter what this is.
  names: ["\\)", "\\]"],
  props: {
    numArgs: 0,
    allowedInText: true,
    allowedInMath: false
  },
  handler(context, args) {
    throw new ParseError("Mismatched " + context.funcName);
  }
});
var chooseMathStyle = (group, options) => {
  switch (options.style.size) {
    case Style$1.DISPLAY.size:
      return group.display;
    case Style$1.TEXT.size:
      return group.text;
    case Style$1.SCRIPT.size:
      return group.script;
    case Style$1.SCRIPTSCRIPT.size:
      return group.scriptscript;
    default:
      return group.text;
  }
};
defineFunction({
  type: "mathchoice",
  names: ["\\mathchoice"],
  props: {
    numArgs: 4,
    primitive: true
  },
  handler: (_ref, args) => {
    var {
      parser
    } = _ref;
    return {
      type: "mathchoice",
      mode: parser.mode,
      display: ordargument(args[0]),
      text: ordargument(args[1]),
      script: ordargument(args[2]),
      scriptscript: ordargument(args[3])
    };
  },
  htmlBuilder: (group, options) => {
    var body = chooseMathStyle(group, options);
    var elements = buildExpression$1(body, options, false);
    return buildCommon.makeFragment(elements);
  },
  mathmlBuilder: (group, options) => {
    var body = chooseMathStyle(group, options);
    return buildExpressionRow(body, options);
  }
});
var assembleSupSub = (base, supGroup, subGroup, options, style, slant, baseShift) => {
  base = buildCommon.makeSpan([], [base]);
  var subIsSingleCharacter = subGroup && utils.isCharacterBox(subGroup);
  var sub2;
  var sup2;
  if (supGroup) {
    var elem = buildGroup$1(supGroup, options.havingStyle(style.sup()), options);
    sup2 = {
      elem,
      kern: Math.max(options.fontMetrics().bigOpSpacing1, options.fontMetrics().bigOpSpacing3 - elem.depth)
    };
  }
  if (subGroup) {
    var _elem = buildGroup$1(subGroup, options.havingStyle(style.sub()), options);
    sub2 = {
      elem: _elem,
      kern: Math.max(options.fontMetrics().bigOpSpacing2, options.fontMetrics().bigOpSpacing4 - _elem.height)
    };
  }
  var finalGroup;
  if (sup2 && sub2) {
    var bottom = options.fontMetrics().bigOpSpacing5 + sub2.elem.height + sub2.elem.depth + sub2.kern + base.depth + baseShift;
    finalGroup = buildCommon.makeVList({
      positionType: "bottom",
      positionData: bottom,
      children: [{
        type: "kern",
        size: options.fontMetrics().bigOpSpacing5
      }, {
        type: "elem",
        elem: sub2.elem,
        marginLeft: makeEm(-slant)
      }, {
        type: "kern",
        size: sub2.kern
      }, {
        type: "elem",
        elem: base
      }, {
        type: "kern",
        size: sup2.kern
      }, {
        type: "elem",
        elem: sup2.elem,
        marginLeft: makeEm(slant)
      }, {
        type: "kern",
        size: options.fontMetrics().bigOpSpacing5
      }]
    }, options);
  } else if (sub2) {
    var top = base.height - baseShift;
    finalGroup = buildCommon.makeVList({
      positionType: "top",
      positionData: top,
      children: [{
        type: "kern",
        size: options.fontMetrics().bigOpSpacing5
      }, {
        type: "elem",
        elem: sub2.elem,
        marginLeft: makeEm(-slant)
      }, {
        type: "kern",
        size: sub2.kern
      }, {
        type: "elem",
        elem: base
      }]
    }, options);
  } else if (sup2) {
    var _bottom = base.depth + baseShift;
    finalGroup = buildCommon.makeVList({
      positionType: "bottom",
      positionData: _bottom,
      children: [{
        type: "elem",
        elem: base
      }, {
        type: "kern",
        size: sup2.kern
      }, {
        type: "elem",
        elem: sup2.elem,
        marginLeft: makeEm(slant)
      }, {
        type: "kern",
        size: options.fontMetrics().bigOpSpacing5
      }]
    }, options);
  } else {
    return base;
  }
  var parts = [finalGroup];
  if (sub2 && slant !== 0 && !subIsSingleCharacter) {
    var spacer = buildCommon.makeSpan(["mspace"], [], options);
    spacer.style.marginRight = makeEm(slant);
    parts.unshift(spacer);
  }
  return buildCommon.makeSpan(["mop", "op-limits"], parts, options);
};
var noSuccessor = ["\\smallint"];
var htmlBuilder$2 = (grp, options) => {
  var supGroup;
  var subGroup;
  var hasLimits = false;
  var group;
  if (grp.type === "supsub") {
    supGroup = grp.sup;
    subGroup = grp.sub;
    group = assertNodeType(grp.base, "op");
    hasLimits = true;
  } else {
    group = assertNodeType(grp, "op");
  }
  var style = options.style;
  var large = false;
  if (style.size === Style$1.DISPLAY.size && group.symbol && !noSuccessor.includes(group.name)) {
    large = true;
  }
  var base;
  if (group.symbol) {
    var fontName = large ? "Size2-Regular" : "Size1-Regular";
    var stash = "";
    if (group.name === "\\oiint" || group.name === "\\oiiint") {
      stash = group.name.slice(1);
      group.name = stash === "oiint" ? "\\iint" : "\\iiint";
    }
    base = buildCommon.makeSymbol(group.name, fontName, "math", options, ["mop", "op-symbol", large ? "large-op" : "small-op"]);
    if (stash.length > 0) {
      var italic = base.italic;
      var oval = buildCommon.staticSvg(stash + "Size" + (large ? "2" : "1"), options);
      base = buildCommon.makeVList({
        positionType: "individualShift",
        children: [{
          type: "elem",
          elem: base,
          shift: 0
        }, {
          type: "elem",
          elem: oval,
          shift: large ? 0.08 : 0
        }]
      }, options);
      group.name = "\\" + stash;
      base.classes.unshift("mop");
      base.italic = italic;
    }
  } else if (group.body) {
    var inner2 = buildExpression$1(group.body, options, true);
    if (inner2.length === 1 && inner2[0] instanceof SymbolNode) {
      base = inner2[0];
      base.classes[0] = "mop";
    } else {
      base = buildCommon.makeSpan(["mop"], inner2, options);
    }
  } else {
    var output = [];
    for (var i = 1; i < group.name.length; i++) {
      output.push(buildCommon.mathsym(group.name[i], group.mode, options));
    }
    base = buildCommon.makeSpan(["mop"], output, options);
  }
  var baseShift = 0;
  var slant = 0;
  if ((base instanceof SymbolNode || group.name === "\\oiint" || group.name === "\\oiiint") && !group.suppressBaseShift) {
    baseShift = (base.height - base.depth) / 2 - options.fontMetrics().axisHeight;
    slant = base.italic;
  }
  if (hasLimits) {
    return assembleSupSub(base, supGroup, subGroup, options, style, slant, baseShift);
  } else {
    if (baseShift) {
      base.style.position = "relative";
      base.style.top = makeEm(baseShift);
    }
    return base;
  }
};
var mathmlBuilder$1 = (group, options) => {
  var node;
  if (group.symbol) {
    node = new MathNode("mo", [makeText(group.name, group.mode)]);
    if (noSuccessor.includes(group.name)) {
      node.setAttribute("largeop", "false");
    }
  } else if (group.body) {
    node = new MathNode("mo", buildExpression2(group.body, options));
  } else {
    node = new MathNode("mi", [new TextNode(group.name.slice(1))]);
    var operator = new MathNode("mo", [makeText("⁡", "text")]);
    if (group.parentIsSupSub) {
      node = new MathNode("mrow", [node, operator]);
    } else {
      node = newDocumentFragment([node, operator]);
    }
  }
  return node;
};
var singleCharBigOps = {
  "∏": "\\prod",
  "∐": "\\coprod",
  "∑": "\\sum",
  "⋀": "\\bigwedge",
  "⋁": "\\bigvee",
  "⋂": "\\bigcap",
  "⋃": "\\bigcup",
  "⨀": "\\bigodot",
  "⨁": "\\bigoplus",
  "⨂": "\\bigotimes",
  "⨄": "\\biguplus",
  "⨆": "\\bigsqcup"
};
defineFunction({
  type: "op",
  names: ["\\coprod", "\\bigvee", "\\bigwedge", "\\biguplus", "\\bigcap", "\\bigcup", "\\intop", "\\prod", "\\sum", "\\bigotimes", "\\bigoplus", "\\bigodot", "\\bigsqcup", "\\smallint", "∏", "∐", "∑", "⋀", "⋁", "⋂", "⋃", "⨀", "⨁", "⨂", "⨄", "⨆"],
  props: {
    numArgs: 0
  },
  handler: (_ref, args) => {
    var {
      parser,
      funcName
    } = _ref;
    var fName = funcName;
    if (fName.length === 1) {
      fName = singleCharBigOps[fName];
    }
    return {
      type: "op",
      mode: parser.mode,
      limits: true,
      parentIsSupSub: false,
      symbol: true,
      name: fName
    };
  },
  htmlBuilder: htmlBuilder$2,
  mathmlBuilder: mathmlBuilder$1
});
defineFunction({
  type: "op",
  names: ["\\mathop"],
  props: {
    numArgs: 1,
    primitive: true
  },
  handler: (_ref2, args) => {
    var {
      parser
    } = _ref2;
    var body = args[0];
    return {
      type: "op",
      mode: parser.mode,
      limits: false,
      parentIsSupSub: false,
      symbol: false,
      body: ordargument(body)
    };
  },
  htmlBuilder: htmlBuilder$2,
  mathmlBuilder: mathmlBuilder$1
});
var singleCharIntegrals = {
  "∫": "\\int",
  "∬": "\\iint",
  "∭": "\\iiint",
  "∮": "\\oint",
  "∯": "\\oiint",
  "∰": "\\oiiint"
};
defineFunction({
  type: "op",
  names: ["\\arcsin", "\\arccos", "\\arctan", "\\arctg", "\\arcctg", "\\arg", "\\ch", "\\cos", "\\cosec", "\\cosh", "\\cot", "\\cotg", "\\coth", "\\csc", "\\ctg", "\\cth", "\\deg", "\\dim", "\\exp", "\\hom", "\\ker", "\\lg", "\\ln", "\\log", "\\sec", "\\sin", "\\sinh", "\\sh", "\\tan", "\\tanh", "\\tg", "\\th"],
  props: {
    numArgs: 0
  },
  handler(_ref3) {
    var {
      parser,
      funcName
    } = _ref3;
    return {
      type: "op",
      mode: parser.mode,
      limits: false,
      parentIsSupSub: false,
      symbol: false,
      name: funcName
    };
  },
  htmlBuilder: htmlBuilder$2,
  mathmlBuilder: mathmlBuilder$1
});
defineFunction({
  type: "op",
  names: ["\\det", "\\gcd", "\\inf", "\\lim", "\\max", "\\min", "\\Pr", "\\sup"],
  props: {
    numArgs: 0
  },
  handler(_ref4) {
    var {
      parser,
      funcName
    } = _ref4;
    return {
      type: "op",
      mode: parser.mode,
      limits: true,
      parentIsSupSub: false,
      symbol: false,
      name: funcName
    };
  },
  htmlBuilder: htmlBuilder$2,
  mathmlBuilder: mathmlBuilder$1
});
defineFunction({
  type: "op",
  names: ["\\int", "\\iint", "\\iiint", "\\oint", "\\oiint", "\\oiiint", "∫", "∬", "∭", "∮", "∯", "∰"],
  props: {
    numArgs: 0,
    allowedInArgument: true
  },
  handler(_ref5) {
    var {
      parser,
      funcName
    } = _ref5;
    var fName = funcName;
    if (fName.length === 1) {
      fName = singleCharIntegrals[fName];
    }
    return {
      type: "op",
      mode: parser.mode,
      limits: false,
      parentIsSupSub: false,
      symbol: true,
      name: fName
    };
  },
  htmlBuilder: htmlBuilder$2,
  mathmlBuilder: mathmlBuilder$1
});
var htmlBuilder$1 = (grp, options) => {
  var supGroup;
  var subGroup;
  var hasLimits = false;
  var group;
  if (grp.type === "supsub") {
    supGroup = grp.sup;
    subGroup = grp.sub;
    group = assertNodeType(grp.base, "operatorname");
    hasLimits = true;
  } else {
    group = assertNodeType(grp, "operatorname");
  }
  var base;
  if (group.body.length > 0) {
    var body = group.body.map((child2) => {
      var childText = child2.text;
      if (typeof childText === "string") {
        return {
          type: "textord",
          mode: child2.mode,
          text: childText
        };
      } else {
        return child2;
      }
    });
    var expression = buildExpression$1(body, options.withFont("mathrm"), true);
    for (var i = 0; i < expression.length; i++) {
      var child = expression[i];
      if (child instanceof SymbolNode) {
        child.text = child.text.replace(/\u2212/, "-").replace(/\u2217/, "*");
      }
    }
    base = buildCommon.makeSpan(["mop"], expression, options);
  } else {
    base = buildCommon.makeSpan(["mop"], [], options);
  }
  if (hasLimits) {
    return assembleSupSub(base, supGroup, subGroup, options, options.style, 0, 0);
  } else {
    return base;
  }
};
var mathmlBuilder2 = (group, options) => {
  var expression = buildExpression2(group.body, options.withFont("mathrm"));
  var isAllString = true;
  for (var i = 0; i < expression.length; i++) {
    var node = expression[i];
    if (node instanceof mathMLTree.SpaceNode) ;
    else if (node instanceof mathMLTree.MathNode) {
      switch (node.type) {
        case "mi":
        case "mn":
        case "ms":
        case "mspace":
        case "mtext":
          break;
        // Do nothing yet.
        case "mo": {
          var child = node.children[0];
          if (node.children.length === 1 && child instanceof mathMLTree.TextNode) {
            child.text = child.text.replace(/\u2212/, "-").replace(/\u2217/, "*");
          } else {
            isAllString = false;
          }
          break;
        }
        default:
          isAllString = false;
      }
    } else {
      isAllString = false;
    }
  }
  if (isAllString) {
    var word = expression.map((node2) => node2.toText()).join("");
    expression = [new mathMLTree.TextNode(word)];
  }
  var identifier = new mathMLTree.MathNode("mi", expression);
  identifier.setAttribute("mathvariant", "normal");
  var operator = new mathMLTree.MathNode("mo", [makeText("⁡", "text")]);
  if (group.parentIsSupSub) {
    return new mathMLTree.MathNode("mrow", [identifier, operator]);
  } else {
    return mathMLTree.newDocumentFragment([identifier, operator]);
  }
};
defineFunction({
  type: "operatorname",
  names: ["\\operatorname@", "\\operatornamewithlimits"],
  props: {
    numArgs: 1
  },
  handler: (_ref, args) => {
    var {
      parser,
      funcName
    } = _ref;
    var body = args[0];
    return {
      type: "operatorname",
      mode: parser.mode,
      body: ordargument(body),
      alwaysHandleSupSub: funcName === "\\operatornamewithlimits",
      limits: false,
      parentIsSupSub: false
    };
  },
  htmlBuilder: htmlBuilder$1,
  mathmlBuilder: mathmlBuilder2
});
defineMacro("\\operatorname", "\\@ifstar\\operatornamewithlimits\\operatorname@");
defineFunctionBuilders({
  type: "ordgroup",
  htmlBuilder(group, options) {
    if (group.semisimple) {
      return buildCommon.makeFragment(buildExpression$1(group.body, options, false));
    }
    return buildCommon.makeSpan(["mord"], buildExpression$1(group.body, options, true), options);
  },
  mathmlBuilder(group, options) {
    return buildExpressionRow(group.body, options, true);
  }
});
defineFunction({
  type: "overline",
  names: ["\\overline"],
  props: {
    numArgs: 1
  },
  handler(_ref, args) {
    var {
      parser
    } = _ref;
    var body = args[0];
    return {
      type: "overline",
      mode: parser.mode,
      body
    };
  },
  htmlBuilder(group, options) {
    var innerGroup = buildGroup$1(group.body, options.havingCrampedStyle());
    var line = buildCommon.makeLineSpan("overline-line", options);
    var defaultRuleThickness = options.fontMetrics().defaultRuleThickness;
    var vlist = buildCommon.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: innerGroup
      }, {
        type: "kern",
        size: 3 * defaultRuleThickness
      }, {
        type: "elem",
        elem: line
      }, {
        type: "kern",
        size: defaultRuleThickness
      }]
    }, options);
    return buildCommon.makeSpan(["mord", "overline"], [vlist], options);
  },
  mathmlBuilder(group, options) {
    var operator = new mathMLTree.MathNode("mo", [new mathMLTree.TextNode("‾")]);
    operator.setAttribute("stretchy", "true");
    var node = new mathMLTree.MathNode("mover", [buildGroup2(group.body, options), operator]);
    node.setAttribute("accent", "true");
    return node;
  }
});
defineFunction({
  type: "phantom",
  names: ["\\phantom"],
  props: {
    numArgs: 1,
    allowedInText: true
  },
  handler: (_ref, args) => {
    var {
      parser
    } = _ref;
    var body = args[0];
    return {
      type: "phantom",
      mode: parser.mode,
      body: ordargument(body)
    };
  },
  htmlBuilder: (group, options) => {
    var elements = buildExpression$1(group.body, options.withPhantom(), false);
    return buildCommon.makeFragment(elements);
  },
  mathmlBuilder: (group, options) => {
    var inner2 = buildExpression2(group.body, options);
    return new mathMLTree.MathNode("mphantom", inner2);
  }
});
defineFunction({
  type: "hphantom",
  names: ["\\hphantom"],
  props: {
    numArgs: 1,
    allowedInText: true
  },
  handler: (_ref2, args) => {
    var {
      parser
    } = _ref2;
    var body = args[0];
    return {
      type: "hphantom",
      mode: parser.mode,
      body
    };
  },
  htmlBuilder: (group, options) => {
    var node = buildCommon.makeSpan([], [buildGroup$1(group.body, options.withPhantom())]);
    node.height = 0;
    node.depth = 0;
    if (node.children) {
      for (var i = 0; i < node.children.length; i++) {
        node.children[i].height = 0;
        node.children[i].depth = 0;
      }
    }
    node = buildCommon.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: node
      }]
    }, options);
    return buildCommon.makeSpan(["mord"], [node], options);
  },
  mathmlBuilder: (group, options) => {
    var inner2 = buildExpression2(ordargument(group.body), options);
    var phantom = new mathMLTree.MathNode("mphantom", inner2);
    var node = new mathMLTree.MathNode("mpadded", [phantom]);
    node.setAttribute("height", "0px");
    node.setAttribute("depth", "0px");
    return node;
  }
});
defineFunction({
  type: "vphantom",
  names: ["\\vphantom"],
  props: {
    numArgs: 1,
    allowedInText: true
  },
  handler: (_ref3, args) => {
    var {
      parser
    } = _ref3;
    var body = args[0];
    return {
      type: "vphantom",
      mode: parser.mode,
      body
    };
  },
  htmlBuilder: (group, options) => {
    var inner2 = buildCommon.makeSpan(["inner"], [buildGroup$1(group.body, options.withPhantom())]);
    var fix = buildCommon.makeSpan(["fix"], []);
    return buildCommon.makeSpan(["mord", "rlap"], [inner2, fix], options);
  },
  mathmlBuilder: (group, options) => {
    var inner2 = buildExpression2(ordargument(group.body), options);
    var phantom = new mathMLTree.MathNode("mphantom", inner2);
    var node = new mathMLTree.MathNode("mpadded", [phantom]);
    node.setAttribute("width", "0px");
    return node;
  }
});
defineFunction({
  type: "raisebox",
  names: ["\\raisebox"],
  props: {
    numArgs: 2,
    argTypes: ["size", "hbox"],
    allowedInText: true
  },
  handler(_ref, args) {
    var {
      parser
    } = _ref;
    var amount = assertNodeType(args[0], "size").value;
    var body = args[1];
    return {
      type: "raisebox",
      mode: parser.mode,
      dy: amount,
      body
    };
  },
  htmlBuilder(group, options) {
    var body = buildGroup$1(group.body, options);
    var dy = calculateSize(group.dy, options);
    return buildCommon.makeVList({
      positionType: "shift",
      positionData: -dy,
      children: [{
        type: "elem",
        elem: body
      }]
    }, options);
  },
  mathmlBuilder(group, options) {
    var node = new mathMLTree.MathNode("mpadded", [buildGroup2(group.body, options)]);
    var dy = group.dy.number + group.dy.unit;
    node.setAttribute("voffset", dy);
    return node;
  }
});
defineFunction({
  type: "internal",
  names: ["\\relax"],
  props: {
    numArgs: 0,
    allowedInText: true,
    allowedInArgument: true
  },
  handler(_ref) {
    var {
      parser
    } = _ref;
    return {
      type: "internal",
      mode: parser.mode
    };
  }
});
defineFunction({
  type: "rule",
  names: ["\\rule"],
  props: {
    numArgs: 2,
    numOptionalArgs: 1,
    allowedInText: true,
    allowedInMath: true,
    argTypes: ["size", "size", "size"]
  },
  handler(_ref, args, optArgs) {
    var {
      parser
    } = _ref;
    var shift = optArgs[0];
    var width = assertNodeType(args[0], "size");
    var height = assertNodeType(args[1], "size");
    return {
      type: "rule",
      mode: parser.mode,
      shift: shift && assertNodeType(shift, "size").value,
      width: width.value,
      height: height.value
    };
  },
  htmlBuilder(group, options) {
    var rule = buildCommon.makeSpan(["mord", "rule"], [], options);
    var width = calculateSize(group.width, options);
    var height = calculateSize(group.height, options);
    var shift = group.shift ? calculateSize(group.shift, options) : 0;
    rule.style.borderRightWidth = makeEm(width);
    rule.style.borderTopWidth = makeEm(height);
    rule.style.bottom = makeEm(shift);
    rule.width = width;
    rule.height = height + shift;
    rule.depth = -shift;
    rule.maxFontSize = height * 1.125 * options.sizeMultiplier;
    return rule;
  },
  mathmlBuilder(group, options) {
    var width = calculateSize(group.width, options);
    var height = calculateSize(group.height, options);
    var shift = group.shift ? calculateSize(group.shift, options) : 0;
    var color = options.color && options.getColor() || "black";
    var rule = new mathMLTree.MathNode("mspace");
    rule.setAttribute("mathbackground", color);
    rule.setAttribute("width", makeEm(width));
    rule.setAttribute("height", makeEm(height));
    var wrapper = new mathMLTree.MathNode("mpadded", [rule]);
    if (shift >= 0) {
      wrapper.setAttribute("height", makeEm(shift));
    } else {
      wrapper.setAttribute("height", makeEm(shift));
      wrapper.setAttribute("depth", makeEm(-shift));
    }
    wrapper.setAttribute("voffset", makeEm(shift));
    return wrapper;
  }
});
function sizingGroup(value, options, baseOptions) {
  var inner2 = buildExpression$1(value, options, false);
  var multiplier = options.sizeMultiplier / baseOptions.sizeMultiplier;
  for (var i = 0; i < inner2.length; i++) {
    var pos = inner2[i].classes.indexOf("sizing");
    if (pos < 0) {
      Array.prototype.push.apply(inner2[i].classes, options.sizingClasses(baseOptions));
    } else if (inner2[i].classes[pos + 1] === "reset-size" + options.size) {
      inner2[i].classes[pos + 1] = "reset-size" + baseOptions.size;
    }
    inner2[i].height *= multiplier;
    inner2[i].depth *= multiplier;
  }
  return buildCommon.makeFragment(inner2);
}
var sizeFuncs = ["\\tiny", "\\sixptsize", "\\scriptsize", "\\footnotesize", "\\small", "\\normalsize", "\\large", "\\Large", "\\LARGE", "\\huge", "\\Huge"];
var htmlBuilder2 = (group, options) => {
  var newOptions = options.havingSize(group.size);
  return sizingGroup(group.body, newOptions, options);
};
defineFunction({
  type: "sizing",
  names: sizeFuncs,
  props: {
    numArgs: 0,
    allowedInText: true
  },
  handler: (_ref, args) => {
    var {
      breakOnTokenText,
      funcName,
      parser
    } = _ref;
    var body = parser.parseExpression(false, breakOnTokenText);
    return {
      type: "sizing",
      mode: parser.mode,
      // Figure out what size to use based on the list of functions above
      size: sizeFuncs.indexOf(funcName) + 1,
      body
    };
  },
  htmlBuilder: htmlBuilder2,
  mathmlBuilder: (group, options) => {
    var newOptions = options.havingSize(group.size);
    var inner2 = buildExpression2(group.body, newOptions);
    var node = new mathMLTree.MathNode("mstyle", inner2);
    node.setAttribute("mathsize", makeEm(newOptions.sizeMultiplier));
    return node;
  }
});
defineFunction({
  type: "smash",
  names: ["\\smash"],
  props: {
    numArgs: 1,
    numOptionalArgs: 1,
    allowedInText: true
  },
  handler: (_ref, args, optArgs) => {
    var {
      parser
    } = _ref;
    var smashHeight = false;
    var smashDepth = false;
    var tbArg = optArgs[0] && assertNodeType(optArgs[0], "ordgroup");
    if (tbArg) {
      var letter = "";
      for (var i = 0; i < tbArg.body.length; ++i) {
        var node = tbArg.body[i];
        letter = node.text;
        if (letter === "t") {
          smashHeight = true;
        } else if (letter === "b") {
          smashDepth = true;
        } else {
          smashHeight = false;
          smashDepth = false;
          break;
        }
      }
    } else {
      smashHeight = true;
      smashDepth = true;
    }
    var body = args[0];
    return {
      type: "smash",
      mode: parser.mode,
      body,
      smashHeight,
      smashDepth
    };
  },
  htmlBuilder: (group, options) => {
    var node = buildCommon.makeSpan([], [buildGroup$1(group.body, options)]);
    if (!group.smashHeight && !group.smashDepth) {
      return node;
    }
    if (group.smashHeight) {
      node.height = 0;
      if (node.children) {
        for (var i = 0; i < node.children.length; i++) {
          node.children[i].height = 0;
        }
      }
    }
    if (group.smashDepth) {
      node.depth = 0;
      if (node.children) {
        for (var _i = 0; _i < node.children.length; _i++) {
          node.children[_i].depth = 0;
        }
      }
    }
    var smashedNode = buildCommon.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: node
      }]
    }, options);
    return buildCommon.makeSpan(["mord"], [smashedNode], options);
  },
  mathmlBuilder: (group, options) => {
    var node = new mathMLTree.MathNode("mpadded", [buildGroup2(group.body, options)]);
    if (group.smashHeight) {
      node.setAttribute("height", "0px");
    }
    if (group.smashDepth) {
      node.setAttribute("depth", "0px");
    }
    return node;
  }
});
defineFunction({
  type: "sqrt",
  names: ["\\sqrt"],
  props: {
    numArgs: 1,
    numOptionalArgs: 1
  },
  handler(_ref, args, optArgs) {
    var {
      parser
    } = _ref;
    var index = optArgs[0];
    var body = args[0];
    return {
      type: "sqrt",
      mode: parser.mode,
      body,
      index
    };
  },
  htmlBuilder(group, options) {
    var inner2 = buildGroup$1(group.body, options.havingCrampedStyle());
    if (inner2.height === 0) {
      inner2.height = options.fontMetrics().xHeight;
    }
    inner2 = buildCommon.wrapFragment(inner2, options);
    var metrics = options.fontMetrics();
    var theta = metrics.defaultRuleThickness;
    var phi = theta;
    if (options.style.id < Style$1.TEXT.id) {
      phi = options.fontMetrics().xHeight;
    }
    var lineClearance = theta + phi / 4;
    var minDelimiterHeight = inner2.height + inner2.depth + lineClearance + theta;
    var {
      span: img,
      ruleWidth,
      advanceWidth
    } = delimiter.sqrtImage(minDelimiterHeight, options);
    var delimDepth = img.height - ruleWidth;
    if (delimDepth > inner2.height + inner2.depth + lineClearance) {
      lineClearance = (lineClearance + delimDepth - inner2.height - inner2.depth) / 2;
    }
    var imgShift = img.height - inner2.height - lineClearance - ruleWidth;
    inner2.style.paddingLeft = makeEm(advanceWidth);
    var body = buildCommon.makeVList({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: inner2,
        wrapperClasses: ["svg-align"]
      }, {
        type: "kern",
        size: -(inner2.height + imgShift)
      }, {
        type: "elem",
        elem: img
      }, {
        type: "kern",
        size: ruleWidth
      }]
    }, options);
    if (!group.index) {
      return buildCommon.makeSpan(["mord", "sqrt"], [body], options);
    } else {
      var newOptions = options.havingStyle(Style$1.SCRIPTSCRIPT);
      var rootm = buildGroup$1(group.index, newOptions, options);
      var toShift = 0.6 * (body.height - body.depth);
      var rootVList = buildCommon.makeVList({
        positionType: "shift",
        positionData: -toShift,
        children: [{
          type: "elem",
          elem: rootm
        }]
      }, options);
      var rootVListWrap = buildCommon.makeSpan(["root"], [rootVList]);
      return buildCommon.makeSpan(["mord", "sqrt"], [rootVListWrap, body], options);
    }
  },
  mathmlBuilder(group, options) {
    var {
      body,
      index
    } = group;
    return index ? new mathMLTree.MathNode("mroot", [buildGroup2(body, options), buildGroup2(index, options)]) : new mathMLTree.MathNode("msqrt", [buildGroup2(body, options)]);
  }
});
var styleMap = {
  "display": Style$1.DISPLAY,
  "text": Style$1.TEXT,
  "script": Style$1.SCRIPT,
  "scriptscript": Style$1.SCRIPTSCRIPT
};
defineFunction({
  type: "styling",
  names: ["\\displaystyle", "\\textstyle", "\\scriptstyle", "\\scriptscriptstyle"],
  props: {
    numArgs: 0,
    allowedInText: true,
    primitive: true
  },
  handler(_ref, args) {
    var {
      breakOnTokenText,
      funcName,
      parser
    } = _ref;
    var body = parser.parseExpression(true, breakOnTokenText);
    var style = funcName.slice(1, funcName.length - 5);
    return {
      type: "styling",
      mode: parser.mode,
      // Figure out what style to use by pulling out the style from
      // the function name
      style,
      body
    };
  },
  htmlBuilder(group, options) {
    var newStyle = styleMap[group.style];
    var newOptions = options.havingStyle(newStyle).withFont("");
    return sizingGroup(group.body, newOptions, options);
  },
  mathmlBuilder(group, options) {
    var newStyle = styleMap[group.style];
    var newOptions = options.havingStyle(newStyle);
    var inner2 = buildExpression2(group.body, newOptions);
    var node = new mathMLTree.MathNode("mstyle", inner2);
    var styleAttributes = {
      "display": ["0", "true"],
      "text": ["0", "false"],
      "script": ["1", "false"],
      "scriptscript": ["2", "false"]
    };
    var attr = styleAttributes[group.style];
    node.setAttribute("scriptlevel", attr[0]);
    node.setAttribute("displaystyle", attr[1]);
    return node;
  }
});
var htmlBuilderDelegate = function htmlBuilderDelegate2(group, options) {
  var base = group.base;
  if (!base) {
    return null;
  } else if (base.type === "op") {
    var delegate = base.limits && (options.style.size === Style$1.DISPLAY.size || base.alwaysHandleSupSub);
    return delegate ? htmlBuilder$2 : null;
  } else if (base.type === "operatorname") {
    var _delegate = base.alwaysHandleSupSub && (options.style.size === Style$1.DISPLAY.size || base.limits);
    return _delegate ? htmlBuilder$1 : null;
  } else if (base.type === "accent") {
    return utils.isCharacterBox(base.base) ? htmlBuilder$a : null;
  } else if (base.type === "horizBrace") {
    var isSup = !group.sub;
    return isSup === base.isOver ? htmlBuilder$3 : null;
  } else {
    return null;
  }
};
defineFunctionBuilders({
  type: "supsub",
  htmlBuilder(group, options) {
    var builderDelegate = htmlBuilderDelegate(group, options);
    if (builderDelegate) {
      return builderDelegate(group, options);
    }
    var {
      base: valueBase,
      sup: valueSup,
      sub: valueSub
    } = group;
    var base = buildGroup$1(valueBase, options);
    var supm;
    var subm;
    var metrics = options.fontMetrics();
    var supShift = 0;
    var subShift = 0;
    var isCharacterBox3 = valueBase && utils.isCharacterBox(valueBase);
    if (valueSup) {
      var newOptions = options.havingStyle(options.style.sup());
      supm = buildGroup$1(valueSup, newOptions, options);
      if (!isCharacterBox3) {
        supShift = base.height - newOptions.fontMetrics().supDrop * newOptions.sizeMultiplier / options.sizeMultiplier;
      }
    }
    if (valueSub) {
      var _newOptions = options.havingStyle(options.style.sub());
      subm = buildGroup$1(valueSub, _newOptions, options);
      if (!isCharacterBox3) {
        subShift = base.depth + _newOptions.fontMetrics().subDrop * _newOptions.sizeMultiplier / options.sizeMultiplier;
      }
    }
    var minSupShift;
    if (options.style === Style$1.DISPLAY) {
      minSupShift = metrics.sup1;
    } else if (options.style.cramped) {
      minSupShift = metrics.sup3;
    } else {
      minSupShift = metrics.sup2;
    }
    var multiplier = options.sizeMultiplier;
    var marginRight = makeEm(0.5 / metrics.ptPerEm / multiplier);
    var marginLeft = null;
    if (subm) {
      var isOiint = group.base && group.base.type === "op" && group.base.name && (group.base.name === "\\oiint" || group.base.name === "\\oiiint");
      if (base instanceof SymbolNode || isOiint) {
        marginLeft = makeEm(-base.italic);
      }
    }
    var supsub;
    if (supm && subm) {
      supShift = Math.max(supShift, minSupShift, supm.depth + 0.25 * metrics.xHeight);
      subShift = Math.max(subShift, metrics.sub2);
      var ruleWidth = metrics.defaultRuleThickness;
      var maxWidth = 4 * ruleWidth;
      if (supShift - supm.depth - (subm.height - subShift) < maxWidth) {
        subShift = maxWidth - (supShift - supm.depth) + subm.height;
        var psi = 0.8 * metrics.xHeight - (supShift - supm.depth);
        if (psi > 0) {
          supShift += psi;
          subShift -= psi;
        }
      }
      var vlistElem = [{
        type: "elem",
        elem: subm,
        shift: subShift,
        marginRight,
        marginLeft
      }, {
        type: "elem",
        elem: supm,
        shift: -supShift,
        marginRight
      }];
      supsub = buildCommon.makeVList({
        positionType: "individualShift",
        children: vlistElem
      }, options);
    } else if (subm) {
      subShift = Math.max(subShift, metrics.sub1, subm.height - 0.8 * metrics.xHeight);
      var _vlistElem = [{
        type: "elem",
        elem: subm,
        marginLeft,
        marginRight
      }];
      supsub = buildCommon.makeVList({
        positionType: "shift",
        positionData: subShift,
        children: _vlistElem
      }, options);
    } else if (supm) {
      supShift = Math.max(supShift, minSupShift, supm.depth + 0.25 * metrics.xHeight);
      supsub = buildCommon.makeVList({
        positionType: "shift",
        positionData: -supShift,
        children: [{
          type: "elem",
          elem: supm,
          marginRight
        }]
      }, options);
    } else {
      throw new Error("supsub must have either sup or sub.");
    }
    var mclass = getTypeOfDomTree(base, "right") || "mord";
    return buildCommon.makeSpan([mclass], [base, buildCommon.makeSpan(["msupsub"], [supsub])], options);
  },
  mathmlBuilder(group, options) {
    var isBrace = false;
    var isOver;
    var isSup;
    if (group.base && group.base.type === "horizBrace") {
      isSup = !!group.sup;
      if (isSup === group.base.isOver) {
        isBrace = true;
        isOver = group.base.isOver;
      }
    }
    if (group.base && (group.base.type === "op" || group.base.type === "operatorname")) {
      group.base.parentIsSupSub = true;
    }
    var children = [buildGroup2(group.base, options)];
    if (group.sub) {
      children.push(buildGroup2(group.sub, options));
    }
    if (group.sup) {
      children.push(buildGroup2(group.sup, options));
    }
    var nodeType;
    if (isBrace) {
      nodeType = isOver ? "mover" : "munder";
    } else if (!group.sub) {
      var base = group.base;
      if (base && base.type === "op" && base.limits && (options.style === Style$1.DISPLAY || base.alwaysHandleSupSub)) {
        nodeType = "mover";
      } else if (base && base.type === "operatorname" && base.alwaysHandleSupSub && (base.limits || options.style === Style$1.DISPLAY)) {
        nodeType = "mover";
      } else {
        nodeType = "msup";
      }
    } else if (!group.sup) {
      var _base = group.base;
      if (_base && _base.type === "op" && _base.limits && (options.style === Style$1.DISPLAY || _base.alwaysHandleSupSub)) {
        nodeType = "munder";
      } else if (_base && _base.type === "operatorname" && _base.alwaysHandleSupSub && (_base.limits || options.style === Style$1.DISPLAY)) {
        nodeType = "munder";
      } else {
        nodeType = "msub";
      }
    } else {
      var _base2 = group.base;
      if (_base2 && _base2.type === "op" && _base2.limits && options.style === Style$1.DISPLAY) {
        nodeType = "munderover";
      } else if (_base2 && _base2.type === "operatorname" && _base2.alwaysHandleSupSub && (options.style === Style$1.DISPLAY || _base2.limits)) {
        nodeType = "munderover";
      } else {
        nodeType = "msubsup";
      }
    }
    return new mathMLTree.MathNode(nodeType, children);
  }
});
defineFunctionBuilders({
  type: "atom",
  htmlBuilder(group, options) {
    return buildCommon.mathsym(group.text, group.mode, options, ["m" + group.family]);
  },
  mathmlBuilder(group, options) {
    var node = new mathMLTree.MathNode("mo", [makeText(group.text, group.mode)]);
    if (group.family === "bin") {
      var variant = getVariant(group, options);
      if (variant === "bold-italic") {
        node.setAttribute("mathvariant", variant);
      }
    } else if (group.family === "punct") {
      node.setAttribute("separator", "true");
    } else if (group.family === "open" || group.family === "close") {
      node.setAttribute("stretchy", "false");
    }
    return node;
  }
});
var defaultVariant = {
  "mi": "italic",
  "mn": "normal",
  "mtext": "normal"
};
defineFunctionBuilders({
  type: "mathord",
  htmlBuilder(group, options) {
    return buildCommon.makeOrd(group, options, "mathord");
  },
  mathmlBuilder(group, options) {
    var node = new mathMLTree.MathNode("mi", [makeText(group.text, group.mode, options)]);
    var variant = getVariant(group, options) || "italic";
    if (variant !== defaultVariant[node.type]) {
      node.setAttribute("mathvariant", variant);
    }
    return node;
  }
});
defineFunctionBuilders({
  type: "textord",
  htmlBuilder(group, options) {
    return buildCommon.makeOrd(group, options, "textord");
  },
  mathmlBuilder(group, options) {
    var text2 = makeText(group.text, group.mode, options);
    var variant = getVariant(group, options) || "normal";
    var node;
    if (group.mode === "text") {
      node = new mathMLTree.MathNode("mtext", [text2]);
    } else if (/[0-9]/.test(group.text)) {
      node = new mathMLTree.MathNode("mn", [text2]);
    } else if (group.text === "\\prime") {
      node = new mathMLTree.MathNode("mo", [text2]);
    } else {
      node = new mathMLTree.MathNode("mi", [text2]);
    }
    if (variant !== defaultVariant[node.type]) {
      node.setAttribute("mathvariant", variant);
    }
    return node;
  }
});
var cssSpace = {
  "\\nobreak": "nobreak",
  "\\allowbreak": "allowbreak"
};
var regularSpace = {
  " ": {},
  "\\ ": {},
  "~": {
    className: "nobreak"
  },
  "\\space": {},
  "\\nobreakspace": {
    className: "nobreak"
  }
};
defineFunctionBuilders({
  type: "spacing",
  htmlBuilder(group, options) {
    if (regularSpace.hasOwnProperty(group.text)) {
      var className = regularSpace[group.text].className || "";
      if (group.mode === "text") {
        var ord = buildCommon.makeOrd(group, options, "textord");
        ord.classes.push(className);
        return ord;
      } else {
        return buildCommon.makeSpan(["mspace", className], [buildCommon.mathsym(group.text, group.mode, options)], options);
      }
    } else if (cssSpace.hasOwnProperty(group.text)) {
      return buildCommon.makeSpan(["mspace", cssSpace[group.text]], [], options);
    } else {
      throw new ParseError('Unknown type of space "' + group.text + '"');
    }
  },
  mathmlBuilder(group, options) {
    var node;
    if (regularSpace.hasOwnProperty(group.text)) {
      node = new mathMLTree.MathNode("mtext", [new mathMLTree.TextNode(" ")]);
    } else if (cssSpace.hasOwnProperty(group.text)) {
      return new mathMLTree.MathNode("mspace");
    } else {
      throw new ParseError('Unknown type of space "' + group.text + '"');
    }
    return node;
  }
});
var pad = () => {
  var padNode = new mathMLTree.MathNode("mtd", []);
  padNode.setAttribute("width", "50%");
  return padNode;
};
defineFunctionBuilders({
  type: "tag",
  mathmlBuilder(group, options) {
    var table = new mathMLTree.MathNode("mtable", [new mathMLTree.MathNode("mtr", [pad(), new mathMLTree.MathNode("mtd", [buildExpressionRow(group.body, options)]), pad(), new mathMLTree.MathNode("mtd", [buildExpressionRow(group.tag, options)])])]);
    table.setAttribute("width", "100%");
    return table;
  }
});
var textFontFamilies = {
  "\\text": void 0,
  "\\textrm": "textrm",
  "\\textsf": "textsf",
  "\\texttt": "texttt",
  "\\textnormal": "textrm"
};
var textFontWeights = {
  "\\textbf": "textbf",
  "\\textmd": "textmd"
};
var textFontShapes = {
  "\\textit": "textit",
  "\\textup": "textup"
};
var optionsWithFont = (group, options) => {
  var font = group.font;
  if (!font) {
    return options;
  } else if (textFontFamilies[font]) {
    return options.withTextFontFamily(textFontFamilies[font]);
  } else if (textFontWeights[font]) {
    return options.withTextFontWeight(textFontWeights[font]);
  } else if (font === "\\emph") {
    return options.fontShape === "textit" ? options.withTextFontShape("textup") : options.withTextFontShape("textit");
  }
  return options.withTextFontShape(textFontShapes[font]);
};
defineFunction({
  type: "text",
  names: [
    // Font families
    "\\text",
    "\\textrm",
    "\\textsf",
    "\\texttt",
    "\\textnormal",
    // Font weights
    "\\textbf",
    "\\textmd",
    // Font Shapes
    "\\textit",
    "\\textup",
    "\\emph"
  ],
  props: {
    numArgs: 1,
    argTypes: ["text"],
    allowedInArgument: true,
    allowedInText: true
  },
  handler(_ref, args) {
    var {
      parser,
      funcName
    } = _ref;
    var body = args[0];
    return {
      type: "text",
      mode: parser.mode,
      body: ordargument(body),
      font: funcName
    };
  },
  htmlBuilder(group, options) {
    var newOptions = optionsWithFont(group, options);
    var inner2 = buildExpression$1(group.body, newOptions, true);
    return buildCommon.makeSpan(["mord", "text"], inner2, newOptions);
  },
  mathmlBuilder(group, options) {
    var newOptions = optionsWithFont(group, options);
    return buildExpressionRow(group.body, newOptions);
  }
});
defineFunction({
  type: "underline",
  names: ["\\underline"],
  props: {
    numArgs: 1,
    allowedInText: true
  },
  handler(_ref, args) {
    var {
      parser
    } = _ref;
    return {
      type: "underline",
      mode: parser.mode,
      body: args[0]
    };
  },
  htmlBuilder(group, options) {
    var innerGroup = buildGroup$1(group.body, options);
    var line = buildCommon.makeLineSpan("underline-line", options);
    var defaultRuleThickness = options.fontMetrics().defaultRuleThickness;
    var vlist = buildCommon.makeVList({
      positionType: "top",
      positionData: innerGroup.height,
      children: [{
        type: "kern",
        size: defaultRuleThickness
      }, {
        type: "elem",
        elem: line
      }, {
        type: "kern",
        size: 3 * defaultRuleThickness
      }, {
        type: "elem",
        elem: innerGroup
      }]
    }, options);
    return buildCommon.makeSpan(["mord", "underline"], [vlist], options);
  },
  mathmlBuilder(group, options) {
    var operator = new mathMLTree.MathNode("mo", [new mathMLTree.TextNode("‾")]);
    operator.setAttribute("stretchy", "true");
    var node = new mathMLTree.MathNode("munder", [buildGroup2(group.body, options), operator]);
    node.setAttribute("accentunder", "true");
    return node;
  }
});
defineFunction({
  type: "vcenter",
  names: ["\\vcenter"],
  props: {
    numArgs: 1,
    argTypes: ["original"],
    // In LaTeX, \vcenter can act only on a box.
    allowedInText: false
  },
  handler(_ref, args) {
    var {
      parser
    } = _ref;
    return {
      type: "vcenter",
      mode: parser.mode,
      body: args[0]
    };
  },
  htmlBuilder(group, options) {
    var body = buildGroup$1(group.body, options);
    var axisHeight = options.fontMetrics().axisHeight;
    var dy = 0.5 * (body.height - axisHeight - (body.depth + axisHeight));
    return buildCommon.makeVList({
      positionType: "shift",
      positionData: dy,
      children: [{
        type: "elem",
        elem: body
      }]
    }, options);
  },
  mathmlBuilder(group, options) {
    return new mathMLTree.MathNode("mpadded", [buildGroup2(group.body, options)], ["vcenter"]);
  }
});
defineFunction({
  type: "verb",
  names: ["\\verb"],
  props: {
    numArgs: 0,
    allowedInText: true
  },
  handler(context, args, optArgs) {
    throw new ParseError("\\verb ended by end of line instead of matching delimiter");
  },
  htmlBuilder(group, options) {
    var text2 = makeVerb(group);
    var body = [];
    var newOptions = options.havingStyle(options.style.text());
    for (var i = 0; i < text2.length; i++) {
      var c = text2[i];
      if (c === "~") {
        c = "\\textasciitilde";
      }
      body.push(buildCommon.makeSymbol(c, "Typewriter-Regular", group.mode, newOptions, ["mord", "texttt"]));
    }
    return buildCommon.makeSpan(["mord", "text"].concat(newOptions.sizingClasses(options)), buildCommon.tryCombineChars(body), newOptions);
  },
  mathmlBuilder(group, options) {
    var text2 = new mathMLTree.TextNode(makeVerb(group));
    var node = new mathMLTree.MathNode("mtext", [text2]);
    node.setAttribute("mathvariant", "monospace");
    return node;
  }
});
var makeVerb = (group) => group.body.replace(/ /g, group.star ? "␣" : " ");
var functions = _functions;
var spaceRegexString = "[ \r\n	]";
var controlWordRegexString = "\\\\[a-zA-Z@]+";
var controlSymbolRegexString = "\\\\[^\uD800-\uDFFF]";
var controlWordWhitespaceRegexString = "(" + controlWordRegexString + ")" + spaceRegexString + "*";
var controlSpaceRegexString = "\\\\(\n|[ \r	]+\n?)[ \r	]*";
var combiningDiacriticalMarkString = "[̀-ͯ]";
var combiningDiacriticalMarksEndRegex = new RegExp(combiningDiacriticalMarkString + "+$");
var tokenRegexString = "(" + spaceRegexString + "+)|" + // whitespace
(controlSpaceRegexString + "|") + // \whitespace
"([!-\\[\\]-‧‪-퟿豈-￿]" + // single codepoint
(combiningDiacriticalMarkString + "*") + // ...plus accents
"|[\uD800-\uDBFF][\uDC00-\uDFFF]" + // surrogate pair
(combiningDiacriticalMarkString + "*") + // ...plus accents
"|\\\\verb\\*([^]).*?\\4|\\\\verb([^*a-zA-Z]).*?\\5" + // \verb unstarred
("|" + controlWordWhitespaceRegexString) + // \macroName + spaces
("|" + controlSymbolRegexString + ")");
class Lexer {
  // Category codes. The lexer only supports comment characters (14) for now.
  // MacroExpander additionally distinguishes active (13).
  constructor(input, settings) {
    this.input = void 0;
    this.settings = void 0;
    this.tokenRegex = void 0;
    this.catcodes = void 0;
    this.input = input;
    this.settings = settings;
    this.tokenRegex = new RegExp(tokenRegexString, "g");
    this.catcodes = {
      "%": 14,
      // comment character
      "~": 13
      // active character
    };
  }
  setCatcode(char, code) {
    this.catcodes[char] = code;
  }
  /**
   * This function lexes a single token.
   */
  lex() {
    var input = this.input;
    var pos = this.tokenRegex.lastIndex;
    if (pos === input.length) {
      return new Token("EOF", new SourceLocation(this, pos, pos));
    }
    var match = this.tokenRegex.exec(input);
    if (match === null || match.index !== pos) {
      throw new ParseError("Unexpected character: '" + input[pos] + "'", new Token(input[pos], new SourceLocation(this, pos, pos + 1)));
    }
    var text2 = match[6] || match[3] || (match[2] ? "\\ " : " ");
    if (this.catcodes[text2] === 14) {
      var nlIndex = input.indexOf("\n", this.tokenRegex.lastIndex);
      if (nlIndex === -1) {
        this.tokenRegex.lastIndex = input.length;
        this.settings.reportNonstrict("commentAtEnd", "% comment has no terminating newline; LaTeX would fail because of commenting the end of math mode (e.g. $)");
      } else {
        this.tokenRegex.lastIndex = nlIndex + 1;
      }
      return this.lex();
    }
    return new Token(text2, new SourceLocation(this, pos, this.tokenRegex.lastIndex));
  }
}
class Namespace {
  /**
   * Both arguments are optional.  The first argument is an object of
   * built-in mappings which never change.  The second argument is an object
   * of initial (global-level) mappings, which will constantly change
   * according to any global/top-level `set`s done.
   */
  constructor(builtins, globalMacros) {
    if (builtins === void 0) {
      builtins = {};
    }
    if (globalMacros === void 0) {
      globalMacros = {};
    }
    this.current = void 0;
    this.builtins = void 0;
    this.undefStack = void 0;
    this.current = globalMacros;
    this.builtins = builtins;
    this.undefStack = [];
  }
  /**
   * Start a new nested group, affecting future local `set`s.
   */
  beginGroup() {
    this.undefStack.push({});
  }
  /**
   * End current nested group, restoring values before the group began.
   */
  endGroup() {
    if (this.undefStack.length === 0) {
      throw new ParseError("Unbalanced namespace destruction: attempt to pop global namespace; please report this as a bug");
    }
    var undefs = this.undefStack.pop();
    for (var undef in undefs) {
      if (undefs.hasOwnProperty(undef)) {
        if (undefs[undef] == null) {
          delete this.current[undef];
        } else {
          this.current[undef] = undefs[undef];
        }
      }
    }
  }
  /**
   * Ends all currently nested groups (if any), restoring values before the
   * groups began.  Useful in case of an error in the middle of parsing.
   */
  endGroups() {
    while (this.undefStack.length > 0) {
      this.endGroup();
    }
  }
  /**
   * Detect whether `name` has a definition.  Equivalent to
   * `get(name) != null`.
   */
  has(name) {
    return this.current.hasOwnProperty(name) || this.builtins.hasOwnProperty(name);
  }
  /**
   * Get the current value of a name, or `undefined` if there is no value.
   *
   * Note: Do not use `if (namespace.get(...))` to detect whether a macro
   * is defined, as the definition may be the empty string which evaluates
   * to `false` in JavaScript.  Use `if (namespace.get(...) != null)` or
   * `if (namespace.has(...))`.
   */
  get(name) {
    if (this.current.hasOwnProperty(name)) {
      return this.current[name];
    } else {
      return this.builtins[name];
    }
  }
  /**
   * Set the current value of a name, and optionally set it globally too.
   * Local set() sets the current value and (when appropriate) adds an undo
   * operation to the undo stack.  Global set() may change the undo
   * operation at every level, so takes time linear in their number.
   * A value of undefined means to delete existing definitions.
   */
  set(name, value, global) {
    if (global === void 0) {
      global = false;
    }
    if (global) {
      for (var i = 0; i < this.undefStack.length; i++) {
        delete this.undefStack[i][name];
      }
      if (this.undefStack.length > 0) {
        this.undefStack[this.undefStack.length - 1][name] = value;
      }
    } else {
      var top = this.undefStack[this.undefStack.length - 1];
      if (top && !top.hasOwnProperty(name)) {
        top[name] = this.current[name];
      }
    }
    if (value == null) {
      delete this.current[name];
    } else {
      this.current[name] = value;
    }
  }
}
var macros = _macros;
defineMacro("\\noexpand", function(context) {
  var t2 = context.popToken();
  if (context.isExpandable(t2.text)) {
    t2.noexpand = true;
    t2.treatAsRelax = true;
  }
  return {
    tokens: [t2],
    numArgs: 0
  };
});
defineMacro("\\expandafter", function(context) {
  var t2 = context.popToken();
  context.expandOnce(true);
  return {
    tokens: [t2],
    numArgs: 0
  };
});
defineMacro("\\@firstoftwo", function(context) {
  var args = context.consumeArgs(2);
  return {
    tokens: args[0],
    numArgs: 0
  };
});
defineMacro("\\@secondoftwo", function(context) {
  var args = context.consumeArgs(2);
  return {
    tokens: args[1],
    numArgs: 0
  };
});
defineMacro("\\@ifnextchar", function(context) {
  var args = context.consumeArgs(3);
  context.consumeSpaces();
  var nextToken = context.future();
  if (args[0].length === 1 && args[0][0].text === nextToken.text) {
    return {
      tokens: args[1],
      numArgs: 0
    };
  } else {
    return {
      tokens: args[2],
      numArgs: 0
    };
  }
});
defineMacro("\\@ifstar", "\\@ifnextchar *{\\@firstoftwo{#1}}");
defineMacro("\\TextOrMath", function(context) {
  var args = context.consumeArgs(2);
  if (context.mode === "text") {
    return {
      tokens: args[0],
      numArgs: 0
    };
  } else {
    return {
      tokens: args[1],
      numArgs: 0
    };
  }
});
var digitToNumber = {
  "0": 0,
  "1": 1,
  "2": 2,
  "3": 3,
  "4": 4,
  "5": 5,
  "6": 6,
  "7": 7,
  "8": 8,
  "9": 9,
  "a": 10,
  "A": 10,
  "b": 11,
  "B": 11,
  "c": 12,
  "C": 12,
  "d": 13,
  "D": 13,
  "e": 14,
  "E": 14,
  "f": 15,
  "F": 15
};
defineMacro("\\char", function(context) {
  var token = context.popToken();
  var base;
  var number = "";
  if (token.text === "'") {
    base = 8;
    token = context.popToken();
  } else if (token.text === '"') {
    base = 16;
    token = context.popToken();
  } else if (token.text === "`") {
    token = context.popToken();
    if (token.text[0] === "\\") {
      number = token.text.charCodeAt(1);
    } else if (token.text === "EOF") {
      throw new ParseError("\\char` missing argument");
    } else {
      number = token.text.charCodeAt(0);
    }
  } else {
    base = 10;
  }
  if (base) {
    number = digitToNumber[token.text];
    if (number == null || number >= base) {
      throw new ParseError("Invalid base-" + base + " digit " + token.text);
    }
    var digit;
    while ((digit = digitToNumber[context.future().text]) != null && digit < base) {
      number *= base;
      number += digit;
      context.popToken();
    }
  }
  return "\\@char{" + number + "}";
});
var newcommand = (context, existsOK, nonexistsOK, skipIfExists) => {
  var arg = context.consumeArg().tokens;
  if (arg.length !== 1) {
    throw new ParseError("\\newcommand's first argument must be a macro name");
  }
  var name = arg[0].text;
  var exists = context.isDefined(name);
  if (exists && !existsOK) {
    throw new ParseError("\\newcommand{" + name + "} attempting to redefine " + (name + "; use \\renewcommand"));
  }
  if (!exists && !nonexistsOK) {
    throw new ParseError("\\renewcommand{" + name + "} when command " + name + " does not yet exist; use \\newcommand");
  }
  var numArgs = 0;
  arg = context.consumeArg().tokens;
  if (arg.length === 1 && arg[0].text === "[") {
    var argText = "";
    var token = context.expandNextToken();
    while (token.text !== "]" && token.text !== "EOF") {
      argText += token.text;
      token = context.expandNextToken();
    }
    if (!argText.match(/^\s*[0-9]+\s*$/)) {
      throw new ParseError("Invalid number of arguments: " + argText);
    }
    numArgs = parseInt(argText);
    arg = context.consumeArg().tokens;
  }
  if (!(exists && skipIfExists)) {
    context.macros.set(name, {
      tokens: arg,
      numArgs
    });
  }
  return "";
};
defineMacro("\\newcommand", (context) => newcommand(context, false, true, false));
defineMacro("\\renewcommand", (context) => newcommand(context, true, false, false));
defineMacro("\\providecommand", (context) => newcommand(context, true, true, true));
defineMacro("\\message", (context) => {
  var arg = context.consumeArgs(1)[0];
  console.log(arg.reverse().map((token) => token.text).join(""));
  return "";
});
defineMacro("\\errmessage", (context) => {
  var arg = context.consumeArgs(1)[0];
  console.error(arg.reverse().map((token) => token.text).join(""));
  return "";
});
defineMacro("\\show", (context) => {
  var tok = context.popToken();
  var name = tok.text;
  console.log(tok, context.macros.get(name), functions[name], symbols.math[name], symbols.text[name]);
  return "";
});
defineMacro("\\bgroup", "{");
defineMacro("\\egroup", "}");
defineMacro("~", "\\nobreakspace");
defineMacro("\\lq", "`");
defineMacro("\\rq", "'");
defineMacro("\\aa", "\\r a");
defineMacro("\\AA", "\\r A");
defineMacro("\\textcopyright", "\\html@mathml{\\textcircled{c}}{\\char`©}");
defineMacro("\\copyright", "\\TextOrMath{\\textcopyright}{\\text{\\textcopyright}}");
defineMacro("\\textregistered", "\\html@mathml{\\textcircled{\\scriptsize R}}{\\char`®}");
defineMacro("ℬ", "\\mathscr{B}");
defineMacro("ℰ", "\\mathscr{E}");
defineMacro("ℱ", "\\mathscr{F}");
defineMacro("ℋ", "\\mathscr{H}");
defineMacro("ℐ", "\\mathscr{I}");
defineMacro("ℒ", "\\mathscr{L}");
defineMacro("ℳ", "\\mathscr{M}");
defineMacro("ℛ", "\\mathscr{R}");
defineMacro("ℭ", "\\mathfrak{C}");
defineMacro("ℌ", "\\mathfrak{H}");
defineMacro("ℨ", "\\mathfrak{Z}");
defineMacro("\\Bbbk", "\\Bbb{k}");
defineMacro("·", "\\cdotp");
defineMacro("\\llap", "\\mathllap{\\textrm{#1}}");
defineMacro("\\rlap", "\\mathrlap{\\textrm{#1}}");
defineMacro("\\clap", "\\mathclap{\\textrm{#1}}");
defineMacro("\\mathstrut", "\\vphantom{(}");
defineMacro("\\underbar", "\\underline{\\text{#1}}");
defineMacro("\\not", '\\html@mathml{\\mathrel{\\mathrlap\\@not}}{\\char"338}');
defineMacro("\\neq", "\\html@mathml{\\mathrel{\\not=}}{\\mathrel{\\char`≠}}");
defineMacro("\\ne", "\\neq");
defineMacro("≠", "\\neq");
defineMacro("\\notin", "\\html@mathml{\\mathrel{{\\in}\\mathllap{/\\mskip1mu}}}{\\mathrel{\\char`∉}}");
defineMacro("∉", "\\notin");
defineMacro("≘", "\\html@mathml{\\mathrel{=\\kern{-1em}\\raisebox{0.4em}{$\\scriptsize\\frown$}}}{\\mathrel{\\char`≘}}");
defineMacro("≙", "\\html@mathml{\\stackrel{\\tiny\\wedge}{=}}{\\mathrel{\\char`≘}}");
defineMacro("≚", "\\html@mathml{\\stackrel{\\tiny\\vee}{=}}{\\mathrel{\\char`≚}}");
defineMacro("≛", "\\html@mathml{\\stackrel{\\scriptsize\\star}{=}}{\\mathrel{\\char`≛}}");
defineMacro("≝", "\\html@mathml{\\stackrel{\\tiny\\mathrm{def}}{=}}{\\mathrel{\\char`≝}}");
defineMacro("≞", "\\html@mathml{\\stackrel{\\tiny\\mathrm{m}}{=}}{\\mathrel{\\char`≞}}");
defineMacro("≟", "\\html@mathml{\\stackrel{\\tiny?}{=}}{\\mathrel{\\char`≟}}");
defineMacro("⟂", "\\perp");
defineMacro("‼", "\\mathclose{!\\mkern-0.8mu!}");
defineMacro("∌", "\\notni");
defineMacro("⌜", "\\ulcorner");
defineMacro("⌝", "\\urcorner");
defineMacro("⌞", "\\llcorner");
defineMacro("⌟", "\\lrcorner");
defineMacro("©", "\\copyright");
defineMacro("®", "\\textregistered");
defineMacro("️", "\\textregistered");
defineMacro("\\ulcorner", '\\html@mathml{\\@ulcorner}{\\mathop{\\char"231c}}');
defineMacro("\\urcorner", '\\html@mathml{\\@urcorner}{\\mathop{\\char"231d}}');
defineMacro("\\llcorner", '\\html@mathml{\\@llcorner}{\\mathop{\\char"231e}}');
defineMacro("\\lrcorner", '\\html@mathml{\\@lrcorner}{\\mathop{\\char"231f}}');
defineMacro("\\vdots", "{\\varvdots\\rule{0pt}{15pt}}");
defineMacro("⋮", "\\vdots");
defineMacro("\\varGamma", "\\mathit{\\Gamma}");
defineMacro("\\varDelta", "\\mathit{\\Delta}");
defineMacro("\\varTheta", "\\mathit{\\Theta}");
defineMacro("\\varLambda", "\\mathit{\\Lambda}");
defineMacro("\\varXi", "\\mathit{\\Xi}");
defineMacro("\\varPi", "\\mathit{\\Pi}");
defineMacro("\\varSigma", "\\mathit{\\Sigma}");
defineMacro("\\varUpsilon", "\\mathit{\\Upsilon}");
defineMacro("\\varPhi", "\\mathit{\\Phi}");
defineMacro("\\varPsi", "\\mathit{\\Psi}");
defineMacro("\\varOmega", "\\mathit{\\Omega}");
defineMacro("\\substack", "\\begin{subarray}{c}#1\\end{subarray}");
defineMacro("\\colon", "\\nobreak\\mskip2mu\\mathpunct{}\\mathchoice{\\mkern-3mu}{\\mkern-3mu}{}{}{:}\\mskip6mu\\relax");
defineMacro("\\boxed", "\\fbox{$\\displaystyle{#1}$}");
defineMacro("\\iff", "\\DOTSB\\;\\Longleftrightarrow\\;");
defineMacro("\\implies", "\\DOTSB\\;\\Longrightarrow\\;");
defineMacro("\\impliedby", "\\DOTSB\\;\\Longleftarrow\\;");
defineMacro("\\dddot", "{\\overset{\\raisebox{-0.1ex}{\\normalsize ...}}{#1}}");
defineMacro("\\ddddot", "{\\overset{\\raisebox{-0.1ex}{\\normalsize ....}}{#1}}");
var dotsByToken = {
  ",": "\\dotsc",
  "\\not": "\\dotsb",
  // \keybin@ checks for the following:
  "+": "\\dotsb",
  "=": "\\dotsb",
  "<": "\\dotsb",
  ">": "\\dotsb",
  "-": "\\dotsb",
  "*": "\\dotsb",
  ":": "\\dotsb",
  // Symbols whose definition starts with \DOTSB:
  "\\DOTSB": "\\dotsb",
  "\\coprod": "\\dotsb",
  "\\bigvee": "\\dotsb",
  "\\bigwedge": "\\dotsb",
  "\\biguplus": "\\dotsb",
  "\\bigcap": "\\dotsb",
  "\\bigcup": "\\dotsb",
  "\\prod": "\\dotsb",
  "\\sum": "\\dotsb",
  "\\bigotimes": "\\dotsb",
  "\\bigoplus": "\\dotsb",
  "\\bigodot": "\\dotsb",
  "\\bigsqcup": "\\dotsb",
  "\\And": "\\dotsb",
  "\\longrightarrow": "\\dotsb",
  "\\Longrightarrow": "\\dotsb",
  "\\longleftarrow": "\\dotsb",
  "\\Longleftarrow": "\\dotsb",
  "\\longleftrightarrow": "\\dotsb",
  "\\Longleftrightarrow": "\\dotsb",
  "\\mapsto": "\\dotsb",
  "\\longmapsto": "\\dotsb",
  "\\hookrightarrow": "\\dotsb",
  "\\doteq": "\\dotsb",
  // Symbols whose definition starts with \mathbin:
  "\\mathbin": "\\dotsb",
  // Symbols whose definition starts with \mathrel:
  "\\mathrel": "\\dotsb",
  "\\relbar": "\\dotsb",
  "\\Relbar": "\\dotsb",
  "\\xrightarrow": "\\dotsb",
  "\\xleftarrow": "\\dotsb",
  // Symbols whose definition starts with \DOTSI:
  "\\DOTSI": "\\dotsi",
  "\\int": "\\dotsi",
  "\\oint": "\\dotsi",
  "\\iint": "\\dotsi",
  "\\iiint": "\\dotsi",
  "\\iiiint": "\\dotsi",
  "\\idotsint": "\\dotsi",
  // Symbols whose definition starts with \DOTSX:
  "\\DOTSX": "\\dotsx"
};
defineMacro("\\dots", function(context) {
  var thedots = "\\dotso";
  var next = context.expandAfterFuture().text;
  if (next in dotsByToken) {
    thedots = dotsByToken[next];
  } else if (next.slice(0, 4) === "\\not") {
    thedots = "\\dotsb";
  } else if (next in symbols.math) {
    if (["bin", "rel"].includes(symbols.math[next].group)) {
      thedots = "\\dotsb";
    }
  }
  return thedots;
});
var spaceAfterDots = {
  // \rightdelim@ checks for the following:
  ")": true,
  "]": true,
  "\\rbrack": true,
  "\\}": true,
  "\\rbrace": true,
  "\\rangle": true,
  "\\rceil": true,
  "\\rfloor": true,
  "\\rgroup": true,
  "\\rmoustache": true,
  "\\right": true,
  "\\bigr": true,
  "\\biggr": true,
  "\\Bigr": true,
  "\\Biggr": true,
  // \extra@ also tests for the following:
  "$": true,
  // \extrap@ checks for the following:
  ";": true,
  ".": true,
  ",": true
};
defineMacro("\\dotso", function(context) {
  var next = context.future().text;
  if (next in spaceAfterDots) {
    return "\\ldots\\,";
  } else {
    return "\\ldots";
  }
});
defineMacro("\\dotsc", function(context) {
  var next = context.future().text;
  if (next in spaceAfterDots && next !== ",") {
    return "\\ldots\\,";
  } else {
    return "\\ldots";
  }
});
defineMacro("\\cdots", function(context) {
  var next = context.future().text;
  if (next in spaceAfterDots) {
    return "\\@cdots\\,";
  } else {
    return "\\@cdots";
  }
});
defineMacro("\\dotsb", "\\cdots");
defineMacro("\\dotsm", "\\cdots");
defineMacro("\\dotsi", "\\!\\cdots");
defineMacro("\\dotsx", "\\ldots\\,");
defineMacro("\\DOTSI", "\\relax");
defineMacro("\\DOTSB", "\\relax");
defineMacro("\\DOTSX", "\\relax");
defineMacro("\\tmspace", "\\TextOrMath{\\kern#1#3}{\\mskip#1#2}\\relax");
defineMacro("\\,", "\\tmspace+{3mu}{.1667em}");
defineMacro("\\thinspace", "\\,");
defineMacro("\\>", "\\mskip{4mu}");
defineMacro("\\:", "\\tmspace+{4mu}{.2222em}");
defineMacro("\\medspace", "\\:");
defineMacro("\\;", "\\tmspace+{5mu}{.2777em}");
defineMacro("\\thickspace", "\\;");
defineMacro("\\!", "\\tmspace-{3mu}{.1667em}");
defineMacro("\\negthinspace", "\\!");
defineMacro("\\negmedspace", "\\tmspace-{4mu}{.2222em}");
defineMacro("\\negthickspace", "\\tmspace-{5mu}{.277em}");
defineMacro("\\enspace", "\\kern.5em ");
defineMacro("\\enskip", "\\hskip.5em\\relax");
defineMacro("\\quad", "\\hskip1em\\relax");
defineMacro("\\qquad", "\\hskip2em\\relax");
defineMacro("\\tag", "\\@ifstar\\tag@literal\\tag@paren");
defineMacro("\\tag@paren", "\\tag@literal{({#1})}");
defineMacro("\\tag@literal", (context) => {
  if (context.macros.get("\\df@tag")) {
    throw new ParseError("Multiple \\tag");
  }
  return "\\gdef\\df@tag{\\text{#1}}";
});
defineMacro("\\bmod", "\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}\\mathbin{\\rm mod}\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}");
defineMacro("\\pod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern8mu}{\\mkern8mu}{\\mkern8mu}(#1)");
defineMacro("\\pmod", "\\pod{{\\rm mod}\\mkern6mu#1}");
defineMacro("\\mod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern12mu}{\\mkern12mu}{\\mkern12mu}{\\rm mod}\\,\\,#1");
defineMacro("\\newline", "\\\\\\relax");
defineMacro("\\TeX", "\\textrm{\\html@mathml{T\\kern-.1667em\\raisebox{-.5ex}{E}\\kern-.125emX}{TeX}}");
var latexRaiseA = makeEm(fontMetricsData["Main-Regular"]["T".charCodeAt(0)][1] - 0.7 * fontMetricsData["Main-Regular"]["A".charCodeAt(0)][1]);
defineMacro("\\LaTeX", "\\textrm{\\html@mathml{" + ("L\\kern-.36em\\raisebox{" + latexRaiseA + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{LaTeX}}");
defineMacro("\\KaTeX", "\\textrm{\\html@mathml{" + ("K\\kern-.17em\\raisebox{" + latexRaiseA + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{KaTeX}}");
defineMacro("\\hspace", "\\@ifstar\\@hspacer\\@hspace");
defineMacro("\\@hspace", "\\hskip #1\\relax");
defineMacro("\\@hspacer", "\\rule{0pt}{0pt}\\hskip #1\\relax");
defineMacro("\\ordinarycolon", ":");
defineMacro("\\vcentcolon", "\\mathrel{\\mathop\\ordinarycolon}");
defineMacro("\\dblcolon", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-.9mu}\\vcentcolon}}{\\mathop{\\char"2237}}');
defineMacro("\\coloneqq", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char"2254}}');
defineMacro("\\Coloneqq", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char"2237\\char"3d}}');
defineMacro("\\coloneq", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char"3a\\char"2212}}');
defineMacro("\\Coloneq", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char"2237\\char"2212}}');
defineMacro("\\eqqcolon", '\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char"2255}}');
defineMacro("\\Eqqcolon", '\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char"3d\\char"2237}}');
defineMacro("\\eqcolon", '\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char"2239}}');
defineMacro("\\Eqcolon", '\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char"2212\\char"2237}}');
defineMacro("\\colonapprox", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char"3a\\char"2248}}');
defineMacro("\\Colonapprox", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char"2237\\char"2248}}');
defineMacro("\\colonsim", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char"3a\\char"223c}}');
defineMacro("\\Colonsim", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char"2237\\char"223c}}');
defineMacro("∷", "\\dblcolon");
defineMacro("∹", "\\eqcolon");
defineMacro("≔", "\\coloneqq");
defineMacro("≕", "\\eqqcolon");
defineMacro("⩴", "\\Coloneqq");
defineMacro("\\ratio", "\\vcentcolon");
defineMacro("\\coloncolon", "\\dblcolon");
defineMacro("\\colonequals", "\\coloneqq");
defineMacro("\\coloncolonequals", "\\Coloneqq");
defineMacro("\\equalscolon", "\\eqqcolon");
defineMacro("\\equalscoloncolon", "\\Eqqcolon");
defineMacro("\\colonminus", "\\coloneq");
defineMacro("\\coloncolonminus", "\\Coloneq");
defineMacro("\\minuscolon", "\\eqcolon");
defineMacro("\\minuscoloncolon", "\\Eqcolon");
defineMacro("\\coloncolonapprox", "\\Colonapprox");
defineMacro("\\coloncolonsim", "\\Colonsim");
defineMacro("\\simcolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\vcentcolon}");
defineMacro("\\simcoloncolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\dblcolon}");
defineMacro("\\approxcolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\vcentcolon}");
defineMacro("\\approxcoloncolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\dblcolon}");
defineMacro("\\notni", "\\html@mathml{\\not\\ni}{\\mathrel{\\char`∌}}");
defineMacro("\\limsup", "\\DOTSB\\operatorname*{lim\\,sup}");
defineMacro("\\liminf", "\\DOTSB\\operatorname*{lim\\,inf}");
defineMacro("\\injlim", "\\DOTSB\\operatorname*{inj\\,lim}");
defineMacro("\\projlim", "\\DOTSB\\operatorname*{proj\\,lim}");
defineMacro("\\varlimsup", "\\DOTSB\\operatorname*{\\overline{lim}}");
defineMacro("\\varliminf", "\\DOTSB\\operatorname*{\\underline{lim}}");
defineMacro("\\varinjlim", "\\DOTSB\\operatorname*{\\underrightarrow{lim}}");
defineMacro("\\varprojlim", "\\DOTSB\\operatorname*{\\underleftarrow{lim}}");
defineMacro("\\gvertneqq", "\\html@mathml{\\@gvertneqq}{≩}");
defineMacro("\\lvertneqq", "\\html@mathml{\\@lvertneqq}{≨}");
defineMacro("\\ngeqq", "\\html@mathml{\\@ngeqq}{≱}");
defineMacro("\\ngeqslant", "\\html@mathml{\\@ngeqslant}{≱}");
defineMacro("\\nleqq", "\\html@mathml{\\@nleqq}{≰}");
defineMacro("\\nleqslant", "\\html@mathml{\\@nleqslant}{≰}");
defineMacro("\\nshortmid", "\\html@mathml{\\@nshortmid}{∤}");
defineMacro("\\nshortparallel", "\\html@mathml{\\@nshortparallel}{∦}");
defineMacro("\\nsubseteqq", "\\html@mathml{\\@nsubseteqq}{⊈}");
defineMacro("\\nsupseteqq", "\\html@mathml{\\@nsupseteqq}{⊉}");
defineMacro("\\varsubsetneq", "\\html@mathml{\\@varsubsetneq}{⊊}");
defineMacro("\\varsubsetneqq", "\\html@mathml{\\@varsubsetneqq}{⫋}");
defineMacro("\\varsupsetneq", "\\html@mathml{\\@varsupsetneq}{⊋}");
defineMacro("\\varsupsetneqq", "\\html@mathml{\\@varsupsetneqq}{⫌}");
defineMacro("\\imath", "\\html@mathml{\\@imath}{ı}");
defineMacro("\\jmath", "\\html@mathml{\\@jmath}{ȷ}");
defineMacro("\\llbracket", "\\html@mathml{\\mathopen{[\\mkern-3.2mu[}}{\\mathopen{\\char`⟦}}");
defineMacro("\\rrbracket", "\\html@mathml{\\mathclose{]\\mkern-3.2mu]}}{\\mathclose{\\char`⟧}}");
defineMacro("⟦", "\\llbracket");
defineMacro("⟧", "\\rrbracket");
defineMacro("\\lBrace", "\\html@mathml{\\mathopen{\\{\\mkern-3.2mu[}}{\\mathopen{\\char`⦃}}");
defineMacro("\\rBrace", "\\html@mathml{\\mathclose{]\\mkern-3.2mu\\}}}{\\mathclose{\\char`⦄}}");
defineMacro("⦃", "\\lBrace");
defineMacro("⦄", "\\rBrace");
defineMacro("\\minuso", "\\mathbin{\\html@mathml{{\\mathrlap{\\mathchoice{\\kern{0.145em}}{\\kern{0.145em}}{\\kern{0.1015em}}{\\kern{0.0725em}}\\circ}{-}}}{\\char`⦵}}");
defineMacro("⦵", "\\minuso");
defineMacro("\\darr", "\\downarrow");
defineMacro("\\dArr", "\\Downarrow");
defineMacro("\\Darr", "\\Downarrow");
defineMacro("\\lang", "\\langle");
defineMacro("\\rang", "\\rangle");
defineMacro("\\uarr", "\\uparrow");
defineMacro("\\uArr", "\\Uparrow");
defineMacro("\\Uarr", "\\Uparrow");
defineMacro("\\N", "\\mathbb{N}");
defineMacro("\\R", "\\mathbb{R}");
defineMacro("\\Z", "\\mathbb{Z}");
defineMacro("\\alef", "\\aleph");
defineMacro("\\alefsym", "\\aleph");
defineMacro("\\Alpha", "\\mathrm{A}");
defineMacro("\\Beta", "\\mathrm{B}");
defineMacro("\\bull", "\\bullet");
defineMacro("\\Chi", "\\mathrm{X}");
defineMacro("\\clubs", "\\clubsuit");
defineMacro("\\cnums", "\\mathbb{C}");
defineMacro("\\Complex", "\\mathbb{C}");
defineMacro("\\Dagger", "\\ddagger");
defineMacro("\\diamonds", "\\diamondsuit");
defineMacro("\\empty", "\\emptyset");
defineMacro("\\Epsilon", "\\mathrm{E}");
defineMacro("\\Eta", "\\mathrm{H}");
defineMacro("\\exist", "\\exists");
defineMacro("\\harr", "\\leftrightarrow");
defineMacro("\\hArr", "\\Leftrightarrow");
defineMacro("\\Harr", "\\Leftrightarrow");
defineMacro("\\hearts", "\\heartsuit");
defineMacro("\\image", "\\Im");
defineMacro("\\infin", "\\infty");
defineMacro("\\Iota", "\\mathrm{I}");
defineMacro("\\isin", "\\in");
defineMacro("\\Kappa", "\\mathrm{K}");
defineMacro("\\larr", "\\leftarrow");
defineMacro("\\lArr", "\\Leftarrow");
defineMacro("\\Larr", "\\Leftarrow");
defineMacro("\\lrarr", "\\leftrightarrow");
defineMacro("\\lrArr", "\\Leftrightarrow");
defineMacro("\\Lrarr", "\\Leftrightarrow");
defineMacro("\\Mu", "\\mathrm{M}");
defineMacro("\\natnums", "\\mathbb{N}");
defineMacro("\\Nu", "\\mathrm{N}");
defineMacro("\\Omicron", "\\mathrm{O}");
defineMacro("\\plusmn", "\\pm");
defineMacro("\\rarr", "\\rightarrow");
defineMacro("\\rArr", "\\Rightarrow");
defineMacro("\\Rarr", "\\Rightarrow");
defineMacro("\\real", "\\Re");
defineMacro("\\reals", "\\mathbb{R}");
defineMacro("\\Reals", "\\mathbb{R}");
defineMacro("\\Rho", "\\mathrm{P}");
defineMacro("\\sdot", "\\cdot");
defineMacro("\\sect", "\\S");
defineMacro("\\spades", "\\spadesuit");
defineMacro("\\sub", "\\subset");
defineMacro("\\sube", "\\subseteq");
defineMacro("\\supe", "\\supseteq");
defineMacro("\\Tau", "\\mathrm{T}");
defineMacro("\\thetasym", "\\vartheta");
defineMacro("\\weierp", "\\wp");
defineMacro("\\Zeta", "\\mathrm{Z}");
defineMacro("\\argmin", "\\DOTSB\\operatorname*{arg\\,min}");
defineMacro("\\argmax", "\\DOTSB\\operatorname*{arg\\,max}");
defineMacro("\\plim", "\\DOTSB\\mathop{\\operatorname{plim}}\\limits");
defineMacro("\\bra", "\\mathinner{\\langle{#1}|}");
defineMacro("\\ket", "\\mathinner{|{#1}\\rangle}");
defineMacro("\\braket", "\\mathinner{\\langle{#1}\\rangle}");
defineMacro("\\Bra", "\\left\\langle#1\\right|");
defineMacro("\\Ket", "\\left|#1\\right\\rangle");
var braketHelper = (one) => (context) => {
  var left = context.consumeArg().tokens;
  var middle = context.consumeArg().tokens;
  var middleDouble = context.consumeArg().tokens;
  var right = context.consumeArg().tokens;
  var oldMiddle = context.macros.get("|");
  var oldMiddleDouble = context.macros.get("\\|");
  context.macros.beginGroup();
  var midMacro = (double) => (context2) => {
    if (one) {
      context2.macros.set("|", oldMiddle);
      if (middleDouble.length) {
        context2.macros.set("\\|", oldMiddleDouble);
      }
    }
    var doubled = double;
    if (!double && middleDouble.length) {
      var nextToken = context2.future();
      if (nextToken.text === "|") {
        context2.popToken();
        doubled = true;
      }
    }
    return {
      tokens: doubled ? middleDouble : middle,
      numArgs: 0
    };
  };
  context.macros.set("|", midMacro(false));
  if (middleDouble.length) {
    context.macros.set("\\|", midMacro(true));
  }
  var arg = context.consumeArg().tokens;
  var expanded = context.expandTokens([
    ...right,
    ...arg,
    ...left
    // reversed
  ]);
  context.macros.endGroup();
  return {
    tokens: expanded.reverse(),
    numArgs: 0
  };
};
defineMacro("\\bra@ket", braketHelper(false));
defineMacro("\\bra@set", braketHelper(true));
defineMacro("\\Braket", "\\bra@ket{\\left\\langle}{\\,\\middle\\vert\\,}{\\,\\middle\\vert\\,}{\\right\\rangle}");
defineMacro("\\Set", "\\bra@set{\\left\\{\\:}{\\;\\middle\\vert\\;}{\\;\\middle\\Vert\\;}{\\:\\right\\}}");
defineMacro("\\set", "\\bra@set{\\{\\,}{\\mid}{}{\\,\\}}");
defineMacro("\\angln", "{\\angl n}");
defineMacro("\\blue", "\\textcolor{##6495ed}{#1}");
defineMacro("\\orange", "\\textcolor{##ffa500}{#1}");
defineMacro("\\pink", "\\textcolor{##ff00af}{#1}");
defineMacro("\\red", "\\textcolor{##df0030}{#1}");
defineMacro("\\green", "\\textcolor{##28ae7b}{#1}");
defineMacro("\\gray", "\\textcolor{gray}{#1}");
defineMacro("\\purple", "\\textcolor{##9d38bd}{#1}");
defineMacro("\\blueA", "\\textcolor{##ccfaff}{#1}");
defineMacro("\\blueB", "\\textcolor{##80f6ff}{#1}");
defineMacro("\\blueC", "\\textcolor{##63d9ea}{#1}");
defineMacro("\\blueD", "\\textcolor{##11accd}{#1}");
defineMacro("\\blueE", "\\textcolor{##0c7f99}{#1}");
defineMacro("\\tealA", "\\textcolor{##94fff5}{#1}");
defineMacro("\\tealB", "\\textcolor{##26edd5}{#1}");
defineMacro("\\tealC", "\\textcolor{##01d1c1}{#1}");
defineMacro("\\tealD", "\\textcolor{##01a995}{#1}");
defineMacro("\\tealE", "\\textcolor{##208170}{#1}");
defineMacro("\\greenA", "\\textcolor{##b6ffb0}{#1}");
defineMacro("\\greenB", "\\textcolor{##8af281}{#1}");
defineMacro("\\greenC", "\\textcolor{##74cf70}{#1}");
defineMacro("\\greenD", "\\textcolor{##1fab54}{#1}");
defineMacro("\\greenE", "\\textcolor{##0d923f}{#1}");
defineMacro("\\goldA", "\\textcolor{##ffd0a9}{#1}");
defineMacro("\\goldB", "\\textcolor{##ffbb71}{#1}");
defineMacro("\\goldC", "\\textcolor{##ff9c39}{#1}");
defineMacro("\\goldD", "\\textcolor{##e07d10}{#1}");
defineMacro("\\goldE", "\\textcolor{##a75a05}{#1}");
defineMacro("\\redA", "\\textcolor{##fca9a9}{#1}");
defineMacro("\\redB", "\\textcolor{##ff8482}{#1}");
defineMacro("\\redC", "\\textcolor{##f9685d}{#1}");
defineMacro("\\redD", "\\textcolor{##e84d39}{#1}");
defineMacro("\\redE", "\\textcolor{##bc2612}{#1}");
defineMacro("\\maroonA", "\\textcolor{##ffbde0}{#1}");
defineMacro("\\maroonB", "\\textcolor{##ff92c6}{#1}");
defineMacro("\\maroonC", "\\textcolor{##ed5fa6}{#1}");
defineMacro("\\maroonD", "\\textcolor{##ca337c}{#1}");
defineMacro("\\maroonE", "\\textcolor{##9e034e}{#1}");
defineMacro("\\purpleA", "\\textcolor{##ddd7ff}{#1}");
defineMacro("\\purpleB", "\\textcolor{##c6b9fc}{#1}");
defineMacro("\\purpleC", "\\textcolor{##aa87ff}{#1}");
defineMacro("\\purpleD", "\\textcolor{##7854ab}{#1}");
defineMacro("\\purpleE", "\\textcolor{##543b78}{#1}");
defineMacro("\\mintA", "\\textcolor{##f5f9e8}{#1}");
defineMacro("\\mintB", "\\textcolor{##edf2df}{#1}");
defineMacro("\\mintC", "\\textcolor{##e0e5cc}{#1}");
defineMacro("\\grayA", "\\textcolor{##f6f7f7}{#1}");
defineMacro("\\grayB", "\\textcolor{##f0f1f2}{#1}");
defineMacro("\\grayC", "\\textcolor{##e3e5e6}{#1}");
defineMacro("\\grayD", "\\textcolor{##d6d8da}{#1}");
defineMacro("\\grayE", "\\textcolor{##babec2}{#1}");
defineMacro("\\grayF", "\\textcolor{##888d93}{#1}");
defineMacro("\\grayG", "\\textcolor{##626569}{#1}");
defineMacro("\\grayH", "\\textcolor{##3b3e40}{#1}");
defineMacro("\\grayI", "\\textcolor{##21242c}{#1}");
defineMacro("\\kaBlue", "\\textcolor{##314453}{#1}");
defineMacro("\\kaGreen", "\\textcolor{##71B307}{#1}");
var implicitCommands = {
  "^": true,
  // Parser.js
  "_": true,
  // Parser.js
  "\\limits": true,
  // Parser.js
  "\\nolimits": true
  // Parser.js
};
class MacroExpander {
  constructor(input, settings, mode) {
    this.settings = void 0;
    this.expansionCount = void 0;
    this.lexer = void 0;
    this.macros = void 0;
    this.stack = void 0;
    this.mode = void 0;
    this.settings = settings;
    this.expansionCount = 0;
    this.feed(input);
    this.macros = new Namespace(macros, settings.macros);
    this.mode = mode;
    this.stack = [];
  }
  /**
   * Feed a new input string to the same MacroExpander
   * (with existing macros etc.).
   */
  feed(input) {
    this.lexer = new Lexer(input, this.settings);
  }
  /**
   * Switches between "text" and "math" modes.
   */
  switchMode(newMode) {
    this.mode = newMode;
  }
  /**
   * Start a new group nesting within all namespaces.
   */
  beginGroup() {
    this.macros.beginGroup();
  }
  /**
   * End current group nesting within all namespaces.
   */
  endGroup() {
    this.macros.endGroup();
  }
  /**
   * Ends all currently nested groups (if any), restoring values before the
   * groups began.  Useful in case of an error in the middle of parsing.
   */
  endGroups() {
    this.macros.endGroups();
  }
  /**
   * Returns the topmost token on the stack, without expanding it.
   * Similar in behavior to TeX's `\futurelet`.
   */
  future() {
    if (this.stack.length === 0) {
      this.pushToken(this.lexer.lex());
    }
    return this.stack[this.stack.length - 1];
  }
  /**
   * Remove and return the next unexpanded token.
   */
  popToken() {
    this.future();
    return this.stack.pop();
  }
  /**
   * Add a given token to the token stack.  In particular, this get be used
   * to put back a token returned from one of the other methods.
   */
  pushToken(token) {
    this.stack.push(token);
  }
  /**
   * Append an array of tokens to the token stack.
   */
  pushTokens(tokens) {
    this.stack.push(...tokens);
  }
  /**
   * Find an macro argument without expanding tokens and append the array of
   * tokens to the token stack. Uses Token as a container for the result.
   */
  scanArgument(isOptional) {
    var start;
    var end;
    var tokens;
    if (isOptional) {
      this.consumeSpaces();
      if (this.future().text !== "[") {
        return null;
      }
      start = this.popToken();
      ({
        tokens,
        end
      } = this.consumeArg(["]"]));
    } else {
      ({
        tokens,
        start,
        end
      } = this.consumeArg());
    }
    this.pushToken(new Token("EOF", end.loc));
    this.pushTokens(tokens);
    return new Token("", SourceLocation.range(start, end));
  }
  /**
   * Consume all following space tokens, without expansion.
   */
  consumeSpaces() {
    for (; ; ) {
      var token = this.future();
      if (token.text === " ") {
        this.stack.pop();
      } else {
        break;
      }
    }
  }
  /**
   * Consume an argument from the token stream, and return the resulting array
   * of tokens and start/end token.
   */
  consumeArg(delims) {
    var tokens = [];
    var isDelimited = delims && delims.length > 0;
    if (!isDelimited) {
      this.consumeSpaces();
    }
    var start = this.future();
    var tok;
    var depth = 0;
    var match = 0;
    do {
      tok = this.popToken();
      tokens.push(tok);
      if (tok.text === "{") {
        ++depth;
      } else if (tok.text === "}") {
        --depth;
        if (depth === -1) {
          throw new ParseError("Extra }", tok);
        }
      } else if (tok.text === "EOF") {
        throw new ParseError("Unexpected end of input in a macro argument, expected '" + (delims && isDelimited ? delims[match] : "}") + "'", tok);
      }
      if (delims && isDelimited) {
        if ((depth === 0 || depth === 1 && delims[match] === "{") && tok.text === delims[match]) {
          ++match;
          if (match === delims.length) {
            tokens.splice(-match, match);
            break;
          }
        } else {
          match = 0;
        }
      }
    } while (depth !== 0 || isDelimited);
    if (start.text === "{" && tokens[tokens.length - 1].text === "}") {
      tokens.pop();
      tokens.shift();
    }
    tokens.reverse();
    return {
      tokens,
      start,
      end: tok
    };
  }
  /**
   * Consume the specified number of (delimited) arguments from the token
   * stream and return the resulting array of arguments.
   */
  consumeArgs(numArgs, delimiters2) {
    if (delimiters2) {
      if (delimiters2.length !== numArgs + 1) {
        throw new ParseError("The length of delimiters doesn't match the number of args!");
      }
      var delims = delimiters2[0];
      for (var i = 0; i < delims.length; i++) {
        var tok = this.popToken();
        if (delims[i] !== tok.text) {
          throw new ParseError("Use of the macro doesn't match its definition", tok);
        }
      }
    }
    var args = [];
    for (var _i = 0; _i < numArgs; _i++) {
      args.push(this.consumeArg(delimiters2 && delimiters2[_i + 1]).tokens);
    }
    return args;
  }
  /**
   * Increment `expansionCount` by the specified amount.
   * Throw an error if it exceeds `maxExpand`.
   */
  countExpansion(amount) {
    this.expansionCount += amount;
    if (this.expansionCount > this.settings.maxExpand) {
      throw new ParseError("Too many expansions: infinite loop or need to increase maxExpand setting");
    }
  }
  /**
   * Expand the next token only once if possible.
   *
   * If the token is expanded, the resulting tokens will be pushed onto
   * the stack in reverse order, and the number of such tokens will be
   * returned.  This number might be zero or positive.
   *
   * If not, the return value is `false`, and the next token remains at the
   * top of the stack.
   *
   * In either case, the next token will be on the top of the stack,
   * or the stack will be empty (in case of empty expansion
   * and no other tokens).
   *
   * Used to implement `expandAfterFuture` and `expandNextToken`.
   *
   * If expandableOnly, only expandable tokens are expanded and
   * an undefined control sequence results in an error.
   */
  expandOnce(expandableOnly) {
    var topToken = this.popToken();
    var name = topToken.text;
    var expansion = !topToken.noexpand ? this._getExpansion(name) : null;
    if (expansion == null || expandableOnly && expansion.unexpandable) {
      if (expandableOnly && expansion == null && name[0] === "\\" && !this.isDefined(name)) {
        throw new ParseError("Undefined control sequence: " + name);
      }
      this.pushToken(topToken);
      return false;
    }
    this.countExpansion(1);
    var tokens = expansion.tokens;
    var args = this.consumeArgs(expansion.numArgs, expansion.delimiters);
    if (expansion.numArgs) {
      tokens = tokens.slice();
      for (var i = tokens.length - 1; i >= 0; --i) {
        var tok = tokens[i];
        if (tok.text === "#") {
          if (i === 0) {
            throw new ParseError("Incomplete placeholder at end of macro body", tok);
          }
          tok = tokens[--i];
          if (tok.text === "#") {
            tokens.splice(i + 1, 1);
          } else if (/^[1-9]$/.test(tok.text)) {
            tokens.splice(i, 2, ...args[+tok.text - 1]);
          } else {
            throw new ParseError("Not a valid argument number", tok);
          }
        }
      }
    }
    this.pushTokens(tokens);
    return tokens.length;
  }
  /**
   * Expand the next token only once (if possible), and return the resulting
   * top token on the stack (without removing anything from the stack).
   * Similar in behavior to TeX's `\expandafter\futurelet`.
   * Equivalent to expandOnce() followed by future().
   */
  expandAfterFuture() {
    this.expandOnce();
    return this.future();
  }
  /**
   * Recursively expand first token, then return first non-expandable token.
   */
  expandNextToken() {
    for (; ; ) {
      if (this.expandOnce() === false) {
        var token = this.stack.pop();
        if (token.treatAsRelax) {
          token.text = "\\relax";
        }
        return token;
      }
    }
    throw new Error();
  }
  /**
   * Fully expand the given macro name and return the resulting list of
   * tokens, or return `undefined` if no such macro is defined.
   */
  expandMacro(name) {
    return this.macros.has(name) ? this.expandTokens([new Token(name)]) : void 0;
  }
  /**
   * Fully expand the given token stream and return the resulting list of
   * tokens.  Note that the input tokens are in reverse order, but the
   * output tokens are in forward order.
   */
  expandTokens(tokens) {
    var output = [];
    var oldStackLength = this.stack.length;
    this.pushTokens(tokens);
    while (this.stack.length > oldStackLength) {
      if (this.expandOnce(true) === false) {
        var token = this.stack.pop();
        if (token.treatAsRelax) {
          token.noexpand = false;
          token.treatAsRelax = false;
        }
        output.push(token);
      }
    }
    this.countExpansion(output.length);
    return output;
  }
  /**
   * Fully expand the given macro name and return the result as a string,
   * or return `undefined` if no such macro is defined.
   */
  expandMacroAsText(name) {
    var tokens = this.expandMacro(name);
    if (tokens) {
      return tokens.map((token) => token.text).join("");
    } else {
      return tokens;
    }
  }
  /**
   * Returns the expanded macro as a reversed array of tokens and a macro
   * argument count.  Or returns `null` if no such macro.
   */
  _getExpansion(name) {
    var definition = this.macros.get(name);
    if (definition == null) {
      return definition;
    }
    if (name.length === 1) {
      var catcode = this.lexer.catcodes[name];
      if (catcode != null && catcode !== 13) {
        return;
      }
    }
    var expansion = typeof definition === "function" ? definition(this) : definition;
    if (typeof expansion === "string") {
      var numArgs = 0;
      if (expansion.indexOf("#") !== -1) {
        var stripped = expansion.replace(/##/g, "");
        while (stripped.indexOf("#" + (numArgs + 1)) !== -1) {
          ++numArgs;
        }
      }
      var bodyLexer = new Lexer(expansion, this.settings);
      var tokens = [];
      var tok = bodyLexer.lex();
      while (tok.text !== "EOF") {
        tokens.push(tok);
        tok = bodyLexer.lex();
      }
      tokens.reverse();
      var expanded = {
        tokens,
        numArgs
      };
      return expanded;
    }
    return expansion;
  }
  /**
   * Determine whether a command is currently "defined" (has some
   * functionality), meaning that it's a macro (in the current group),
   * a function, a symbol, or one of the special commands listed in
   * `implicitCommands`.
   */
  isDefined(name) {
    return this.macros.has(name) || functions.hasOwnProperty(name) || symbols.math.hasOwnProperty(name) || symbols.text.hasOwnProperty(name) || implicitCommands.hasOwnProperty(name);
  }
  /**
   * Determine whether a command is expandable.
   */
  isExpandable(name) {
    var macro = this.macros.get(name);
    return macro != null ? typeof macro === "string" || typeof macro === "function" || !macro.unexpandable : functions.hasOwnProperty(name) && !functions[name].primitive;
  }
}
var unicodeSubRegEx = /^[₊₋₌₍₎₀₁₂₃₄₅₆₇₈₉ₐₑₕᵢⱼₖₗₘₙₒₚᵣₛₜᵤᵥₓᵦᵧᵨᵩᵪ]/;
var uSubsAndSups = Object.freeze({
  "₊": "+",
  "₋": "-",
  "₌": "=",
  "₍": "(",
  "₎": ")",
  "₀": "0",
  "₁": "1",
  "₂": "2",
  "₃": "3",
  "₄": "4",
  "₅": "5",
  "₆": "6",
  "₇": "7",
  "₈": "8",
  "₉": "9",
  "ₐ": "a",
  "ₑ": "e",
  "ₕ": "h",
  "ᵢ": "i",
  "ⱼ": "j",
  "ₖ": "k",
  "ₗ": "l",
  "ₘ": "m",
  "ₙ": "n",
  "ₒ": "o",
  "ₚ": "p",
  "ᵣ": "r",
  "ₛ": "s",
  "ₜ": "t",
  "ᵤ": "u",
  "ᵥ": "v",
  "ₓ": "x",
  "ᵦ": "β",
  "ᵧ": "γ",
  "ᵨ": "ρ",
  "ᵩ": "ϕ",
  "ᵪ": "χ",
  "⁺": "+",
  "⁻": "-",
  "⁼": "=",
  "⁽": "(",
  "⁾": ")",
  "⁰": "0",
  "¹": "1",
  "²": "2",
  "³": "3",
  "⁴": "4",
  "⁵": "5",
  "⁶": "6",
  "⁷": "7",
  "⁸": "8",
  "⁹": "9",
  "ᴬ": "A",
  "ᴮ": "B",
  "ᴰ": "D",
  "ᴱ": "E",
  "ᴳ": "G",
  "ᴴ": "H",
  "ᴵ": "I",
  "ᴶ": "J",
  "ᴷ": "K",
  "ᴸ": "L",
  "ᴹ": "M",
  "ᴺ": "N",
  "ᴼ": "O",
  "ᴾ": "P",
  "ᴿ": "R",
  "ᵀ": "T",
  "ᵁ": "U",
  "ⱽ": "V",
  "ᵂ": "W",
  "ᵃ": "a",
  "ᵇ": "b",
  "ᶜ": "c",
  "ᵈ": "d",
  "ᵉ": "e",
  "ᶠ": "f",
  "ᵍ": "g",
  "ʰ": "h",
  "ⁱ": "i",
  "ʲ": "j",
  "ᵏ": "k",
  "ˡ": "l",
  "ᵐ": "m",
  "ⁿ": "n",
  "ᵒ": "o",
  "ᵖ": "p",
  "ʳ": "r",
  "ˢ": "s",
  "ᵗ": "t",
  "ᵘ": "u",
  "ᵛ": "v",
  "ʷ": "w",
  "ˣ": "x",
  "ʸ": "y",
  "ᶻ": "z",
  "ᵝ": "β",
  "ᵞ": "γ",
  "ᵟ": "δ",
  "ᵠ": "ϕ",
  "ᵡ": "χ",
  "ᶿ": "θ"
});
var unicodeAccents = {
  "́": {
    "text": "\\'",
    "math": "\\acute"
  },
  "̀": {
    "text": "\\`",
    "math": "\\grave"
  },
  "̈": {
    "text": '\\"',
    "math": "\\ddot"
  },
  "̃": {
    "text": "\\~",
    "math": "\\tilde"
  },
  "̄": {
    "text": "\\=",
    "math": "\\bar"
  },
  "̆": {
    "text": "\\u",
    "math": "\\breve"
  },
  "̌": {
    "text": "\\v",
    "math": "\\check"
  },
  "̂": {
    "text": "\\^",
    "math": "\\hat"
  },
  "̇": {
    "text": "\\.",
    "math": "\\dot"
  },
  "̊": {
    "text": "\\r",
    "math": "\\mathring"
  },
  "̋": {
    "text": "\\H"
  },
  "̧": {
    "text": "\\c"
  }
};
var unicodeSymbols = {
  "á": "á",
  "à": "à",
  "ä": "ä",
  "ǟ": "ǟ",
  "ã": "ã",
  "ā": "ā",
  "ă": "ă",
  "ắ": "ắ",
  "ằ": "ằ",
  "ẵ": "ẵ",
  "ǎ": "ǎ",
  "â": "â",
  "ấ": "ấ",
  "ầ": "ầ",
  "ẫ": "ẫ",
  "ȧ": "ȧ",
  "ǡ": "ǡ",
  "å": "å",
  "ǻ": "ǻ",
  "ḃ": "ḃ",
  "ć": "ć",
  "ḉ": "ḉ",
  "č": "č",
  "ĉ": "ĉ",
  "ċ": "ċ",
  "ç": "ç",
  "ď": "ď",
  "ḋ": "ḋ",
  "ḑ": "ḑ",
  "é": "é",
  "è": "è",
  "ë": "ë",
  "ẽ": "ẽ",
  "ē": "ē",
  "ḗ": "ḗ",
  "ḕ": "ḕ",
  "ĕ": "ĕ",
  "ḝ": "ḝ",
  "ě": "ě",
  "ê": "ê",
  "ế": "ế",
  "ề": "ề",
  "ễ": "ễ",
  "ė": "ė",
  "ȩ": "ȩ",
  "ḟ": "ḟ",
  "ǵ": "ǵ",
  "ḡ": "ḡ",
  "ğ": "ğ",
  "ǧ": "ǧ",
  "ĝ": "ĝ",
  "ġ": "ġ",
  "ģ": "ģ",
  "ḧ": "ḧ",
  "ȟ": "ȟ",
  "ĥ": "ĥ",
  "ḣ": "ḣ",
  "ḩ": "ḩ",
  "í": "í",
  "ì": "ì",
  "ï": "ï",
  "ḯ": "ḯ",
  "ĩ": "ĩ",
  "ī": "ī",
  "ĭ": "ĭ",
  "ǐ": "ǐ",
  "î": "î",
  "ǰ": "ǰ",
  "ĵ": "ĵ",
  "ḱ": "ḱ",
  "ǩ": "ǩ",
  "ķ": "ķ",
  "ĺ": "ĺ",
  "ľ": "ľ",
  "ļ": "ļ",
  "ḿ": "ḿ",
  "ṁ": "ṁ",
  "ń": "ń",
  "ǹ": "ǹ",
  "ñ": "ñ",
  "ň": "ň",
  "ṅ": "ṅ",
  "ņ": "ņ",
  "ó": "ó",
  "ò": "ò",
  "ö": "ö",
  "ȫ": "ȫ",
  "õ": "õ",
  "ṍ": "ṍ",
  "ṏ": "ṏ",
  "ȭ": "ȭ",
  "ō": "ō",
  "ṓ": "ṓ",
  "ṑ": "ṑ",
  "ŏ": "ŏ",
  "ǒ": "ǒ",
  "ô": "ô",
  "ố": "ố",
  "ồ": "ồ",
  "ỗ": "ỗ",
  "ȯ": "ȯ",
  "ȱ": "ȱ",
  "ő": "ő",
  "ṕ": "ṕ",
  "ṗ": "ṗ",
  "ŕ": "ŕ",
  "ř": "ř",
  "ṙ": "ṙ",
  "ŗ": "ŗ",
  "ś": "ś",
  "ṥ": "ṥ",
  "š": "š",
  "ṧ": "ṧ",
  "ŝ": "ŝ",
  "ṡ": "ṡ",
  "ş": "ş",
  "ẗ": "ẗ",
  "ť": "ť",
  "ṫ": "ṫ",
  "ţ": "ţ",
  "ú": "ú",
  "ù": "ù",
  "ü": "ü",
  "ǘ": "ǘ",
  "ǜ": "ǜ",
  "ǖ": "ǖ",
  "ǚ": "ǚ",
  "ũ": "ũ",
  "ṹ": "ṹ",
  "ū": "ū",
  "ṻ": "ṻ",
  "ŭ": "ŭ",
  "ǔ": "ǔ",
  "û": "û",
  "ů": "ů",
  "ű": "ű",
  "ṽ": "ṽ",
  "ẃ": "ẃ",
  "ẁ": "ẁ",
  "ẅ": "ẅ",
  "ŵ": "ŵ",
  "ẇ": "ẇ",
  "ẘ": "ẘ",
  "ẍ": "ẍ",
  "ẋ": "ẋ",
  "ý": "ý",
  "ỳ": "ỳ",
  "ÿ": "ÿ",
  "ỹ": "ỹ",
  "ȳ": "ȳ",
  "ŷ": "ŷ",
  "ẏ": "ẏ",
  "ẙ": "ẙ",
  "ź": "ź",
  "ž": "ž",
  "ẑ": "ẑ",
  "ż": "ż",
  "Á": "Á",
  "À": "À",
  "Ä": "Ä",
  "Ǟ": "Ǟ",
  "Ã": "Ã",
  "Ā": "Ā",
  "Ă": "Ă",
  "Ắ": "Ắ",
  "Ằ": "Ằ",
  "Ẵ": "Ẵ",
  "Ǎ": "Ǎ",
  "Â": "Â",
  "Ấ": "Ấ",
  "Ầ": "Ầ",
  "Ẫ": "Ẫ",
  "Ȧ": "Ȧ",
  "Ǡ": "Ǡ",
  "Å": "Å",
  "Ǻ": "Ǻ",
  "Ḃ": "Ḃ",
  "Ć": "Ć",
  "Ḉ": "Ḉ",
  "Č": "Č",
  "Ĉ": "Ĉ",
  "Ċ": "Ċ",
  "Ç": "Ç",
  "Ď": "Ď",
  "Ḋ": "Ḋ",
  "Ḑ": "Ḑ",
  "É": "É",
  "È": "È",
  "Ë": "Ë",
  "Ẽ": "Ẽ",
  "Ē": "Ē",
  "Ḗ": "Ḗ",
  "Ḕ": "Ḕ",
  "Ĕ": "Ĕ",
  "Ḝ": "Ḝ",
  "Ě": "Ě",
  "Ê": "Ê",
  "Ế": "Ế",
  "Ề": "Ề",
  "Ễ": "Ễ",
  "Ė": "Ė",
  "Ȩ": "Ȩ",
  "Ḟ": "Ḟ",
  "Ǵ": "Ǵ",
  "Ḡ": "Ḡ",
  "Ğ": "Ğ",
  "Ǧ": "Ǧ",
  "Ĝ": "Ĝ",
  "Ġ": "Ġ",
  "Ģ": "Ģ",
  "Ḧ": "Ḧ",
  "Ȟ": "Ȟ",
  "Ĥ": "Ĥ",
  "Ḣ": "Ḣ",
  "Ḩ": "Ḩ",
  "Í": "Í",
  "Ì": "Ì",
  "Ï": "Ï",
  "Ḯ": "Ḯ",
  "Ĩ": "Ĩ",
  "Ī": "Ī",
  "Ĭ": "Ĭ",
  "Ǐ": "Ǐ",
  "Î": "Î",
  "İ": "İ",
  "Ĵ": "Ĵ",
  "Ḱ": "Ḱ",
  "Ǩ": "Ǩ",
  "Ķ": "Ķ",
  "Ĺ": "Ĺ",
  "Ľ": "Ľ",
  "Ļ": "Ļ",
  "Ḿ": "Ḿ",
  "Ṁ": "Ṁ",
  "Ń": "Ń",
  "Ǹ": "Ǹ",
  "Ñ": "Ñ",
  "Ň": "Ň",
  "Ṅ": "Ṅ",
  "Ņ": "Ņ",
  "Ó": "Ó",
  "Ò": "Ò",
  "Ö": "Ö",
  "Ȫ": "Ȫ",
  "Õ": "Õ",
  "Ṍ": "Ṍ",
  "Ṏ": "Ṏ",
  "Ȭ": "Ȭ",
  "Ō": "Ō",
  "Ṓ": "Ṓ",
  "Ṑ": "Ṑ",
  "Ŏ": "Ŏ",
  "Ǒ": "Ǒ",
  "Ô": "Ô",
  "Ố": "Ố",
  "Ồ": "Ồ",
  "Ỗ": "Ỗ",
  "Ȯ": "Ȯ",
  "Ȱ": "Ȱ",
  "Ő": "Ő",
  "Ṕ": "Ṕ",
  "Ṗ": "Ṗ",
  "Ŕ": "Ŕ",
  "Ř": "Ř",
  "Ṙ": "Ṙ",
  "Ŗ": "Ŗ",
  "Ś": "Ś",
  "Ṥ": "Ṥ",
  "Š": "Š",
  "Ṧ": "Ṧ",
  "Ŝ": "Ŝ",
  "Ṡ": "Ṡ",
  "Ş": "Ş",
  "Ť": "Ť",
  "Ṫ": "Ṫ",
  "Ţ": "Ţ",
  "Ú": "Ú",
  "Ù": "Ù",
  "Ü": "Ü",
  "Ǘ": "Ǘ",
  "Ǜ": "Ǜ",
  "Ǖ": "Ǖ",
  "Ǚ": "Ǚ",
  "Ũ": "Ũ",
  "Ṹ": "Ṹ",
  "Ū": "Ū",
  "Ṻ": "Ṻ",
  "Ŭ": "Ŭ",
  "Ǔ": "Ǔ",
  "Û": "Û",
  "Ů": "Ů",
  "Ű": "Ű",
  "Ṽ": "Ṽ",
  "Ẃ": "Ẃ",
  "Ẁ": "Ẁ",
  "Ẅ": "Ẅ",
  "Ŵ": "Ŵ",
  "Ẇ": "Ẇ",
  "Ẍ": "Ẍ",
  "Ẋ": "Ẋ",
  "Ý": "Ý",
  "Ỳ": "Ỳ",
  "Ÿ": "Ÿ",
  "Ỹ": "Ỹ",
  "Ȳ": "Ȳ",
  "Ŷ": "Ŷ",
  "Ẏ": "Ẏ",
  "Ź": "Ź",
  "Ž": "Ž",
  "Ẑ": "Ẑ",
  "Ż": "Ż",
  "ά": "ά",
  "ὰ": "ὰ",
  "ᾱ": "ᾱ",
  "ᾰ": "ᾰ",
  "έ": "έ",
  "ὲ": "ὲ",
  "ή": "ή",
  "ὴ": "ὴ",
  "ί": "ί",
  "ὶ": "ὶ",
  "ϊ": "ϊ",
  "ΐ": "ΐ",
  "ῒ": "ῒ",
  "ῑ": "ῑ",
  "ῐ": "ῐ",
  "ό": "ό",
  "ὸ": "ὸ",
  "ύ": "ύ",
  "ὺ": "ὺ",
  "ϋ": "ϋ",
  "ΰ": "ΰ",
  "ῢ": "ῢ",
  "ῡ": "ῡ",
  "ῠ": "ῠ",
  "ώ": "ώ",
  "ὼ": "ὼ",
  "Ύ": "Ύ",
  "Ὺ": "Ὺ",
  "Ϋ": "Ϋ",
  "Ῡ": "Ῡ",
  "Ῠ": "Ῠ",
  "Ώ": "Ώ",
  "Ὼ": "Ὼ"
};
class Parser {
  constructor(input, settings) {
    this.mode = void 0;
    this.gullet = void 0;
    this.settings = void 0;
    this.leftrightDepth = void 0;
    this.nextToken = void 0;
    this.mode = "math";
    this.gullet = new MacroExpander(input, settings, this.mode);
    this.settings = settings;
    this.leftrightDepth = 0;
  }
  /**
   * Checks a result to make sure it has the right type, and throws an
   * appropriate error otherwise.
   */
  expect(text2, consume) {
    if (consume === void 0) {
      consume = true;
    }
    if (this.fetch().text !== text2) {
      throw new ParseError("Expected '" + text2 + "', got '" + this.fetch().text + "'", this.fetch());
    }
    if (consume) {
      this.consume();
    }
  }
  /**
   * Discards the current lookahead token, considering it consumed.
   */
  consume() {
    this.nextToken = null;
  }
  /**
   * Return the current lookahead token, or if there isn't one (at the
   * beginning, or if the previous lookahead token was consume()d),
   * fetch the next token as the new lookahead token and return it.
   */
  fetch() {
    if (this.nextToken == null) {
      this.nextToken = this.gullet.expandNextToken();
    }
    return this.nextToken;
  }
  /**
   * Switches between "text" and "math" modes.
   */
  switchMode(newMode) {
    this.mode = newMode;
    this.gullet.switchMode(newMode);
  }
  /**
   * Main parsing function, which parses an entire input.
   */
  parse() {
    if (!this.settings.globalGroup) {
      this.gullet.beginGroup();
    }
    if (this.settings.colorIsTextColor) {
      this.gullet.macros.set("\\color", "\\textcolor");
    }
    try {
      var parse = this.parseExpression(false);
      this.expect("EOF");
      if (!this.settings.globalGroup) {
        this.gullet.endGroup();
      }
      return parse;
    } finally {
      this.gullet.endGroups();
    }
  }
  /**
   * Fully parse a separate sequence of tokens as a separate job.
   * Tokens should be specified in reverse order, as in a MacroDefinition.
   */
  subparse(tokens) {
    var oldToken = this.nextToken;
    this.consume();
    this.gullet.pushToken(new Token("}"));
    this.gullet.pushTokens(tokens);
    var parse = this.parseExpression(false);
    this.expect("}");
    this.nextToken = oldToken;
    return parse;
  }
  /**
   * Parses an "expression", which is a list of atoms.
   *
   * `breakOnInfix`: Should the parsing stop when we hit infix nodes? This
   *                 happens when functions have higher precedence than infix
   *                 nodes in implicit parses.
   *
   * `breakOnTokenText`: The text of the token that the expression should end
   *                     with, or `null` if something else should end the
   *                     expression.
   */
  parseExpression(breakOnInfix, breakOnTokenText) {
    var body = [];
    while (true) {
      if (this.mode === "math") {
        this.consumeSpaces();
      }
      var lex = this.fetch();
      if (Parser.endOfExpression.indexOf(lex.text) !== -1) {
        break;
      }
      if (breakOnTokenText && lex.text === breakOnTokenText) {
        break;
      }
      if (breakOnInfix && functions[lex.text] && functions[lex.text].infix) {
        break;
      }
      var atom = this.parseAtom(breakOnTokenText);
      if (!atom) {
        break;
      } else if (atom.type === "internal") {
        continue;
      }
      body.push(atom);
    }
    if (this.mode === "text") {
      this.formLigatures(body);
    }
    return this.handleInfixNodes(body);
  }
  /**
   * Rewrites infix operators such as \over with corresponding commands such
   * as \frac.
   *
   * There can only be one infix operator per group.  If there's more than one
   * then the expression is ambiguous.  This can be resolved by adding {}.
   */
  handleInfixNodes(body) {
    var overIndex = -1;
    var funcName;
    for (var i = 0; i < body.length; i++) {
      if (body[i].type === "infix") {
        if (overIndex !== -1) {
          throw new ParseError("only one infix operator per group", body[i].token);
        }
        overIndex = i;
        funcName = body[i].replaceWith;
      }
    }
    if (overIndex !== -1 && funcName) {
      var numerNode;
      var denomNode;
      var numerBody = body.slice(0, overIndex);
      var denomBody = body.slice(overIndex + 1);
      if (numerBody.length === 1 && numerBody[0].type === "ordgroup") {
        numerNode = numerBody[0];
      } else {
        numerNode = {
          type: "ordgroup",
          mode: this.mode,
          body: numerBody
        };
      }
      if (denomBody.length === 1 && denomBody[0].type === "ordgroup") {
        denomNode = denomBody[0];
      } else {
        denomNode = {
          type: "ordgroup",
          mode: this.mode,
          body: denomBody
        };
      }
      var node;
      if (funcName === "\\\\abovefrac") {
        node = this.callFunction(funcName, [numerNode, body[overIndex], denomNode], []);
      } else {
        node = this.callFunction(funcName, [numerNode, denomNode], []);
      }
      return [node];
    } else {
      return body;
    }
  }
  /**
   * Handle a subscript or superscript with nice errors.
   */
  handleSupSubscript(name) {
    var symbolToken = this.fetch();
    var symbol = symbolToken.text;
    this.consume();
    this.consumeSpaces();
    var group;
    do {
      var _group;
      group = this.parseGroup(name);
    } while (((_group = group) == null ? void 0 : _group.type) === "internal");
    if (!group) {
      throw new ParseError("Expected group after '" + symbol + "'", symbolToken);
    }
    return group;
  }
  /**
   * Converts the textual input of an unsupported command into a text node
   * contained within a color node whose color is determined by errorColor
   */
  formatUnsupportedCmd(text2) {
    var textordArray = [];
    for (var i = 0; i < text2.length; i++) {
      textordArray.push({
        type: "textord",
        mode: "text",
        text: text2[i]
      });
    }
    var textNode = {
      type: "text",
      mode: this.mode,
      body: textordArray
    };
    var colorNode = {
      type: "color",
      mode: this.mode,
      color: this.settings.errorColor,
      body: [textNode]
    };
    return colorNode;
  }
  /**
   * Parses a group with optional super/subscripts.
   */
  parseAtom(breakOnTokenText) {
    var base = this.parseGroup("atom", breakOnTokenText);
    if ((base == null ? void 0 : base.type) === "internal") {
      return base;
    }
    if (this.mode === "text") {
      return base;
    }
    var superscript;
    var subscript;
    while (true) {
      this.consumeSpaces();
      var lex = this.fetch();
      if (lex.text === "\\limits" || lex.text === "\\nolimits") {
        if (base && base.type === "op") {
          var limits = lex.text === "\\limits";
          base.limits = limits;
          base.alwaysHandleSupSub = true;
        } else if (base && base.type === "operatorname") {
          if (base.alwaysHandleSupSub) {
            base.limits = lex.text === "\\limits";
          }
        } else {
          throw new ParseError("Limit controls must follow a math operator", lex);
        }
        this.consume();
      } else if (lex.text === "^") {
        if (superscript) {
          throw new ParseError("Double superscript", lex);
        }
        superscript = this.handleSupSubscript("superscript");
      } else if (lex.text === "_") {
        if (subscript) {
          throw new ParseError("Double subscript", lex);
        }
        subscript = this.handleSupSubscript("subscript");
      } else if (lex.text === "'") {
        if (superscript) {
          throw new ParseError("Double superscript", lex);
        }
        var prime = {
          type: "textord",
          mode: this.mode,
          text: "\\prime"
        };
        var primes = [prime];
        this.consume();
        while (this.fetch().text === "'") {
          primes.push(prime);
          this.consume();
        }
        if (this.fetch().text === "^") {
          primes.push(this.handleSupSubscript("superscript"));
        }
        superscript = {
          type: "ordgroup",
          mode: this.mode,
          body: primes
        };
      } else if (uSubsAndSups[lex.text]) {
        var isSub = unicodeSubRegEx.test(lex.text);
        var subsupTokens = [];
        subsupTokens.push(new Token(uSubsAndSups[lex.text]));
        this.consume();
        while (true) {
          var token = this.fetch().text;
          if (!uSubsAndSups[token]) {
            break;
          }
          if (unicodeSubRegEx.test(token) !== isSub) {
            break;
          }
          subsupTokens.unshift(new Token(uSubsAndSups[token]));
          this.consume();
        }
        var body = this.subparse(subsupTokens);
        if (isSub) {
          subscript = {
            type: "ordgroup",
            mode: "math",
            body
          };
        } else {
          superscript = {
            type: "ordgroup",
            mode: "math",
            body
          };
        }
      } else {
        break;
      }
    }
    if (superscript || subscript) {
      return {
        type: "supsub",
        mode: this.mode,
        base,
        sup: superscript,
        sub: subscript
      };
    } else {
      return base;
    }
  }
  /**
   * Parses an entire function, including its base and all of its arguments.
   */
  parseFunction(breakOnTokenText, name) {
    var token = this.fetch();
    var func = token.text;
    var funcData = functions[func];
    if (!funcData) {
      return null;
    }
    this.consume();
    if (name && name !== "atom" && !funcData.allowedInArgument) {
      throw new ParseError("Got function '" + func + "' with no arguments" + (name ? " as " + name : ""), token);
    } else if (this.mode === "text" && !funcData.allowedInText) {
      throw new ParseError("Can't use function '" + func + "' in text mode", token);
    } else if (this.mode === "math" && funcData.allowedInMath === false) {
      throw new ParseError("Can't use function '" + func + "' in math mode", token);
    }
    var {
      args,
      optArgs
    } = this.parseArguments(func, funcData);
    return this.callFunction(func, args, optArgs, token, breakOnTokenText);
  }
  /**
   * Call a function handler with a suitable context and arguments.
   */
  callFunction(name, args, optArgs, token, breakOnTokenText) {
    var context = {
      funcName: name,
      parser: this,
      token,
      breakOnTokenText
    };
    var func = functions[name];
    if (func && func.handler) {
      return func.handler(context, args, optArgs);
    } else {
      throw new ParseError("No function handler for " + name);
    }
  }
  /**
   * Parses the arguments of a function or environment
   */
  parseArguments(func, funcData) {
    var totalArgs = funcData.numArgs + funcData.numOptionalArgs;
    if (totalArgs === 0) {
      return {
        args: [],
        optArgs: []
      };
    }
    var args = [];
    var optArgs = [];
    for (var i = 0; i < totalArgs; i++) {
      var argType = funcData.argTypes && funcData.argTypes[i];
      var isOptional = i < funcData.numOptionalArgs;
      if (funcData.primitive && argType == null || // \sqrt expands into primitive if optional argument doesn't exist
      funcData.type === "sqrt" && i === 1 && optArgs[0] == null) {
        argType = "primitive";
      }
      var arg = this.parseGroupOfType("argument to '" + func + "'", argType, isOptional);
      if (isOptional) {
        optArgs.push(arg);
      } else if (arg != null) {
        args.push(arg);
      } else {
        throw new ParseError("Null argument, please report this as a bug");
      }
    }
    return {
      args,
      optArgs
    };
  }
  /**
   * Parses a group when the mode is changing.
   */
  parseGroupOfType(name, type, optional) {
    switch (type) {
      case "color":
        return this.parseColorGroup(optional);
      case "size":
        return this.parseSizeGroup(optional);
      case "url":
        return this.parseUrlGroup(optional);
      case "math":
      case "text":
        return this.parseArgumentGroup(optional, type);
      case "hbox": {
        var group = this.parseArgumentGroup(optional, "text");
        return group != null ? {
          type: "styling",
          mode: group.mode,
          body: [group],
          style: "text"
          // simulate \textstyle
        } : null;
      }
      case "raw": {
        var token = this.parseStringGroup("raw", optional);
        return token != null ? {
          type: "raw",
          mode: "text",
          string: token.text
        } : null;
      }
      case "primitive": {
        if (optional) {
          throw new ParseError("A primitive argument cannot be optional");
        }
        var _group2 = this.parseGroup(name);
        if (_group2 == null) {
          throw new ParseError("Expected group as " + name, this.fetch());
        }
        return _group2;
      }
      case "original":
      case null:
      case void 0:
        return this.parseArgumentGroup(optional);
      default:
        throw new ParseError("Unknown group type as " + name, this.fetch());
    }
  }
  /**
   * Discard any space tokens, fetching the next non-space token.
   */
  consumeSpaces() {
    while (this.fetch().text === " ") {
      this.consume();
    }
  }
  /**
   * Parses a group, essentially returning the string formed by the
   * brace-enclosed tokens plus some position information.
   */
  parseStringGroup(modeName, optional) {
    var argToken = this.gullet.scanArgument(optional);
    if (argToken == null) {
      return null;
    }
    var str = "";
    var nextToken;
    while ((nextToken = this.fetch()).text !== "EOF") {
      str += nextToken.text;
      this.consume();
    }
    this.consume();
    argToken.text = str;
    return argToken;
  }
  /**
   * Parses a regex-delimited group: the largest sequence of tokens
   * whose concatenated strings match `regex`. Returns the string
   * formed by the tokens plus some position information.
   */
  parseRegexGroup(regex, modeName) {
    var firstToken = this.fetch();
    var lastToken = firstToken;
    var str = "";
    var nextToken;
    while ((nextToken = this.fetch()).text !== "EOF" && regex.test(str + nextToken.text)) {
      lastToken = nextToken;
      str += lastToken.text;
      this.consume();
    }
    if (str === "") {
      throw new ParseError("Invalid " + modeName + ": '" + firstToken.text + "'", firstToken);
    }
    return firstToken.range(lastToken, str);
  }
  /**
   * Parses a color description.
   */
  parseColorGroup(optional) {
    var res = this.parseStringGroup("color", optional);
    if (res == null) {
      return null;
    }
    var match = /^(#[a-f0-9]{3,4}|#[a-f0-9]{6}|#[a-f0-9]{8}|[a-f0-9]{6}|[a-z]+)$/i.exec(res.text);
    if (!match) {
      throw new ParseError("Invalid color: '" + res.text + "'", res);
    }
    var color = match[0];
    if (/^[0-9a-f]{6}$/i.test(color)) {
      color = "#" + color;
    }
    return {
      type: "color-token",
      mode: this.mode,
      color
    };
  }
  /**
   * Parses a size specification, consisting of magnitude and unit.
   */
  parseSizeGroup(optional) {
    var res;
    var isBlank = false;
    this.gullet.consumeSpaces();
    if (!optional && this.gullet.future().text !== "{") {
      res = this.parseRegexGroup(/^[-+]? *(?:$|\d+|\d+\.\d*|\.\d*) *[a-z]{0,2} *$/, "size");
    } else {
      res = this.parseStringGroup("size", optional);
    }
    if (!res) {
      return null;
    }
    if (!optional && res.text.length === 0) {
      res.text = "0pt";
      isBlank = true;
    }
    var match = /([-+]?) *(\d+(?:\.\d*)?|\.\d+) *([a-z]{2})/.exec(res.text);
    if (!match) {
      throw new ParseError("Invalid size: '" + res.text + "'", res);
    }
    var data = {
      number: +(match[1] + match[2]),
      // sign + magnitude, cast to number
      unit: match[3]
    };
    if (!validUnit(data)) {
      throw new ParseError("Invalid unit: '" + data.unit + "'", res);
    }
    return {
      type: "size",
      mode: this.mode,
      value: data,
      isBlank
    };
  }
  /**
   * Parses an URL, checking escaped letters and allowed protocols,
   * and setting the catcode of % as an active character (as in \hyperref).
   */
  parseUrlGroup(optional) {
    this.gullet.lexer.setCatcode("%", 13);
    this.gullet.lexer.setCatcode("~", 12);
    var res = this.parseStringGroup("url", optional);
    this.gullet.lexer.setCatcode("%", 14);
    this.gullet.lexer.setCatcode("~", 13);
    if (res == null) {
      return null;
    }
    var url = res.text.replace(/\\([#$%&~_^{}])/g, "$1");
    return {
      type: "url",
      mode: this.mode,
      url
    };
  }
  /**
   * Parses an argument with the mode specified.
   */
  parseArgumentGroup(optional, mode) {
    var argToken = this.gullet.scanArgument(optional);
    if (argToken == null) {
      return null;
    }
    var outerMode = this.mode;
    if (mode) {
      this.switchMode(mode);
    }
    this.gullet.beginGroup();
    var expression = this.parseExpression(false, "EOF");
    this.expect("EOF");
    this.gullet.endGroup();
    var result = {
      type: "ordgroup",
      mode: this.mode,
      loc: argToken.loc,
      body: expression
    };
    if (mode) {
      this.switchMode(outerMode);
    }
    return result;
  }
  /**
   * Parses an ordinary group, which is either a single nucleus (like "x")
   * or an expression in braces (like "{x+y}") or an implicit group, a group
   * that starts at the current position, and ends right before a higher explicit
   * group ends, or at EOF.
   */
  parseGroup(name, breakOnTokenText) {
    var firstToken = this.fetch();
    var text2 = firstToken.text;
    var result;
    if (text2 === "{" || text2 === "\\begingroup") {
      this.consume();
      var groupEnd = text2 === "{" ? "}" : "\\endgroup";
      this.gullet.beginGroup();
      var expression = this.parseExpression(false, groupEnd);
      var lastToken = this.fetch();
      this.expect(groupEnd);
      this.gullet.endGroup();
      result = {
        type: "ordgroup",
        mode: this.mode,
        loc: SourceLocation.range(firstToken, lastToken),
        body: expression,
        // A group formed by \begingroup...\endgroup is a semi-simple group
        // which doesn't affect spacing in math mode, i.e., is transparent.
        // https://tex.stackexchange.com/questions/1930/when-should-one-
        // use-begingroup-instead-of-bgroup
        semisimple: text2 === "\\begingroup" || void 0
      };
    } else {
      result = this.parseFunction(breakOnTokenText, name) || this.parseSymbol();
      if (result == null && text2[0] === "\\" && !implicitCommands.hasOwnProperty(text2)) {
        if (this.settings.throwOnError) {
          throw new ParseError("Undefined control sequence: " + text2, firstToken);
        }
        result = this.formatUnsupportedCmd(text2);
        this.consume();
      }
    }
    return result;
  }
  /**
   * Form ligature-like combinations of characters for text mode.
   * This includes inputs like "--", "---", "``" and "''".
   * The result will simply replace multiple textord nodes with a single
   * character in each value by a single textord node having multiple
   * characters in its value.  The representation is still ASCII source.
   * The group will be modified in place.
   */
  formLigatures(group) {
    var n = group.length - 1;
    for (var i = 0; i < n; ++i) {
      var a = group[i];
      var v = a.text;
      if (v === "-" && group[i + 1].text === "-") {
        if (i + 1 < n && group[i + 2].text === "-") {
          group.splice(i, 3, {
            type: "textord",
            mode: "text",
            loc: SourceLocation.range(a, group[i + 2]),
            text: "---"
          });
          n -= 2;
        } else {
          group.splice(i, 2, {
            type: "textord",
            mode: "text",
            loc: SourceLocation.range(a, group[i + 1]),
            text: "--"
          });
          n -= 1;
        }
      }
      if ((v === "'" || v === "`") && group[i + 1].text === v) {
        group.splice(i, 2, {
          type: "textord",
          mode: "text",
          loc: SourceLocation.range(a, group[i + 1]),
          text: v + v
        });
        n -= 1;
      }
    }
  }
  /**
   * Parse a single symbol out of the string. Here, we handle single character
   * symbols and special functions like \verb.
   */
  parseSymbol() {
    var nucleus = this.fetch();
    var text2 = nucleus.text;
    if (/^\\verb[^a-zA-Z]/.test(text2)) {
      this.consume();
      var arg = text2.slice(5);
      var star = arg.charAt(0) === "*";
      if (star) {
        arg = arg.slice(1);
      }
      if (arg.length < 2 || arg.charAt(0) !== arg.slice(-1)) {
        throw new ParseError("\\verb assertion failed --\n                    please report what input caused this bug");
      }
      arg = arg.slice(1, -1);
      return {
        type: "verb",
        mode: "text",
        body: arg,
        star
      };
    }
    if (unicodeSymbols.hasOwnProperty(text2[0]) && !symbols[this.mode][text2[0]]) {
      if (this.settings.strict && this.mode === "math") {
        this.settings.reportNonstrict("unicodeTextInMathMode", 'Accented Unicode text character "' + text2[0] + '" used in math mode', nucleus);
      }
      text2 = unicodeSymbols[text2[0]] + text2.slice(1);
    }
    var match = combiningDiacriticalMarksEndRegex.exec(text2);
    if (match) {
      text2 = text2.substring(0, match.index);
      if (text2 === "i") {
        text2 = "ı";
      } else if (text2 === "j") {
        text2 = "ȷ";
      }
    }
    var symbol;
    if (symbols[this.mode][text2]) {
      if (this.settings.strict && this.mode === "math" && extraLatin.indexOf(text2) >= 0) {
        this.settings.reportNonstrict("unicodeTextInMathMode", 'Latin-1/Unicode text character "' + text2[0] + '" used in math mode', nucleus);
      }
      var group = symbols[this.mode][text2].group;
      var loc = SourceLocation.range(nucleus);
      var s;
      if (ATOMS.hasOwnProperty(group)) {
        var family = group;
        s = {
          type: "atom",
          mode: this.mode,
          family,
          loc,
          text: text2
        };
      } else {
        s = {
          type: group,
          mode: this.mode,
          loc,
          text: text2
        };
      }
      symbol = s;
    } else if (text2.charCodeAt(0) >= 128) {
      if (this.settings.strict) {
        if (!supportedCodepoint(text2.charCodeAt(0))) {
          this.settings.reportNonstrict("unknownSymbol", 'Unrecognized Unicode character "' + text2[0] + '"' + (" (" + text2.charCodeAt(0) + ")"), nucleus);
        } else if (this.mode === "math") {
          this.settings.reportNonstrict("unicodeTextInMathMode", 'Unicode text character "' + text2[0] + '" used in math mode', nucleus);
        }
      }
      symbol = {
        type: "textord",
        mode: "text",
        loc: SourceLocation.range(nucleus),
        text: text2
      };
    } else {
      return null;
    }
    this.consume();
    if (match) {
      for (var i = 0; i < match[0].length; i++) {
        var accent2 = match[0][i];
        if (!unicodeAccents[accent2]) {
          throw new ParseError("Unknown accent ' " + accent2 + "'", nucleus);
        }
        var command = unicodeAccents[accent2][this.mode] || unicodeAccents[accent2].text;
        if (!command) {
          throw new ParseError("Accent " + accent2 + " unsupported in " + this.mode + " mode", nucleus);
        }
        symbol = {
          type: "accent",
          mode: this.mode,
          loc: SourceLocation.range(nucleus),
          label: command,
          isStretchy: false,
          isShifty: true,
          // $FlowFixMe
          base: symbol
        };
      }
    }
    return symbol;
  }
}
Parser.endOfExpression = ["}", "\\endgroup", "\\end", "\\right", "&"];
var parseTree = function parseTree2(toParse, settings) {
  if (!(typeof toParse === "string" || toParse instanceof String)) {
    throw new TypeError("KaTeX can only parse string typed expression");
  }
  var parser = new Parser(toParse, settings);
  delete parser.gullet.macros.current["\\df@tag"];
  var tree = parser.parse();
  delete parser.gullet.macros.current["\\current@color"];
  delete parser.gullet.macros.current["\\color"];
  if (parser.gullet.macros.get("\\df@tag")) {
    if (!settings.displayMode) {
      throw new ParseError("\\tag works only in display equations");
    }
    tree = [{
      type: "tag",
      mode: "text",
      body: tree,
      tag: parser.subparse([new Token("\\df@tag")])
    }];
  }
  return tree;
};
var render = function render2(expression, baseNode, options) {
  baseNode.textContent = "";
  var node = renderToDomTree(expression, options).toNode();
  baseNode.appendChild(node);
};
if (typeof document !== "undefined") {
  if (document.compatMode !== "CSS1Compat") {
    typeof console !== "undefined" && console.warn("Warning: KaTeX doesn't work in quirks mode. Make sure your website has a suitable doctype.");
    render = function render3() {
      throw new ParseError("KaTeX doesn't work in quirks mode.");
    };
  }
}
var renderToString = function renderToString2(expression, options) {
  var markup = renderToDomTree(expression, options).toMarkup();
  return markup;
};
var generateParseTree = function generateParseTree2(expression, options) {
  var settings = new Settings(options);
  return parseTree(expression, settings);
};
var renderError = function renderError2(error, expression, options) {
  if (options.throwOnError || !(error instanceof ParseError)) {
    throw error;
  }
  var node = buildCommon.makeSpan(["katex-error"], [new SymbolNode(expression)]);
  node.setAttribute("title", error.toString());
  node.setAttribute("style", "color:" + options.errorColor);
  return node;
};
var renderToDomTree = function renderToDomTree2(expression, options) {
  var settings = new Settings(options);
  try {
    var tree = parseTree(expression, settings);
    return buildTree(tree, expression, settings);
  } catch (error) {
    return renderError(error, expression, settings);
  }
};
var renderToHTMLTree = function renderToHTMLTree2(expression, options) {
  var settings = new Settings(options);
  try {
    var tree = parseTree(expression, settings);
    return buildHTMLTree(tree, expression, settings);
  } catch (error) {
    return renderError(error, expression, settings);
  }
};
var version = "0.16.28";
var __domTree = {
  Span,
  Anchor,
  SymbolNode,
  SvgNode,
  PathNode,
  LineNode
};
var katex = {
  /**
   * Current KaTeX version
   */
  version,
  /**
   * Renders the given LaTeX into an HTML+MathML combination, and adds
   * it as a child to the specified DOM node.
   */
  render,
  /**
   * Renders the given LaTeX into an HTML+MathML combination string,
   * for sending to the client.
   */
  renderToString,
  /**
   * KaTeX error, usually during parsing.
   */
  ParseError,
  /**
   * The schema of Settings
   */
  SETTINGS_SCHEMA,
  /**
   * Parses the given LaTeX into KaTeX's internal parse tree structure,
   * without rendering to HTML or MathML.
   *
   * NOTE: This method is not currently recommended for public use.
   * The internal tree representation is unstable and is very likely
   * to change. Use at your own risk.
   */
  __parse: generateParseTree,
  /**
   * Renders the given LaTeX into an HTML+MathML internal DOM tree
   * representation, without flattening that representation to a string.
   *
   * NOTE: This method is not currently recommended for public use.
   * The internal tree representation is unstable and is very likely
   * to change. Use at your own risk.
   */
  __renderToDomTree: renderToDomTree,
  /**
   * Renders the given LaTeX into an HTML internal DOM tree representation,
   * without MathML and without flattening that representation to a string.
   *
   * NOTE: This method is not currently recommended for public use.
   * The internal tree representation is unstable and is very likely
   * to change. Use at your own risk.
   */
  __renderToHTMLTree: renderToHTMLTree,
  /**
   * extends internal font metrics object with a new object
   * each key in the new object represents a font name
  */
  __setFontMetrics: setFontMetrics,
  /**
   * adds a new symbol to builtin symbols table
   */
  __defineSymbol: defineSymbol,
  /**
   * adds a new function to builtin function list,
   * which directly produce parse tree elements
   * and have their own html/mathml builders
   */
  __defineFunction: defineFunction,
  /**
   * adds a new macro to builtin macro list
   */
  __defineMacro: defineMacro,
  /**
   * Expose the dom tree node types, which can be useful for type checking nodes.
   *
   * NOTE: These methods are not currently recommended for public use.
   * The internal tree representation is unstable and is very likely
   * to change. Use at your own risk.
   */
  __domTree
};
const _hoisted_1$1 = {
  key: 0,
  class: "math-editor"
};
const _hoisted_2$1 = ["placeholder", "onKeydown"];
const _hoisted_3 = { class: "math-editor__preview" };
const _hoisted_4 = {
  key: 0,
  class: "math-error"
};
const _hoisted_5 = ["innerHTML"];
const _hoisted_6 = { class: "math-editor__actions" };
const _hoisted_7 = ["innerHTML"];
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "MathNodeView",
  props: nodeViewProps,
  setup(__props) {
    const props = __props;
    const isEditing = ref(false);
    const latexInput = ref("");
    const renderError3 = ref(null);
    const textareaRef = ref(null);
    function renderLatex(latex, displayMode) {
      if (!latex.trim()) {
        return `<span class="math-placeholder">${t("editor.mathEmpty")}</span>`;
      }
      try {
        renderError3.value = null;
        return katex.renderToString(latex, {
          displayMode,
          throwOnError: false,
          errorColor: "#cc0000",
          strict: false,
          trust: false
        });
      } catch (e) {
        renderError3.value = e instanceof Error ? e.message : "Render error";
        return `<span class="math-error">${renderError3.value}</span>`;
      }
    }
    const displayHtml = computed(() => {
      return renderLatex(props.node.attrs.latex, props.node.attrs.block);
    });
    const previewHtml = computed(() => {
      return renderLatex(latexInput.value, props.node.attrs.block);
    });
    function startEdit() {
      if (props.editor?.isEditable === false) return;
      isEditing.value = true;
      latexInput.value = props.node.attrs.latex || "";
      nextTick(() => {
        textareaRef.value?.focus();
        textareaRef.value?.select();
      });
    }
    function saveAndClose() {
      if (latexInput.value !== props.node.attrs.latex) {
        props.updateAttributes({ latex: latexInput.value });
      }
      isEditing.value = false;
    }
    function cancelEdit() {
      isEditing.value = false;
      latexInput.value = props.node.attrs.latex || "";
    }
    function handleBlur(e) {
      const relatedTarget = e.relatedTarget;
      if (relatedTarget?.closest(".math-editor")) {
        return;
      }
      saveAndClose();
    }
    function handleClick() {
      const pos = props.getPos();
      if (typeof pos === "number") {
        props.editor?.commands.setNodeSelection(pos);
      }
    }
    onMounted(() => {
      if (!props.node.attrs.latex && props.editor?.isEditable) {
        startEdit();
      }
    });
    watch(
      () => props.node.attrs.latex,
      (newLatex) => {
        if (!isEditing.value) {
          latexInput.value = newLatex || "";
        }
      }
    );
    return (_ctx, _cache) => {
      return openBlock(), createBlock(unref(NodeViewWrapper), {
        class: normalizeClass(["math-node-wrapper", { "is-block": _ctx.node.attrs.block, "is-editing": isEditing.value, "is-selected": _ctx.selected }]),
        as: _ctx.node.attrs.block ? "div" : "span"
      }, {
        default: withCtx(() => [
          isEditing.value ? (openBlock(), createElementBlock("div", _hoisted_1$1, [
            withDirectives(createElementVNode("textarea", {
              ref_key: "textareaRef",
              ref: textareaRef,
              "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => latexInput.value = $event),
              class: "math-editor__input",
              placeholder: unref(t)("editor.mathPlaceholder"),
              onKeydown: [
                withKeys(withModifiers(saveAndClose, ["ctrl"]), ["enter"]),
                withKeys(cancelEdit, ["escape"])
              ],
              onBlur: handleBlur
            }, null, 40, _hoisted_2$1), [
              [vModelText, latexInput.value]
            ]),
            createElementVNode("div", _hoisted_3, [
              renderError3.value ? (openBlock(), createElementBlock("span", _hoisted_4, toDisplayString(renderError3.value), 1)) : (openBlock(), createElementBlock("span", {
                key: 1,
                innerHTML: previewHtml.value
              }, null, 8, _hoisted_5))
            ]),
            createElementVNode("div", _hoisted_6, [
              createElementVNode("button", {
                type: "button",
                class: "math-btn math-btn--cancel",
                onClick: cancelEdit
              }, toDisplayString(unref(t)("editor.cancel")), 1),
              createElementVNode("button", {
                type: "button",
                class: "math-btn math-btn--save",
                onClick: saveAndClose
              }, toDisplayString(unref(t)("editor.accept")), 1)
            ])
          ])) : (openBlock(), createElementBlock("span", {
            key: 1,
            class: normalizeClass(["math-display", { "math-empty": !_ctx.node.attrs.latex }]),
            onDblclick: startEdit,
            onClick: handleClick,
            innerHTML: displayHtml.value
          }, null, 42, _hoisted_7))
        ]),
        _: 1
      }, 8, ["class", "as"]);
    };
  }
});
const MathExtension = Node.create({
  name: "math",
  group: "inline",
  inline: true,
  atom: true,
  addOptions() {
    return {
      inline: true,
      block: true,
      katexOptions: DEFAULT_KATEX_OPTIONS
    };
  },
  addAttributes() {
    return {
      latex: {
        default: "",
        parseHTML: (element) => element.getAttribute("data-latex") || element.textContent || "",
        renderHTML: (attributes) => ({
          "data-latex": attributes.latex
        })
      },
      block: {
        default: false,
        parseHTML: (element) => element.getAttribute("data-block") === "true",
        renderHTML: (attributes) => ({
          "data-block": attributes.block ? "true" : "false"
        })
      }
    };
  },
  parseHTML() {
    return [
      {
        tag: 'span[data-type="math"]'
      },
      {
        tag: 'div[data-type="math"]'
      },
      // 支持从 Markdown 粘贴的 LaTeX
      {
        tag: "span.math-inline"
      },
      {
        tag: "div.math-block"
      }
    ];
  },
  renderHTML({ HTMLAttributes }) {
    const isBlock = HTMLAttributes["data-block"] === "true";
    const tag = isBlock ? "div" : "span";
    return [
      tag,
      mergeAttributes(HTMLAttributes, {
        "data-type": "math",
        class: isBlock ? "math-node math-block" : "math-node math-inline"
      })
    ];
  },
  addNodeView() {
    return VueNodeViewRenderer(_sfc_main$1);
  },
  addCommands() {
    return {
      insertInlineMath: (latex = "") => ({ commands }) => {
        return commands.insertContent({
          type: this.name,
          attrs: { latex, block: false }
        });
      },
      insertBlockMath: (latex = "") => ({ chain }) => {
        return chain().insertContent({
          type: "paragraph",
          content: [
            {
              type: this.name,
              attrs: { latex, block: true }
            }
          ]
        }).run();
      },
      updateMath: (latex) => ({ commands }) => {
        return commands.updateAttributes(this.name, { latex });
      }
    };
  },
  addKeyboardShortcuts() {
    return {
      // Ctrl/Cmd + M: 插入行内公式
      "Mod-m": () => this.editor.commands.insertInlineMath(),
      // Ctrl/Cmd + Shift + M: 插入块级公式
      "Mod-Shift-m": () => this.editor.commands.insertBlockMath()
    };
  },
  addInputRules() {
    const nodeType = this.type;
    return [
      new InputRule({
        // 匹配 $latex$ 格式
        find: /\$([^$]+)\$$/,
        handler: ({ state: state2, range, match }) => {
          const latex = match[1];
          if (!latex) return null;
          const { tr } = state2;
          tr.replaceWith(range.from, range.to, nodeType.create({ latex, block: false }));
        }
      })
    ];
  }
});
function getExtensionsByVersion(_version = "basic", optionsOrEnableImageResize = true) {
  const options = typeof optionsOrEnableImageResize === "boolean" ? { enableImageResize: optionsOrEnableImageResize } : optionsOrEnableImageResize;
  const { enableImageResize = true, disableHistory = false } = options;
  const extensions = [];
  const starterKitConfig = {
    // 禁用一些高级功能，在基础版中通过其他扩展提供
    heading: {
      levels: [1, 2, 3, 4, 5, 6]
    },
    // 禁用 link 和 underline，因为后面会单独添加配置版本
    link: false,
    underline: false
  };
  if (disableHistory) {
    starterKitConfig.history = false;
  }
  extensions.push(StarterKit.configure(starterKitConfig));
  extensions.push(
    Placeholder.configure({
      placeholder: "开始编辑你的文档..."
    })
  );
  extensions.push(
    TextAlign.configure({
      types: ["heading", "paragraph"]
    })
  );
  extensions.push(Underline);
  extensions.push(Color);
  extensions.push(TextStyle);
  extensions.push(Highlight.configure({
    multicolor: true
  }));
  extensions.push(
    ResizableImage.configure({
      inline: true,
      allowBase64: true,
      enableResize: enableImageResize
      // 根据配置决定是否启用图片增强功能
    })
  );
  extensions.push(
    Link.configure({
      openOnClick: true,
      // 允许点击链接跳转
      HTMLAttributes: {
        target: "_blank",
        rel: "noopener noreferrer"
      }
    })
  );
  extensions.push(TaskList);
  extensions.push(
    TaskItem.configure({
      nested: true
    })
  );
  extensions.push(
    Table.configure({
      resizable: true
    })
  );
  extensions.push(TableRow);
  extensions.push(TableCell$1);
  extensions.push(TableHeader);
  extensions.push(FontFamily);
  extensions.push(FontSize);
  extensions.push(Subscript);
  extensions.push(Superscript);
  extensions.push(LineHeight);
  extensions.push(CharacterCount);
  extensions.push(PasteImage);
  extensions.push(PasteWord);
  extensions.push(ListShortcuts);
  extensions.push(FormatPainter);
  extensions.push(MathExtension);
  extensions.push(AiHighlightMark);
  extensions.push(CustomAiExtension);
  extensions.push(ContinueWritingExtension);
  extensions.push(PolishExtension);
  extensions.push(SummarizeExtension);
  extensions.push(TranslationExtension);
  return extensions;
}
const __vite_import_meta_env__ = {};
const _hoisted_1 = { class: "continuous-pages" };
const _hoisted_2 = {
  key: 1,
  class: "editor-fallback"
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "TiptapProEditor",
  props: {
    version: { default: "basic" },
    versionConfig: {},
    zoomBarPlacement: { default: "bottom" },
    readonly: { type: Boolean, default: false },
    previewMode: { type: Boolean, default: false },
    documentId: {},
    initialContent: { default: "<p>开始编辑你的文档...</p>" },
    tableMenuShowMode: {},
    features: {},
    locale: {}
  },
  emits: ["update", "collaboratorsChange", "collaboratorsListChange"],
  setup(__props, { expose: __expose, emit: __emit }) {
    const props = __props;
    const isPreviewMode = computed(() => props.previewMode);
    const emit = __emit;
    const editor = shallowRef(null);
    const editorError = ref(null);
    const containerRef = ref(null);
    const dragHandleMenuRef = ref(null);
    const totalPages = ref(1);
    const zoomLevel = ref(100);
    const isFirstInit = ref(true);
    const isInitializing = ref(false);
    const editorInstance = computed(() => editor.value);
    const userStore = useUserStore();
    const getUserInfo = () => {
      try {
        const userInfo = userStore.userInfo;
        if (userInfo) {
          const id = userInfo.userId || userInfo.id || userInfo.user_id || "anonymous";
          const name = userInfo.realName || userInfo.userName || userInfo.name || userInfo.real_name || userInfo.username || "匿名用户";
          return { id, name };
        }
      } catch {
      }
      return { id: "anonymous", name: "匿名用户" };
    };
    const collaboration = useCollaboration({
      getUserInfo,
      onCollaboratorsChange: (count) => emit("collaboratorsChange", count),
      onCollaboratorsListChange: (users) => emit("collaboratorsListChange", users)
    });
    const collaborationEnabled = ref(false);
    watch(
      () => [editor.value, collaboration.collaboratorsCount.value],
      ([e, count]) => {
        if (!e) return;
        try {
          ;
          e.storage.__collaborationUsersCount = count;
        } catch {
        }
      },
      { immediate: true }
    );
    const getFeatureConfig = (featureName) => {
      if (props.features?.[featureName] !== void 0) {
        return props.features[featureName];
      }
      if (props.versionConfig?.features?.[featureName] !== void 0) {
        return props.versionConfig.features[featureName];
      }
      return false;
    };
    const shouldShowHeaderNav = computed(() => getFeatureConfig("headerNav"));
    const shouldShowFooterNav = computed(() => getFeatureConfig("footerNav"));
    const collaborationWsUrl = computed(() => __vite_import_meta_env__?.VITE_COLLABORATION_WS_URL || "");
    const isCollaborationFeatureEnabled = computed(() => getFeatureConfig("collaboration"));
    const shouldShowCollaboration = computed(() => {
      if (isCollaborationFeatureEnabled.value && !collaborationWsUrl.value) {
        console.warn("[Tiptap UI Kit] Collaboration feature enabled but VITE_COLLABORATION_WS_URL is not configured in .env");
        return false;
      }
      return isCollaborationFeatureEnabled.value && !!collaborationWsUrl.value;
    });
    const isCollaborationAvailable = computed(() => {
      return collaborationEnabled.value && shouldShowCollaboration.value && !!props.documentId;
    });
    const handleCollaborationChange = async (enabled) => {
      if (collaborationEnabled.value !== enabled) {
        collaborationEnabled.value = enabled;
      }
    };
    watch(
      () => shouldShowCollaboration.value,
      (newValue) => {
        if (collaborationEnabled.value !== newValue) {
          collaborationEnabled.value = newValue;
        }
      },
      { immediate: true }
    );
    watch(
      () => collaborationEnabled.value,
      async (newValue, oldValue) => {
        if (oldValue === void 0) return;
        if (newValue !== oldValue && editor.value && !isInitializing.value) {
          await initEditor();
        }
      }
    );
    const toolbarConfig = computed(() => {
      const disableUndoRedo = isCollaborationAvailable.value && collaboration.collaboratorsCount.value > 1;
      switch (props.version) {
        case "advanced":
        case "premium":
          return {
            ...ADVANCED_TOOLBAR_CONFIG,
            codeBlock: true,
            link: true,
            table: true,
            font: true,
            lineHeight: true,
            clearFormat: true,
            undoRedo: true,
            undoRedoDisabled: disableUndoRedo,
            subscriptSuperscript: true,
            formatPainter: true,
            formatPainterDisabled: disableUndoRedo
          };
        case "basic":
        default:
          return {
            ...BASIC_TOOLBAR_CONFIG,
            undoRedo: true,
            undoRedoDisabled: disableUndoRedo
          };
      }
    });
    const currentLocale2 = computed(() => props.locale || "zh-CN");
    const mapLocaleToTiptapLocale = (locale) => {
      const localeMap = {
        "zh-CN": "zh-CN",
        "zh-TW": "zh-TW",
        "zh-HK": "zh-TW",
        "en-US": "en-US",
        "en": "en-US"
      };
      if (localeMap[locale]) return localeMap[locale];
      if (locale.startsWith("zh")) return locale.includes("TW") || locale.includes("HK") ? "zh-TW" : "zh-CN";
      if (locale.startsWith("en")) return "en-US";
      return "zh-CN";
    };
    const initTiptapI18n = () => {
      const tiptapLocale = mapLocaleToTiptapLocale(currentLocale2.value);
      createI18n({ locale: tiptapLocale });
    };
    initTiptapI18n();
    watch(
      () => currentLocale2.value,
      (newLocale) => {
        const tiptapLocale = mapLocaleToTiptapLocale(newLocale);
        const tiptapI18n = useI18n();
        tiptapI18n.setLocale(tiptapLocale);
      },
      { immediate: false }
    );
    const calculatePages = () => {
      nextTick(() => {
        const proseMirrorEl = containerRef.value?.querySelector(".ProseMirror");
        if (!proseMirrorEl) return;
        const style = getComputedStyle(proseMirrorEl);
        const paddingTop = parseFloat(style.paddingTop) || 0;
        const paddingBottom = parseFloat(style.paddingBottom) || 0;
        const contentHeight = proseMirrorEl.scrollHeight - (paddingTop + paddingBottom);
        const pageContentHeight = A4_HEIGHT_PX - (paddingTop + paddingBottom);
        const pages = Math.ceil(contentHeight / pageContentHeight);
        totalPages.value = Math.max(pages, 1);
      });
    };
    const getEditorContent = () => {
      try {
        return editor.value?.getJSON() ?? null;
      } catch {
        return null;
      }
    };
    const getInitialContent = () => {
      if (!isFirstInit.value && editor.value && !isCollaborationAvailable.value) {
        const currentContent = getEditorContent();
        if (currentContent) return currentContent;
      }
      return normalizeContent(props.initialContent, { silent: true });
    };
    const initCollaborationFeature = async (initialContent, extensions) => {
      if (!isCollaborationAvailable.value) {
        collaboration.disable();
        return;
      }
      try {
        if (collaboration.instance.value) {
          collaboration.disable();
          await new Promise((resolve) => setTimeout(resolve, 100));
        }
        const collabExtensions = await collaboration.initWithExtensions({
          documentId: props.documentId,
          readonly: props.readonly,
          initialContent,
          getUserInfo
        });
        if (collabExtensions.length === 0) {
          return;
        }
        extensions.push(...collabExtensions);
      } catch {
      }
    };
    const initEditor = async () => {
      if (isInitializing.value) return;
      try {
        isInitializing.value = true;
        const initialContentToUse = getInitialContent();
        if (isFirstInit.value) {
          isFirstInit.value = false;
        }
        const enableImageResize = props.versionConfig?.features?.advanced !== false;
        const extensions = getExtensionsByVersion(props.version, {
          enableImageResize,
          disableHistory: isCollaborationAvailable.value
        });
        if (props.features?.dragHandleMenu) {
          extensions.push(
            DragHandleWithMenuExtension.configure({
              onHandleClick: (event) => dragHandleMenuRef.value?.handleDragHandleClick(event)
            })
          );
        }
        await initCollaborationFeature(initialContentToUse, extensions);
        if (editor.value) {
          editor.value.destroy();
          editor.value = null;
        }
        await nextTick();
        const shouldSetContentOnInit = !isCollaborationAvailable.value;
        editor.value = new Editor({
          editable: !props.readonly && !isPreviewMode.value,
          extensions,
          content: shouldSetContentOnInit ? initialContentToUse : void 0,
          editorProps: {
            attributes: { class: "word-editor-content" }
          },
          onUpdate: ({ editor: editor2 }) => {
            calculatePages();
            emit("update", editor2.getJSON());
          }
        });
        await nextTick();
        if (collaboration.instance.value && editor.value) {
          collaboration.setEditor(editor.value);
        }
        if (containerRef.value) {
          containerRef.value.style.setProperty("--a4-width-px", `${A4_WIDTH_PX}px`);
          containerRef.value.style.setProperty("--padding-top-px", `${PAGE_PADDING_TOP_PX}px`);
          containerRef.value.style.setProperty("--padding-bottom-px", `${PAGE_PADDING_BOTTOM_PX}px`);
          containerRef.value.style.setProperty("--page-content-height-px", `${PAGE_CONTENT_HEIGHT_PX}px`);
        }
        calculatePages();
      } catch (error) {
        console.error("[TiptapProEditor] Editor initialization failed:", error);
        editorError.value = "编辑器初始化失败";
      } finally {
        isInitializing.value = false;
      }
    };
    const destroyEditor = async () => {
      collaboration.disable();
      if (editor.value) {
        editor.value.destroy();
        editor.value = null;
      }
    };
    onMounted(async () => {
      await initEditor();
    });
    onBeforeUnmount(async () => {
      await destroyEditor();
    });
    const watchAndReinit = (getter, shouldReinit = (newVal, oldVal) => newVal !== oldVal) => {
      watch(
        getter,
        async (newValue, oldValue) => {
          if (oldValue === void 0 || !editor.value || isInitializing.value) return;
          if (shouldReinit(newValue, oldValue)) {
            await nextTick();
            await initEditor();
          }
        }
      );
    };
    watchAndReinit(
      () => props.features?.dragHandleMenu,
      (newVal, oldVal) => (newVal ?? false) !== (oldVal ?? false)
    );
    watchAndReinit(
      () => props.documentId,
      (newId, oldId) => shouldShowCollaboration.value && newId !== oldId
    );
    __expose({
      getEditor: () => editor.value,
      getJSON: () => editor.value?.getJSON() || null,
      getHTML: () => editor.value?.getHTML() || "",
      getText: () => editor.value?.getText() || ""
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(["tiptap-pro-editor word-mode", { "is-preview-mode": isPreviewMode.value }])
      }, [
        editorInstance.value && !isPreviewMode.value ? (openBlock(), createBlock(unref(ToolbarNav), {
          key: 0,
          editor: editorInstance.value,
          config: toolbarConfig.value,
          enabled: shouldShowHeaderNav.value,
          class: "word-toolbar"
        }, createSlots({ _: 2 }, [
          shouldShowCollaboration.value ? {
            name: "right",
            fn: withCtx(() => [
              createVNode(unref(CollaborationToggle), {
                modelValue: collaborationEnabled.value,
                "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => collaborationEnabled.value = $event),
                "collaborators-count": unref(collaboration).collaboratorsCount.value,
                "collaborators-list": [...unref(collaboration).collaboratorsList.value],
                "show-label": "",
                onChange: handleCollaborationChange
              }, null, 8, ["modelValue", "collaborators-count", "collaborators-list"])
            ]),
            key: "0"
          } : void 0
        ]), 1032, ["editor", "config", "enabled"])) : createCommentVNode("", true),
        editorInstance.value && !isPreviewMode.value && (props.features?.linkBubbleMenu ?? false) ? (openBlock(), createBlock(unref(LinkBubbleMenu), {
          key: 1,
          editor: editorInstance.value,
          readonly: __props.readonly,
          enabled: props.features?.linkBubbleMenu ?? false
        }, null, 8, ["editor", "readonly", "enabled"])) : createCommentVNode("", true),
        editorInstance.value && !isPreviewMode.value ? (openBlock(), createBlock(unref(TableToolbar), {
          key: 2,
          editor: editorInstance.value,
          readonly: __props.readonly,
          "show-mode": props.tableMenuShowMode ?? 2,
          enabled: props.features?.tableToolbar ?? false
        }, null, 8, ["editor", "readonly", "show-mode", "enabled"])) : createCommentVNode("", true),
        editorInstance.value && !isPreviewMode.value && (props.features?.image ?? false) ? (openBlock(), createBlock(unref(ImageToolbar), {
          key: 3,
          editor: editorInstance.value,
          readonly: __props.readonly,
          enabled: props.features?.image ?? false
        }, null, 8, ["editor", "readonly", "enabled"])) : createCommentVNode("", true),
        editorInstance.value && !isPreviewMode.value && (props.features?.floatingMenu ?? false) ? (openBlock(), createBlock(unref(FloatingMenu), {
          key: 4,
          editor: editorInstance.value,
          readonly: __props.readonly,
          enabled: props.features?.floatingMenu ?? false
        }, null, 8, ["editor", "readonly", "enabled"])) : createCommentVNode("", true),
        editorInstance.value && !isPreviewMode.value && (props.features?.dragHandleMenu ?? false) ? (openBlock(), createBlock(unref(_sfc_main$3), {
          key: 5,
          ref_key: "dragHandleMenuRef",
          ref: dragHandleMenuRef,
          editor: editorInstance.value,
          readonly: __props.readonly
        }, null, 8, ["editor", "readonly"])) : createCommentVNode("", true),
        createElementVNode("div", {
          class: "word-document-container",
          ref_key: "containerRef",
          ref: containerRef
        }, [
          createElementVNode("div", {
            class: "document-pages",
            style: normalizeStyle({ transform: `scale(${zoomLevel.value / 100})` })
          }, [
            createElementVNode("div", _hoisted_1, [
              editorInstance.value ? (openBlock(), createBlock(unref(EditorContent), {
                key: 0,
                editor: editorInstance.value,
                class: "word-content-multi"
              }, null, 8, ["editor"])) : (openBlock(), createElementBlock("div", _hoisted_2, toDisplayString(editorError.value || "正在初始化编辑器..."), 1))
            ])
          ], 4)
        ], 512),
        editorInstance.value && !isPreviewMode.value && shouldShowFooterNav.value ? (openBlock(), createBlock(unref(FooterNav), {
          key: 6,
          zoomLevel: zoomLevel.value,
          "onUpdate:zoomLevel": _cache[1] || (_cache[1] = ($event) => zoomLevel.value = $event),
          totalPages: totalPages.value,
          editor: editorInstance.value,
          showCharCount: true
        }, null, 8, ["zoomLevel", "totalPages", "editor"])) : createCommentVNode("", true)
      ], 2);
    };
  }
});
const PRESET_CONFIGS = {
  /** 最小配置 */
  minimal: {
    features: {
      textFormat: true,
      list: true,
      undoRedo: true
    }
  },
  /** 基础配置 */
  basic: {
    features: {
      heading: true,
      textFormat: true,
      list: true,
      align: true,
      link: true,
      undoRedo: true,
      headerNav: true
    }
  },
  /** 高级配置 */
  advanced: {
    features: {
      heading: true,
      textFormat: true,
      list: true,
      align: true,
      color: true,
      image: true,
      font: true,
      link: true,
      table: true,
      codeBlock: true,
      undoRedo: true,
      formatPainter: true,
      zoom: true,
      headerNav: true,
      footerNav: true,
      dragHandleMenu: true,
      linkBubbleMenu: true,
      tableToolbar: true,
      imageToolbar: true
    }
  },
  /** 完整配置（含 AI） */
  full: {
    features: {
      heading: true,
      textFormat: true,
      list: true,
      align: true,
      color: true,
      image: true,
      font: true,
      link: true,
      table: true,
      codeBlock: true,
      undoRedo: true,
      formatPainter: true,
      zoom: true,
      subscriptSuperscript: true,
      clearFormat: true,
      headerNav: true,
      footerNav: true,
      dragHandleMenu: true,
      floatingMenu: true,
      linkBubbleMenu: true,
      tableToolbar: true,
      imageToolbar: true,
      ai: true
    }
  },
  /** Notion 风格配置 - 极简工具栏 + 浮动格式化 */
  notion: {
    themePreset: "notion",
    features: {
      // 固定工具栏只保留撤消/重做
      undoRedo: true,
      // 浮动工具栏（选中文字时显示）
      floatingMenu: true,
      linkBubbleMenu: true,
      // 拖拽排序（六个点菜单）
      dragHandleMenu: true,
      // 隐藏固定工具栏中的其他按钮
      heading: false,
      textFormat: false,
      list: false,
      align: false,
      color: false,
      image: false,
      font: false,
      link: false,
      table: false,
      codeBlock: false,
      formatPainter: false,
      zoom: false,
      headerNav: false,
      footerNav: false
    }
  }
};
function mergeConfig(preset, overrides) {
  const base = typeof preset === "string" ? PRESET_CONFIGS[preset] : preset;
  return {
    theme: "light",
    themePreset: "default",
    locale: "zh-CN",
    ...base,
    ...overrides,
    features: {
      ...base.features,
      ...overrides?.features
    }
  };
}
let currentPreset = "default";
let currentMode = "light";
const customThemes = /* @__PURE__ */ new Map();
function setTheme(preset, mode = "light") {
  currentPreset = preset;
  currentMode = mode;
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  root.classList.remove("theme-default", "theme-notion", "theme-github", "theme-typora", "theme-word");
  if (preset !== "default") {
    root.classList.add(`theme-${preset}`);
  }
  root.setAttribute("data-theme", mode === "auto" ? getSystemTheme() : mode);
  if (preset === "custom" && customThemes.has("custom")) {
    applyCustomTheme(customThemes.get("custom"));
  }
}
function getTheme() {
  return { preset: currentPreset, mode: currentMode };
}
function toggleThemeMode() {
  const newMode = currentMode === "light" ? "dark" : "light";
  setTheme(currentPreset, newMode);
  return newMode;
}
function registerTheme(name, variables) {
  customThemes.set(name, variables);
}
function applyCustomTheme(variables) {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  for (const [key, value] of Object.entries(variables)) {
    root.style.setProperty(key, value);
  }
}
function getSystemTheme() {
  if (typeof window === "undefined") return "light";
  return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}
function watchSystemTheme(callback) {
  if (typeof window === "undefined") return () => {
  };
  const mediaQuery = window.matchMedia("(prefers-color-scheme: dark)");
  const handler = (e) => {
    callback(e.matches ? "dark" : "light");
  };
  mediaQuery.addEventListener("change", handler);
  return () => mediaQuery.removeEventListener("change", handler);
}
const THEME_PRESETS = ["default", "notion", "github", "typora", "word"];
let currentDevice = "pc";
function setDeviceView(device) {
  currentDevice = device;
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  root.setAttribute("data-device", device);
}
function getDeviceView() {
  return currentDevice;
}
const DEVICE_VIEWS = ["pc", "pad", "mobile"];
let currentOrientation = "portrait";
function setOrientation(orientation) {
  currentOrientation = orientation;
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  root.setAttribute("data-orientation", orientation);
}
function getOrientation() {
  return currentOrientation;
}
const ORIENTATIONS = ["portrait", "landscape"];
export {
  AI_PROVIDERS,
  AiHighlightMark,
  AiMenuButton,
  _sfc_main$b as AiSettingsModal,
  AiSuggestionPopover,
  AiToolbarMenu,
  ContinueWritingExtension,
  CustomAiExtension,
  CustomAiPopover,
  DEFAULT_CONFIG,
  DEVICE_VIEWS,
  ORIENTATIONS,
  PRESET_CONFIGS,
  PolishExtension,
  SummarizeExtension,
  THEME_PRESETS,
  _sfc_main as TiptapProEditor,
  TranslationExtension,
  aiSuggestionManager,
  applyCustomTheme,
  createI18n,
  enUS,
  getAiRequestConfig,
  getDeviceView,
  getOrientation,
  getProviderInfo,
  getTheme,
  initTheme,
  mergeConfig,
  registerTheme,
  setDeviceView,
  setOrientation,
  setTheme,
  setUserInfo,
  t,
  toggleThemeMode,
  useAi,
  useAiConfig,
  useI18n,
  usePreferences,
  useUserStore,
  watchSystemTheme,
  zhCN,
  zhTW
};
