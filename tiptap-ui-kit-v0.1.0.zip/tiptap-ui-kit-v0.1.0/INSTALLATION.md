# Tiptap UI Kit - Installation Guide

Thank you for purchasing Tiptap UI Kit!

## Quick Start

1. Install dependencies:
   \`\`\`bash
   pnpm install
   \`\`\`

2. Import in your project:
   \`\`\`typescript
   import { TiptapProEditor } from './src'
   import './dist/tiptap-ui-kit.css'
   \`\`\`

3. Or use the built version:
   \`\`\`typescript
   import { TiptapProEditor } from './dist'
   \`\`\`

## License

Your license key: [WILL BE PROVIDED]

For support: https://github.com/benngaihk/Tiptap-UI-Kit/issues

## Documentation

- README.md - Full documentation
- docs/TESTING.md - How to run tests
- docs/DEPLOYMENT.md - How to deploy
- CHANGELOG.md - Version history

Enjoy building! 🚀
