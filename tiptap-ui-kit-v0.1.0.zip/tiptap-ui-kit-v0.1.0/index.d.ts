import { default as AiSuggestionPopover } from './shared/AiSuggestionPopover.vue';
import { Component } from 'vue';
import { ComponentOptionsMixin } from 'vue';
import { ComponentProvideOptions } from 'vue';
import { ComputedRef } from 'vue';
import { default as CustomAiPopover } from './shared/CustomAiPopover.vue';
import { DefineComponent } from 'vue';
import { DocumentType as DocumentType_2 } from '@tiptap/core';
import { Editor } from '@tiptap/vue-3';
import { Editor as Editor_2 } from '@tiptap/core';
import { Extension } from '@tiptap/core';
import { JSONContent } from '@tiptap/core';
import { Mark } from '@tiptap/core';
import { MarkType } from '@tiptap/core';
import { NodeType } from '@tiptap/core';
import { PublicProps } from 'vue';
import { readonly } from 'vue';
import { Ref } from 'vue';
import { ref } from 'vue';
import { TextType } from '@tiptap/core';

/** 提供商列表 */
export declare const AI_PROVIDERS: AiProviderInfo[];

/** AI adapter interface */
export declare interface AiAdapter {
    /** Provider name */
    provider: AiProvider_2;
    /** Chat completion (non-streaming) */
    chat(messages: AiMessage[], options?: Partial<AiConfig_2>): Promise<AiResponse>;
    /** Chat completion (streaming) */
    chatStream(messages: AiMessage[], callbacks: AiStreamCallbacks, options?: Partial<AiConfig_2>): Promise<void>;
}

/** AI configuration */
export declare interface AiConfig {
    provider: 'openai' | 'aliyun' | 'ollama' | 'deepseek';
    apiKey: string;
    model?: string;
    baseUrl?: string;
}

/** AI configuration from env */
declare interface AiConfig_2 {
    provider: AiProvider_2;
    apiKey?: string;
    apiSecret?: string;
    baseUrl?: string;
    model?: string;
    temperature?: number;
    maxTokens?: number;
}

/** AI 配置状态 */
export declare interface AiConfigState {
    /** 用户配置 */
    config: AiUserConfig | null;
    /** 是否已初始化 */
    initialized: boolean;
    /** 连接测试状态 */
    testStatus: 'idle' | 'testing' | 'success' | 'error';
    /** 测试错误信息 */
    testError: string | null;
}

/**
 * AI Highlight Mark Extension
 * @description Highlights text that is being processed by AI
 */
export declare const AiHighlightMark: Mark<AiHighlightOptions, any>;

declare interface AiHighlightOptions {
    HTMLAttributes: Record<string, any>;
}

export declare const AiMenuButton: DefineComponent<Props, {}, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {}, string, PublicProps, Readonly<Props> & Readonly<{}>, {
active: boolean;
placement: "top" | "bottom" | "bottomLeft" | "bottomRight" | "topLeft" | "topRight";
}, {}, {}, {}, string, ComponentProvideOptions, false, {}, any>;

/** Message format */
export declare interface AiMessage {
    role: 'system' | 'user' | 'assistant';
    content: string;
}

/**
 * AI Configuration Types
 * @description AI 用户配置系统类型定义
 */
/** 支持的 AI 提供商 */
export declare type AiProvider = 'openai' | 'deepseek' | 'anthropic' | 'aliyun' | 'ollama' | 'custom';

/**
 * AI Types
 * Common types for AI adapters
 */
/** Supported AI providers */
declare type AiProvider_2 = 'openai' | 'aliyun' | 'ollama' | 'deepseek' | 'anthropic' | 'custom';

/** AI 提供商信息 */
export declare interface AiProviderInfo {
    /** 提供商 ID */
    id: AiProvider;
    /** 显示名称 */
    name: string;
    /** 描述 */
    description: string;
    /** 默认 API 端点 */
    defaultEndpoint: string;
    /** 默认模型 */
    defaultModel: string;
    /** 是否需要 API Key */
    requiresApiKey: boolean;
    /** 文档链接 */
    docsUrl?: string;
}

/** Non-streaming response */
declare interface AiResponse {
    content: string;
    finishReason?: string;
    usage?: {
        promptTokens: number;
        completionTokens: number;
        totalTokens: number;
    };
}

export declare const AiSettingsModal: DefineComponent<Props_3, {}, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {
"update:open": (value: boolean) => any;
saved: () => any;
}, string, PublicProps, Readonly<Props_3> & Readonly<{
"onUpdate:open"?: ((value: boolean) => any) | undefined;
onSaved?: (() => any) | undefined;
}>, {
open: boolean;
}, {}, {}, {}, string, ComponentProvideOptions, false, {}, any>;

/** Streaming callbacks */
export declare interface AiStreamCallbacks {
    onStart?: () => void;
    onToken?: (token: string) => void;
    onComplete?: (fullText: string) => void;
    onError?: (error: Error) => void;
}

export declare interface AiSuggestionData {
    originalText: string;
    suggestedText: string;
    isStreaming: boolean;
}

declare class AiSuggestionManager {
    private editor;
    private popoverApp;
    private container;
    private state;
    private visibleRef;
    private originalTextRef;
    private suggestedTextRef;
    private isStreamingRef;
    private isTemporarilyHidden;
    private clickHandler;
    /**
     * Initialize the suggestion manager
     */
    init(editor: Editor_2): void;
    /**
     * Setup click handler for highlighted text
     */
    private setupClickHandler;
    /**
     * Remove click handler to prevent memory leaks
     */
    private removeClickHandler;
    /**
     * Restore existing highlights from the document
     */
    private restoreExistingHighlights;
    /**
     * Restore a suggestion from saved data
     */
    private restoreSuggestion;
    /**
     * Show AI suggestion popover
     */
    show(originalText: string, originalSelection: {
        from: number;
        to: number;
    }, editor?: Editor_2): void;
    /**
     * Show the popover (for clicking on highlighted text)
     */
    private showPopover;
    /**
     * Update suggested text (for streaming)
     */
    updateSuggestion(text: string): void;
    /**
     * Stop streaming
     */
    stopStreaming(): void;
    /**
     * Accept the suggestion
     */
    accept(): void;
    /**
     * Build paragraph nodes from text with newlines
     */
    private buildParagraphNodes;
    /**
     * Reject the suggestion
     */
    reject(): void;
    /**
     * Cancel (temporarily hide) the suggestion
     */
    cancel(): void;
    /**
     * Hide the popover and cleanup
     */
    hide(): void;
    /**
     * Check if suggestion is visible
     */
    isVisible(): boolean;
    /**
     * Get current state
     */
    getState(): AiSuggestionState;
    /**
     * Mount the popover component
     */
    private mountPopover;
    /**
     * Unmount the popover component
     */
    private unmountPopover;
    /**
     * Calculate popover position based on selection
     */
    private calculatePopoverPosition;
    /**
     * Cleanup
     */
    destroy(): void;
}

export declare const aiSuggestionManager: AiSuggestionManager;

export { AiSuggestionPopover }

export declare interface AiSuggestionState {
    visible: boolean;
    originalText: string;
    suggestedText: string;
    isStreaming: boolean;
    originalSelection: {
        from: number;
        to: number;
    };
}

export declare const AiToolbarMenu: DefineComponent<Props_2, {}, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {}, string, PublicProps, Readonly<Props_2> & Readonly<{}>, {}, {}, {}, {}, string, ComponentProvideOptions, false, {}, any>;

/** 用户 AI 配置 */
export declare interface AiUserConfig {
    /** 选择的提供商 */
    provider: AiProvider;
    /** API Key（加密存储） */
    apiKey: string;
    /** API 端点（可选，用于自定义或代理） */
    endpoint?: string;
    /** 模型名称 */
    model: string;
    /** 请求超时（毫秒） */
    timeout: number;
    /** 是否启用 */
    enabled: boolean;
    /** 最后更新时间 */
    updatedAt: number;
}

/**
 * Apply custom theme variables
 */
export declare function applyCustomTheme(variables: Record<string, string>): void;

/**
 * 协作用户信息
 */
export declare interface CollaboratorInfo {
    id: string | number;
    name: string;
    color: string;
}

/** 连接测试结果 */
declare interface ConnectionTestResult {
    success: boolean;
    message: string;
    latency?: number;
}

/**
 * Continue Writing Extension for Tiptap v3
 * @description AI-powered text continuation based on selection
 */
export declare const ContinueWritingExtension: Extension<ContinueWritingOptions, any>;

export declare interface ContinueWritingOptions {
}

/**
 * Create i18n instance
 */
export declare function createI18n(options?: {
    locale?: LocaleCode;
    fallbackLocale?: LocaleCode;
    messages?: Record<string, LocaleMessages>;
}): void;

/**
 * Custom AI Extension for Tiptap v3
 * @description AI-powered custom text processing with user-defined prompts
 */
export declare const CustomAiExtension: Extension<CustomAiOptions, any>;

export declare interface CustomAiOptions {
}

export { CustomAiPopover }

/** 默认配置值 */
export declare const DEFAULT_CONFIG: Omit<AiUserConfig, 'apiKey' | 'updatedAt'>;

/** Export device view options */
export declare const DEVICE_VIEWS: readonly ["pc", "pad", "mobile"];

/** Device view type */
export declare type DeviceView = 'pc' | 'pad' | 'mobile';

/** Editor configuration */
export declare interface EditorConfig {
    /** Theme mode (light/dark/auto) */
    theme?: ThemeMode;
    /** Theme preset */
    themePreset?: ThemePreset;
    /** Custom theme CSS variables */
    customTheme?: Record<string, string>;
    /** Feature flags */
    features?: FeatureFlags;
    /** AI configuration */
    aiConfig?: AiConfig;
    /** Locale */
    locale?: 'zh-CN' | 'zh-TW' | 'en-US';
    /** Readonly mode */
    readonly?: boolean;
    /** Preview mode (no toolbar) */
    previewMode?: boolean;
    /** Initial content */
    initialContent?: string;
    /** Placeholder */
    placeholder?: string;
    /** License key */
    licenseKey?: string;
}

/**
 * 编辑器实例引用
 */
export declare interface EditorInstance {
    editor: Editor | null;
    getEditor: () => Editor | null;
    getJSON: () => JSONContent | null;
    getHTML: () => string;
    getText: () => string;
}

/**
 * 版本类型
 */
export declare type EditorVersion = 'basic' | 'advanced' | 'premium';

export declare const enUS: TiptapLocale;

/**
 * 编辑器功能配置
 */
export declare interface FeatureConfig {
    /** 是否启用拖拽功能 */
    dragHandle?: boolean;
    /** 是否启用六个点（拖拽手柄菜单）功能 */
    dragHandleMenu?: boolean;
    /** 是否启用表格功能 */
    table?: boolean;
    /** 是否启用表格工具栏（默认关闭，需显式开启） */
    tableToolbar?: boolean;
    /** 是否启用@提及功能 */
    mention?: boolean;
    /** 是否启用悬浮框功能 */
    floatingMenu?: boolean;
    /** 是否启用图片工具栏功能 */
    image?: boolean;
    /** 是否启用链接悬浮框功能 */
    linkBubbleMenu?: boolean;
    /** 是否启用协作编辑功能 */
    collaboration?: boolean;
    /** 是否启用头部导航 */
    headerNav?: boolean;
    /** 是否启用底部导航 */
    footerNav?: boolean;
}

/** Feature flags */
export declare interface FeatureFlags {
    heading?: boolean;
    textFormat?: boolean;
    list?: boolean;
    align?: boolean;
    color?: boolean;
    image?: boolean;
    font?: boolean;
    link?: boolean;
    table?: boolean;
    codeBlock?: boolean;
    undoRedo?: boolean;
    formatPainter?: boolean;
    zoom?: boolean;
    subscriptSuperscript?: boolean;
    clearFormat?: boolean;
    headerNav?: boolean;
    footerNav?: boolean;
    dragHandleMenu?: boolean;
    floatingMenu?: boolean;
    linkBubbleMenu?: boolean;
    tableToolbar?: boolean;
    imageToolbar?: boolean;
    ai?: boolean;
}

/**
 * 获取静态配置（非响应式，用于 API 调用）
 */
export declare function getAiRequestConfig(): {
    endpoint: string;
    apiKey: string;
    model: string;
    timeout: number;
    provider: AiProvider;
} | null;

/**
 * Get current device view
 */
export declare function getDeviceView(): DeviceView;

/**
 * Get current orientation
 */
export declare function getOrientation(): Orientation;

/** 根据 provider ID 获取提供商信息 */
export declare function getProviderInfo(provider: AiProvider): AiProviderInfo | undefined;

/**
 * Get current theme
 */
export declare function getTheme(): {
    preset: ThemePreset;
    mode: ThemeMode;
};

/**
 * Initialize theme from system preferences
 */
export declare function initTheme(): void;

export declare type LocaleCode = 'zh-CN' | 'zh-TW' | 'en-US';

export declare type LocaleMessages = typeof zhCN;

/** 合并配置 */
export declare function mergeConfig(preset: PresetName | Partial<EditorConfig>, overrides?: Partial<EditorConfig>): EditorConfig;

/** Orientation type */
export declare type Orientation = 'portrait' | 'landscape';

/** Export orientation options */
export declare const ORIENTATIONS: readonly ["portrait", "landscape"];

/**
 * Polish Extension for Tiptap v3
 * @description AI-powered text polishing/refinement based on selection
 */
export declare const PolishExtension: Extension<PolishOptions, any>;

export declare interface PolishOptions {
}

/** Preset configurations */
export declare const PRESET_CONFIGS: {
    /** 最小配置 */
    readonly minimal: {
        features: {
            textFormat: true;
            list: true;
            undoRedo: true;
        };
    };
    /** 基础配置 */
    readonly basic: {
        features: {
            heading: true;
            textFormat: true;
            list: true;
            align: true;
            link: true;
            undoRedo: true;
            headerNav: true;
        };
    };
    /** 高级配置 */
    readonly advanced: {
        features: {
            heading: true;
            textFormat: true;
            list: true;
            align: true;
            color: true;
            image: true;
            font: true;
            link: true;
            table: true;
            codeBlock: true;
            undoRedo: true;
            formatPainter: true;
            zoom: true;
            headerNav: true;
            footerNav: true;
            dragHandleMenu: true;
            linkBubbleMenu: true;
            tableToolbar: true;
            imageToolbar: true;
        };
    };
    /** 完整配置（含 AI） */
    readonly full: {
        features: {
            heading: true;
            textFormat: true;
            list: true;
            align: true;
            color: true;
            image: true;
            font: true;
            link: true;
            table: true;
            codeBlock: true;
            undoRedo: true;
            formatPainter: true;
            zoom: true;
            subscriptSuperscript: true;
            clearFormat: true;
            headerNav: true;
            footerNav: true;
            dragHandleMenu: true;
            floatingMenu: true;
            linkBubbleMenu: true;
            tableToolbar: true;
            imageToolbar: true;
            ai: true;
        };
    };
    /** Notion 风格配置 - 极简工具栏 + 浮动格式化 */
    readonly notion: {
        themePreset: ThemePreset;
        features: {
            undoRedo: true;
            floatingMenu: true;
            linkBubbleMenu: true;
            dragHandleMenu: true;
            heading: false;
            textFormat: false;
            list: false;
            align: false;
            color: false;
            image: false;
            font: false;
            link: false;
            table: false;
            codeBlock: false;
            formatPainter: false;
            zoom: false;
            headerNav: false;
            footerNav: false;
        };
    };
};

export declare type PresetName = keyof typeof PRESET_CONFIGS;

declare interface Props {
    editor: Editor_2;
    icon?: Component;
    label?: string;
    title?: string;
    active?: boolean;
    placement?: 'top' | 'bottom' | 'bottomLeft' | 'bottomRight' | 'topLeft' | 'topRight';
}

declare interface Props_2 {
    editor: Editor | null;
    adapter: AiAdapter;
}

declare interface Props_3 {
    open?: boolean;
}

/**
 * Register custom theme
 */
export declare function registerTheme(name: string, variables: Record<string, string>): void;

/**
 * Set device view
 */
export declare function setDeviceView(device: DeviceView): void;

/**
 * Set orientation
 */
export declare function setOrientation(orientation: Orientation): void;

/**
 * Set theme
 */
export declare function setTheme(preset: ThemePreset, mode?: ThemeMode): void;

/**
 * Set user info (call this on app init)
 */
export declare function setUserInfo(info: UserInfo): void;

export declare const SummarizeExtension: Extension<SummarizeOptions, any>;

export declare interface SummarizeOptions {
}

/**
 * Translate a key with optional interpolation
 */
export declare function t(key: string, params?: Record<string, string | number>): string;

/**
 * Preferences Adapter
 * Replaces @vben/preferences
 */
declare type Theme = 'light' | 'dark';

/** Export all presets for import */
export declare const THEME_PRESETS: readonly ["default", "notion", "github", "typora", "word"];

/**
 * Editor Configuration Types
 * Pluggable feature system
 */
/** Theme mode */
export declare type ThemeMode = 'light' | 'dark' | 'auto';

/** Theme preset */
export declare type ThemePreset = 'default' | 'notion' | 'typora' | 'word' | 'github' | 'custom';

export declare interface TiptapLocale {
    toolbar: {
        bold: string;
        italic: string;
        underline: string;
        strikethrough: string;
        code: string;
        subscript: string;
        superscript: string;
        clear: string;
        clearFormat: string;
        formatPainter: string;
        heading: string;
        heading1: string;
        heading2: string;
        heading3: string;
        heading4: string;
        heading5: string;
        heading6: string;
        paragraph: string;
        fontFamily: string;
        fontSize: string;
        lineHeight: string;
        textColor: string;
        backgroundColor: string;
        highlightColor: string;
        bulletList: string;
        orderedList: string;
        taskList: string;
        indent: string;
        outdent: string;
        alignLeft: string;
        alignCenter: string;
        alignRight: string;
        alignJustify: string;
        insertLink: string;
        insertImage: string;
        insertTable: string;
        insertCodeBlock: string;
        insertHorizontalRule: string;
        link: string;
        linkUrl: string;
        linkText: string;
        openLink: string;
        editLink: string;
        removeLink: string;
        undo: string;
        redo: string;
        undoDisabledInCollab: string;
        redoDisabledInCollab: string;
        more: string;
    };
    table: {
        insertTable: string;
        deleteTable: string;
        addColumnBefore: string;
        addColumnAfter: string;
        deleteColumn: string;
        addRowBefore: string;
        addRowAfter: string;
        deleteRow: string;
        mergeCells: string;
        splitCell: string;
        toggleHeaderCell: string;
        toggleHeaderColumn: string;
        toggleHeaderRow: string;
        setCellAttribute: string;
        fixTables: string;
    };
    bubbleMenu: {
        turnInto: string;
        textStyle: string;
        color: string;
    };
    dragMenu: {
        delete: string;
        duplicate: string;
        copy: string;
        cut: string;
        moveUp: string;
        moveDown: string;
    };
    codeBlock: {
        language: string;
        selectLanguage: string;
    };
    stats: {
        characters: string;
        words: string;
        pages: string;
        zoom: string;
        reset: string;
        total: string;
    };
    placeholder: {
        default: string;
        heading: string;
        paragraph: string;
    };
    messages: {
        imageUploadFailed: string;
        imageUploadSuccess: string;
        invalidImageFormat: string;
        imageTooLarge: string;
        networkError: string;
        pasteCleanedUp: string;
        linkRequired: string;
        linkInvalid: string;
        translationFailed: string;
        polishFailed: string;
        summarizeFailed: string;
        continueWritingFailed: string;
        customAiFailed: string;
    };
    editor: {
        h1: string;
        h2: string;
        h3: string;
        h4: string;
        h5: string;
        h6: string;
        paragraph: string;
        heading: string;
        heading1: string;
        heading2: string;
        heading3: string;
        heading4: string;
        heading5: string;
        heading6: string;
        bold: string;
        italic: string;
        underline: string;
        strike: string;
        inlineCode: string;
        superscript: string;
        subscript: string;
        bulletList: string;
        orderedList: string;
        taskList: string;
        align: string;
        alignLeft: string;
        alignCenter: string;
        alignRight: string;
        alignJustify: string;
        indent: string;
        outdent: string;
        indentAndAlign: string;
        colors: string;
        text: string;
        highlight: string;
        textColor: string;
        backgroundColor: string;
        defaultColors: string;
        standardColors: string;
        showAdvanced: string;
        hideAdvanced: string;
        clearColor: string;
        actions: string;
        cut: string;
        copy: string;
        delete: string;
        undo: string;
        redo: string;
        undoDisabledInCollab: string;
        redoDisabledInCollab: string;
        clearFormat: string;
        formatPainter: string;
        font: string;
        fontSize: string;
        lineHeight: string;
        insertLink: string;
        insertImage: string;
        insertTable: string;
        image: string;
        link: string;
        editLink: string;
        openLink: string;
        removeLink: string;
        linkPlaceholder: string;
        imagePlaceholder: string;
        deleteTable: string;
        includeHeader: string;
        localUpload: string;
        localUploadImage: string;
        webUpload: string;
        clickOrDragUpload: string;
        onlySupportImage: string;
        more: string;
        aiTool: string;
        ai: string;
        pleaseSelectTextToSample: string;
        pleaseSelectTextToSampleShort: string;
        pleaseSelectTextToSampleDouble: string;
        sampleSuccessSingle: string;
        sampleSuccessContinuous: string;
        formatPainterExited: string;
        collaborationNoFormatPainter: string;
        enterValidLink: string;
        math: string;
        mathInline: string;
        mathBlock: string;
        mathPlaceholder: string;
        mathEmpty: string;
        continueWriting: string;
        polish: string;
        summarize: string;
        translate: string;
        translateTo: string;
        customAi: string;
        selectLanguage: string;
        aiSuggestion: string;
        aiContinueWriting: string;
        originalText: string;
        suggestedText: string;
        generatedContent: string;
        generating: string;
        selectedContent: string;
        currentStatus: string;
        noTextSelected: string;
        pleaseSelectText: string;
        continueWritingRequiresSelection: string;
        polishRequiresSelection: string;
        summarizeRequiresSelection: string;
        translateRequiresSelection: string;
        customAiRequiresSelection: string;
        aiPrompt: string;
        aiPromptPlaceholder: string;
        customAiCommand: string;
        customAiPromptPlaceholder: string;
        execute: string;
        cancel: string;
        reject: string;
        accept: string;
        lang: {
            'zh-CN': string;
            'zh-TW': string;
            zh: string;
            en: string;
            ja: string;
            th: string;
            fr: string;
            es: string;
            pt: string;
            ko: string;
            vi: string;
            ru: string;
            de: string;
            hi: string;
            id: string;
            ar: string;
        };
    };
    versionHistory: {
        title: string;
        saveVersion: string;
        noVersions: string;
        autoSave: string;
        words: string;
        justNow: string;
        minutesAgo: string;
        hoursAgo: string;
        daysAgo: string;
        restore: string;
        compare: string;
        rename: string;
        delete: string;
        comparing: string;
        clearCompare: string;
        versionName: string;
        saved: string;
        restored: string;
        deleted: string;
        noDiff: string;
    };
    aiSettings: {
        title: string;
        provider: string;
        apiKeyPlaceholder: string;
        apiKeyHint: string;
        endpoint: string;
        model: string;
        enableAi: string;
        testConnection: string;
        testing: string;
        testSuccess: string;
        testFailed: string;
        viewDocs: string;
        save: string;
        cancel: string;
        clear: string;
    };
}

export declare const TiptapProEditor: DefineComponent<TiptapProEditorProps, {
getEditor: () => Editor | null;
getJSON: () => DocumentType_2<Record<string, any> | undefined, NodeType<string, Record<string, any> | undefined, any, (NodeType<any, any, any, any> | TextType<MarkType<any, any>>)[]>[]> | null;
getHTML: () => string;
getText: () => string;
}, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {
update: (content: any) => any;
collaboratorsChange: (count: number) => any;
collaboratorsListChange: (users: {
id: string | number;
name: string;
color: string;
}[]) => any;
}, string, PublicProps, Readonly<TiptapProEditorProps> & Readonly<{
onUpdate?: ((content: any) => any) | undefined;
onCollaboratorsChange?: ((count: number) => any) | undefined;
onCollaboratorsListChange?: ((users: {
id: string | number;
name: string;
color: string;
}[]) => any) | undefined;
}>, {
readonly: boolean;
version: EditorVersion;
initialContent: string | object;
zoomBarPlacement: "bottom" | "belowToolbar";
previewMode: boolean;
}, {}, {}, {}, string, ComponentProvideOptions, false, {}, any>;

/**
 * 编辑器暴露的方法
 */
export declare interface TiptapProEditorExpose {
    getEditor: () => Editor | null;
    getJSON: () => JSONContent | null;
    getHTML: () => string;
    getText: () => string;
}

/**
 * 编辑器 Props
 */
export declare interface TiptapProEditorProps {
    /** 版本配置 */
    version?: EditorVersion;
    /** 版本配置对象（与 version 二选一） */
    versionConfig?: VersionConfig;
    /** 缩放条位置：底部固定或工具栏下方 */
    zoomBarPlacement?: 'bottom' | 'belowToolbar';
    /** 是否为只读模式 */
    readonly?: boolean;
    /** 是否为预览模式（无头部/底部导航，不可编辑，不可点击） */
    previewMode?: boolean;
    /** 文档ID(用于加载和保存以及协同房间) */
    documentId?: string;
    /** 初始内容 - 可以是 HTML 字符串或 JSON 对象（ProseMirror 格式） */
    initialContent?: string | object;
    /** 表格悬浮框显示模式：1=聚焦显示；2=单元格选中显示 */
    tableMenuShowMode?: 1 | 2;
    /** 功能配置（兼容旧版） */
    features?: FeatureConfig;
    /** 语言设置 */
    locale?: string;
}

/**
 * Toggle between light and dark mode
 */
export declare function toggleThemeMode(): ThemeMode;

export declare const TranslationExtension: Extension<TranslationOptions, any>;

export declare interface TranslationOptions {
    defaultTargetLang?: string;
}

export declare function useAi(options: UseAiOptions): UseAiReturn;

/**
 * useAiConfig Composable
 */
export declare function useAiConfig(): {
    config: Readonly<Ref<    {
    readonly provider: AiProvider;
    readonly apiKey: string;
    readonly endpoint?: string | undefined;
    readonly model: string;
    readonly timeout: number;
    readonly enabled: boolean;
    readonly updatedAt: number;
    } | null, {
    readonly provider: AiProvider;
    readonly apiKey: string;
    readonly endpoint?: string | undefined;
    readonly model: string;
    readonly timeout: number;
    readonly enabled: boolean;
    readonly updatedAt: number;
    } | null>>;
    isConfigured: Readonly<Ref<boolean, boolean>>;
    isEnabled: Readonly<Ref<boolean, boolean>>;
    currentProvider: Readonly<Ref<AiProvider, AiProvider>>;
    currentProviderInfo: Readonly<Ref<    {
    readonly id: AiProvider;
    readonly name: string;
    readonly description: string;
    readonly defaultEndpoint: string;
    readonly defaultModel: string;
    readonly requiresApiKey: boolean;
    readonly docsUrl?: string | undefined;
    } | undefined, {
    readonly id: AiProvider;
    readonly name: string;
    readonly description: string;
    readonly defaultEndpoint: string;
    readonly defaultModel: string;
    readonly requiresApiKey: boolean;
    readonly docsUrl?: string | undefined;
    } | undefined>>;
    testStatus: Readonly<Ref<"error" | "idle" | "testing" | "success", "error" | "idle" | "testing" | "success">>;
    testError: Readonly<Ref<string | null, string | null>>;
    providers: AiProviderInfo[];
    saveConfig: (newConfig: AiUserConfig) => void;
    updateConfig: (partial: Partial<AiUserConfig>) => void;
    setProvider: (provider: AiProvider) => void;
    testConnection: () => Promise<ConnectionTestResult>;
    clearConfig: () => void;
    getRequestConfig: () => {
        endpoint: string;
        apiKey: string;
        model: string;
        timeout: number;
    } | null;
};

export declare interface UseAiOptions {
    adapter: AiAdapter;
    onError?: (error: Error) => void;
}

export declare interface UseAiReturn {
    isLoading: Readonly<ReturnType<typeof readonly<ReturnType<typeof ref<boolean>>>>>;
    result: Readonly<ReturnType<typeof readonly<ReturnType<typeof ref<string>>>>>;
    error: Readonly<ReturnType<typeof readonly<ReturnType<typeof ref<Error | null>>>>>;
    continueWriting: (text: string) => Promise<string>;
    polish: (text: string) => Promise<string>;
    summarize: (text: string) => Promise<string>;
    translate: (text: string, targetLang: string) => Promise<string>;
    customAi: (text: string, instruction: string) => Promise<string>;
    continueWritingStream: (text: string, callbacks: AiStreamCallbacks) => Promise<void>;
    polishStream: (text: string, callbacks: AiStreamCallbacks) => Promise<void>;
    summarizeStream: (text: string, callbacks: AiStreamCallbacks) => Promise<void>;
    translateStream: (text: string, targetLang: string, callbacks: AiStreamCallbacks) => Promise<void>;
    customAiStream: (text: string, instruction: string, callbacks: AiStreamCallbacks) => Promise<void>;
    abort: () => void;
}

/**
 * Use i18n composable
 */
export declare function useI18n(): {
    t: typeof t;
    locale: ComputedRef<LocaleCode>;
    setLocale: (locale: LocaleCode) => void;
    availableLocales: LocaleCode[];
};

/**
 * Use preferences (compatible with @vben/preferences)
 */
export declare function usePreferences(): {
    theme: Readonly<Ref<Theme, Theme>>;
    isDark: Readonly<Ref<boolean, boolean>>;
    setTheme: (t: Theme) => void;
    toggleTheme: () => void;
};

/**
 * User Adapter
 * Replaces @vben/stores useUserStore
 */
export declare interface UserInfo {
    userId: string | number;
    realName: string;
    userName: string;
    avatar?: string;
}

/**
 * Get user store (compatible with @vben/stores)
 */
export declare function useUserStore(): {
    userInfo: {
        readonly userId: string | number;
        readonly realName: string;
        readonly userName: string;
        readonly avatar?: string | undefined;
    } | null;
    setUserInfo: typeof setUserInfo;
    getUserInfo: () => {
        userId: string | number;
        realName: string;
        userName: string;
        avatar?: string | undefined;
    } | null;
};

/**
 * 版本配置接口
 */
export declare interface VersionConfig {
    /** 版本类型（基础版/进阶版/高级版） */
    version?: EditorVersion;
    /** 功能开关配置 */
    features?: {
        /** 基础版功能 */
        basic?: boolean;
        /** 进阶版功能 */
        advanced?: boolean;
        /** AI功能 */
        ai?: boolean;
        /** 协作编辑 */
        collaboration?: boolean;
        /** 头部导航 */
        headerNav?: boolean;
        /** 底部导航 */
        footerNav?: boolean;
        /** 预览模式 */
        previewMode?: boolean;
    };
}

/**
 * Watch system theme changes
 */
export declare function watchSystemTheme(callback: (mode: 'light' | 'dark') => void): () => void;

export declare const zhCN: TiptapLocale;

export declare const zhTW: TiptapLocale;

export { }


declare module '@tiptap/core' {
    interface Commands<ReturnType> {
        customAi: {
            /**
             * Trigger custom AI command
             */
            customAi: () => ReturnType;
        };
    }
}


declare module '@tiptap/core' {
    interface Commands<ReturnType> {
        translation: {
            translate: (targetLang?: string) => ReturnType;
        };
    }
}


declare module '@tiptap/core' {
    interface Commands<ReturnType> {
        aiHighlight: {
            /**
             * Set AI highlight mark with suggestion data
             */
            setAiHighlight: (data?: AiSuggestionData) => ReturnType;
            /**
             * Unset AI highlight mark
             */
            unsetAiHighlight: () => ReturnType;
        };
    }
}


declare module '@tiptap/core' {
    interface Commands<ReturnType> {
        polish: {
            /**
             * Trigger AI polish (refine) text
             */
            polish: () => ReturnType;
        };
    }
}


declare module '@tiptap/core' {
    interface Commands<ReturnType> {
        summarize: {
            summarize: () => ReturnType;
        };
    }
}


declare module '@tiptap/core' {
    interface Commands<ReturnType> {
        continueWriting: {
            /**
             * Trigger AI continue writing
             */
            continueWriting: () => ReturnType;
        };
    }
}


declare module '@tiptap/core' {
    interface Commands<ReturnType> {
        math: {
            /** 插入行内公式 */
            insertInlineMath: (latex?: string) => ReturnType;
            /** 插入块级公式 */
            insertBlockMath: (latex?: string) => ReturnType;
            /** 更新公式内容 */
            updateMath: (latex: string) => ReturnType;
        };
    }
}


declare module '@tiptap/core' {
    interface Commands<ReturnType> {
        formatPainter: {
            /**
             * 开启格式刷并采样当前选区样式
             * @param mode - 模式：1 为单次模式（默认），2 为连续模式
             */
            startFormatPainting: (mode?: 1 | 2) => ReturnType;
            /** 开启格式刷连续应用模式 */
            startContinuousFormatPainting: () => ReturnType;
            /** 将采样到的样式应用到当前选区 */
            applyFormat: () => ReturnType;
            /** 取消格式刷状态并清除缓存 */
            cancelFormatPainting: () => ReturnType;
            /** 切换连续应用模式 */
            toggleContinuousMode: () => ReturnType;
        };
    }
}
