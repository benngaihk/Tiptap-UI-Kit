/**
 * Configs Entry
 */
export * from './editorConstants';
//# sourceMappingURL=index.d.ts.map