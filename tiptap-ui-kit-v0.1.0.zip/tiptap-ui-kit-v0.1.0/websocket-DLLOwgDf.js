const __vite_import_meta_env__ = {};
function getWebSocketUrl(documentId) {
  const baseUrl = __vite_import_meta_env__?.VITE_COLLABORATION_WS_URL;
  if (!baseUrl) {
    console.warn("[Tiptap] VITE_COLLABORATION_WS_URL not configured");
    return "";
  }
  return `${baseUrl}/${documentId}`;
}
export {
  getWebSocketUrl
};
