/**
 * Continue Writing Feature
 * @description AI-powered text continuation based on selection
 */
export { ContinueWritingExtension } from './ContinueWritingExtension';
export type { ContinueWritingOptions } from './ContinueWritingExtension';
//# sourceMappingURL=index.d.ts.map