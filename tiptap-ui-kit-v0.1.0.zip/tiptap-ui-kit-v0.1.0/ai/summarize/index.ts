/**
 * Summarize Feature
 * @description AI-powered content summarization
 */

export { SummarizeExtension } from './SummarizeExtension';
export type { SummarizeOptions } from './SummarizeExtension';

