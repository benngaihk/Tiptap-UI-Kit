"use strict";Object.defineProperty(exports,Symbol.toStringTag,{value:"Module"});const t={};exports.getWebSocketUrl=function(e){const o=t?.VITE_COLLABORATION_WS_URL;return o?`${o}/${e}`:""};
