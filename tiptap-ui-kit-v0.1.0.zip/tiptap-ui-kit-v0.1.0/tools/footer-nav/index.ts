/**
 * Footer Nav - 底部导航工具栏
 * @description 底部导航栏组件，集成缩放控制、页数统计和字数统计功能
 */

// 组件导出
export { default as FooterNav } from './FooterNav.vue'

