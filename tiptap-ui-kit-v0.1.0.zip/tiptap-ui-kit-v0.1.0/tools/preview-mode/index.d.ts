/**
 * Preview Mode - 预览模式模块
 * @description 提供纯预览功能，无工具栏，不可编辑，不可点击
 */
export { default as PreviewMode } from './PreviewMode.vue';
//# sourceMappingURL=index.d.ts.map