import type { Editor } from '@tiptap/vue-3';
type __VLS_Props = {
    editor: Editor | null | undefined;
    readonly?: boolean;
    enabled?: boolean;
};
declare const _default: import("vue").DefineComponent<__VLS_Props, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<__VLS_Props> & Readonly<{}>, {
    readonly: boolean;
    enabled: boolean;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
export default _default;
//# sourceMappingURL=ImageToolbar.vue.d.ts.map