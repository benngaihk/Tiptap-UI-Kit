/**
 * Image Toolbar - 图片工具栏模块
 * @description 提供图片对齐、预览、删除等功能的气泡菜单工具栏
 */
export { default as ImageToolbar } from './ImageToolbar.vue';
//# sourceMappingURL=index.d.ts.map