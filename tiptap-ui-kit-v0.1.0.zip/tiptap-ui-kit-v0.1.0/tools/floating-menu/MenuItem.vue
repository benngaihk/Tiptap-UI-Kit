<template>
  <div>
    <!-- 菜单项组件 -->
  </div>
</template>

<script setup lang="ts">
// 占位组件
</script>

