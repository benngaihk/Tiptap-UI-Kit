/**
 * Floating Menu Feature Module
 * @description 悬浮框功能模块统一导出
 */
export { default as FloatingMenu } from './FloatingMenu.vue';
export { default as MenuItem } from './MenuItem.vue';
//# sourceMappingURL=index.d.ts.map