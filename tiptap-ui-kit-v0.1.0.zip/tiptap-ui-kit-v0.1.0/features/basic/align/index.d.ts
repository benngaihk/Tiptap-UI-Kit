/**
 * Align Components - 对齐组件统一导出
 */
export { default as AlignDropdown } from './AlignDropdown.vue';
export type { AlignValue } from '@/configs/toolbar';
//# sourceMappingURL=index.d.ts.map