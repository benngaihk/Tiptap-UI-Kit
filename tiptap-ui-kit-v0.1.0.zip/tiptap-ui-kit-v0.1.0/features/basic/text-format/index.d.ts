/**
 * Text Format Components - 文本格式组件统一导出
 */
export { default as TextFormatButtons } from './TextFormatButtons.vue';
export type { TextFormatType, TextFormatConfig } from '@/configs/toolbar';
//# sourceMappingURL=index.d.ts.map