/**
 * Color Components - 颜色组件统一导出
 */
export { default as ColorPicker } from './ColorPicker.vue';
//# sourceMappingURL=index.d.ts.map