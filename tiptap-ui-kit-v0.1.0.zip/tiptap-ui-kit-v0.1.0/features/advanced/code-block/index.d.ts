/**
 * Code Block - 代码块功能模块
 * @description 提供代码块插入功能（点击直接插入，使用默认语言）
 */
export { default as CodeBlockDropdown } from './CodeBlockDropdown.vue';
//# sourceMappingURL=index.d.ts.map