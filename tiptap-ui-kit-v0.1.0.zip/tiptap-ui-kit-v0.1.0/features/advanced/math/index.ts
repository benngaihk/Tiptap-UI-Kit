/**
 * Math Feature
 */
export { default as MathButton } from './MathButton.vue'
