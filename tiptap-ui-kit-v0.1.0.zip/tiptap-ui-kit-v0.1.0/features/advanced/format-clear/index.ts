/**
 * Format Clear - 格式清除功能模块
 * @description 提供清除格式功能
 */

// 组件导出
export { default as ClearFormatButton } from './ClearFormatButton.vue'

