/**
 * Format Clear - 格式清除功能模块
 * @description 提供清除格式功能
 */
export { default as ClearFormatButton } from './ClearFormatButton.vue';
//# sourceMappingURL=index.d.ts.map