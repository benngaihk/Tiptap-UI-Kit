/**
 * Undo Redo - 撤销/重做功能模块
 * @description 提供撤销和重做工具栏按钮功能
 */
export { default as UndoRedoButton } from './UndoRedoButton.vue';
//# sourceMappingURL=index.d.ts.map