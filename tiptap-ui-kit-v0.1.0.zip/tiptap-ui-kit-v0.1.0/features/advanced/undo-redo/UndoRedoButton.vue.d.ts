import type { Editor } from '@tiptap/vue-3';
interface Props {
    editor: Editor | null | undefined;
    /** 是否禁用按钮（协作模式下需要禁用） */
    disabled?: boolean;
}
declare const _default: import("vue").DefineComponent<Props, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<Props> & Readonly<{}>, {
    disabled: boolean;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
export default _default;
//# sourceMappingURL=UndoRedoButton.vue.d.ts.map