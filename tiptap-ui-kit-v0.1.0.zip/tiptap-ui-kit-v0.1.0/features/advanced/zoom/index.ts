/**
 * Zoom - 缩放功能模块
 * @description 提供文档缩放、页数统计和字数统计功能
 */

// 组件导出
export { default as ZoomBar } from './ZoomBar.vue'

