/**
 * Subscript Superscript - 上标下标功能模块
 * @description 提供上标和下标工具栏按钮功能
 */

// 组件导出
export { default as SubscriptSuperscriptButton } from './SubscriptSuperscriptButton.vue'

