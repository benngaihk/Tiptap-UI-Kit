/**
 * FontSize Extension - 字号扩展
 * @description 自定义字号扩展
 */
import { Extension } from '@tiptap/core';
/**
 * FontSize 扩展
 */
export declare const FontSize: Extension<any, any>;
//# sourceMappingURL=fontSize.d.ts.map