/**
 * PasteWord Extension - 粘贴 Word 文档扩展
 * @description 支持粘贴 Word 文档内容
 */
import { Extension } from '@tiptap/core';
export declare const PasteWord: Extension<any, any>;
//# sourceMappingURL=pasteWord.d.ts.map