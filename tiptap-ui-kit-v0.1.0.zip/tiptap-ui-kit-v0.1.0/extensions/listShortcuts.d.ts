/**
 * ListShortcuts Extension - 列表快捷键扩展
 * @description 提供列表相关的快捷键支持
 */
import { Extension } from '@tiptap/core';
export declare const ListShortcuts: Extension<any, any>;
//# sourceMappingURL=listShortcuts.d.ts.map