/**
 * Format Painter Extension
 * TODO: Copy from source and decouple
 */

import { Extension } from '@tiptap/core'

export const FormatPainter = Extension.create({
  name: 'formatPainter',
  // TODO: Implement format painter logic
})
