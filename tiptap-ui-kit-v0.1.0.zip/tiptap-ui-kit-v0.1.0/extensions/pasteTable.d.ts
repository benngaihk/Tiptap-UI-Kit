/**
 * Paste Table Extension
 * Cleans up pasted content from Excel
 * TODO: Copy from source and decouple
 */
import { Extension } from '@tiptap/core';
export declare const PasteTable: Extension<any, any>;
//# sourceMappingURL=pasteTable.d.ts.map