/**
 * PasteImage Extension - 粘贴图片扩展
 * @description 支持粘贴图片功能
 */
import { Extension } from '@tiptap/core';
export declare const PasteImage: Extension<any, any>;
//# sourceMappingURL=pasteImage.d.ts.map