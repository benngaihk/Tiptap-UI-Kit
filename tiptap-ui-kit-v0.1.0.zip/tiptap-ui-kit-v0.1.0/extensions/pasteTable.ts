/**
 * Paste Table Extension
 * Cleans up pasted content from Excel
 * TODO: Copy from source and decouple
 */

import { Extension } from '@tiptap/core'

export const PasteTable = Extension.create({
  name: 'pasteTable',
  // TODO: Implement paste handler with table content cleanup
})
