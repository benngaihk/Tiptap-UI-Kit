/**
 * Locales Entry
 */

export * from './manager'
export type { TiptapLocale } from './types'
export { zhCN } from './zh-CN'
export { zhTW } from './zh-TW'
export { enUS } from './en-US'
